/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.component.wx.job;

import java.util.Arrays;

import com.saic.framework.redis.client.IRedisClient;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.component.wx.Constants;
import com.saic.ebiz.component.wx.entity.Token;
import com.saic.ebiz.component.wx.util.CommonUtil;

/**
 * @author hejian
 * @deprecated
 * @see TicketThread
 */
public class AccessTokenThread extends CommonOperation {
	
	private IRedisClient redisClient;
	
	public AccessTokenThread(String appId,String appSecret) {
		this.appId = appId;
		this.appSecret = appSecret;
	}
	
	public AccessTokenThread(String appId,String appSecret,IRedisClient redisClient) {
		this.appId = appId;
		this.appSecret = appSecret;
		this.redisClient = redisClient;
	}
	
	/**
	 * 根据AccessToken: + this.appId检查有效期
	 * 有效期小于20分钟，去请求更新token
	 * 集群环境为了防止jvm请求多次更新token，against redis的feature设置分布式同步锁
	 * 单次锁有效期2分钟，过期之后，释放锁
	 * 如果请求超过2分钟仍然返回，丢弃该次请求
	 * 
	 * @param jedis
	 * @throws InterruptedException
	 */
//	void getOrUpdateAccessToken() throws InterruptedException{
//		//获取AccessToken的获取时间
//		long ttlTime = redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE);
//		logger.info("appId : {}'s access token ttl : {}", this.appId, ttlTime);
//		//ttlTime = -2 未找到 , ttlTime = -1 永不过期
//		if(ttlTime < 0 || ttlTime < Constants.BEFORE_EXPIRY_20_MINUTES){
//			logger.info("AccessToken:Lock: 过期时间 ttl :" + redisClient.ttl(getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK),Constants.REDIS_NAME_SPACE));
//			//如果线程未执行expiry操作，key永远存在
//			if(redisClient.exists(getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK),Constants.REDIS_NAME_SPACE)){
//				//ttl == -1
//				if(redisClient.ttl(getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK),Constants.REDIS_NAME_SPACE) == -1){
//					logger.info("redis 存在永不过期的key : " + getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK) + " 并删除");
//					redisClient.del(getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK),Constants.REDIS_NAME_SPACE);
//				}
//			}
//			//集群环境下需要设置分布式锁，只去获取一次即可
//			long lockFlag = redisClient.setnx(getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK),Constants.REDIS_NAME_SPACE, Constants.REDIS_CACHE_VALUE);
//			//如果返回1，说明设置成功，获得锁
//			if(lockFlag == 1){
//				syncToken();
//			} else{
//				logger.warn(this.getName() + "抢锁失败，等待重试!!!");
//				Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//			}
//		}else{
//			Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//		}
//	}
//	
//	private void syncToken(){
//		String timeoutKey = getRedisCacheKey(Constants.PREFIX_TOKEN_TIMEOUT) + System.currentTimeMillis();
//		String tokenKey = getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK);
//		//设置超时标记2分钟
//		redisClient.setex(timeoutKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT, Constants.REDIS_CACHE_VALUE);
//		//设置超时时间
//		redisClient.expire(timeoutKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT);
//		//设置同步锁2分钟，如果超时，自动放弃锁，让其他线程可以获取锁
//		redisClient.setex(tokenKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT, Constants.REDIS_CACHE_VALUE);
//		//设置超时时间
//		redisClient.expire(tokenKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT);
//		Token token = CommonUtil.getAccessToken(this.appId, this.appSecret);
//		logger.info("获取Token : " + JSONObject.toJSONString(token));
//		if(token == null){
//			logger.error("Token获取异常");
//		}else{
//			//请求未超时则放入redis
//			if(redisClient.ttl(timeoutKey,Constants.REDIS_NAME_SPACE) > 0){
//				//cache WeChat token
//				logger.info("获取token未超时，放入redis当中");
//				redisClient.setex(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE, token.getExpiresIn(), token.getToken());
//				redisClient.expire(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE, token.getExpiresIn());
//			}else{
//				//超时则放弃，并返回，不需要clearLockFlag.因为已经超时，key已经不存在，否则会把其他的线程的key清除了
//				logger.error("获取token 超时 ");
//				return;
//				/*if(ttlTime < 0){
//					//redis乐观锁
//					jedis.watch(TOKEN_LOCK);
//					String oldValue = jedis.get(TOKEN_LOCK);
//					//设置完后与第一次得到的值不同，说明其他线程修改过。
//					if(oldValue.equals(jedis.getSet(TOKEN_LOCK, oldValue + "NEW"))){
//						getToken(jedis,times);
//					}
//                    Transaction t = jedis.multi();
//                    jedis.set(TOKEN_LOCK, oldValue + "NEW");
//                    if (t.exec() != null) {
//                    	getToken(jedis,times);
//                    }
//					//释放锁
//					jedis.unwatch();
//				}*/
//			}
//		}
//		clearLockFlag(redisClient,Arrays.asList(timeoutKey,tokenKey));
//	}
//	
//	private void synchnorizeAccessToken() throws InterruptedException{
//		//获取AccessToken的获取时间
//		long tokenTtlTime = redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE);
//		logger.info("appId : {}'s access token ttl : {}", this.appId, tokenTtlTime);
//		String token_lock = getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK);
//		//ttl -1 未找到或者永不过期
//		if(tokenTtlTime < 0 || tokenTtlTime < Constants.BEFORE_EXPIRY_20_MINUTES){
//			//获取分布式锁的key,并判断过期时间
//			logger.info("AccessToken_Lock 分布式锁过期时间  : " + redisClient.ttl(token_lock,Constants.REDIS_NAME_SPACE));
//			//如果线程未执行expire操作，key永远存在
//			if(redisClient.exists(token_lock,Constants.REDIS_NAME_SPACE)){
//				//ttl == -1
//				if(redisClient.ttl(token_lock,Constants.REDIS_NAME_SPACE) == -1){
//					long result = redisClient.del(getRedisCacheKey(Constants.PREFIX_TOKEN_LOCK),Constants.REDIS_NAME_SPACE);
//					logger.info("redis 存在永不过期的key : " + token_lock + "并删除" + (result > 0 ? "成功" : "失败"));
//				}
//			}
//			//集群环境下需要设置分布式锁，只去获取一次即可
//			long lockFlag = redisClient.setnx(token_lock,Constants.REDIS_NAME_SPACE, Constants.REDIS_CACHE_VALUE);
//			logger.info(appId + ": token flag : " + lockFlag);
//			//如果返回1，说明设置成功，获得锁
//			if(lockFlag == 1){
//				logger.warn(this.getName() + "抢锁成功!!!进行Token更新操作");
//				String timeoutKey = getRedisCacheKey(Constants.PREFIX_TOKEN_TIMEOUT) + System.currentTimeMillis();
//				//设置超时标记2分钟
//				redisClient.setex(timeoutKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT, Constants.REDIS_CACHE_VALUE);
//				//设置超时时间
////				redisClient.expire(timeoutKey, Constants.LOCK_TIMEOUT);
//				//设置同步锁2分钟，如果超时，自动放弃锁，让其他线程可以获取锁
//				redisClient.setex(token_lock,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT, Constants.REDIS_CACHE_VALUE);
//				//设置超时时间
////				redisClient.expire(token_lock, Constants.LOCK_TIMEOUT);
//				Token token = CommonUtil.getAccessToken(this.appId, this.appSecret);
//				logger.info("获取Token : " + JSONObject.toJSONString(token));
//				long timeout = redisClient.ttl(timeoutKey,Constants.REDIS_NAME_SPACE);
//				logger.info("获取token有效期两分钟，剩余时间 {} 秒", timeout);
//				if(token == null){
//					if(timeout > 0){
//						logger.info("删除超时时间标志 {} {} ",timeoutKey ,(redisClient.del(timeoutKey,Constants.REDIS_NAME_SPACE) > 0 ? "success" : "failure"));
//						logger.info("删除分布式锁标志 {} {} ",token_lock ,(redisClient.del(token_lock,Constants.REDIS_NAME_SPACE) > 0 ? "success" : "failure"));
//					}
//					logger.error("Token获取异常  睡眠一分钟 ");
//					//睡眠一分钟，防止超过访问微信服务器次数限制
//					Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//				} else {
//					//请求未超时则放入redis
//					if(timeout > 0){
//						//cache WeChat token
//						logger.info("获取token未超时，放入redis当中");
//						//判断ttl是否大于1200秒，大于则不放置
//						if(redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE) < Constants.BEFORE_EXPIRY_20_MINUTES){
//							logger.info("其他线程未更新Token进行更新");
//							redisClient.setex(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE,token.getExpiresIn() , token.getToken());
////							redisClient.expire(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN), token.getExpiresIn());
//						} else{
//							logger.error("其他线程已更新Token，放弃这次更新");
//						}
//					}else{
//						//超时则放弃，并返回，不需要clearLockFlag.因为已经超时，key已经不存在，否则会把其他的线程的key清除了
//						logger.error("获取token超时 ");
//						return;
//					}
//				}
//			} else{
//				logger.warn(this.getName() + "抢锁失败，等待重试!!!");
//				Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//			}
//		}else{
//			logger.info("Redis Access Token缓存有效, 睡眠一分钟 ");
//			Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//		}
//	}

	@Override
	public void run() {
//		while (flag) {
//			try {
////				getOrUpdateAccessToken();
//				synchnorizeAccessToken();
//			} catch (InterruptedException e) {
//				logger.error(e.getMessage());
//			}
//		}
	}
}


