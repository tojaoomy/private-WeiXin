/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.component.wx.job;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.saic.ebiz.component.wx.Constants;
import com.saic.framework.redis.client.IRedisClient;

/**
 * @author hejian
 *
 */
public abstract class CommonOperation extends Thread{

	protected Logger logger = LoggerFactory.getLogger(getClass());
	protected volatile boolean flag = true;
	protected String appId;
	protected String appSecret;

	/**
	 * 
	 */
	public CommonOperation() {
		super();
	}

	public void terminalThread() {
		this.flag = false;
	}

	/** 根据appid获取rediskey */
	protected String getRedisCacheKey(String prefixKey) {
		return prefixKey + this.appId;
	}

	protected void clearLockFlag(IRedisClient redisClient, List<String> keys) {
//		redisClient.del(keys.toArray(new String[0]));
		for(String key : keys){
			redisClient.del(key,Constants.REDIS_NAME_SPACE);
		}
	}

}