/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.component.wx.job;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.saic.framework.redis.client.IRedisClient;
import com.saic.ebiz.component.wx.Constants;
import com.saic.ebiz.component.wx.util.AppIdSecretHelper;

/**
 * @author hejian
 * 
 */
@Component
public class TicketJob implements InitializingBean, DisposableBean {
	
private Logger logger = LoggerFactory.getLogger(getClass());
	
	private List<CommonOperation> threads = new ArrayList<CommonOperation>();

	/**缓存接口.*/
    @Resource(name="springRedisClient")
    private IRedisClient springRedisClient;
	
	@Autowired
	private AppIdSecretHelper appIdSecretHelper;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 bdf9bedfd1e36dc2797cddc02847cb88
	 * 测试账号        04a4ea410735b9a134d41ed29ce64699
	 * 
	 */
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
	
	private TicketThread ticketThread;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.beans.factory.DisposableBean#destroy()
	 */
	@Override
	public void destroy() throws Exception {
		for(CommonOperation thread : threads){
			if(thread.isAlive()){
				thread.terminalThread();
				logger.info(thread.getName() + " be terminaled!!!");
			}else{
				logger.info(thread.getName() + " is already terminal!!!");
			}
		}
		logger.info("threads all have stoped!!!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() throws Exception {

		ticketThread = new TicketThread(appId, appSecret,springRedisClient);
		ticketThread.setName("Ticket线程 : " + appId);
		ticketThread.start();
		logger.info(ticketThread.getName() + " 启动成功!!!");
		threads.add(ticketThread);
	}
	
	public String getToken() {
        return ticketThread.getToken();
	}
	
	public String getTicket() {
	    return ticketThread.getTicket();
	}
}
