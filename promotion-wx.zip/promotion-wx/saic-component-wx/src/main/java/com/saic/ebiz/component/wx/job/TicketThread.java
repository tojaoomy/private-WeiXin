/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.component.wx.job;

import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;

import com.saic.framework.redis.client.IRedisClient;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.component.wx.Constants;
import com.saic.ebiz.component.wx.entity.JsapiTicket;
import com.saic.ebiz.component.wx.entity.Token;
import com.saic.ebiz.component.wx.util.CommonUtil;

/**
 * @author hejian
 * 
 */
public class TicketThread extends CommonOperation {

	private IRedisClient redisClient;
	

	public TicketThread(String appId, String appSecret) {
		this.appId = appId;
		this.appSecret = appSecret;
	}

	public TicketThread(String appId, String appSecret, IRedisClient redisClient) {
		this.appId = appId;
		this.appSecret = appSecret;
		this.redisClient = redisClient;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Thread#run()
	 */
	@Override
	public void run() {
		while (flag) {
			try {
			    logger.info("TicketThread job running....");
			    syncTokenAndTicket();
			    
			    Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
			} catch (Exception e) {
				logger.error("TicketThread exception:",e.fillInStackTrace());
			}
		}
	}
	
	
	public void syncTokenAndTicket() {
        logger.info("syncTokenAndTicket start............");
        
        //1 从缓存中判断token和ticket是否都存在
        String nameSpace = Constants.REDIS_NAME_SPACE;
        String tokenKey = getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN);
        String ticketKey = getRedisCacheKey(Constants.PREFIX_REDIS_TICKET);
        String lockKey =  getRedisCacheKey(Constants.PREFIX_TOKEN_TICKET_LOCK);
        String lockValue = Constants.TOKEN_TICKET_LOCK_VALUE;
        
        //异常情况，token或ticket先于lock失效
        if(redisClient.ttl(tokenKey, nameSpace) <=0 || redisClient.ttl(ticketKey, nameSpace) <=0) {
            redisClient.del(lockKey, nameSpace);
            logger.info("syncTokenAndTicket 异常情况，token或ticket先于lock失效");
        }
        
        Long lockTtl = redisClient.ttl(lockKey, nameSpace);
        logger.info("syncTokenAndTicket lockTtl:{} .....", lockTtl);
        
        //2 任何一个不存在，就发起一次请求, 并放入redis
        if(lockTtl <=0) {

            Long lockFlag = redisClient.setnx(lockKey, nameSpace, lockValue);
            logger.info("syncTokenAndTicket lockFlag :{}", lockFlag);
            
            //当前线程锁定成功
            if(lockFlag != null && lockFlag == 1) {
                Token token = CommonUtil.getAccessToken(appId, appSecret);      
                JsapiTicket jsapiTicket = CommonUtil.getJsapiTicket(token);
            
                logger.info("syncTokenAndTicket token:{}, jsapiTicket:{}", token, jsapiTicket);
                
                //同时获取token和ticket成功
                if(token != null && jsapiTicket != null) {
                    redisClient.expire(lockKey, nameSpace, Constants.REDIS_EXPIRE_ONE_HOUR);
                    
                    redisClient.setex(tokenKey, nameSpace, Constants.REDIS_EXPIRE_ONE_AND_HALF_HOUR, token.getToken());
                    redisClient.setex(ticketKey, nameSpace, Constants.REDIS_EXPIRE_ONE_AND_HALF_HOUR, jsapiTicket.getTicket());
                }
            }
        }
        
        logger.info("syncTokenAndTicket end..............");
    }

	public String getToken() {
	    String nameSpace = Constants.REDIS_NAME_SPACE;
        String tokenKey = getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN);
        
        String token = redisClient.get(tokenKey, nameSpace, null);
        if(StringUtils.isBlank(token)) {
            syncTokenAndTicket();
            
            token = redisClient.get(tokenKey, nameSpace, null);
        }
        
        return token;
	}
	
	public String getTicket() {
	    String nameSpace = Constants.REDIS_NAME_SPACE;
        String ticketKey = getRedisCacheKey(Constants.PREFIX_REDIS_TICKET);
        
        String ticket = redisClient.get(ticketKey, nameSpace, null);
        if(StringUtils.isBlank(ticket)) {
            syncTokenAndTicket();
            
            ticket = redisClient.get(ticketKey, nameSpace, null);
        }
        
        return ticket;
	}
	
//	private void synchronizeTicket() throws InterruptedException{
//		long ticketTtlTime = redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_TICKET),Constants.REDIS_NAME_SPACE);
//		logger.info(appId + ":ticket exipry time : " + ticketTtlTime);
//		String ticketLock = getRedisCacheKey(Constants.PREFIX_TICKET_LOCK);
//		// ttlTime = -2 未找到 -1 永不过期
//		if (ticketTtlTime < 0 || ticketTtlTime < Constants.BEFORE_EXPIRY_20_MINUTES) {
//			//获取分布式锁的key,并判断过期时间
//			logger.info("Ticket_Lock 分布式锁过期时间  : " + redisClient.ttl(ticketLock,Constants.REDIS_NAME_SPACE));
//			//如果线程未执行expire操作，key永远存在
//			if(redisClient.exists(ticketLock,Constants.REDIS_NAME_SPACE)){
//				//存在永不过期的key，redis是同步的，不用担心并发问题
//				if(redisClient.ttl(ticketLock,Constants.REDIS_NAME_SPACE) == -1){
//					long result = redisClient.del(ticketLock,Constants.REDIS_NAME_SPACE);
//					logger.info("redis 存在永不过期的key : " + ticketLock + "并删除" + (result > 0 ? "成功" : "失败"));
//				}
//			}
//			// 集群环境下需要设置分布式锁，只去获取一次即可
//			long lockFlag = redisClient.setnx(getRedisCacheKey(Constants.PREFIX_TICKET_LOCK),Constants.REDIS_NAME_SPACE,
//					Constants.REDIS_CACHE_VALUE);
//			logger.info(appId + ":ticket flag : " + lockFlag);
//			// 如果返回1，说明设置成功，获得锁
//			if (lockFlag == 1) {
//				logger.warn(this.getName() + "抢锁成功!!!进行Ticket更新操作");
//				Token token = new Token();
//				// 获取ticket首先需要token，如果没有则自己获取token
//				String redisToken = "";
//				//最多获取5次。
//				int account = 0;
//				do{
//					//判断token的有效期必须大于1200 + 300秒，防止Token线程去更新Token后，此次获取的token无效
//					if(redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE) < (Constants.BEFORE_EXPIRY_20_MINUTES + 300)){
//						//休眠一分钟
//						Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//						continue;
//					}
//					redisToken = redisClient.get(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE,null);
//					if(redisToken == null || redisToken.length() == 0){
//						logger.warn("redis未获取正确的access_token,重新获取Token");
//						Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//						//请求3次都异常，退出循环
//						if(++account > 3 ){
//							logger.info("从redis获取access_token 次数 ： " + account);
//							break;
//						}
//					}else{
//						logger.info("redis获取正确的access_token");
//						break;
//					}
//				} while(true);
//				
//				if (redisToken == null || redisToken.length() == 0) {
//					token = CommonUtil.getAccessToken(appId, appSecret);
//					logger.warn("ticket job 未获取正确的access_token,重新获取Token : " + JSONObject.toJSONString(token));
//					if (token == null) {
//						Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//						return;
//					}else{
//						//需要重新更新redis。因为微信服务器access_token接口发生改变，只要一更新access_token，上次的失效。
//						redisClient.setex(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE, token.getExpiresIn(), token.getToken());
//					}
//				}
//				
//				token.setToken(redisToken);
//				token.setExpiresIn(redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE).intValue());
//				
//				String timeoutKey = getRedisCacheKey(Constants.PREFIX_TICKET_TIMEOUT) + System.currentTimeMillis();
//				// 设置超时标记2分钟
//				redisClient.setex(timeoutKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT,Constants.REDIS_CACHE_VALUE);
////				redisClient.expire(timeoutKey, Constants.LOCK_TIMEOUT);
//				// 设置同步锁2分钟，如果超时，自动放弃锁，让其他线程可以获取锁
//				redisClient.setex(ticketLock,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT,Constants.REDIS_CACHE_VALUE);
////				redisClient.expire(ticketLock, Constants.LOCK_TIMEOUT);
//				
//				JsapiTicket jsapiTicket = CommonUtil.getJsapiTicket(token);
//				logger.info("JsapiTicket : " + com.meidusa.fastjson.JSONObject.toJSONString(jsapiTicket));
//				long timeout = redisClient.ttl(timeoutKey,Constants.REDIS_NAME_SPACE);
//				logger.info("获取Ticket有效期两分钟，剩余时间 {} 秒", timeout);
//				if (jsapiTicket == null) {
//					if(timeout > 0){
//						logger.info("删除超时时间标志 {} {} ",timeoutKey ,(redisClient.del(timeoutKey,Constants.REDIS_NAME_SPACE) > 0 ? "success" : "failure"));
//						logger.info("删除分布式锁标志 {} {} ",ticketLock ,(redisClient.del(ticketLock,Constants.REDIS_NAME_SPACE) > 0 ? "success" : "failure"));
//					}
//					logger.error("Ticket 获取异常  睡眠一分钟");
//					//睡眠一分钟，防止超过访问微信服务器次数限制
//					Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//				} else {
//					// 请求未超时则放入redis
//					if (redisClient.ttl(timeoutKey,Constants.REDIS_NAME_SPACE) > 0) {
//						// cache WeChat ticket
//						logger.info("获取ticket 未超时，放入redis当中");
//						//判断ttl是否大于1200秒，大于则不放置
//						if(redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_TICKET),Constants.REDIS_NAME_SPACE) < Constants.BEFORE_EXPIRY_20_MINUTES){
//							logger.info("其他线程未更新Ticket进行更新");
//							redisClient.setex(getRedisCacheKey(Constants.PREFIX_REDIS_TICKET),Constants.REDIS_NAME_SPACE, jsapiTicket.getExpiresIn(), jsapiTicket.getTicket());
//						} else{
//							logger.error("其他线程已更新Ticket，放弃这次更新");
//						}
//					} else {
//						logger.error("获取 Ticket 超时");
//						// 超时则放弃，并返回，不需要clearLockFlag.因为已经超时，key已经不存在，否则会把其他的线程的key清除了
//						return;
//					}
//				}
//			} else{
//				logger.warn(this.getName() + "抢锁失败，等待重试!!!");
//				Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//			}
//		} else {
//			logger.info("Redis Ticke 缓存有效, 睡眠一分钟 ");
//			Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//		}
//	}
//
//	/**
//	 * 
//	 * @param jedis
//	 *            redis对象
//	 * @param times
//	 *            调用次数
//	 * @throws InterruptedException
//	 */
//	void getOrUpdateTicket() throws InterruptedException {
//		long ttlTime = redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_TICKET),Constants.REDIS_NAME_SPACE);
//		logger.info(appId + ":ticket exipry time : " + ttlTime);
//		// ttlTime = -2 未找到 -1 永不过期
//		if (ttlTime < 0 || ttlTime < Constants.BEFORE_EXPIRY_20_MINUTES) {
//			logger.info("Ticket:Lock: 过期时间 ttl :" + redisClient.ttl(getRedisCacheKey(Constants.PREFIX_TICKET_LOCK),Constants.REDIS_NAME_SPACE));
//			//如果线程未执行expiry操作，key永远存在
//			if(redisClient.exists(getRedisCacheKey(Constants.PREFIX_TICKET_LOCK),Constants.REDIS_NAME_SPACE)){
//				//存在永不过期的key，redis是同步的，不用担心并发问题
//				if(redisClient.ttl(getRedisCacheKey(Constants.PREFIX_TICKET_LOCK),Constants.REDIS_NAME_SPACE) == -1){
//					logger.info("redis 存在永不过期的key : " + getRedisCacheKey(Constants.PREFIX_TICKET_LOCK) + " 并删除");
//					redisClient.del(getRedisCacheKey(Constants.PREFIX_TICKET_LOCK),Constants.REDIS_NAME_SPACE);
//				}
//			}
//			// 集群环境下需要设置分布式锁，只去获取一次即可
//			long lockFlag = redisClient.setnx(getRedisCacheKey(Constants.PREFIX_TICKET_LOCK),Constants.REDIS_NAME_SPACE,
//					Constants.REDIS_CACHE_VALUE);
//			logger.info(appId + ":ticket flag : " + lockFlag);
//			// 如果返回1，说明设置成功，获得锁
//			if (lockFlag == 1) {
//				syncTicket();
//			} else{
//				logger.warn(this.getName() + "抢锁失败，等待重试!!!");
//				Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//			}
//		} else {
//			Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//		}
//	}
//
//	/**
//	 * @param jedis
//	 * @throws InterruptedException
//	 */
//	private void syncTicket() throws InterruptedException {
//		Token token = new Token();
//		// 获取ticket首先需要token，如果没有则自己获取token
//		String redisToken = "";
//		//最多获取5次。
//		int account = 0;
//		do{
//			redisToken = redisClient.get(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE,null);
//			if(redisToken == null || redisToken.length() == 0){
//				logger.warn("redis未获取正确的access_token,重新获取Token");
//				Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//				//请求3次都异常，退出循环
//				if(++account > 3 ){
//					logger.info("从redis获取access_token 次数 ： " + account);
//					break;
//				}
//			}else{
//				logger.info("redis获取正确的access_token");
//				break;
//			}
//		} while(true);
//		
//		if (redisToken == null || redisToken.length() == 0) {
//			token = CommonUtil.getAccessToken(appId, appSecret);
//			logger.warn("ticket job 未获取正确的access_token,重新获取Token : " + JSONObject.toJSONString(token));
//			if (token == null) {
//				Thread.sleep(Constants.THREAD_SLEEP_ONE_MINUTE);
//				return;
//			}
//		} else {
//			token.setToken(redisToken);
//			token.setExpiresIn(redisClient.ttl(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE).intValue());
//			//需要重新更新redis。因为微信服务器access_token接口发生改变，只要一更新access_token，上次的失效。
//			redisClient.setex(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE, token.getExpiresIn(), token.getToken());
//		}
//		String timeoutKey = getRedisCacheKey(Constants.PREFIX_TICKET_TIMEOUT) + System.currentTimeMillis();
//		String ticketKey = getRedisCacheKey(Constants.PREFIX_TICKET_LOCK);
//		// 设置超时标记2分钟
//		redisClient.setex(timeoutKey,Constants.REDIS_NAME_SPACE,Constants.LOCK_TIMEOUT,Constants.REDIS_CACHE_VALUE);
//		redisClient.expire(timeoutKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT);
//		// 设置同步锁2分钟，如果超时，自动放弃锁，让其他线程可以获取锁
//		redisClient.setex(ticketKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT,Constants.REDIS_CACHE_VALUE);
//		redisClient.expire(ticketKey,Constants.REDIS_NAME_SPACE, Constants.LOCK_TIMEOUT);
//		
//		JsapiTicket jsapiTicket = CommonUtil.getJsapiTicket(token);
//		logger.info("JsapiTicket : "
//				+ com.meidusa.fastjson.JSONObject.toJSONString(jsapiTicket));
//		if (jsapiTicket == null) {
//			logger.error("Ticket 获取异常");
//		} else {
//			// 请求未超时则放入redis
//			if (redisClient.ttl(timeoutKey,Constants.REDIS_NAME_SPACE) > 0) {
//				// cache WeChat token
//				logger.info("获取 Ticket 未超时，放入redis当中");
//				redisClient.setex(getRedisCacheKey(Constants.PREFIX_REDIS_TICKET),Constants.REDIS_NAME_SPACE,
//						jsapiTicket.getExpiresIn(), jsapiTicket.getTicket());
//				redisClient.expire(getRedisCacheKey(Constants.PREFIX_REDIS_TICKET),Constants.REDIS_NAME_SPACE,
//						jsapiTicket.getExpiresIn());
//			} else {
//				logger.error("获取 Ticket 超时");
//				// 超时则放弃，并返回，不需要clearLockFlag.因为已经超时，key已经不存在，否则会把其他的线程的key清除了
//				return;
//			}
//		}
//		clearLockFlag(redisClient, Arrays.asList(timeoutKey, ticketKey));
//	}
//
//	
	
	
	
}
