/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.component.wx.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.component.wx.entity.AppIdSecret;

/**
 * @author hejian
 * 
 */
@Component
public class AppIdSecretHelper implements InitializingBean{
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	//@Value("${ebiz.component.wx.app}")
	private String appPairs;
	
	private List<AppIdSecret> appIdSecretList = new ArrayList<AppIdSecret>();

	/**
	 * @return the appIdSecretList
	 */
	public List<AppIdSecret> getAppIdSecretList() {
		return appIdSecretList;
	}
	
	/** 微信服务号个数 */
	public int applicationCounts(){
		return appIdSecretList.size();
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
//		String[] appPairArray = appPairs.split(",| ");
//		logger.info("读取所有微信服务号app配置信息 : " + JSONObject.toJSONString(appPairArray));
//		for(String str : appPairArray){
//			if(str == null || str.trim().length() == 0){
//				logger.error("读取所有微信服务号app配置信息失败 ");
//				continue;
//			}else{
//				String[] temp = str.split("=| ");
//				logger.info("读取独立微信服务号app配置信息 : " + JSONObject.toJSONString(temp));
//				if(temp.length < 2){
//					logger.error("读取独立微信服务号app配置信息");
//					return;
//				}else{
//					AppIdSecret appIdSecret = new AppIdSecret();
//					//第一个是appid，第二个是密钥
//					appIdSecret.setAppId(temp[0]);
//					appIdSecret.setAppSecret(temp[1]);
//					appIdSecretList.add(appIdSecret);
//				}
//			}
//		}
//		logger.info("app信息列表 : " + JSONObject.toJSONString(appIdSecretList));
	}

}