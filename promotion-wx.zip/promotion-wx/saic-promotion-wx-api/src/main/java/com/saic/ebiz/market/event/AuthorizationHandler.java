/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.event;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.market.common.enumeration.Authorization;

/**
 * @author hejian
 *
 */
public interface AuthorizationHandler extends Handler{

	/***
	 * 
	 * backUrl主要是给用户登录注册使用的跳转地址
	 * 
	 * 根据授权回调获取STATE的参数决定backUrl
	 * 
	 * @see Authorization
	 * 
	 * @param request http request.
	 * @return backUrl 登录注册使用的跳转地址
	 */
	String buildBackUrl(HttpServletRequest request);
	
	/**
	 * 
	 * @param request
	 * @param backUrl 自定义URL
	 * @return
	 */
	String buildCustomBackUrl(HttpServletRequest request, String backUrl);
	
	/***
	 * 回调地址决定回调页面
	 * 
	 * @param request
	 * @param backUrl
	 * @param openId 微信对应服务号唯一标识
	 * @param userId 用户id
	 * @return 视图对象
	 */
	ModelAndView buildView(HttpServletRequest request,String backUrl,String openId, Long userId);
	
}
