package com.saic.ebiz.market.event;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * 
 * 定义微信自定义菜单的事件处理器test
 * @author hejian
 *
 */
public interface EventHandler {
	public String handler(Map<String,String> requestMap,HttpServletRequest request);
}
