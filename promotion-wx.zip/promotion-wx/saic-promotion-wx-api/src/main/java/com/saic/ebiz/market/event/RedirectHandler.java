/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.event;

/**
 * @author hejian
 * 
 */
public interface RedirectHandler extends Handler {
	public String buildBackUrl(String backUrl, Long userId);
}
