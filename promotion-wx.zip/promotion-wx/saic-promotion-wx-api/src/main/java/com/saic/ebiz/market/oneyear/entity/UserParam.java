/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: UserParam.java
 * Author:   xiejuan
 * Date:     2014年11月6日 下午2:08:48
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.oneyear.entity;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class UserParam {
    
    private String openId;
    
    private String nickname;

    /**
     * @return the openId
     */
    public String getOpenId() {
        return openId;
    }

    /**
     * @param openId the openId to set
     */
    public void setOpenId(String openId) {
        this.openId = openId;
    }

    /**
     * @return the nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * @param nickname the nickname to set
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
    
    
    
}
