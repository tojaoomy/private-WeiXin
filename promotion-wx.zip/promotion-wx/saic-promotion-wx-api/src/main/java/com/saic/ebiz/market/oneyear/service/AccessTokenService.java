/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: accessTokenService.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午10:59:08
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.oneyear.service;

import com.saic.ebiz.market.oneyear.entity.UserAccessToken;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface AccessTokenService {
    /***
     * 
     * 功能描述:微信AccessTokeen,并将保存到Redis中，缓存时间：2小时 <br>
     * 〈功能详细描述〉
     *
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String getAccessToken();
    
    
    /***
     * 
     * 功能描述:sns微信AccessTokeen,并将保存到Redis中，缓存时间：2小时 <br>
     * 〈功能详细描述〉
     *
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String getSNSAccessToken(String code);
    
    
    /***
     * 
     * 功能描述: <br>
     * 〈功能详细描述〉
     *
     * @param sessionId 会话ID
     * @param code 
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public UserAccessToken getUserAccessToken(String sessionId,String code);
    
    /**
     * 
     * 网页授权 <br>
     * 〈功能详细描述〉
     *
     * @param redirectUrl
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String auth(String redirectUrl);
    
    /**
     * 
     * 关注授权 <br>
     * 〈功能详细描述〉
     *
     * @param redirectUrl
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String baseAuth(String redirectUrl);

}
