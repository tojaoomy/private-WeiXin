/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.order;

import java.math.BigDecimal;
import java.util.List;

import com.saic.ebiz.market.entity.InquiryOrderVO;
import com.saic.ebiz.order.entity.BrandVO;
import com.saic.ebiz.order.entity.PromotionCity;
import com.saic.ebiz.order.entity.PromotionStore;
import com.saic.ebiz.promotion.service.vo.Promotion;

/**
 * @author hejian
 * 
 */
public interface Order {
	/**
	 * 
	 * @param inquiryOrderVO
	 *            询价单对象VO
	 * @return 订单号
	 * @throws Exception 
	 */
	public String placeOrder(InquiryOrderVO inquiryOrderVO) throws Exception;

	/**
	 * 
	 * @param orderId
	 *            订单号
	 * @return TRUE 成功 FALSE 失败
	 */
	public boolean cancleOrder(Long orderId);
	/**
     * 
     * 功能描述:得到活动相关品牌 <br>
     * @param promotionID ：活动id
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public List<PromotionBrand> getPromotionBrand(long promotionID);
    /**
     * 
     * 功能描述:得到活动相关车系 <br>
     * @param promotionID ：活动id
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public List<PromotionSeries> getPromotionSeries(long promotionID,long brandId);
    
    public List<PromotionStore> getDealerStoreList(Long promotionId,
			Long vehicleModelId, Long colorId,Long cityId);
    /**
     * 
     * 功能描述:得到活动相关车型 <br>
     * @param promotionID ：活动id
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public List<PromotionModel> getPromotionModel(long promotionID,long seriesId);
    /**
     * 
     * 功能描述:得到活动相关颜色 <br>
     * @param promotionID ：活动id
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public List<PromotionModelColor> getPromotionModelColor(long promotionID,long modelId);
    /**
     * 
     * 功能描述: 得到活动相关的城市<br>
     * 〈功能详细描述〉
     *
     * @param promotionID
     * @param productId
     * @param colorId
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public List<PromotionCity> getCityOnly(Long promotionId,Long vehicleModelId,Long colorId);
    /**
     * 
     * 功能描述: 得到活动活动店铺的列表<br>
     * 〈功能详细描述〉
     *
     * @param promotionID
     * @param productId
     * @param colorId
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public List<StoreBaseInfo> getPromStroeList(long promotionID,long productId,long colorId);
    
    /**
     * 
     * 功能描述: 得到配额<br>
     * @param promotionID
     * @param productId
     * @param storeId
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public BigDecimal getPromotionDeposit(long promotionID);
    
    /**
     * 功能描述: 获取预订页面的车型列表<br>
     * @param promotionID
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public List<BrandVO> getModelList(Promotion promotion,long subscriptionId);
    
    /**
     * 
     * 功能描述: 得到商品信息<br>
     * @param promotionId
     * @param productId
     * @param colorId
     * @param storeId
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public PromotionMerchandise getPromotionMerchandise(long promotionId,long productId,long colorId,long storeId);
}
