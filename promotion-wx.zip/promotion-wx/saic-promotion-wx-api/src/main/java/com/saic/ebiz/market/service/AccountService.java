package com.saic.ebiz.market.service;
/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindingResult;

import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.market.common.entity.user.UserBean;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.sso.client.entity.LoginInfo;

public interface AccountService {

    /**
     * 功能描述: 用户登录<br>
     * 〈功能详细描述〉.
     * 
     * @param appCode appId 主站的为1
     * @param aliasName 用户名
     * @param password the password
     * @param autoLogin 是否保存密码
     * @param request the request
     * @param response the response
     * @return request response
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    LoginInfo userLogin(int appCode, String aliasName, String password, boolean autoLogin, HttpServletRequest request,
            HttpServletResponse response);
    
	/**
	 * 功能描述:保存用户id和openid的关联关系<br>
     * 〈功能详细描述〉.
	 * @param userid
	 * @param openId
	 * @return
	 */
    boolean	addWinxinOpenIDAndUserIdReleation(long userid,String openId);
    
    
    LoginInfo userLoginnew(int appCode, String aliasName, String password, boolean autoLogin, HttpServletRequest request,
            HttpServletResponse response);
    /**
     * 功能描述: 用户注销<br>
     * .
     * 
     * @param userId the user id
     * @param request the request
     * @param response the response
     * @return true, if successful
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    boolean userLogout(long userId, HttpServletRequest request, HttpServletResponse response);

    /**
     * 功能描述: 验证表单用户登陆<br>
     * .
     * 
     * @param userBean the user bean
     * @param result the result
     * @return BindingResult spring 绑定UserBean result对象
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    BindingResult validateUserLogin(UserBean userBean, BindingResult result);

    /**
     * 功能描述: 验证表单用户注册<br>
     * .
     * 
     * @param userBean the user bean
     * @param result the result
     * @return BindingResult spring 绑定UserBean result对象
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    BindingResult validateUserRegister(UserBean userBean, BindingResult result);
    
    /**
     * 功能描述: 验证表单用户注册<br>
     * .
     * 
     * @param userBean the user bean
     * @param result the result
     * @return BindingResult spring 绑定UserBean result对象
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    BindingResult validateUserRegisterByaliasType(UserBean userBean, BindingResult result);

    /**
     * 功能描述: 用户注册<br>
     * 〈功能详细描述〉.
     * 
     * @param userName 用户名
     * @param passWord 密码
     * @param aliasType the alias type
     * @param appId the app id
     * @param createType the create type
     * @param securityType the security type
     * @return UserBean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    ResponseVO userRegister(String userName, String passWord, int aliasType, int appId, int createType, int securityType);

    /**
     * 功能描述: 用户注册_手机注册和邮箱注册<br>
     * 〈功能详细描述〉.
     * 
     * @param userName 用户名
     * @param passWord 密码
     * @param checkcode 
     * @param aliasType the alias type
     * @param appId the app id
     * @param createType the create type
     * @param securityType the security type
     * @return UserBean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    ResponseVO userRegisterforEmailAndPhone(String userName, String passWord, String checkcode, int aliasType, int appId, int createType, int securityType,String authURL);
    
    /**
     * 功能描述: 验证用户名是否存在<br>
     * .
     * 
     * @param aliasName - 别名账号
     * @param aliasType - 认证类型-->1:用户名，2:手机， 3:邮箱…
     * @param appId - 应用ID,注册来源的应用ID号，1：电商主站应用
     * @return ResponseVO 返回结果对象信息，验证结果 100:已存在,101:不存在
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    ResponseVO aliasNameIsUsed(String aliasName, int aliasType, int appId);
    /**
     * 功能描述: 验证用户名是否存在<br>
     * .
     * 
     * @param aliasName - 别名账号
     * @param aliasType - 认证类型-->1:用户名，2:手机， 3:邮箱…
     * @param appId - 应用ID,注册来源的应用ID号，1：电商主站应用
     * @return ResponseVO 返回结果对象信息，验证结果 100:已存在,101:不存在
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    ResponseVO aliasNameIsUsedByaliasType(String aliasName, int aliasType, int appId);
    
    
    /**
     * 功能描述: 返回登陆页面图片<br>
     * .
     * 
     * @return string 图片url
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    String loginPageImage();
    
    /**
     * 功能描述: 返回登陆状态 登陆成功返回userId未成功返回0<br>
     * .
     * 
     * @param request the request
     * @return userId/0
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    Long getLoginStatus(HttpServletRequest request);
    
    /**
     * 功能描述: 注册完后调用邀请好友接口<br>
     * .
     * 
     * @param friendRegVO the friend reg vo
     * @return 100-业务成功；102-数据库异常业务失败
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    Integer friendReg(UserBaseInfoVO friendRegVO);
    /**
     * 根据userid获得会员信息
     * @param usrid
     * @return
     */
    UserBaseInfoVO getMemberinfoByuserId(String usrid);


	List<WebAccountVO> findWebAccountByCondition(WebAccountVO wv);
}
