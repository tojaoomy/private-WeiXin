/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.List;
import java.util.Map;

import com.saic.ebiz.market.entity.DistrictVO;
import com.saic.ebiz.market.entity.PinyinCityEntity;
import com.saic.ebiz.market.entity.ProvinceSerialVO;
import com.saic.ebiz.market.entity.ProvinceVO;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;

/**
 * 
 * 区域相关的服务
 * 
 * 	1.获取所有的省份城市
 *  2.根据城市获取省份
 *  3.根据活动获取省份
 *  4.根据活动、车型获取省份
 *  5.根据活动、车型、颜色获取省份
 * @author hejian
 * 
 */
public interface AreaService {
	/**
	 * 获取当前系统所有的省份对象
	 * @return 省份对象集合
	 */
	public List<ProvinceVO> getAllProvinces();
	
	/**
	 * 三级联动
	 * @return
	 */
	public List<ProvinceSerialVO> getAllProvinceSerials();

	/**
	 * 获取给定城市的省份对象
	 * @return 省份对象集合
	 */
	public ProvinceVO getProvinceByCityId(Long cityId);
	
	/**
	 * 通过MarketType获取城市
	 * 
	 * @see MarketType#ROUTINE
	 * @return 省份对象集合
	 */
	public List<ProvinceVO> getProvinceByMarkeyType(Integer marketType);
	
	/**
	 * 通过MarketType获取城市
	 * 
	 * @see MarketType#ROUTINE
	 * @return 拼音对象集合
	 */
	public List<PinyinCityEntity> getPinyinCity(Integer marketType);
	
	/**
	 * 
	 * @param promotionId 活动ID号
	 * @return 省份对象集合
	 */
	public List<ProvinceVO> getProvinceByPromotionId(Long promotionId);
	
	/**
	 * 
	 * @param promotionId 活动ID号
	 * @param vichealModelId 车型ID号
	 * @return 省份对象集合
	 */
	public List<ProvinceVO> getProvinceByPromotionIdAndVichealModelId(Long promotionId,Long vichealModelId);
	
	/**
	 * 
	 * @param promotionId  活动ID号
	 * @param vichealModelId  车型ID号
	 * @param colorId 颜色ID号
	 * @return 省份对象集合
	 */
	public List<DistrictVO> getDistrictWithStoreByMapData(Map<Long, List<Long>> map);
	
}
