/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.List;

import com.saic.ebiz.mdm.entity.WebAccountVO;

/**
 * @author hejian
 *
 */
public interface BoundingService {
	/**
     * 获取绑定信息
     * 
     * @param fromUserName openid
     * @return
     */
    public List<WebAccountVO> checkBounding(String fromUserName);
    
    /**
     * 
     * @param fromUserName openid
     * 
     * @return true 该用户已绑定 false 未绑定
     * 	
     */
    public boolean checkResultBounding(String fromUserName);
    
    /**
     * 
     * @param fromUserName openid
     * @return 返回对应的userid
     */
    public String getBoundingUserId(String fromUserName);
    
    /**
     * 解除绑定
     * @param fromUserName 
     * @return
     */
    public boolean deleteWebAccountByOpenId(String fromUserName);
    
    /**
     * 解除绑定
     * @param userId 
     * @return
     */
    public boolean deleteWebAccountByUserId(Long userId);
    
    /**
     * 根据用户id在mdm系统查找绑定的openid
     * @param userId 用户id
     * @return 微信服务号openid
     */
    public String getOpenIdByUserId(Long userId);
}
