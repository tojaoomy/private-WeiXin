/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.List;

import com.saic.ebiz.market.entity.BrandVO;
import com.saic.ebiz.market.entity.SeriesVO;

/**
 * @author hejian
 * 
 */
public interface BrandService {

	/**
	 * 根据品牌号获取对应品牌的信息 
	 * @param brandId 品牌id 
	 * @return
	 */
	public BrandVO findBrandById(Long brandId);
	
	/**
	 * 获取所有的品牌
	 * 
	 * @return
	 */
	List<BrandVO> getAllBrands();

	/**
	 * 
	 * @param promotionId
	 *            活动id
	 * @return
	 */
	List<BrandVO> getBrandsByPromotionId(Long promotionId);
	

	/**
	 * 
	 * @param marketType 活动类型
	 * @param cityId 城市id
	 * @return
	 */
	List<BrandVO> getBrandsByMarketType(Integer marketType,Long cityId);
	
	/**
	 * 
	 * @param marketType marketType 活动类型
	 * @param cityId 城市id
	 * @param brandId 品牌id
	 * @return
	 */
	List<SeriesVO> getSeriesByMarketType(Integer marketType,Long cityId,Long brandId);
	
	/**
	 * 
	 * @param promotionId
	 *            活动id
	 * @param cityId
	 *            城市id
	 * @return
	 */
	List<BrandVO> getBrandsByPromotionIdAndCityId(Long promotionId, Long cityId);

	/**
	 * 根据活动，城市，车型返回品牌的相关信息
	 * 车型确定，只返回一条记录。
	 * 
	 * @param promotionId
	 *            活动id
	 * @param cityId
	 *            城市id
	 * @param modelId
	 *            车型id
	 * @return
	 */
	BrandVO getBrandsByPromotionIdAndCityIdAndModelId(Long promotionId,
			Long cityId, Long modelId);
}
