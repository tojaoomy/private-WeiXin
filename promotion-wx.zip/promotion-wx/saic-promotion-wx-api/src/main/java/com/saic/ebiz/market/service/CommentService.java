/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.List;

import com.saic.ebiz.market.entity.Comment;
import com.saic.ebiz.market.entity.CommentVO;

/**
 * 获取用户评价的服务。
 * 
 * @author hejian
 *
 */
public interface CommentService {
	
	public List<CommentVO> getCommentByBrandIds(int size,Long... brandIds);
	
	public void saveComment(Comment comment);
}
