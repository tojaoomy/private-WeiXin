/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.service;


import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.market.common.entity.user.SecretSecurityBean;
import com.saic.ebiz.market.common.entity.user.UserBean;

/**
 *  用户找回密码<br>
 */
public interface FindPassWordService {

    /**
     * 确认名称是否存在<br>
     * .
     * 
     * @param aliasName 别名
     * @param aliasType 别名类型
     * @param appCode 应用ID
     * @return rtnCode(结果码):100：别名不存在；101：别名存在,其他：参考错误编码
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    ResponseVO aliasNameIsUsed(String aliasName, int aliasType, int appCode);

    /**
     * 只根据id执行密码的修改<br>
     * .
     * 
     * @param acctId 用户账号id（为空时，账号别名不能为空）
     * @param newPasswd 新密码
     * @param securityType the security type
     * @return rtnCode(结果码):100：修改成功；其他：参考错误编码规则
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    ResponseVO updatePasswd(Long acctId, String newPasswd, int securityType);
    
    /**
     * 校验会员安保问答<br>
     * .
     * 
     * @param acctId 用户账号id（为空时，账号别名不能为空）
     * @param securityList 安保问题列表
     * @param queId 问题代码
     * @param queContent 问题内容
     * @return rtnCode(结果码):100：修改成功；其他：参考错误编码规则
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    ResponseVO verifySecurityInfo(Long acctId, SecretSecurityBean securityList,int queId,String queContent);

    /**
     * 返回用户名验证结果<br>
     * .
     * 
     * @param aliasName 别名
     * @param aliasType 别名类型
     * @param appCode 应用ID
     * @param ssb the ssb
     * @param userBean the user bean
     * @return rtnCode(结果码):1：不绑定2：手机3：邮箱4：密保5：手机、邮箱6：手机、密保 7：邮箱、密保8：手机、邮箱、安保9：不存在
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     * @ssb 返回密保问题
     */
    ResponseVO aliasNameIsUsed(String aliasName, int aliasType, int appCode, SecretSecurityBean ssb, UserBean userBean);

    /**
     * 功能描述: <br>
     * 根据用户名获取用户需要页面显示的手机邮箱等信息.
     * 
     * @param userBean the new user bean info
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    void setUserBeanInfo(UserBean userBean);
}