/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import com.saic.ebiz.market.order.Order;

/**
 * @author hejian
 *
 */
public interface OrderService extends Order {
	
}
