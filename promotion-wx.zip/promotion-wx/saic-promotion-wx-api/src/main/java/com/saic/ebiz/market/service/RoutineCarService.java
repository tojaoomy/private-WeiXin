/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.List;

import com.ibm.framework.dal.pagination.Pagination;
import com.saic.ebiz.market.entity.RoutineCarVO;

/**
 * @author hejian
 * 
 */
public interface RoutineCarService {

	/**
	 * 通过活动类型、车系和颜色获取所有的常规车信息
	 * 
	 * @param markeyType
	 *            活动类型
	 * @param cityId
	 *            城市id
	 * @param brandId
	 *            品牌id
	 * @param seriesId
	 *            车系
	 * @see RoutineCarVO
	 * @return 常规车列表
	 */
	public List<RoutineCarVO> findConventionalVehicleByPromotionIdSeriesIdColorId(
			Integer markeyType, Long cityId,Long brandId, Long seriesId,boolean availableOnly, Pagination page);
	
	public List<RoutineCarVO> findRoutineCar(List<Long> routineCarIds);
}
