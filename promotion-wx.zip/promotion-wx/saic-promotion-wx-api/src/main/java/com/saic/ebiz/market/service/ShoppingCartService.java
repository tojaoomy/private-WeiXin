/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.List;

import com.saic.ebiz.market.entity.ShoppingCart;

/**
 * @author hejian
 *
 */
public interface ShoppingCartService {
	/**
	 * 
	 * @param userId 用户id
	 * @param routineCarId	常规车id
	 * @return true 成功 false 失败
	 */
	public boolean put(Long userId,Long cityId, Long routineCarId);
	
	/**
	 * 
	 * @param userId 用户id
	 * @param routineCarId	常规车id
	 * @return true 成功 false 失败
	 */
	public boolean remove(Long userId,Long cityId, Long routineCarId);
	

	/**
	 * 
	 * @param userId 用户id
	 * @return true 成功 false 失败
	 */
	public boolean empty(String userId);
	
	/**
	 * 
	 * @param uerId 用户id
	 * @return true 成功 false 失败
	 */
	public boolean empty(Long userId,Long cityId);
	
	/**
	 * 
	 * @param uerId 用户id
	 * @return 购物车列表
	 */
	public List<ShoppingCart> loadByUserId(Long userId,Long cityId);
}
