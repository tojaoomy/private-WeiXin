/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.List;

import com.saic.ebiz.market.entity.DistrictVO;

/**
 * @author hejian
 *
 */
public interface StoreService {
	/**
	 * 常规车--返回该城市下有常规车Id和颜色id的经销商
	 * @param cityId 城市
	 * @param routineCarId
	 * @param colorId
	 * @return 
	 */
	List<DistrictVO> getStoreByCreterial(Long cityId,
			Long promotionId, Long colorId);
	
}
