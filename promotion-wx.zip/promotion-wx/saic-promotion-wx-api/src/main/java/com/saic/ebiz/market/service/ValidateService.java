/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.service;


import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.iam.service.exception.ArgumentException;
import com.saic.ebiz.market.common.entity.user.BasicPersonalInfoBean;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;

/**
 * 手机、邮箱帐号验证<br>
 */
public interface ValidateService {

    /**
     * 功能描述: 邮箱验证.<br>
     * 〈功能详细描述〉
     * @param userId 用户ID
     * @param emailAddress 邮箱地址
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public void toValidateEmail(long userId, String emailAddress);

    /**
     * 功能描述: 手机验证.<br>
     * 〈功能详细描述〉
     * @param pnoheNumber 手机号码
     * @return BasicPersonalInfoBean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public BasicPersonalInfoBean toValidatePhone(String pnoheNumber);

    /**
     * 功能描述: 根据邮件来获该用户所注册的邮箱网站.<br>
     * 〈功能详细描述〉
     * @param emailName 邮箱
     * @return BasicPersonalInfoBean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public BasicPersonalInfoBean toGetHandEmailByParmes(String emailName);

    /**
     * 功能描述: 校验手机、邮箱是否已存在.<br>
     * 〈功能详细描述〉
     * @param aliasName 别名账号
     * @param aliasType 认证类型-->1:用户名，2:手机， 3:邮箱
     * @param appCode 应用ID,注册来源的应用ID号，1：电商主站应用
     * @return int
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int toFrontCheckPhoneOrEma(String aliasName, int aliasType, int appCode);
    
    /**
     * 判断用户是否存在
     * @param aliasName
     * @param aliasType
     * @param appId
     * @return
     */
    public ResponseVO accountIsExist(String aliasName, int aliasType, int appId);
 
    /**
     * 功能描述:调用发送邮件接口服务. <br>
     * 〈功能详细描述〉给需要验证的邮箱发送验证链接
     * @param acctId 用户id
     * @param email 目标email地址
     * @param templateID 邮件内容模板id
     * @param authURL 跳转的链接
     * @return int
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int toReqAuthMail(long acctId
            , String email, String templateID, String authURL);
    /**
     * 功能描述: 验证邮件链接是否有效、并邦定该邮箱.<br>
     * 〈功能详细描述〉
     * @param userId 用户id
     * @param authCode 邮件验证码
     * @param createType 1
     * @return String
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String toVerifyAuthMailAndBind(String userId
            , String authCode, int createType);

    /**
     * 功能描述: 发送验证码.<br>
     * 〈功能详细描述〉给已经验证可以用的手机、邮箱发送验证码
     * 
     * @param acctId 用户id
     * @param authType 1:用户名，2:手机， 3:邮箱
     * @param authInfo 认证信息
     * @param complateId 模板id
     * @return the int
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int toReqCheckCode(long acctId
            , int authType, String authInfo, String complateId);
    /**
     * 功能描述: 发送验证码.<br>
     * 〈功能详细描述〉给已经验证可以用的手机、邮箱发送验证码
     * 
     * @param acctId 用户id
     * @param authType 1:用户名，2:手机， 3:邮箱
     * @param authInfo 认证信息
     * @param complateId 模板id
     * @return the int
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int toReqCheckCodeByMobile(int authType, String authInfo, String complateId);
    /**
     * 功能描述: 发送验证码.<br>
     * 〈功能详细描述〉给已经验证可以用的手机、邮箱发送验证码
     * 
     * @param acctId 用户id
     * @param authType 1:用户名，2:手机， 3:邮箱
     * @param authInfo 认证信息
     * @param complateId 模板id
     * @return the int
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
	public void toReqCheckCodeForUms(int authType, String valueNum,String temStyle);
    /**
     * 功能描述: 校验手机、验证码有效性.<br>
     * @param userId 用户
     * @param authType  0:用户名，1:手机， 2:邮箱
     * @param inputCode 验证码
     * @param authInfo 手机、邮箱
     * @param createType 模板
     * @return int 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int toAuthCheckCode(long userId
            , int authType, String inputCode
            , String authInfo, int createType);
    /**
     * 功能描述: 校验密码是否正确.<br>
     * 〈功能详细描述〉
     * @param userId 用户id
     * @param appId 应用ID,注册来源的应用ID号，1：B2C电商主站应用
     * @param aliasName     别名账号
     * @param password      输入的密码
     * @return int
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int toCheckPass(long userId
            , int appId
            , String aliasName
            , String password);
    /**
     * 功能描述: 校验手机或者邮箱校验码,成功之后增加或者更新帐号别名.<br>
     * 〈功能详细描述〉校验手机或者邮箱校验码
     * @param userId 用户名id
     * @param authType 验证类型认证类型-->1:用户名，2:手机， 3:邮箱…
     * @param inputCode 用户输入的验证码
     * @param authInfo 手机或者邮箱号
     * @param createType 1
     * @return int
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int toVerifyAuthCodeAndBind(
            long userId
            , int authType
            , String inputCode
            , String authInfo
            , int createType);
    /**
     * 功能描述: 查询用户认证信息.<br>
     * 〈功能详细描述〉根据账号id查询用户的认证信息及设置的安保问题
     * @param aliasName 帐户别名
     * @param userId 用户id
     * @param appId 应用ID,注册来源的应用ID号，1：B2C电商主站应用
     * @param tempId 模板id  2手机  3邮箱
     * @return String
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String toGetResultNum(
            String aliasName
            , long userId
            , int appId
            , String tempId);
    /**
     * 功能描述: 发送邀请好友邮件.<br>
     * 〈功能详细描述〉对主站传来的 好友邮箱验证并进行好友邀请函发送
     * @param userId 用户id
     * @param friendEmail 好友Email地址
     * @param inviteURL 邀请注册URL
     * @return boolean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public boolean sendInviteEmail(
            long userId
            , String friendEmail
            , String inviteURL);
    /**
     * 功能描述: 获取邀请好友签名串.<br>
     * 〈功能详细描述〉返回给主站邀请好友会员签名串
     * @param userId 用户id
     * @return InviteSignVO
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public UserBaseInfoVO getInviteSign(long userId);
    
    /**
     * 车主认证手机验证码.<br>
     * @param userId 用户Id
     * @param inputCode 验证码
     * @param authInfo 手机号码
     * @return int 验证是否成功
     */
    public int toAuthCheckCodeByApp(long userId, String inputCode,
            String authInfo) throws ArgumentException;
    
    /**
     * 车主认证手机验证码获取.<br>
     * @param acctId 用户Id
     * @param authType 验证类型
     * @param authInfo 手机号码
     * @param complateId 模板编号
     * @param activeTime 失效时间
     * @return int 状态编号
     */
    public int toReqCheckCodeByApp(long acctId, int authType, String authInfo,
            String complateId, int activeTime);

    /**
     * 
     * 功能描述: <br>
     * 根据用户名获取用户ID
     *
     * @param aliasName 用户名
     * @return userId
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    String getUserIdForUserName(String aliasName);
    /**
     * 用户点击邮箱中的激活链接绑定邮箱 并激活账号
     * @param userId
     * @param authCode
     * @param createType
     * @return
     */
	String toBindAndActiveMail(String userId, String authCode, int createType);

	public void getAuthInfo(String userName, Long userId, int i,BasicPersonalInfoBean bpibean);

    ResponseVO validateActiveEmail(String authInfo, String validateCode);
	public boolean updateNickNameByUserName(String userName, String nickname);
	public boolean updateNickNameByUserid(String userId, String nickname);
	
	/**
	 * 
	 * 功能描述: <br>
	 * 〈功能详细描述〉
	 *
	 * @param authURL
	 * @param email
	 * @param typeId
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
    Boolean sendFindPwdEmail(String authURL, String email, String typeId);
    
    /**
     * 
     * 功能描述: <br>
     * 验证新密码和原密码是否一样
     *
     * @param userName
     * @param newpw
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    Boolean compareNewPwordWithOld(String userName, String newpw);

	


}
