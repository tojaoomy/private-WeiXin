/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: PayService.java
 * Author:   LiuXue
 * Date:     2013年12月12日 下午14:41:41
 * Description: //模块目的、功能描述
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.service;

import java.util.Map;

import com.saic.ebiz.pmf.service.entity.dto.PayDTO;

/**.
 * 〈一句话功能简述〉订单支付接口<br>
 * 〈功能详细描述〉提供促销车活动支付相关接口
 *
 * @author LiuXue
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface PayService {

    /**
     * . 功能描述: 支付提交<br>
     * 〈功能详细描述〉根据提供的支付信息调用支付平台接口，让支付平台返回网银跳转链接或支付宝链接
     * @author LiuXue
     * @param pay 支付信息实体
     * @return String URL 跳转的网银页面或支付宝页面链接
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    String payment(PayDTO pay);
    /**
     * . 功能描述: 收到支付宝回调数据添加到支付记录表和回调信息表<br>
     * 〈功能详细描述〉根据提供的订单编号查询支付状态
     * 
     * @author LiuXue
     * @param params the params
     * @param type 回调类型:1同步2异步
     * @return the string
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    String updatePaymentAndCallBack(Map<String, String> params, String type);
    
    /**
     * app异步回调函数.
     * 
     * @param params the params
     * @param type the type
     * @return the string
     */
    String appUpdatePaymentAndCallBack(Map<String, String> params, String type);
}
