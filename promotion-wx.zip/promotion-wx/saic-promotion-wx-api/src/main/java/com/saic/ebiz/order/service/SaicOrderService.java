/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.order.service;

import com.saic.ebiz.order.service.entity.PreOrder;
import com.saic.ebiz.order.service.exception.PreOrderQuotaLackException;

/**
 * @author hejian
 *
 */
public interface SaicOrderService {

	/**
	 * 生成预订单，返回订单号
	 * 
	 * @param preOrder 			预订单信息
	 * @param subscriptionId	报名信息ID
	 * @param promotionId		活动ID
	 * @return 生成的订单号
	 * 
	 */
	public String createPreOrder(PreOrder preOrder,Long subscriptionId) throws PreOrderQuotaLackException;
}
