package com.saic.ebiz.order.service;
/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */


import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.saic.ebiz.carlib.service.entity.VelBrand;
import com.saic.ebiz.carlib.service.entity.VelModelColorExt;
import com.saic.ebiz.carlib.service.entity.VelSeries;
import com.saic.ebiz.order.entity.BrandVO;
import com.saic.ebiz.order.entity.CityVO;
import com.saic.ebiz.order.entity.ColorImageVO;
import com.saic.ebiz.order.entity.PreOrderVO;
import com.saic.ebiz.order.entity.PromotionStore;
import com.saic.ebiz.order.entity.ProvinceVO;

/**
 * 该接口主要是为车享购三期服务，并不全适用车享购一期、二期
 * 
 * @author hejian
 *
 */
public interface SaicShoppingService {
	
	/**
	 * 
	 * @param promotion 活动
	 * @param vehicleModelId 车型
	 * @param colorId	颜色
	 * @return 卖该颜色车型的经销商集合
	 * 
	 */
	public List<PromotionStore> getDealerStoreList(Long promotionId,Long vehicleModelId,Long colorId,Long cityId);
	
	/**
	 * 
	 * @param promotionId 活动
	 * @param request
	 * @return 返回该活动预定金
	 */
	public BigDecimal getDeposit(long promotionId);
	
	/**
	 * 
	 * @param promotionId		活动
	 * @param brandId			品牌
	 * @param seriesId			车系
	 * @param vehicleModelId 	车型
	 * @return 实际上只返回一条记录
	 * 		该记录包含品牌
	 * 				-> 车系
	 * 					-> 车型
	 * 						-> 颜色
	 */
	public List<BrandVO> getVehicleModelList(Long promotionId, Long vehicleModelId);
	
	/**
	 * 
	 * @param promotionId		活动
	 * @param brandId			品牌
	 * @param seriesId			车系
	 * @return 
	 * 		该记录包含品牌
	 * 				-> 车系
	 * 					-> 车型
	 */
	public List<BrandVO> getListBySeriesId(Long promotionId, Long brandId, Long seriesId);
	
	/**
	 * 
	 * @param promotionId		活动
	 * @param brandId			品牌
	 * @param seriesId			车系
	 * @return 
	 */
	public List<ColorImageVO> getColorListBySeriesId(Long promotionId,Long vehicleModelId);
	
	/**
	 * 通过品牌ID获取品牌信息
	 * 
	 * @param brandId
	 * @return 
	 */
	public VelBrand findBrandById(Long brandId);
	
	/**
	 * 通过车系ID获取车系信息
	 * @param seriesId
	 * @return
	 */
	public VelSeries findSeriesById(Long seriesId);
	
	/**
	 * 通过车型ID获取车型信息
	 * @param vehicleModelId
	 * @return
	 */
	
	public VelModelColorExt findModelById(Long vehicleModelId);
	
	/**
	 * 根据活动获取城市列表
	 * @param promotionId 活动ID
	 * @param showProvince TRUE显示省份和城市列表 ,FALSE在预订单页只显示城市
	 * @return
	 */
	public List<ProvinceVO> getProvinceVOByPromotionId(Long promotionId,Long vehicleModelId,boolean showProvince,Long colorId);
	
	public List<CityVO> getCityOnly(Long promotionId,Long vehicleModelId,Long colorId);
	
	/**
	 * 
	 * @param preOrderVO 
	 * @param request
	 * @return 订单号
	 * 
	 */
	public String placeOrder(PreOrderVO preOrderVO, HttpServletRequest request);
}
