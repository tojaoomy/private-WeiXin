/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * Author:   chenliang
 * Date:     2013年11月27日 下午9:39:37
 */
package com.saic.ebiz.commons;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.core.io.Resource;

import com.ibm.framework.exception.BaseException;


/**
 * 获取Properties配置<br>
 * @author chenliang
 */
public class PropertiesConfiger {
    
    /** 配置文件. */
    private Resource resource;
    
    /** 配置. */
    private Properties properties = null;

    /**
     * 读取配置文件.
     * 
     * @param in the in
     * @return 配置
     */
    public Properties loadConfig(InputStream in) {
        Properties prop = new Properties();
        try {
            prop.load(in);
        } catch (IOException e) {
            throw new BaseException(e);
        }
        return prop;
    }

    /**
     * 读取配置.
     * 
     * @param key 配置key
     * @return String 配置value
     */
    public String getProperty(String key) {
        if (properties == null) {
            InputStream reader;
            try {
                reader = resource.getInputStream();
                properties = loadConfig(reader);
                reader.close();
            } catch (IOException e) {
                throw new BaseException(e);
            }
        }
        String value = properties.getProperty(key, null);
        if (value == null) {
            throw new BaseException("value值为null!");
        }
        return value;
    }

    /**
     * Gets the resource.
     * 
     * @return the resource
     */
    public Resource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     * 
     * @param resource the resource to set
     */
    public void setResource(Resource resource) {
        this.resource = resource;
    }

    /**
     * Gets the properties.
     * 
     * @return the properties
     */
    public Properties getProperties() {
        return properties;
    }

    /**
     * Sets the properties.
     * 
     * @param properties the properties to set
     */
    public void setProperties(Properties properties) {
        this.properties = properties;
    }
}
