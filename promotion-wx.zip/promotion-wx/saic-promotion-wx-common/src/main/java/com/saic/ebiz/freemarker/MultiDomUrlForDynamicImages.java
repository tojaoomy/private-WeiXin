/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: MultiDomUrlDynamicImages.java
 * Author:   chenliang
 * Date:     2014年4月2日 上午11:45:39
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.freemarker;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import com.ibm.framework.web.freemarker.MultiDomUrl;

import freemarker.template.TemplateModelException;

/**
 * 实现产品图片静态资源的自动多域名处理<br></br>
 * 
 * <b>注：该类仅适用于产品类的静态图片.</b></br>
 * 在<code>com.ibm.framework.web.freemarker.MultiDomUrl</code>的基础上增加</br>
 * 了对于没有配置图片的uri，返回一个默认图片地址
 *
 * @author chenliang
 * @see com.ibm.framework.web.freemarker.MultiDomUrl
 */
public class MultiDomUrlForDynamicImages extends MultiDomUrl {

    /** 默认图片服务器数量. */
    private static final int DEFAULT_HOST_NUMBER = 5;
    
    /** 默认图片. */
    private String imgDefault = "" ;
 
    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Object exec(List arguments) throws TemplateModelException {
        String url = StringUtils.EMPTY;
        
        // 判断参数值, 为空则返回默认图片
        if (null == arguments || arguments.size() == 0) {
            url = imgDefault;
        // 获取资源文件名
        } else {
            url = (String) arguments.get(0);
            
            // 图片地址为空则返回默认图片
            if (StringUtils.isBlank(url)) {
                url = imgDefault;
                
            // url地址为"/140x120", 这种情况在ftl中调用是：${imgUrl("/150x100${retHd.dealerPictureUrl}")}，
            // 但${retHd.dealerPictureUrl}不存在或为null
            } else if (url.lastIndexOf("/") == 0) {
                // 搜索接口没图片会返回String类型的null, 类似"/150x100null"
                if (StringUtils.containsIgnoreCase(url, "null")) {
                    url = url.replaceAll("(?i)null", StringUtils.EMPTY) + imgDefault;
                } else {
                    url += imgDefault;
                }
            }
        }

        int imgNumber = DEFAULT_HOST_NUMBER;
        if (!StringUtils.isBlank(getImgHostNumber())) {
            imgNumber = Integer.parseInt(getImgHostNumber());
        }

        // 获取新域名编号
        int suffix = Math.abs(stringToInt(url) % imgNumber) + getImgUrlStarNum();

        // 替换编号所在位置的占位符
        String hostName = getHost().replace(getImgHostTag(), String.valueOf(suffix));

        if (!hostName.endsWith("/")) {
            hostName = hostName + "/";
        }

        if (url.startsWith("/")) {
            url = url.substring(NumberUtils.INTEGER_ONE);
        }
        // 组装形成新域名
        String result = hostName + url;

        return result;
    }

    /**
     * 获取资源文件名的hashcode.
     * 
     * @param str 参考说明
     * @return int 返回值
     */
    private int stringToInt(String str) {
        return str.hashCode();
    }

    /**
     * @return the imgDefault
     */
    public String getImgDefault() {
        return imgDefault;
    }

    /**
     * @param imgDefault the imgDefault to set
     */
    public void setImgDefault(String imgDefault) {
        this.imgDefault = imgDefault;
    }

}
