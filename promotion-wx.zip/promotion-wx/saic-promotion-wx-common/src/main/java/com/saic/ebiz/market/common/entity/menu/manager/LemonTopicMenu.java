package com.saic.ebiz.market.common.entity.menu.manager;

import com.saic.ebiz.market.common.entity.authentication.Token;
import com.saic.ebiz.market.common.entity.menu.Button;
import com.saic.ebiz.market.common.entity.menu.ClickButon;
import com.saic.ebiz.market.common.entity.menu.ComplexButton;
import com.saic.ebiz.market.common.entity.menu.Menu;
import com.saic.ebiz.market.common.entity.menu.ViewButton;
import com.saic.ebiz.market.common.util.CommonUtil;
import com.saic.ebiz.market.common.util.MenuUtil;

/**
 * 
 * 〈一句话功能简述〉<br> 
 * 车享订阅号菜单
 *
 * @author yanwanjun
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class LemonTopicMenu {

    
    
    private static final String SIT_APP_ID = "wxd135e946c87c40d0";
    private static final String SIT_APP_SECRET = "43cb36ebd3138c639aea181258e2fa5e";
    
    private static final String PRE_APP_ID = "wx71618a22b8de89b0";
    private static final String PRE_APP_SECRET = "99801502f5a4fd11a3d54a4c6a45d015";

    private static final String PRD_APP_ID = "wx0db3d3db0507573c";
    private static final String PRD_APP_SECRET = "9310a15dc8d046463128229618c914b8";
    
    
    public static Menu getMenuNew(String env){
        
        
        
        //正式上线后的88节菜单
//        ViewButton btn2_1 = new ViewButton();
//        btn2_1.setName("88节主会场");
//        btn2_1.setUrl("http://car."+env+".com/promotion/baba/main.htm");
//        
//        ViewButton btn2_2 = new ViewButton();
//        btn2_2.setName("人脉是金");
//        if(env.equals("chexiang")) {
//            btn2_2.setUrl("http://mgo.chexiang.com/spreadPraise/home?channel=CX_ZC_H5_praise__redbag_20160808&H5Click");
//        } else {
//            btn2_2.setUrl("http://mgo."+env+".chexiang.com/spreadPraise/home?channel=CX_ZC_H5_praise__redbag_20160808&H5Click");
//        }
//        
//        ComplexButton btn2 = new ComplexButton();
//        btn2.setName("车享88节");
//        btn2.setSub_button(new Button[]{btn2_1,btn2_2});
        
        //预热
//        ViewButton btn2 = new ViewButton();
//        btn2.setName("车享88节");
//        btn2.setUrl("http://go.chexiang.com");

        ViewButton btn1 = new ViewButton();
        btn1.setName("特价车");
        btn1.setUrl("http://c."+env+".com/promotion/index.htm?utm_source=Weixin_Dyh&utm_medium=B&utm_term=&utm_content=&utm_campaign=tjc");

        ViewButton btn2 = new ViewButton();
        btn2.setName("全新科沃兹 ");
        btn2.setUrl("http://c."+env+".com/detail/52995.htm?utm_source=Weixin_Dyh&utm_medium=cdl&utm_term=&utm_content=brandCavalier");

        ViewButton btn3 = new ViewButton();
        btn3.setName("宝骏310首发");
        btn3.setUrl("http://c."+env+".com/detail/53013.htm?utm_source=Weixin_Dyh&utm_medium=cdl&utm_term=a&utm_content=brandbaojun310");

        
        Menu menu = new Menu();
        menu.setButton(new Button[]{btn1,btn2,btn3});
        
        return menu;
    }

    public static void main(String[] args) {
        //可修改到不同的环境：sit, pre, chexiang
        String env = "chexiang"; 
        
        String appId = null; 
        String appSecret = null;
        if(env.equals("sit")) {
            appId = SIT_APP_ID;
            appSecret = SIT_APP_SECRET;
        } else if(env.equals("pre")) {
            appId = PRE_APP_ID;
            appSecret = PRE_APP_SECRET;
        } else if(env.equals("chexiang")) {
            appId = PRD_APP_ID;
            appSecret = PRD_APP_SECRET;
        }
        
        //到redis中查对应的token值,key: promotion_wx.AccessToken_{appId}
        //String token = "";
        Token token = CommonUtil.getAccessToken(appId, appSecret);
        if (token != null) {
            int result = MenuUtil.createMenu(getMenuNew(env), token.getToken());
            if (result == 0) {
                System.out.println("创建菜单成功");
            } else {
                System.out.println("创建菜单失败");
            }
        }
    }

}
