/**
 *
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName : MenuManager.java
 * Author : 何剑
 * Date : 2014年9月22日
 * 
 */
package com.saic.ebiz.market.common.entity.menu.manager;

import com.saic.ebiz.market.common.entity.authentication.Token;
import com.saic.ebiz.market.common.entity.menu.Button;
import com.saic.ebiz.market.common.entity.menu.ClickButon;
import com.saic.ebiz.market.common.entity.menu.ComplexButton;
import com.saic.ebiz.market.common.entity.menu.Menu;
import com.saic.ebiz.market.common.util.CommonUtil;
import com.saic.ebiz.market.common.util.MenuUtil;

/**
 * @author hejian
 *
 *  @date 2014年9月22日
 */
public class MenuManager {
    public static Menu getMenu(){
        ClickButon btn11 = new ClickButon();
        btn11.setName("询价购车");
        btn11.setKey("saic_of_mine");
        
        ClickButon btn12 = new ClickButon();
        btn12.setName("一口价");
        btn12.setKey("solid_price");
        
        ClickButon btn21 = new ClickButon();
        btn21.setName("第一年盛典");
        btn21.setKey("first_year_ceremony");
        
        ClickButon btn31 = new ClickButon();
        btn31.setName("在线咨询");
        btn31.setKey("service_online");
        
        ClickButon btn32 = new ClickButon();
        btn32.setName("客服电话");
        btn32.setKey("service_phone");
        
        ComplexButton mainBtn1 = new ComplexButton();
        mainBtn1.setName("车享购");
        mainBtn1.setSub_button(new Button[]{btn11,btn12});
        
        ComplexButton mainBtn2 = new ComplexButton();
        mainBtn2.setName("精彩活动");
        mainBtn2.setSub_button(new Button[]{btn21});
        
        ComplexButton mainBtn3 = new ComplexButton();
        mainBtn3.setName("个人中心");
        mainBtn3.setSub_button(new Button[]{btn31,btn32});
        
        Menu menu = new Menu();
        menu.setButton(new Button[]{mainBtn1,mainBtn2,mainBtn3});
//        
//        return menu;
    	return SaicMenuManager.getMenuNew("pre");
    }
    
    public static void main(String[] args) {
        //到redistribute中查对应的值, key:
        //key: promotion_wx.AccessToken_{appId}
        String token = "";
        //Token token = CommonUtil.getAccessToken("wx867e1eccd949be40", "569db832b89eb72f009d2c4bcd981859");
        if(token != null){
            int result = MenuUtil.createMenu(getMenu(), token);
            if(result == 0){
                System.out.println("创建菜单成功");
            }else{
                System.out.println("创建菜单失败");
            }
        }
    }
}
