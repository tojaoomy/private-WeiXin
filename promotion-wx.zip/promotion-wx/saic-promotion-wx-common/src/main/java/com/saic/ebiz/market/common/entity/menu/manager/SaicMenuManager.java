
package com.saic.ebiz.market.common.entity.menu.manager;

import com.saic.ebiz.market.common.entity.authentication.Token;
import com.saic.ebiz.market.common.entity.menu.Button;
import com.saic.ebiz.market.common.entity.menu.ClickButon;
import com.saic.ebiz.market.common.entity.menu.ComplexButton;
import com.saic.ebiz.market.common.entity.menu.Menu;
import com.saic.ebiz.market.common.entity.menu.ViewButton;
import com.saic.ebiz.market.common.util.CommonUtil;
import com.saic.ebiz.market.common.util.MenuUtil;

/**
 * @author hejian
 * 
 * 车享新车服务号菜单
 * @date 2014年9月22日
 */
public class SaicMenuManager {
    
    
    private static final String SIT_APP_ID = "wx867e1eccd949be40";
    private static final String SIT_APP_SECRET = "569db832b89eb72f009d2c4bcd981859";
    
    private static final String PRE_APP_ID = "wx8a42af69b34b280e";
    private static final String PRE_APP_SECRET = "e944d912a3f4dc8469d9b3630837f4f5";

    private static final String PRD_APP_ID = "wxc2c9c0c1d5115808";
    private static final String PRD_APP_SECRET = "bdf9bedfd1e36dc2797cddc02847cb88";
    
    
    public static Menu getMenuNew(String env){
    	
        
//        ViewButton btn1 = new ViewButton();
//        btn1.setName("车享88节");
//        btn1.setUrl("http://m.car."+env+".com/promotion/baba/main.htm");
        
        //菜单1
//        ViewButton btn1_1 = new ViewButton();
//        btn1_1.setName("88节主会场");
//        btn1_1.setUrl("http://m.car."+env+".com/promotion/baba/main.htm");
//        
//        ViewButton btn1_2 = new ViewButton();
//        btn1_2.setName("人脉是金");
//        if(env.equals("chexiang")) {
//            btn1_2.setUrl("http://mgo.chexiang.com/spreadPraise/home?channel=CX_ZC_H5_praise__redbag_20160808&H5Click");
//        } else {
//            btn1_2.setUrl("http://mgo."+env+".chexiang.com/spreadPraise/home?channel=CX_ZC_H5_praise__redbag_20160808&H5Click");
//        }
//        
//        ViewButton btn1_3 = new ViewButton();
//        btn1_3.setName("新车会场");
//        btn1_3.setUrl("http://m.car."+env+".com/promotion/baba/branch.htm");
//        
//        ComplexButton btn1 = new ComplexButton();
//        btn1.setName("车享88节");
//        btn1.setSub_button(new Button[]{btn1_1,btn1_2,btn1_3});
        
        
        //菜单1
//        ClickButon btn1 = new ClickButon();
//        btn1.setName("车知道");
//        btn1.setKey("club");  	
//    	
//        ViewButton btn2_0 = new ViewButton();
//        btn2_0.setName("金九银十");
//        btn2_0.setUrl("http://c."+env+".com/golden/main.htm");
//
//		ViewButton btn2_1 = new ViewButton();
//		btn2_1.setName("特价车");
//		btn2_1.setUrl("http://c."+env+".com/promotion/index.htm?utm_source=Weixin_xinchecdl&utm_medium=B&utm_term=&utm_content=&utm_campaign=tjc");
//		
//    	ViewButton btn2_2 = new ViewButton();
//    	btn2_2.setName("贷款购车");
//    	btn2_2.setUrl("http://m.car."+env+".com/finance/index.htm");
//    	
//    	ViewButton btn2_3 = new ViewButton();
//    	btn2_3.setName("车享新车");
//    	btn2_3.setUrl("http://m.car."+env+".com/mall/index.htm");
//
//    	ComplexButton btn2 = new ComplexButton();
//        btn2.setName("我要买车");
//        btn2.setSub_button(new Button[]{btn2_0,btn2_1,btn2_2,btn2_3});
        
        
        
        //菜单1
        ViewButton btn1_1 = new ViewButton();
        btn1_1.setName("彩礼驾到");
        btn1_1.setUrl("http://c."+env+".com/golden/main.htm?utm_source=chexiangxinche&utm_medium=caidanlan&utm_term=a&utm_content=cailijin9yin10");
        
        ViewButton btn1_2 = new ViewButton();
        btn1_2.setName("金秋送爽");
        btn1_2.setUrl("http://c."+env+".com/golden/branch.htm?utm_source=chexiangxinche&utm_medium=caidanlan&utm_term=a&utm_content=jinqiujin9yin10");
        
        ComplexButton btn1 = new ComplexButton();
        btn1.setName("彩礼驾到");
        btn1.setSub_button(new Button[]{btn1_1,btn1_2});
        
        //菜单2
        ViewButton btn2_1 = new ViewButton();
        btn2_1.setName("享特价");
        btn2_1.setUrl("http://m.car."+env+".com/mall/list.htm?marketTagName=golden?utm_source=chexiangxinche&utm_medium=caidanlan&utm_term=a&utm_content=tejiajin9yin10");
        
        ViewButton btn2_2 = new ViewButton();
        btn2_2.setName("贷款购车");
        btn2_2.setUrl("http://m.car."+env+".com/finance/index.htm");
        
        ViewButton btn2_3 = new ViewButton();
        btn2_3.setName("车享新车");
        btn2_3.setUrl("http://m.car."+env+".com/mall/index.htm");

        ComplexButton btn2 = new ComplexButton();
        btn2.setName("我要买车");
        btn2.setSub_button(new Button[]{btn2_1,btn2_2,btn2_3});
        
        
        //菜单3
        ViewButton btn3 = new ViewButton();
        btn3.setName("我的");
        btn3.setUrl("http://member."+env+".com/m/index.htm");
        

        
        Menu menu = new Menu();
        menu.setButton(new Button[]{btn1,btn2,btn3});
        
        return menu;
    }

    public static void main(String[] args) {
        
        //可修改到不同的环境：sit, pre, chexiang
        String env = "chexiang";
        
//        String appId = null; 
//        String appSecret = null;
//        if(env.equals("sit")) {
//            appId = SIT_APP_ID;
//            appSecret = SIT_APP_SECRET;
//        } else if(env.equals("pre")) {
//            appId = PRE_APP_ID;
//            appSecret = PRE_APP_SECRET;
//        } else if(env.equals("chexiang")) {
//            appId = PRD_APP_ID;
//            appSecret = PRD_APP_SECRET;
//        }
        
        //到redis中查对应的token值, 在redis中搜索*AccessToken*, 找到key: promotion_wx.AccessToken_{appId}
        String token = "Avj6pGFlxp4h9d2towdEd7DojkoXUKkFzHiJ2Xo1P4zY1j5MkE5xJAPTWobqw4oTxLd7JHxXr1th_49cTp9r2yGHGqsKZJoGbjng8soUFm5fQ-0UeMnJKaPK1mK3gHMIYJGfAHAQBY";
        //Token token = CommonUtil.getAccessToken(appId, appSecret);
        if (token != null) {
            int result = MenuUtil.createMenu(getMenuNew(env), token);
            if (result == 0) {
                System.out.println("创建菜单成功");
            } else {
                System.out.println("创建菜单失败");
            }
        }
    }
}
