/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.common.entity.praise;

import java.util.List;

import com.saic.ebiz.promotion.service.vo.Praise;

/**
 * @author hejian
 *
 */
public class PraiseResult {
	/**
	 * 该车型该活动用户首次点赞返回状态
	 *  0	SUCCESS	成功
	 *	4	NOTSTARTED	未开始
	 *	5	ENDED	已结束
	 *
	 * 该车型该活动用户已经点赞，重复点赞返回状态
	 *  1	TWICE	同一活动同一车型今天已点赞
	 *	2	UNQUALIFIED	用户今天已点赞，不能领券
	 *	5	ENDED	车型点赞次数已满，不能领券
	 *	8	FULL	用户已领3张券
	 *	9	RESULT_FAIL	券已领完
	 */
	private int praiseStatus = -1;
	
	/**
	 * 用户点击点赞后，获取最新的点赞数据
	 */
	private Praise praise;
	
	/**
	 * 用户红包
	 */
	private List<String> didiCoupon;

	/**
	 * @return the praiseStatus
	 */
	public int getPraiseStatus() {
		return praiseStatus;
	}

	/**
	 * @param praiseStatus the praiseStatus to set
	 */
	public void setPraiseStatus(int praiseStatus) {
		this.praiseStatus = praiseStatus;
	}

	/**
	 * @return the praise
	 */
	public Praise getPraise() {
		return praise;
	}

	/**
	 * @param praise the praise to set
	 */
	public void setPraise(Praise praise) {
		this.praise = praise;
	}

	/**
	 * @return the didiCoupon
	 */
	public List<String> getDidiCoupon() {
		return didiCoupon;
	}

	/**
	 * @param didiCoupon the didiCoupon to set
	 */
	public void setDidiCoupon(List<String> didiCoupon) {
		this.didiCoupon = didiCoupon;
	}
	
}
