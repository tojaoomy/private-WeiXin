/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.common.entity.user;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import com.saic.ebiz.market.common.util.RegexUtil;

/**
 * 个人基本信息 Bean. <br>
 */
public class BasicPersonalInfoBean implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -4187134619375322031L;

	/**
     * 用户id.
     */
    private Long userId;

    /**
     * 真实姓名.
     */
    @NotEmpty(message = "请输入姓名")
    private String name;

    /**
     * 昵称.
     */
    @Length(min = 0, max = 10, message = "最多输入10个字符")
    private String nickName;

    /**
     * 证件类型.
     */
    private Integer idStyle;

    /**
     * 证件号码.
     */
    private String idNumber;

    /**
     * 性别.
     */
    private String sex;

    /**
     * 生日 - 年.
     */
    private String year;

    /**
     * 生日 - 月.
     */
    private String month;

    /**
     * 生日 - 日.
     */
    private String day;

    /**
     * 手机.
     */
    @NotEmpty(message = "请输入手机号码")
    @Pattern(regexp = RegexUtil.REGEX_PHONE, message = "手机号码不符合规范!")
    private String mobile;

    /**
     * 手机是否绑定.
     */
    private Integer isMobileBlock;

    /**
     * 邮件地址.
     */
    @NotEmpty(message = "请输入邮箱")
    @Pattern(regexp = RegexUtil.REGEX_EMAIL,message = "请输入正确的邮箱地址")
    private String email;

    /**
     * 邮件是否绑定.
     */
    private Integer isEmailBlock;

    /**
     * 所在地-省.
     */
    private String province;

    /**
     * 所在地-市.
     */
    private String city;

    /**
     * 所在地-县.
     */
    private String district;

    /**
     * 详细地址.
     */
    @NotEmpty(message = "请输入详细地址")
    private String address;

    /**
     * 邮编.
     */
    @NotEmpty(message = "请输入邮编")
    private String zipCode;

    /**
     * 验证码.
     */
    @NotEmpty(message = "请输入验证码")
    private String captcha;

    /**
     * 获取验证码倒计时.
     */
    private int countdown;

    /**
     * 是否可用.
     */
    private String isFlag;

    /**
     * 注册的邮箱网站.
     */
    private String registerWebsit;

    /**
     * 格式化隐藏的eamil地址.
     */
    private String partHideEmail;

    /**
     * 手机验证码.
     */
    private String phoneCode;

    /**
     * 格式化隐藏的手机号码.
     */
    private String partHidePhone;

    /**
     * 密码.
     */
    private String pwd;

    /**
     * 返回的错误信息结果.
     */
    private String resultMessage;
    
    /** 跳转url*/
    private String backUrl;

    /**
     * Gets the captcha.
     * 
     * @return the captcha
     */
    public String getCaptcha() {
        return captcha;
    }

    /**
     * Sets the captcha.
     * 
     * @param captcha the captcha to set
     */
    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }


    /**
     * Gets the user id.
     * 
     * @return the user id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     * 
     * @param userId the user id to set
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * Gets the name.
     * 
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     * 
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the nick name.
     * 
     * @return the nickName
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * Sets the nick name.
     * 
     * @param nickName the nickName to set
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * Gets the id number.
     * 
     * @return the idNumber
     */
    public String getIdNumber() {
        return idNumber;
    }

    /**
     * Sets the id number.
     * 
     * @param idNumber the idNumber to set
     */
    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    /**
     * Gets the sex.
     * 
     * @return the sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * Sets the sex.
     * 
     * @param sex the sex to set
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * Gets the year.
     * 
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * Sets the year.
     * 
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * Gets the month.
     * 
     * @return the month
     */
    public String getMonth() {
        return month;
    }

    /**
     * Sets the month.
     * 
     * @param month the month to set
     */
    public void setMonth(String month) {
        this.month = month;
    }

    /**
     * Gets the day.
     * 
     * @return the day
     */
    public String getDay() {
        return day;
    }

    /**
     * Sets the day.
     * 
     * @param day the day to set
     */
    public void setDay(String day) {
        this.day = day;
    }

    /**
     * Gets the mobile.
     * 
     * @return the mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * Sets the mobile.
     * 
     * @param mobile the mobile to set
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    /**
     * Gets the email.
     * 
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email.
     * 
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the province.
     * 
     * @return the province
     */
    public String getProvince() {
        return province;
    }

    /**
     * Sets the province.
     * 
     * @param province the province to set
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * Gets the city.
     * 
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the city.
     * 
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Gets the district.
     * 
     * @return the district
     */
    public String getDistrict() {
        return district;
    }

    /**
     * Sets the district.
     * 
     * @param district the district to set
     */
    public void setDistrict(String district) {
        this.district = district;
    }

    /**
     * Gets the address.
     * 
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the address.
     * 
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Gets the zip code.
     * 
     * @return the zipCode
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * Sets the zip code.
     * 
     * @param zipCode the zipCode to set
     */
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * Gets the checks if is mobile block.
     * 
     * @return the isMobileBlock
     */
    public Integer getIsMobileBlock() {
        return isMobileBlock;
    }

    /**
     * Sets the checks if is mobile block.
     * 
     * @param isMobileBlock the isMobileBlock to set
     */
    public void setIsMobileBlock(Integer isMobileBlock) {
        this.isMobileBlock = isMobileBlock;
    }

    /**
     * Gets the checks if is email block.
     * 
     * @return the isEmailBlock
     */
    public Integer getIsEmailBlock() {
        return isEmailBlock;
    }

    /**
     * Sets the checks if is email block.
     * 
     * @param isEmailBlock the isEmailBlock to set
     */
    public void setIsEmailBlock(Integer isEmailBlock) {
        this.isEmailBlock = isEmailBlock;
    }

    /**
     * Gets the id style.
     * 
     * @return the idStyle
     */
    public Integer getIdStyle() {
        return idStyle;
    }

    /**
     * Sets the id style.
     * 
     * @param idStyle the idStyle to set
     */
    public void setIdStyle(Integer idStyle) {
        this.idStyle = idStyle;
    }

    /**
     * Gets the checks if is flag.
     * 
     * @return the isFlag
     */
    public String getIsFlag() {
        return isFlag;
    }

    /**
     * Sets the checks if is flag.
     * 
     * @param isFlag the isFlag to set
     */
    public void setIsFlag(String isFlag) {
        this.isFlag = isFlag;
    }

    /**
     * Gets the register websit.
     * 
     * @return the registerWebsit
     */
    public String getRegisterWebsit() {
        return registerWebsit;
    }

    /**
     * Sets the register websit.
     * 
     * @param registerWebsit the registerWebsit to set
     */
    public void setRegisterWebsit(String registerWebsit) {
        this.registerWebsit = registerWebsit;
    }

    /**
     * Gets the part hide email.
     * 
     * @return the partHideEmail
     */
    public String getPartHideEmail() {
        return partHideEmail;
    }

    /**
     * Sets the part hide email.
     * 
     * @param partHideEmail the partHideEmail to set
     */
    public void setPartHideEmail(String partHideEmail) {
        this.partHideEmail = partHideEmail;
    }

    /**
     * Gets the phone code.
     * 
     * @return the phoneCode
     */
    public String getPhoneCode() {
        return phoneCode;
    }

    /**
     * Sets the phone code.
     * 
     * @param phoneCode the phoneCode to set
     */
    public void setPhoneCode(String phoneCode) {
        this.phoneCode = phoneCode;
    }

    /**
     * Gets the part hide phone.
     * 
     * @return the partHidePhone
     */
    public String getPartHidePhone() {
        return partHidePhone;
    }

    /**
     * Sets the part hide phone.
     * 
     * @param partHidePhone the partHidePhone to set
     */
    public void setPartHidePhone(String partHidePhone) {
        this.partHidePhone = partHidePhone;
    }

    /**
     * Gets the result message.
     * 
     * @return the resultMessage
     */
    public String getResultMessage() {
        return resultMessage;
    }

    /**
     * Sets the result message.
     * 
     * @param resultMessage the resultMessage to set
     */
    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    /**
     * Gets the countdown.
     * 
     * @return the countdown
     */
    public int getCountdown() {
        return countdown;
    }

    /**
     * Sets the countdown.
     * 
     * @param countdown the countdown to set
     */
    public void setCountdown(int countdown) {
        this.countdown = countdown;
    }

    /**
     * Gets the pwd.
     * 
     * @return the pwd
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * Sets the pwd.
     * 
     * @param pwd the pwd to set
     */
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * @return the backUrl
     */
    public String getBackUrl() {
        return backUrl;
    }

    /**
     * @param backUrl the backUrl to set
     */
    public void setBackUrl(String backUrl) {
        this.backUrl = backUrl;
    }

}
