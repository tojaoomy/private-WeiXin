/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.common.entity.user;

import java.io.Serializable;
import java.util.List;

/**
 * 家庭工作情况 Bean. <br>
 */
public class FamilyInfoBean implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -5490646908384480144L;

	/**
     * 用户id.
     */
    private Integer userId;

    /**
     * 婚姻状况.
     */
    private String maritalStatus;

    /**
     * 小孩年龄.
     */
    private List<String> kidAge;

    /**
     * 行业类别.
     */
    private String industryStyle;

    /**
     * 单位名称.
     */
    private String unitName;

    /**
     * 职业.
     */
    private String profession;

    /**
     * 职务.
     */
    private String position;

    /**
     * 个人月收入.
     */
    private String income;
    
    /**
     * 教育程度.
     */
    private String education;
    
    /**
     * 兴趣爱好.
     */
    private String interests;

    /**
     * Gets the user id.
     * 
     * @return the userId
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     * 
     * @param userId the userId to set
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * Gets the marital status.
     * 
     * @return the maritalStatus
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Sets the marital status.
     * 
     * @param maritalStatus the maritalStatus to set
     */
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    /**
     * Gets the kid age.
     * 
     * @return the kidAge
     */
    public List<String> getKidAge() {
        return kidAge;
    }

    /**
     * Sets the kid age.
     * 
     * @param kidAge the kidAge to set
     */
    public void setKidAge(List<String> kidAge) {
        this.kidAge = kidAge;
    }

    /**
     * Gets the industry style.
     * 
     * @return the industryStyle
     */
    public String getIndustryStyle() {
        return industryStyle;
    }

    /**
     * Sets the industry style.
     * 
     * @param industryStyle the industryStyle to set
     */
    public void setIndustryStyle(String industryStyle) {
        this.industryStyle = industryStyle;
    }

    /**
     * Gets the unit name.
     * 
     * @return the unitName
     */
    public String getUnitName() {
        return unitName;
    }

    /**
     * Sets the unit name.
     * 
     * @param unitName the unitName to set
     */
    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    /**
     * Gets the profession.
     * 
     * @return the profession
     */
    public String getProfession() {
        return profession;
    }

    /**
     * Sets the profession.
     * 
     * @param profession the profession to set
     */
    public void setProfession(String profession) {
        this.profession = profession;
    }

    /**
     * Gets the position.
     * 
     * @return the position
     */
    public String getPosition() {
        return position;
    }

    /**
     * Sets the position.
     * 
     * @param position the position to set
     */
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * Gets the income.
     * 
     * @return the income
     */
    public String getIncome() {
        return income;
    }

    /**
     * Sets the income.
     * 
     * @param income the income to set
     */
    public void setIncome(String income) {
        this.income = income;
    }

    /**
     * Gets the education.
     * 
     * @return the education
     */
    public String getEducation() {
        return education;
    }

    /**
     * Sets the education.
     * 
     * @param education the education to set
     */
    public void setEducation(String education) {
        this.education = education;
    }

    /**
     * Gets the interests.
     * 
     * @return the interests
     */
    public String getInterests() {
        return interests;
    }

    /**
     * Sets the interests.
     * 
     * @param interests the interests to set
     */
    public void setInterests(String interests) {
        this.interests = interests;
    }
    
}
