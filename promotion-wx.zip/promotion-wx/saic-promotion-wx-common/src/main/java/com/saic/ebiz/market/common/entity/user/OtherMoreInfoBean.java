/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.common.entity.user;

import java.io.Serializable;

/**
 * 其他更多信息 Bean. <br>
 */
public class OtherMoreInfoBean implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -1951457937872515612L;
	/**
     * 用户id.
     */
    private Integer userId;
    /**
     * 开户银行.
     */
    private String openBank;
    /**
     * 开户银行省市.
     */
    private String openBankProvince;
    /**
     * 开户银行帐号.
     */
    private String openBankAccount;
    /**
     * 开户个人名称.
     */
    private String openPersonalName;
    /**
     * 传真号.
     */
    private String faxNumber;
    /**
     * QQ号.
     */
    private Integer qqNumber;
    /**
     * 个人网站.
     */
    private String personalWebsite;
    /**
     * 微博帐号.
     */
    private String weiboAccount;
    /**
     * 微信帐号.
     */
    private String weixinAccount;

    /**
     * Gets the user id.
     * 
     * @return the userId
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     * 
     * @param userId the userId to set
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * Gets the open bank.
     * 
     * @return the openBank
     */
    public String getOpenBank() {
        return openBank;
    }

    /**
     * Sets the open bank.
     * 
     * @param openBank the openBank to set
     */
    public void setOpenBank(String openBank) {
        this.openBank = openBank;
    }

    /**
     * Gets the open bank province.
     * 
     * @return the openBankProvince
     */
    public String getOpenBankProvince() {
        return openBankProvince;
    }

    /**
     * Sets the open bank province.
     * 
     * @param openBankProvince the openBankProvince to set
     */
    public void setOpenBankProvince(String openBankProvince) {
        this.openBankProvince = openBankProvince;
    }

    /**
     * Gets the open bank account.
     * 
     * @return the openBankAccount
     */
    public String getOpenBankAccount() {
        return openBankAccount;
    }

    /**
     * Sets the open bank account.
     * 
     * @param openBankAccount the openBankAccount to set
     */
    public void setOpenBankAccount(String openBankAccount) {
        this.openBankAccount = openBankAccount;
    }

    /**
     * Gets the open personal name.
     * 
     * @return the openPersonalName
     */
    public String getOpenPersonalName() {
        return openPersonalName;
    }

    /**
     * Sets the open personal name.
     * 
     * @param openPersonalName the openPersonalName to set
     */
    public void setOpenPersonalName(String openPersonalName) {
        this.openPersonalName = openPersonalName;
    }

    /**
     * Gets the fax number.
     * 
     * @return the faxNumber
     */
    public String getFaxNumber() {
        return faxNumber;
    }

    /**
     * Sets the fax number.
     * 
     * @param faxNumber the faxNumber to set
     */
    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    /**
     * Gets the qq number.
     * 
     * @return the qqNumber
     */
    public Integer getQqNumber() {
        return qqNumber;
    }

    /**
     * Sets the qq number.
     * 
     * @param qqNumber the qqNumber to set
     */
    public void setQqNumber(Integer qqNumber) {
        this.qqNumber = qqNumber;
    }

    /**
     * Gets the personal website.
     * 
     * @return the personalWebsite
     */
    public String getPersonalWebsite() {
        return personalWebsite;
    }

    /**
     * Sets the personal website.
     * 
     * @param personalWebsite the personalWebsite to set
     */
    public void setPersonalWebsite(String personalWebsite) {
        this.personalWebsite = personalWebsite;
    }

    /**
     * Gets the weibo account.
     * 
     * @return the weiboAccount
     */
    public String getWeiboAccount() {
        return weiboAccount;
    }

    /**
     * Sets the weibo account.
     * 
     * @param weiboAccount the weiboAccount to set
     */
    public void setWeiboAccount(String weiboAccount) {
        this.weiboAccount = weiboAccount;
    }

    /**
     * Gets the weixin account.
     * 
     * @return the weixinAccount
     */
    public String getWeixinAccount() {
        return weixinAccount;
    }

    /**
     * Sets the weixin account.
     * 
     * @param weixinAccount the weixinAccount to set
     */
    public void setWeixinAccount(String weixinAccount) {
        this.weixinAccount = weixinAccount;
    }
    
}
