/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.common.entity.user;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 用户所有属性类<br>
 * .
 * @author chenliang
 */
public class UserBean implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -4799950993901535987L;
	/** 用户编号. */
    private Integer userId;
    /** 用户名. */
    @NotEmpty(message = "用户名必须填写!")
    private String userName;
    /**用户名字类型,1手机号,2邮箱,3用户名**/
    private int userNameType=-1;
    /** 用户密码. */
    @NotEmpty(message = "密码必须填写!")
    private String password;

    /** 确认用户密码. */
//    @NotEmpty(message = "确认密码必须填写!")
    private String newPassword;

    /** 用户旧密码. */
//    @NotEmpty(message = "请输入登录密码!")
    private String oldPassword;
    
    /** 密码强度. */
    private int pwdstrong;

    /** 用户注册或登录成功的回调url. */
    private String backUrl;

    /** 用户基础信息. */
    private BasicPersonalInfoBean basicInfo;

    /** 用户家庭信息. */
    private FamilyInfoBean familyInfo;

    /** 用户其它信息. */
    private OtherMoreInfoBean otherInfo;

    /** 新的邮箱帐号. */
    private String newBindEmail;

    /** 新邦定的手机号码. */
    private String newBindPhone;

    /** 邀请好友签名串. */
    private String registerMd5Sn;

    /** 邀请好友id. */
    private Long inviteid;

    /** 邦定的邮箱帐号. */
//    @NotEmpty(message = "邮箱不能为空!")
//    @Email(message = "邮箱格式不正确!")
    private String bindEmail;

    /** 半隐藏格式的邮箱(页面显示). */
    private String partMail;

    /** 格式化手机号码. */
    private String hidePhone;

    /** 邦定的手机号码. */
    private String phoneNum;

    /** 是否邦定手机. */
    private String isBindPhoneFalg;

    /** 是否邦邮箱. */
    private String isBindMailFlag;

    /** 验证码. */
    @NotEmpty(message = "验证码不能为空!")
    private String checkCode;

    /** 用户注册的网站. */
    private String handEmail;

    /** 隐藏标示. */
    private String HandFlag;

    /** 登陆url. */
    private String loginImg;

    /** 登陆或者注册 0/1 */
    private String actionType;
    
    
    /**
     * Gets the user id.
     * 
     * @return the userId
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     * 
     * @param userId the userId to set
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * Gets the password.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     * 
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the basic info.
     * 
     * @return the basicInfo
     */
    public BasicPersonalInfoBean getBasicInfo() {
        return basicInfo;
    }

    /**
     * Sets the basic info.
     * 
     * @param basicInfo the basicInfo to set
     */
    public void setBasicInfo(BasicPersonalInfoBean basicInfo) {
        this.basicInfo = basicInfo;
    }

    /**
     * Gets the family info.
     * 
     * @return the familyInfo
     */
    public FamilyInfoBean getFamilyInfo() {
        return familyInfo;
    }

    /**
     * Sets the family info.
     * 
     * @param familyInfo the familyInfo to set
     */
    public void setFamilyInfo(FamilyInfoBean familyInfo) {
        this.familyInfo = familyInfo;
    }

    /**
     * Gets the other info.
     * 
     * @return the otherInfo
     */
    public OtherMoreInfoBean getOtherInfo() {
        return otherInfo;
    }

    /**
     * Sets the other info.
     * 
     * @param otherInfo the otherInfo to set
     */
    public void setOtherInfo(OtherMoreInfoBean otherInfo) {
        this.otherInfo = otherInfo;
    }

    /**
     * Gets the user name.
     * 
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the user name.
     * 
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Gets the new password.
     * 
     * @return the newPassword
     */
    public String getNewPassword() {
        return newPassword;
    }

    /**
     * Sets the new password.
     * 
     * @param newPassword the newPassword to set
     */
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    /**
     * Gets the old password.
     * 
     * @return the oldPassword
     */
    public String getOldPassword() {
        return oldPassword;
    }

    /**
     * Sets the old password.
     * 
     * @param oldPassword the oldPassword to set
     */
    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    /**
     * Gets the bind email.
     * 
     * @return the bind email
     */
    public String getBindEmail() {
        return bindEmail;
    }

    /**
     * Sets the bind email.
     * 
     * @param bindEmail the new bind email
     */
    public void setBindEmail(String bindEmail) {
        this.bindEmail = bindEmail;
    }

    /**
     * Gets the check code.
     * 
     * @return the check code
     */
    public String getCheckCode() {
        return checkCode;
    }

    /**
     * Sets the check code.
     * 
     * @param checkCode the new check code
     */
    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    /**
     * Gets the phone num.
     * 
     * @return the phoneNum
     */
    public String getPhoneNum() {
        return phoneNum;
    }

    /**
     * Sets the phone num.
     * 
     * @param phoneNum the phoneNum to set
     */
    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    /**
     * Gets the hand email.
     * 
     * @return the handEmail
     */
    public String getHandEmail() {
        return handEmail;
    }

    /**
     * Sets the hand email.
     * 
     * @param handEmail the handEmail to set
     */
    public void setHandEmail(String handEmail) {
        this.handEmail = handEmail;
    }

    /**
     * Gets the part mail.
     * 
     * @return the partMail
     */
    public String getPartMail() {
        return partMail;
    }

    /**
     * Sets the part mail.
     * 
     * @param partMail the partMail to set
     */
    public void setPartMail(String partMail) {
        this.partMail = partMail;
    }

    /**
     * Gets the new bind email.
     * 
     * @return the newBindEmail
     */
    public String getNewBindEmail() {
        return newBindEmail;
    }

    /**
     * Sets the new bind email.
     * 
     * @param newBindEmail the newBindEmail to set
     */
    public void setNewBindEmail(String newBindEmail) {
        this.newBindEmail = newBindEmail;
    }

    /**
     * Gets the hide phone.
     * 
     * @return the hidePhone
     */
    public String getHidePhone() {
        return hidePhone;
    }

    /**
     * Sets the hide phone.
     * 
     * @param hidePhone the hidePhone to set
     */
    public void setHidePhone(String hidePhone) {
        this.hidePhone = hidePhone;
    }

    /**
     * Gets the new bind phone.
     * 
     * @return the newBindPhone
     */
    public String getNewBindPhone() {
        return newBindPhone;
    }

    /**
     * Sets the new bind phone.
     * 
     * @param newBindPhone the newBindPhone to set
     */
    public void setNewBindPhone(String newBindPhone) {
        this.newBindPhone = newBindPhone;
    }

    /**
     * Gets the checks if is bind phone falg.
     * 
     * @return the isBindPhoneFalg
     */
    public String getIsBindPhoneFalg() {
        return isBindPhoneFalg;
    }

    /**
     * Sets the checks if is bind phone falg.
     * 
     * @param isBindPhoneFalg the isBindPhoneFalg to set
     */
    public void setIsBindPhoneFalg(String isBindPhoneFalg) {
        this.isBindPhoneFalg = isBindPhoneFalg;
    }

    /**
     * Gets the checks if is bind mail flag.
     * 
     * @return the isBindMailFlag
     */
    public String getIsBindMailFlag() {
        return isBindMailFlag;
    }

    /**
     * Sets the checks if is bind mail flag.
     * 
     * @param isBindMailFlag the isBindMailFlag to set
     */
    public void setIsBindMailFlag(String isBindMailFlag) {
        this.isBindMailFlag = isBindMailFlag;
    }

    /**
     * Gets the back url.
     * 
     * @return the backUrl
     */
    public String getBackUrl() {
        return backUrl;
    }

    /**
     * Sets the back url.
     * 
     * @param backUrl the backUrl to set
     */
    public void setBackUrl(String backUrl) {
        this.backUrl = backUrl;
    }

    /**
     * Gets the hand flag.
     * 
     * @return the handFlag
     */
    public String getHandFlag() {
        return HandFlag;
    }

    /**
     * Sets the hand flag.
     * 
     * @param handFlag the handFlag to set
     */
    public void setHandFlag(String handFlag) {
        HandFlag = handFlag;
    }

    /**
     * Gets the login img.
     * 
     * @return the loginImg
     */
    public String getLoginImg() {
        return loginImg;
    }

    /**
     * Sets the login img.
     * 
     * @param loginImg the loginImg to set
     */
    public void setLoginImg(String loginImg) {
        this.loginImg = loginImg;
    }

    /**
     * Gets the actionType.
     * 
     * @return the actionType
     */
    public String getActionType() {
        return actionType;
    }

    /**
     * Sets the actionType.
     * 
     * @param actionType the actionType to set
     */
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    /**
     * Gets the registerMd5Sn.
     * 
     * @return the registerMd5Sn
     */
    public String getRegisterMd5Sn() {
        return registerMd5Sn;
    }

    /**
     * Sets the registerMd5Sn.
     * 
     * @param registerMd5Sn the registerMd5Sn to set
     */
    public void setRegisterMd5Sn(String registerMd5Sn) {
        this.registerMd5Sn = registerMd5Sn;
    }

    /**
     * Gets the inviteid.
     * 
     * @return the inviteid
     */
    public Long getInviteid() {
        return inviteid;
    }

    /**
     * Sets the inviteid.
     * 
     * @param inviteid the inviteid to set
     */
    public void setInviteid(Long inviteid) {
        this.inviteid = inviteid;
    }

    /**
     * @return the pwdstrong
     */
    public int getPwdstrong() {
        return pwdstrong;
    }

    /**
     * @param pwdstrong the pwdstrong to set
     */
    public void setPwdstrong(int pwdstrong) {
        this.pwdstrong = pwdstrong;
    }

	public int getUserNameType() {
		return userNameType;
	}

	public void setUserNameType(int userNameType) {
		this.userNameType = userNameType;
	}
    
}
