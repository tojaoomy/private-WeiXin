package com.saic.ebiz.market.common.util;

import java.util.UUID;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.WXconstant;
import com.saic.framework.redis.client.IRedisClient;

@Component
public class MyOpenIdTokenUtil {
	
//	@Resource
//	private SpringBinaryRedisClientImpl springRedisClient;
	
	@Resource(name="springRedisClient")
    private IRedisClient springRedisClient;
	
	
	 private Logger recordKeyLog = LoggerFactory.getLogger("RECORD-KEY");
	
	 //生产token
	public String setOpenIdToken(String OpenId, String WeiXinId){
		 recordKeyLog.info("setOpenIdToken方法参数:OpenId="+OpenId+"，WeiXinId="+WeiXinId);
		UUID uuid = UUID.randomUUID();
		String token = uuid.toString()+"--"+WeiXinId;
		 recordKeyLog.info("setOpenIdToken方法生成token="+token);
		 springRedisClient.setex(token,Constants.REDIS_NAME_SPACE, WXconstant.REDISTIME, OpenId);
		recordKeyLog.info("setOpenIdToken返回token="+token);
		return token;
	}
	
	//token换取openId
	public String getOpenIdToken(String token){
		 recordKeyLog.info("getOpenIdToken参数uuidStr="+token);
		String openId = springRedisClient.get(token,Constants.REDIS_NAME_SPACE,null);
		 recordKeyLog.info("getOpenIdToken获值OpenIdObj="+openId);
		return openId;
	}
	
	
	// 抢锁逻辑,抢到返回true,redis中该商品token置为true
	public boolean acquireTokenFromRedis(int reidsTokenType){
		    boolean result = false;
	        long retValue = 0;
	        try {
	            retValue = springRedisClient.setnx(WXconstant.REDIS_WX_TOKEN_KEY+reidsTokenType,Constants.REDIS_NAME_SPACE,WXconstant.REDIS_CACHE_TOKEN_VALUE);
	        } catch (Exception t) {
	        	recordKeyLog.error(t.getMessage());
	        }
	        if (retValue == 1) {
	            springRedisClient.expireAt(WXconstant.REDIS_WX_TOKEN_KEY+reidsTokenType,Constants.REDIS_NAME_SPACE, WXconstant.REDIS_CACHE_TOKEN_EXPIRE_TIME);// 设置失效时间
	            result = true; // 抢到令牌
	        }
	        // 当且仅当当前线程抢到redis令牌后，返回true，否则false
	        return result;
	}
	
	// 释放Token(独占锁)
    public void releaseTokenToRedis(int reidsTokenType) {
        springRedisClient.del(WXconstant.REDIS_WX_TOKEN_KEY+reidsTokenType,Constants.REDIS_NAME_SPACE);
    }
	
}
