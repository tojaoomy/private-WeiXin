/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.common.util;

import java.math.BigDecimal;
import java.util.Map;

import com.ibm.framework.uts.util.StringUtils;
import com.saic.ebiz.promotion.service.entity.WxOperLogEntity;

/**
 * @author hejian
 * 
 */
public class WXLoggerMutator {

	/**
	 * 记录文本消息记录
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logContentMessage(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setContent(requestMap.get("Content"));
		enLogEntity.setMsgId(requestMap.get("MsgId"));
	}

	/**
	 * 记录图片信息
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logImageMessage(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setPicUrl(requestMap.get("PicUrl"));
		enLogEntity.setMediaId(requestMap.get("MediaId"));
		enLogEntity.setMsgId(requestMap.get("MsgId"));
	}
	
	/**
	 * 记录语音信息
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logVoiceMessage(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setMediaFormat(requestMap.get("Format"));
		enLogEntity.setMediaId(requestMap.get("MediaId"));
		enLogEntity.setMsgId(requestMap.get("MsgId"));
	}
	
	/**
	 * 记录语音信息
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logVideoMessage(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setThumbMediaId(requestMap.get("ThumbMediaId"));
		enLogEntity.setMediaId(requestMap.get("MediaId"));
		enLogEntity.setMsgId(requestMap.get("MsgId"));
	}

	/**
	 * 记录地理位置记录
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logLocationMessage(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setLatitude(new BigDecimal(requestMap.get("Location_X")));
		enLogEntity.setLongitude(new BigDecimal(requestMap.get("Location_Y")));
		enLogEntity.setMapScale(new BigDecimal(requestMap.get("Scale")));
		enLogEntity.setGeoLabel(requestMap.get("Label"));
		enLogEntity.setMsgId(requestMap.get("MsgId"));
	}

	/**
	 * 记录文本消息记录
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logLinkMessage(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setTitle(requestMap.get("Title"));
		enLogEntity.setDescription(requestMap.get("Description"));
		enLogEntity.setUrl(requestMap.get("Url"));
		enLogEntity.setMsgId(requestMap.get("MsgId"));
	}


	/**
	 * 记录关注事件
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logEventSubscribe(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setEvent(requestMap.get("Event"));
		String ticket = requestMap.get("Ticket");
		String eventKey = requestMap.get("EventKey");
		
		if(StringUtils.hasText(ticket)){
			enLogEntity.setTicket(ticket);
		}
		
		if(StringUtils.hasText(eventKey)){
			enLogEntity.setEventKey(eventKey);
			enLogEntity.setChannelSource(eventKey.substring(eventKey.lastIndexOf("_") + 1));
		}else{
			enLogEntity.setChannelSource("99");
		}
	}

	/**
	 * 记录取消关注
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logEventUnsubscribe(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setEvent(requestMap.get("Event"));
	}

	/**
	 * 记录扫描二维码事件
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logEventScan(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setEvent(requestMap.get("Event"));
		enLogEntity.setTicket(requestMap.get("Ticket"));
		enLogEntity.setEventKey(requestMap.get("EventKey"));
	}

	/**
	 * 记录地理位置事件
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logEventLocation(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setEvent(requestMap.get("Event"));
		enLogEntity.setLatitude(new BigDecimal(requestMap.get("Latitude")));
		enLogEntity.setLongitude(new BigDecimal(requestMap.get("Longitude")));
		enLogEntity.setMapPrecision(new BigDecimal(requestMap.get("Precision")));
	}

	/**
	 * 记录菜单点击事件
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logEventClick(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
//		enLogEntity.setTicket(requestMap.get("Ticket"));
		enLogEntity.setTicket("CLICK");
		enLogEntity.setEventKey(requestMap.get("EventKey"));
	}

	/**
	 * 记录视图事件
	 * 
	 * @param enLogEntity
	 * @param requestMap
	 */
	public static void logEventView(WxOperLogEntity enLogEntity,
			Map<String, String> requestMap) {
		enLogEntity.setTicket("VIEW");
		enLogEntity.setEventKey(requestMap.get("EventKey"));
	}
	
}
