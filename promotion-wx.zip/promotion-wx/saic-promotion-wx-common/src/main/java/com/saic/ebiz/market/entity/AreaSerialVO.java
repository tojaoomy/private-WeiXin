/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

/**
 * @author hejian
 *
 */
public class AreaSerialVO {
	/** 区县code. */
    private Long code;
    
    /** 中文名称. */
    private String name;
    
    /** 对应市的id. */
    private Long pvalue;

	/**
	 * @return the code
	 */
	public Long getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(Long code) {
		this.code = code;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the pvalue
	 */
	public Long getPvalue() {
		return pvalue;
	}

	/**
	 * @param pvalue the pvalue to set
	 */
	public void setPvalue(Long pvalue) {
		this.pvalue = pvalue;
	}
}
