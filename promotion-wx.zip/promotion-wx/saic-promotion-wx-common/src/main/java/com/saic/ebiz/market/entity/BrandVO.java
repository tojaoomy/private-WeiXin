/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * 根据常规车的需求，品牌需级联车系。
 * 
 * 车型的数据由多项配置组成。因此只需要设置品牌的车系即可。
 * 
 * 在SeriesVO，则不需要set车型参数。
 * 
 * @see RoutineCarVO
 * 
 *  常规车品牌
 */
public class BrandVO {

    /** 品牌Id.  */
    private Long id;

    /** 品牌名称. */
    private String name;

    /**
     *  品牌图片缩略图
     */
    private String imageUrl;

    /** 车系List. */
    private List<SeriesVO> series = new ArrayList<SeriesVO>();

    /**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the imageUrl
	 */
	public String getImageUrl() {
		return imageUrl;
	}

	/**
	 * @param imageUrl the imageUrl to set
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	
	public void setDefaultImage(){
		this.imageUrl = "brands/" + this.id + ".png";
	}

	/**
	 * @return the series
	 */
	public List<SeriesVO> getSeries() {
		return series;
	}

	/**
	 * @param series the series to set
	 */
	public void setSeries(List<SeriesVO> series) {
		this.series = series;
	}

}