/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.List;


/**
 * 城市对象VO
 */
public class CitySerialVO {
    
    /** 城市id. */
    private Long code;
    
    /** 中文名称. */
    private String name;
    
    /** 对应省的id. */
    private Long pvalue;
    
    /** 城市下的区域. */
    private List<AreaSerialVO> children = new ArrayList<AreaSerialVO>();
    

	/**
	 * @return the provinceId
	 */
	public Long getPvalue() {
		return pvalue;
	}


	/**
	 * @return the code
	 */
	public Long getCode() {
		return code;
	}


	/**
	 * @param code the code to set
	 */
	public void setCode(Long code) {
		this.code = code;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the children
	 */
	public List<AreaSerialVO> getChildren() {
		return children;
	}


	/**
	 * @param children the children to set
	 */
	public void setChildren(List<AreaSerialVO> children) {
		this.children = children;
	}


	/**
	 * @param pvalue the pvalue to set
	 */
	public void setPvalue(Long pvalue) {
		this.pvalue = pvalue;
	}

}
