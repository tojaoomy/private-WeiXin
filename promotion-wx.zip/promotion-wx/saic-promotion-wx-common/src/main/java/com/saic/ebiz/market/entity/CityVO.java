/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.List;


/**
 * 城市对象VO
 */
public class CityVO {
    
    /** 城市id. */
    private Long code;
    
    /** 中文名称. */
    private String name;
    
    /** 城市id. */
    private Long value;
    
    /** 中文名称. */
    private String text;
    
    /** 对应省的id. */
    private Long pvalue;
    
    /** 城市下的区域. */
    private List<DistrictVO> districts = new ArrayList<DistrictVO>();
    
    /**
	 * @return the cityId
	 */
	public Long getValue() {
		return value;
	}

	/**
	 * @param cityId the cityId to set
	 */
	public void setValue(Long cityId) {
		this.value = cityId;
	}

	/**
	 * @return the cityName
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param cityName the cityName to set
	 */
	public void setText(String cityName) {
		this.text = cityName;
	}

	/**
	 * @return the provinceId
	 */
	public Long getPvalue() {
		return pvalue;
	}

	/**
	 * @param provinceId the provinceId to set
	 */
	public void setPvalue(Long provinceId) {
		this.pvalue = provinceId;
	}

	/**
	 * @return the districts
	 */
	public List<DistrictVO> getChildren() {
		return districts;
	}

	/**
	 * @param districts the districts to set
	 */
	public void setChildren(List<DistrictVO> districts) {
		this.districts = districts;
	}

	public Long getCode() {
		return code;
	}

	public void setCode(Long code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
