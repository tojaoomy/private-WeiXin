/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

/**
 * @author hejian
 *
 */
public class ColorVO {
	/**
	 * 活动商品颜色Id
	 */
	private Long colorId;
	
	/**
	 * 活动商品颜色名称
	 */
	private String name;
	
	/**
	 * 图片URL
	 */
	private String url;
	
	/**
	 * @return the colorId
	 */
	public Long getColorId() {
		return colorId;
	}

	/**
	 * @param colorId the colorId to set
	 */
	public void setColorId(Long colorId) {
		this.colorId = colorId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

}
