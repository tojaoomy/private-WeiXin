/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

import java.util.Date;

/**
 * 
 * 客户发表评价模型
 * 
 * @author hejian
 * 
 */
public class Comment {

	/** 用户id */
	private Long userId;

	/** 用户姓名 */
	private String userRealName;

	/** 手机 */
	private String mobile;

	/** 询价单id */
	private Long inquireOrderId;

	/** 常规车id */
	private Long routineCarId;

	/** 品牌id */
	private Long brandId;

	/** 车系id */
	private Long seriesId;

	/** 车型id */
	private Long vehicleModelId;

	/** 经销商省 */
	private Long dealerProvinceId;

	/** 经销商市 */
	private Long dealerCityId;

	/** 经销商区域 */
	private Long dealerDistrictId;

	/** 经销商 */
	private Long dealerId;

	/** 店铺id */
	private Long storeId;

	/** 评价来源 */
	private Integer source;

	/** 评价详情 */
	private String commentDetails;

	/** 评价时间 */
	private Date createTime;

	/** 评分 */
	private Double score;

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the userRealName
	 */
	public String getUserRealName() {
		return userRealName;
	}

	/**
	 * @param userRealName
	 *            the userRealName to set
	 */
	public void setUserRealName(String userRealName) {
		this.userRealName = userRealName;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile
	 *            the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the inquireOrderId
	 */
	public Long getInquireOrderId() {
		return inquireOrderId;
	}

	/**
	 * @param inquireOrderId
	 *            the inquireOrderId to set
	 */
	public void setInquireOrderId(Long inquireOrderId) {
		this.inquireOrderId = inquireOrderId;
	}

	/**
	 * @return the routineCarId
	 */
	public Long getRoutineCarId() {
		return routineCarId;
	}

	/**
	 * @param routineCarId
	 *            the routineCarId to set
	 */
	public void setRoutineCarId(Long routineCarId) {
		this.routineCarId = routineCarId;
	}

	/**
	 * @return the brandId
	 */
	public Long getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId
	 *            the brandId to set
	 */
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}

	/**
	 * @return the seriesId
	 */
	public Long getSeriesId() {
		return seriesId;
	}

	/**
	 * @param seriesId
	 *            the seriesId to set
	 */
	public void setSeriesId(Long seriesId) {
		this.seriesId = seriesId;
	}

	/**
	 * @return the vehicleModelId
	 */
	public Long getVehicleModelId() {
		return vehicleModelId;
	}

	/**
	 * @param vehicleModelId
	 *            the vehicleModelId to set
	 */
	public void setVehicleModelId(Long vehicleModelId) {
		this.vehicleModelId = vehicleModelId;
	}

	/**
	 * @return the dealerProvinceId
	 */
	public Long getDealerProvinceId() {
		return dealerProvinceId;
	}

	/**
	 * @param dealerProvinceId
	 *            the dealerProvinceId to set
	 */
	public void setDealerProvinceId(Long dealerProvinceId) {
		this.dealerProvinceId = dealerProvinceId;
	}

	/**
	 * @return the dealerCityId
	 */
	public Long getDealerCityId() {
		return dealerCityId;
	}

	/**
	 * @param dealerCityId
	 *            the dealerCityId to set
	 */
	public void setDealerCityId(Long dealerCityId) {
		this.dealerCityId = dealerCityId;
	}

	/**
	 * @return the dealerDistrictId
	 */
	public Long getDealerDistrictId() {
		return dealerDistrictId;
	}

	/**
	 * @param dealerDistrictId
	 *            the dealerDistrictId to set
	 */
	public void setDealerDistrictId(Long dealerDistrictId) {
		this.dealerDistrictId = dealerDistrictId;
	}

	/**
	 * @return the dealerId
	 */
	public Long getDealerId() {
		return dealerId;
	}

	/**
	 * @param dealerId
	 *            the dealerId to set
	 */
	public void setDealerId(Long dealerId) {
		this.dealerId = dealerId;
	}

	/**
	 * @return the storeId
	 */
	public Long getStoreId() {
		return storeId;
	}

	/**
	 * @param storeId
	 *            the storeId to set
	 */
	public void setStoreId(Long storeId) {
		this.storeId = storeId;
	}

	/**
	 * @return the source
	 */
	public Integer getSource() {
		return source;
	}

	/**
	 * @param source
	 *            the source to set
	 */
	public void setSource(Integer source) {
		this.source = source;
	}

	/**
	 * @return the commentDetails
	 */
	public String getCommentDetails() {
		return commentDetails;
	}

	/**
	 * @param commentDetails
	 *            the commentDetails to set
	 */
	public void setCommentDetails(String commentDetails) {
		this.commentDetails = commentDetails;
	}

	/**
	 * @return the createTime
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * @param createTime
	 *            the createTime to set
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * @return the score
	 */
	public Double getScore() {
		return score;
	}

	/**
	 * @param score
	 *            the score to set
	 */
	public void setScore(Double score) {
		this.score = score;
	}
}
