/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

import java.util.Date;

/**
 * 
 * 客户在下询价单时，展示用户评价
 * 
 * @author hejian
 * 
 */
public class CommentVO {

	/** 用户id */
	private Long userId;

	/** 用户姓名 */
	private String userRealName;

	/** 手机 */
	private String mobile;

	/** 询价单id */
	private Long inquireOrderId;

	/** 常规车id */
	private Long routineCarId;

	/** 品牌id */
	private Long brandId;
	
	/** 品牌名称 */
	private String brandName;

	/** 车系id */
	private Long seriesId;
	
	/** 车系名称 */
	private String seriesName;

	/** 车型id */
	private Long vehicleModelId;

	/** 车型图片url */
	private String vehicleModelImageUrl;

	/** 评价详情 */
	private String commentDetails;

	/** 评价时间 */
	private Date createTime;

	/** 评分 */
	private Double score;

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the userRealName
	 */
	public String getUserRealName() {
		return userRealName;
	}

	/**
	 * @param userRealName
	 *            the userRealName to set
	 */
	public void setUserRealName(String userRealName) {
		this.userRealName = userRealName;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile
	 *            the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the inquireOrderId
	 */
	public Long getInquireOrderId() {
		return inquireOrderId;
	}

	/**
	 * @param inquireOrderId
	 *            the inquireOrderId to set
	 */
	public void setInquireOrderId(Long inquireOrderId) {
		this.inquireOrderId = inquireOrderId;
	}

	/**
	 * @return the routineCarId
	 */
	public Long getRoutineCarId() {
		return routineCarId;
	}

	/**
	 * @param routineCarId
	 *            the routineCarId to set
	 */
	public void setRoutineCarId(Long routineCarId) {
		this.routineCarId = routineCarId;
	}

	/**
	 * @return the brandId
	 */
	public Long getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId
	 *            the brandId to set
	 */
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}
	
	/**
	 * @return the brandName
	 */
	public String getBrandName() {
		return brandName;
	}

	/**
	 * @param brandName the brandName to set
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * @return the seriesId
	 */
	public Long getSeriesId() {
		return seriesId;
	}

	/**
	 * @param seriesId
	 *            the seriesId to set
	 */
	public void setSeriesId(Long seriesId) {
		this.seriesId = seriesId;
	}

	/**
	 * @return the seriesName
	 */
	public String getSeriesName() {
		return seriesName;
	}

	/**
	 * @param seriesName the seriesName to set
	 */
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}

	/**
	 * @return the vehicleModelId
	 */
	public Long getVehicleModelId() {
		return vehicleModelId;
	}

	/**
	 * @param vehicleModelId
	 *            the vehicleModelId to set
	 */
	public void setVehicleModelId(Long vehicleModelId) {
		this.vehicleModelId = vehicleModelId;
	}

	/**
	 * @return the vehicleModelImageUrl
	 */
	public String getVehicleModelImageUrl() {
		return vehicleModelImageUrl;
	}

	/**
	 * @param vehicleModelImageUrl
	 *            the vehicleModelImageUrl to set
	 */
	public void setVehicleModelImageUrl(String vehicleModelImageUrl) {
		this.vehicleModelImageUrl = vehicleModelImageUrl;
	}

	/**
	 * @return the commentDetails
	 */
	public String getCommentDetails() {
		return commentDetails;
	}

	/**
	 * @param commentDetails
	 *            the commentDetails to set
	 */
	public void setCommentDetails(String commentDetails) {
		this.commentDetails = commentDetails;
	}

	/**
	 * @return the createTime
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * @param createTime
	 *            the createTime to set
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * @return the score
	 */
	public Double getScore() {
		return score;
	}

	/**
	 * @param score
	 *            the score to set
	 */
	public void setScore(Double score) {
		this.score = score;
	}
}
