/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.saic.ebiz.mdm.partner.entity.StoreBaseInfo;


/**
 * 区域/县 等对象VO
 */
public class DistrictVO {
    
    /** 区域id. */
    private Long value;
    
    /** 区域中文名称. */
    private String text;
    
    /** 对应城市的id. */
    private Long pvalue;
    
    /** 店铺-商品 */
    private Map<String,Long> storeMerchainseMap = new HashMap<String,Long>();
    
    /** 经销商. */
    private List<StoreBaseInfo> stores = new ArrayList<StoreBaseInfo>();

    /**
	 * @return the districtId
	 */
	public Long getValue() {
		return value;
	}

	/**
	 * @param districtId the districtId to set
	 */
	public void setValue(Long districtId) {
		this.value = districtId;
	}

	/**
	 * @return the districtName
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param districtName the districtName to set
	 */
	public void setText(String districtName) {
		this.text = districtName;
	}

	/**
	 * @return the cityId
	 */
	public Long getPvalue() {
		return pvalue;
	}

	/**
	 * @param cityId the cityId to set
	 */
	public void setPvalue(Long cityId) {
		this.pvalue = cityId;
	}

	/**
	 * @return the storeMerchainseMap
	 */
	public Map<String, Long> getStoreMerchainseMap() {
		return storeMerchainseMap;
	}

	/**
	 * @param storeMerchainseMap the storeMerchainseMap to set
	 */
	public void setStoreMerchainseMap(Map<String, Long> storeMerchainseMap) {
		this.storeMerchainseMap = storeMerchainseMap;
	}

	/**
	 * @return the stores
	 */
	public List<StoreBaseInfo> getStores() {
		return stores;
	}

	/**
	 * @param stores the stores to set
	 */
	public void setStores(List<StoreBaseInfo> stores) {
		this.stores = stores;
	}

	/**
	 * @return the stores
	 */
	public List<StoreBaseInfo> getChildren() {
		return stores;
	}

	/**
	 * @param stores the stores to set
	 */
	public void setChildren(List<StoreBaseInfo> stores) {
		this.stores = stores;
	}

}
