/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

import java.util.Date;
import java.util.List;

/**
 * 
 * 询价单对象模型
 * 
 * @author hejian
 * 
 */
public class InquiryOrderVO {

	 /** 预定单编码 */
    private String actOrderId;

    /** 父定单编码 */
    private String parentOrderId;

    /** 促销活动编码 */
    private Integer prmtActId;

    /** 促销活动名称 */
    private String prmtActName;

    /** 预订数量 */
    private Integer amount;

    /** 会员编码 */
    private Long userId;

    /** 会员姓名 */
    private String userName;

    /** 手机号码 */
    private String mobileNo;

    /** 备注说明 */
    private String remarkDesc;
    
    /** loanFlag 是否车贷 */
    private String loanFlag = "N";
    
    /** needInsuranceFlag 是否需要车险 */
    private String needInsuranceFlag = "N";
    
    /** registerLicenceFlag 是否需要上牌 */
    private String registerLicenceFlag = "N";
    
    /** licenseProvinceId 上牌省ID */
    private Long licenseProvinceId;
    
    /** licenseCityId 上牌城市ID */
    private Long licenseCityId;
    
    /** createId 创建人ID */
    private Long createId;
    
    /** createName 创建人姓名 */
    private String createName;
    
    /** lastModifiedId 最后修改人 */
    private Long lastModifiedId;
    
    /** lastModifiedName 最后修改名称 */
    private String lastModifiedName;
    
    /** orderSource 订单来源(1 PC, 2 微信） */
    private Integer orderSource;
    
    /** custProvinceId 客户所在省ID */
    private Long custProvinceId;
    
    /** custCityId 客户所在市ID */
    private Long custCityId;
    
    /** 以下字段只用作查询 */
    /** 支付时间 */
    private Date payTime;
    
    /** 活动订单状态（询价状态） 11：已提交，12：超时未支付，13：已支付，14：取消，15：中标 */
    private Integer status;

    /** 支付状态 1：未支付，2：支付成功，3：支付失败 */
    private Integer payStatus;

    /** 退款状态 1：未退款，2：退款中，3：退款成功 */
    private Integer refundStatus;
    
    /** selections 用户选择列表 */
    private List<RoutineCarSelection> selections;
    
    /** validCode 校验码 */
    private String validCode;

	/**
	 * @return the actOrderId
	 */
	public String getActOrderId() {
		return actOrderId;
	}

	/**
	 * @param actOrderId the actOrderId to set
	 */
	public void setActOrderId(String actOrderId) {
		this.actOrderId = actOrderId;
	}

	/**
	 * @return the parentOrderId
	 */
	public String getParentOrderId() {
		return parentOrderId;
	}

	/**
	 * @param parentOrderId the parentOrderId to set
	 */
	public void setParentOrderId(String parentOrderId) {
		this.parentOrderId = parentOrderId;
	}

	/**
	 * @return the prmtActId
	 */
	public Integer getPrmtActId() {
		return prmtActId;
	}

	/**
	 * @param prmtActId the prmtActId to set
	 */
	public void setPrmtActId(Integer prmtActId) {
		this.prmtActId = prmtActId;
	}

	/**
	 * @return the prmtActName
	 */
	public String getPrmtActName() {
		return prmtActName;
	}

	/**
	 * @param prmtActName the prmtActName to set
	 */
	public void setPrmtActName(String prmtActName) {
		this.prmtActName = prmtActName;
	}

	/**
	 * @return the amount
	 */
	public Integer getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the remarkDesc
	 */
	public String getRemarkDesc() {
		return remarkDesc;
	}

	/**
	 * @param remarkDesc the remarkDesc to set
	 */
	public void setRemarkDesc(String remarkDesc) {
		this.remarkDesc = remarkDesc;
	}

	/**
	 * @return the loanFlag
	 */
	public String getLoanFlag() {
		return loanFlag;
	}

	/**
	 * @param loanFlag the loanFlag to set
	 */
	public void setLoanFlag(String loanFlag) {
		this.loanFlag = loanFlag;
	}

	/**
	 * @return the needInsuranceFlag
	 */
	public String getNeedInsuranceFlag() {
		return needInsuranceFlag;
	}

	/**
	 * @param needInsuranceFlag the needInsuranceFlag to set
	 */
	public void setNeedInsuranceFlag(String needInsuranceFlag) {
		this.needInsuranceFlag = needInsuranceFlag;
	}

	/**
	 * @return the registerLicenceFlag
	 */
	public String getRegisterLicenceFlag() {
		return registerLicenceFlag;
	}

	/**
	 * @param registerLicenceFlag the registerLicenceFlag to set
	 */
	public void setRegisterLicenceFlag(String registerLicenceFlag) {
		this.registerLicenceFlag = registerLicenceFlag;
	}

	/**
	 * @return the licenseProvinceId
	 */
	public Long getLicenseProvinceId() {
		return licenseProvinceId;
	}

	/**
	 * @param licenseProvinceId the licenseProvinceId to set
	 */
	public void setLicenseProvinceId(Long licenseProvinceId) {
		this.licenseProvinceId = licenseProvinceId;
	}

	/**
	 * @return the licenseCityId
	 */
	public Long getLicenseCityId() {
		return licenseCityId;
	}

	/**
	 * @param licenseCityId the licenseCityId to set
	 */
	public void setLicenseCityId(Long licenseCityId) {
		this.licenseCityId = licenseCityId;
	}

	/**
	 * @return the createId
	 */
	public Long getCreateId() {
		return createId;
	}

	/**
	 * @param createId the createId to set
	 */
	public void setCreateId(Long createId) {
		this.createId = createId;
	}

	/**
	 * @return the createName
	 */
	public String getCreateName() {
		return createName;
	}

	/**
	 * @param createName the createName to set
	 */
	public void setCreateName(String createName) {
		this.createName = createName;
	}

	/**
	 * @return the lastModifiedId
	 */
	public Long getLastModifiedId() {
		return lastModifiedId;
	}

	/**
	 * @param lastModifiedId the lastModifiedId to set
	 */
	public void setLastModifiedId(Long lastModifiedId) {
		this.lastModifiedId = lastModifiedId;
	}

	/**
	 * @return the lastModifiedName
	 */
	public String getLastModifiedName() {
		return lastModifiedName;
	}

	/**
	 * @param lastModifiedName the lastModifiedName to set
	 */
	public void setLastModifiedName(String lastModifiedName) {
		this.lastModifiedName = lastModifiedName;
	}

	/**
	 * @return the orderSource
	 */
	public Integer getOrderSource() {
		return orderSource;
	}

	/**
	 * @param orderSource the orderSource to set
	 */
	public void setOrderSource(Integer orderSource) {
		this.orderSource = orderSource;
	}

	/**
	 * @return the custProvinceId
	 */
	public Long getCustProvinceId() {
		return custProvinceId;
	}

	/**
	 * @param custProvinceId the custProvinceId to set
	 */
	public void setCustProvinceId(Long custProvinceId) {
		this.custProvinceId = custProvinceId;
	}

	/**
	 * @return the custCityId
	 */
	public Long getCustCityId() {
		return custCityId;
	}

	/**
	 * @param custCityId the custCityId to set
	 */
	public void setCustCityId(Long custCityId) {
		this.custCityId = custCityId;
	}

	/**
	 * @return the payTime
	 */
	public Date getPayTime() {
		return payTime;
	}

	/**
	 * @param payTime the payTime to set
	 */
	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the payStatus
	 */
	public Integer getPayStatus() {
		return payStatus;
	}

	/**
	 * @param payStatus the payStatus to set
	 */
	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}

	/**
	 * @return the refundStatus
	 */
	public Integer getRefundStatus() {
		return refundStatus;
	}

	/**
	 * @param refundStatus the refundStatus to set
	 */
	public void setRefundStatus(Integer refundStatus) {
		this.refundStatus = refundStatus;
	}

	/**
	 * @return the selections
	 */
	public List<RoutineCarSelection> getSelections() {
		return selections;
	}

	/**
	 * @param selections the selections to set
	 */
	public void setSelections(List<RoutineCarSelection> selections) {
		this.selections = selections;
	}

	/**
	 * @return the validCode
	 */
	public String getValidCode() {
		return validCode;
	}

	/**
	 * @param validCode the validCode to set
	 */
	public void setValidCode(String validCode) {
		this.validCode = validCode;
	}
    
}
