/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

import java.math.BigDecimal;

/**
 * @author hejian
 *
 */
public class MerchandiseStoreOrder {
	 /** 表来源 （1:t_promotion_qualification; 2:t_promotion_merchandise） */
    private Integer tableSource;
    
    /** 表id */
    private Long objectId;
    
    /** 店铺id */
    private Long storeId;
    
    /** 以下字段仅用于展示 */
    /** 店铺名称 */
    private Long storeName;
    
    /** 店铺地址 */
    private Long storeAddress;
    
    /** barePrice 裸车价 */
    private BigDecimal barePrice;
    
    /** totalServiceFee 综合服务费 */
    private BigDecimal totalServiceFee;
    
    /** purchaseTax 购置税 */
    private BigDecimal purchaseTax;
    
    /** insurerName 保险公司 */
    private String insurerName;
    
    /** premium 保险费 */
    private BigDecimal premium;
    
    /** licenseProvinceId 上牌省ID */
    private Long licenseProvinceId;
    
    /** licenseCityId 上牌城市ID */
    private Long licenseCityId;
    
    /** licenseFee 上牌费 */
    private BigDecimal licenseFee;
    
    /** totalPrice 购车总价 */
    private BigDecimal totalPrice;
    
    /** remark 附送礼物 */
    private String remark;
    
    /** isWithCar 是否有现车 */
    private Integer isWithCar;
    
    /** takePeriodWithCar 有现车提车周期  */
    private Integer takePeriodWithCar;
    
    /** isWithoutCar 是否无现车（预订) */
    private Integer isWithoutCar;
    
    /** takePeriodWithoutCar 无现车提车周期 */
    private Integer takePeriodWithoutCar;

	/**
	 * @return the tableSource
	 */
	public Integer getTableSource() {
		return tableSource;
	}

	/**
	 * @param tableSource the tableSource to set
	 */
	public void setTableSource(Integer tableSource) {
		this.tableSource = tableSource;
	}

	/**
	 * @return the objectId
	 */
	public Long getObjectId() {
		return objectId;
	}

	/**
	 * @param objectId the objectId to set
	 */
	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

	/**
	 * @return the storeId
	 */
	public Long getStoreId() {
		return storeId;
	}

	/**
	 * @param storeId the storeId to set
	 */
	public void setStoreId(Long storeId) {
		this.storeId = storeId;
	}

	/**
	 * @return the storeName
	 */
	public Long getStoreName() {
		return storeName;
	}

	/**
	 * @param storeName the storeName to set
	 */
	public void setStoreName(Long storeName) {
		this.storeName = storeName;
	}

	/**
	 * @return the storeAddress
	 */
	public Long getStoreAddress() {
		return storeAddress;
	}

	/**
	 * @param storeAddress the storeAddress to set
	 */
	public void setStoreAddress(Long storeAddress) {
		this.storeAddress = storeAddress;
	}

	/**
	 * @return the barePrice
	 */
	public BigDecimal getBarePrice() {
		return barePrice;
	}

	/**
	 * @param barePrice the barePrice to set
	 */
	public void setBarePrice(BigDecimal barePrice) {
		this.barePrice = barePrice;
	}

	/**
	 * @return the totalServiceFee
	 */
	public BigDecimal getTotalServiceFee() {
		return totalServiceFee;
	}

	/**
	 * @param totalServiceFee the totalServiceFee to set
	 */
	public void setTotalServiceFee(BigDecimal totalServiceFee) {
		this.totalServiceFee = totalServiceFee;
	}

	/**
	 * @return the purchaseTax
	 */
	public BigDecimal getPurchaseTax() {
		return purchaseTax;
	}

	/**
	 * @param purchaseTax the purchaseTax to set
	 */
	public void setPurchaseTax(BigDecimal purchaseTax) {
		this.purchaseTax = purchaseTax;
	}

	/**
	 * @return the insurerName
	 */
	public String getInsurerName() {
		return insurerName;
	}

	/**
	 * @param insurerName the insurerName to set
	 */
	public void setInsurerName(String insurerName) {
		this.insurerName = insurerName;
	}

	/**
	 * @return the premium
	 */
	public BigDecimal getPremium() {
		return premium;
	}

	/**
	 * @param premium the premium to set
	 */
	public void setPremium(BigDecimal premium) {
		this.premium = premium;
	}

	/**
	 * @return the licenseProvinceId
	 */
	public Long getLicenseProvinceId() {
		return licenseProvinceId;
	}

	/**
	 * @param licenseProvinceId the licenseProvinceId to set
	 */
	public void setLicenseProvinceId(Long licenseProvinceId) {
		this.licenseProvinceId = licenseProvinceId;
	}

	/**
	 * @return the licenseCityId
	 */
	public Long getLicenseCityId() {
		return licenseCityId;
	}

	/**
	 * @param licenseCityId the licenseCityId to set
	 */
	public void setLicenseCityId(Long licenseCityId) {
		this.licenseCityId = licenseCityId;
	}

	/**
	 * @return the licenseFee
	 */
	public BigDecimal getLicenseFee() {
		return licenseFee;
	}

	/**
	 * @param licenseFee the licenseFee to set
	 */
	public void setLicenseFee(BigDecimal licenseFee) {
		this.licenseFee = licenseFee;
	}

	/**
	 * @return the totalPrice
	 */
	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the isWithCar
	 */
	public Integer getIsWithCar() {
		return isWithCar;
	}

	/**
	 * @param isWithCar the isWithCar to set
	 */
	public void setIsWithCar(Integer isWithCar) {
		this.isWithCar = isWithCar;
	}

	/**
	 * @return the takePeriodWithCar
	 */
	public Integer getTakePeriodWithCar() {
		return takePeriodWithCar;
	}

	/**
	 * @param takePeriodWithCar the takePeriodWithCar to set
	 */
	public void setTakePeriodWithCar(Integer takePeriodWithCar) {
		this.takePeriodWithCar = takePeriodWithCar;
	}

	/**
	 * @return the isWithoutCar
	 */
	public Integer getIsWithoutCar() {
		return isWithoutCar;
	}

	/**
	 * @param isWithoutCar the isWithoutCar to set
	 */
	public void setIsWithoutCar(Integer isWithoutCar) {
		this.isWithoutCar = isWithoutCar;
	}

	/**
	 * @return the takePeriodWithoutCar
	 */
	public Integer getTakePeriodWithoutCar() {
		return takePeriodWithoutCar;
	}

	/**
	 * @param takePeriodWithoutCar the takePeriodWithoutCar to set
	 */
	public void setTakePeriodWithoutCar(Integer takePeriodWithoutCar) {
		this.takePeriodWithoutCar = takePeriodWithoutCar;
	}
    
}
