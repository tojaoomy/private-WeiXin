/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * 该类是给城市根据拼音分类查找功能实现。
 * @author hejian
 *
 */
public class PinyinCityEntity {
	
	/** 拼音首字母  */
	private String firstLetter;
	
	/** 同一个字母组合下面的城市
	 *  比如 字母c
	 *  成都,长沙,重庆
	 *  */
	private List<CityVO> cities = new ArrayList<CityVO>();

	/**
	 * @return the firstLetter
	 */
	public String getFirstLetter() {
		return firstLetter;
	}

	/**
	 * @param firstLetter the firstLetter to set
	 */
	public void setFirstLetter(String firstLetter) {
		this.firstLetter = firstLetter;
	}

	/**
	 * @return the cities
	 */
	public List<CityVO> getCities() {
		return cities;
	}

	/**
	 * @param cities the cities to set
	 */
	public void setCities(List<CityVO> cities) {
		this.cities = cities;
	}
}
