/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * 三级联动
 * 
 * 省份对象VO
 */
public class ProvinceSerialVO {
    
    /** 省id. */
    private Long code;
    
    /** 省的名称. */
    private String name;

    /** 省下的城市. */
    private List<CitySerialVO> children = new ArrayList<CitySerialVO>();

	/**
	 * @return the code
	 */
	public Long getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(Long code) {
		this.code = code;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the children
	 */
	public List<CitySerialVO> getChildren() {
		return children;
	}

	/**
	 * @param children the children to set
	 */
	public void setChildren(List<CitySerialVO> children) {
		this.children = children;
	}

}
