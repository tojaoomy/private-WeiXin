/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author hejian
 *
 */
public class RoutineCarSelection {
	/** 常规车id */
    private Long routineCarId;
    
    /** 活动id */
    private Long promotionId;
    
    /** 颜色id */
    private Long colorId;
    
    /** 店铺配额匹配  */
    private List<MerchandiseStoreOrder> maps;
    
    /** 以下字段仅用于展示 */
    /** batchDesc 批次描述 */
    private String batchDesc;
    
    /** batchGift 本批次车享礼 */
    private String batchGift;
    
    /** title 显示完整车型名称 */
    private String title;
    
    /** msrp 厂商指导价 */
    private BigDecimal msrp;
    
    /** isPriceDiffCommit 是否差价承诺（1 是，2 否） */
    private Integer isPriceDiffCommit;
    
    /** priceDiffCommitPeriod 差价承诺期限 */
    private Integer priceDiffCommitPeriod;

	/**
	 * @return the routineCarId
	 */
	public Long getRoutineCarId() {
		return routineCarId;
	}

	/**
	 * @param routineCarId the routineCarId to set
	 */
	public void setRoutineCarId(Long routineCarId) {
		this.routineCarId = routineCarId;
	}

	/**
	 * @return the promotionId
	 */
	public Long getPromotionId() {
		return promotionId;
	}

	/**
	 * @param promotionId the promotionId to set
	 */
	public void setPromotionId(Long promotionId) {
		this.promotionId = promotionId;
	}

	/**
	 * @return the colorId
	 */
	public Long getColorId() {
		return colorId;
	}

	/**
	 * @param colorId the colorId to set
	 */
	public void setColorId(Long colorId) {
		this.colorId = colorId;
	}

	/**
	 * @return the maps
	 */
	public List<MerchandiseStoreOrder> getMaps() {
		return maps;
	}

	/**
	 * @param maps the maps to set
	 */
	public void setMaps(List<MerchandiseStoreOrder> maps) {
		this.maps = maps;
	}

	/**
	 * @return the batchDesc
	 */
	public String getBatchDesc() {
		return batchDesc;
	}

	/**
	 * @param batchDesc the batchDesc to set
	 */
	public void setBatchDesc(String batchDesc) {
		this.batchDesc = batchDesc;
	}

	/**
	 * @return the batchGift
	 */
	public String getBatchGift() {
		return batchGift;
	}

	/**
	 * @param batchGift the batchGift to set
	 */
	public void setBatchGift(String batchGift) {
		this.batchGift = batchGift;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the msrp
	 */
	public BigDecimal getMsrp() {
		return msrp;
	}

	/**
	 * @param msrp the msrp to set
	 */
	public void setMsrp(BigDecimal msrp) {
		this.msrp = msrp;
	}

	/**
	 * @return the isPriceDiffCommit
	 */
	public Integer getIsPriceDiffCommit() {
		return isPriceDiffCommit;
	}

	/**
	 * @param isPriceDiffCommit the isPriceDiffCommit to set
	 */
	public void setIsPriceDiffCommit(Integer isPriceDiffCommit) {
		this.isPriceDiffCommit = isPriceDiffCommit;
	}

	/**
	 * @return the priceDiffCommitPeriod
	 */
	public Integer getPriceDiffCommitPeriod() {
		return priceDiffCommitPeriod;
	}

	/**
	 * @param priceDiffCommitPeriod the priceDiffCommitPeriod to set
	 */
	public void setPriceDiffCommitPeriod(Integer priceDiffCommitPeriod) {
		this.priceDiffCommitPeriod = priceDiffCommitPeriod;
	}
    
}
