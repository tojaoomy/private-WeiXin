/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 常规车对象模型
 * 
 * @author hejian
 * 
 */
public class RoutineCarVO {

	/** routineCarId 常规车ID */
	private Long routineCarId;
	
	/** 活动id */
	private Long promotionId;

	/** 标签(热卖，紧缺，豪华...) */
	private String tag;

	/** 品牌 */
	private Long brandId;

	private String brandName;

	/** 车系 */
	private Long seriesId;

	private String seriesName;

	/** 车型 */
	private Long vehicleModelId;

	private String vehicleModelName;

	/** carType 常规车类型（1 常规车， 2 特殊车） */
	private Integer carType;

	/** 批次号 */
	private String batchNum;

	/** 批次描述 */
	private String batchDescription;

	/** 已经下单数 */
	private Integer numOfOrder;

	/** 厂商指导价 */
	private BigDecimal marketPrice;

	/** 享购车平均优惠 */
	private BigDecimal avgSave;

	/** 平均提车周期 /天 */
	private Long periodOfPickUP;
	
	  /** isPriceDiffCommit 是否差价承诺（1 是，2 否） */
    private Integer isPriceDiffCommit;
    
    /** priceDiffCommitPeriod 差价承诺期限 */
    private Integer priceDiffCommitPeriod;

	/** 车型颜色 */
	private List<ColorImageVO> colors = new ArrayList<ColorImageVO>();

	/**
	 * 显示颜色的中文内容，格式为颜色A、颜色B eg. 红色、蓝色、白色
	 * */
	private String colorDisplay;

	/** 封面图片ID */
	private Long coverImgId;

	/** 封面图片URL */
	private String coverImgUrl;

	/** 常规车补贴 */
	private String subsidy;

	/** 车享批次礼品 */
	private String batchGift;

	/**
	 * @return the routineCarId
	 */
	public Long getRoutineCarId() {
		return routineCarId;
	}

	/**
	 * @param routineCarId
	 *            the routineCarId to set
	 */
	public void setRoutineCarId(Long routineCarId) {
		this.routineCarId = routineCarId;
	}

	/**
	 * @return the promotionId
	 */
	public Long getPromotionId() {
		return promotionId;
	}

	/**
	 * @param promotionId the promotionId to set
	 */
	public void setPromotionId(Long promotionId) {
		this.promotionId = promotionId;
	}

	/**
	 * @return the tag
	 */
	public String getTag() {
		return tag;
	}

	/**
	 * @param tag
	 *            the tag to set
	 */
	public void setTag(String tag) {
		this.tag = tag;
	}

	/**
	 * @return the brandId
	 */
	public Long getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId
	 *            the brandId to set
	 */
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}

	/**
	 * @return the brandName
	 */
	public String getBrandName() {
		return brandName;
	}

	/**
	 * @param brandName
	 *            the brandName to set
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * @return the seriesId
	 */
	public Long getSeriesId() {
		return seriesId;
	}

	/**
	 * @param seriesId
	 *            the seriesId to set
	 */
	public void setSeriesId(Long seriesId) {
		this.seriesId = seriesId;
	}

	/**
	 * @return the seriesName
	 */
	public String getSeriesName() {
		return seriesName;
	}

	/**
	 * @param seriesName
	 *            the seriesName to set
	 */
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}

	/**
	 * @return the vehicleModelId
	 */
	public Long getVehicleModelId() {
		return vehicleModelId;
	}

	/**
	 * @param vehicleModelId
	 *            the vehicleModelId to set
	 */
	public void setVehicleModelId(Long vehicleModelId) {
		this.vehicleModelId = vehicleModelId;
	}

	/**
	 * @return the vehicleModelName
	 */
	public String getVehicleModelName() {
		return vehicleModelName;
	}

	/**
	 * @param vehicleModelName
	 *            the vehicleModelName to set
	 */
	public void setVehicleModelName(String vehicleModelName) {
		this.vehicleModelName = vehicleModelName;
	}

	/**
	 * @return the carType
	 */
	public Integer getCarType() {
		return carType;
	}

	/**
	 * @param carType
	 *            the carType to set
	 */
	public void setCarType(Integer carType) {
		this.carType = carType;
	}

	/**
	 * @return the batchNum
	 */
	public String getBatchNum() {
		return batchNum;
	}

	/**
	 * @param batchNum
	 *            the batchNum to set
	 */
	public void setBatchNum(String batchNum) {
		this.batchNum = batchNum;
	}

	/**
	 * @return the batchDescription
	 */
	public String getBatchDescription() {
		return batchDescription;
	}

	/**
	 * @param batchDescription
	 *            the batchDescription to set
	 */
	public void setBatchDescription(String batchDescription) {
		this.batchDescription = batchDescription;
	}

	/**
	 * @return the numOfOrder
	 */
	public Integer getNumOfOrder() {
		return numOfOrder;
	}

	/**
	 * @param numOfOrder
	 *            the numOfOrder to set
	 */
	public void setNumOfOrder(Integer numOfOrder) {
		this.numOfOrder = numOfOrder;
	}

	/**
	 * @return the marketPrice
	 */
	public BigDecimal getMarketPrice() {
		return marketPrice;
	}

	/**
	 * @param marketPrice
	 *            the marketPrice to set
	 */
	public void setMarketPrice(BigDecimal marketPrice) {
		this.marketPrice = marketPrice;
	}

	/**
	 * @return the avgSave
	 */
	public BigDecimal getAvgSave() {
		return avgSave;
	}

	/**
	 * @param avgSave
	 *            the avgSave to set
	 */
	public void setAvgSave(BigDecimal avgSave) {
		this.avgSave = avgSave;
	}

	/**
	 * @return the periodOfPickUP
	 */
	public Long getPeriodOfPickUP() {
		return periodOfPickUP;
	}

	/**
	 * @param periodOfPickUP
	 *            the periodOfPickUP to set
	 */
	public void setPeriodOfPickUP(Long periodOfPickUP) {
		this.periodOfPickUP = periodOfPickUP;
	}

	/**
	 * @return the colors
	 */
	public List<ColorImageVO> getColors() {
		return colors;
	}

	/**
	 * @param colors
	 *            the colors to set
	 */
	public void setColors(List<ColorImageVO> colors) {
		this.colors = colors;
	}

	/**
	 * @return the colorDisplay
	 */
	public String getColorDisplay() {
		return colorDisplay;
	}

	/**
	 * @param colorDisplay
	 *            the colorDisplay to set
	 */
	public void setColorDisplay(String colorDisplay) {
		this.colorDisplay = colorDisplay;
	}

	/**
	 * @return the coverImgId
	 */
	public Long getCoverImgId() {
		return coverImgId;
	}

	/**
	 * @param coverImgId
	 *            the coverImgId to set
	 */
	public void setCoverImgId(Long coverImgId) {
		this.coverImgId = coverImgId;
	}

	/**
	 * @return the coverImgUrl
	 */
	public String getCoverImgUrl() {
		return coverImgUrl;
	}

	/**
	 * @param coverImgUrl
	 *            the coverImgUrl to set
	 */
	public void setCoverImgUrl(String coverImgUrl) {
		this.coverImgUrl = coverImgUrl;
	}

	/**
	 * @return the subsidy
	 */
	public String getSubsidy() {
		return subsidy;
	}

	/**
	 * @param subsidy
	 *            the subsidy to set
	 */
	public void setSubsidy(String subsidy) {
		this.subsidy = subsidy;
	}

	/**
	 * @return the batchGift
	 */
	public String getBatchGift() {
		return batchGift;
	}

	/**
	 * @param batchGift
	 *            the batchGift to set
	 */
	public void setBatchGift(String batchGift) {
		this.batchGift = batchGift;
	}

	/**
	 * @return the isPriceDiffCommit
	 */
	public Integer getIsPriceDiffCommit() {
		return isPriceDiffCommit;
	}

	/**
	 * @param isPriceDiffCommit the isPriceDiffCommit to set
	 */
	public void setIsPriceDiffCommit(Integer isPriceDiffCommit) {
		this.isPriceDiffCommit = isPriceDiffCommit;
	}

	/**
	 * @return the priceDiffCommitPeriod
	 */
	public Integer getPriceDiffCommitPeriod() {
		return priceDiffCommitPeriod;
	}

	/**
	 * @param priceDiffCommitPeriod the priceDiffCommitPeriod to set
	 */
	public void setPriceDiffCommitPeriod(Integer priceDiffCommitPeriod) {
		this.priceDiffCommitPeriod = priceDiffCommitPeriod;
	}

	/** 车享全场礼品 */
	// private String globalGift;

}
