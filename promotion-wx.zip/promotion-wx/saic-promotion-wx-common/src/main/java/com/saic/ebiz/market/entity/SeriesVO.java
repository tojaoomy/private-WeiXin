/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.List;


/**
 * 
 * 常规车车系
 * 
 * @author hejian
 *
 */
public class SeriesVO {

    /** 车系Id.  */
    private Long id;
    
    /** 车系名称. */
    private String name;
    
    /** 品牌id. */
    private Long brandId;
    
    /** 品牌名称  */
    private String brandName;
    
    /** 车型list. */
//    private List<VehicleModelVO> vehicleModels = new ArrayList<VehicleModelVO>();
    
    /** 车型list. */
    private List<RoutineCarVO> routineCars = new ArrayList<RoutineCarVO>();
    
    /**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
     * Gets the brand id.
     * 
     * @return the brandId
     */
    public Long getBrandId() {
        return brandId;
    }

    /**
     * Sets the brand id.
     * 
     * @param brandId the brandId to set
     */
    public void setBrandId(Long brandId) {
        this.brandId = brandId;
    }

	/**
	 * @return the brandName
	 */
	public String getBrandName() {
		return brandName;
	}

	/**
	 * @param brandName the brandName to set
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * @return the routineCars
	 */
	public List<RoutineCarVO> getRoutineCars() {
		return routineCars;
	}

	/**
	 * @param routineCars the routineCars to set
	 */
	public void setRoutineCars(List<RoutineCarVO> routineCars) {
		this.routineCars = routineCars;
	}

//	/**
//	 * @return the vehicleModels
//	 */
//	public List<VehicleModelVO> getVehicleModels() {
//		return vehicleModels;
//	}
//
//	/**
//	 * @param vehicleModels the vehicleModels to set
//	 */
//	public void setVehicleModels(List<VehicleModelVO> vehicleModels) {
//		this.vehicleModels = vehicleModels;
//	}

}