/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.entity;

/**
 * @author hejian
 * 
 */
public class ShoppingCart {
	
	/** routineCarId 常规车ID */
	private Long routineCarId;

	/** title 显示完整车型名称 */
	private String title;

	/** 封面图片ID */
	private Long coverImgId;

	/** 封面图片URL */
	private String coverImgUrl;

	/**
	 * @return the routineCarId
	 */
	public Long getRoutineCarId() {
		return routineCarId;
	}

	/**
	 * @param routineCarId
	 *            the routineCarId to set
	 */
	public void setRoutineCarId(Long routineCarId) {
		this.routineCarId = routineCarId;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the coverImgId
	 */
	public Long getCoverImgId() {
		return coverImgId;
	}

	/**
	 * @param coverImgId
	 *            the coverImgId to set
	 */
	public void setCoverImgId(Long coverImgId) {
		this.coverImgId = coverImgId;
	}

	/**
	 * @return the coverImgUrl
	 */
	public String getCoverImgUrl() {
		return coverImgUrl;
	}

	/**
	 * @param coverImgUrl
	 *            the coverImgUrl to set
	 */
	public void setCoverImgUrl(String coverImgUrl) {
		this.coverImgUrl = coverImgUrl;
	}

}
