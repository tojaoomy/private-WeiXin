/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * 车型VO
 * 
 * 包含该车型下所有的颜色(颜色url)
 * 
 * @author hejian
 *
 */
public class VehicleModelVO {
    
    /** 车型id.  */
    private Long id;
    
    /** 车型名称. */
    private String name;
    
    /** 品牌id */
    private Long brandId;
    
    /** 车系id. */
    private Long seriesId;
    
    /** 颜色list. */
    private List<ColorImageVO> colors = new ArrayList<ColorImageVO>();

    /**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the brandId
	 */
	public Long getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId the brandId to set
	 */
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}

	/**
	 * @return the seriesId
	 */
	public Long getSeriesId() {
		return seriesId;
	}

	/**
	 * @param seriesId the seriesId to set
	 */
	public void setSeriesId(Long seriesId) {
		this.seriesId = seriesId;
	}

	/**
	 * @return the colors
	 */
	public List<ColorImageVO> getColors() {
		return colors;
	}

	/**
	 * @param colors the colors to set
	 */
	public void setColors(List<ColorImageVO> colors) {
		this.colors = colors;
	}
    
}
