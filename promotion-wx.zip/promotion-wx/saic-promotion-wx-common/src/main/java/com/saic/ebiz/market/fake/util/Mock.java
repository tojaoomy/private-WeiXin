/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.fake.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author hejian
 *
 */
public class Mock {
	
	private static Logger logger = LoggerFactory.getLogger(Mock.class);
	
	public static boolean isAppMock(){
		try {
			logger.info("Mock => System.getProperty('app.development.mock') : "
					+ System.getProperty("app.development.mock"));
			return Boolean.valueOf(System.getProperty("app.development.mock"));
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static boolean isDevMock(){
		try {
			logger.info("Mock => System.getProperty('system.development.mock') : "
					+ System.getProperty("system.development.mock"));
			return Boolean.valueOf(System.getProperty("system.development.mock"));
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
