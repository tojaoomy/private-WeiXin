/**
 * 
 */
package com.saic.ebiz.order.entity;

/**
 * @author hejian
 * 
 */
public class AccessCondition {
	/** 用户是否可以参加该活动 */
	private boolean userLimit = false;
	/** 用户参加该活动次数限制 */
	private int user_prmt_limit_num;
	/** 用户是否可以参加该经销商活动 */
	private boolean userStoreLimit = false;
	/** 用户参加该经销商活动次数限制 */
	private int user_store_limit_num;

	/**
	 * @return the userLimit
	 */
	public boolean isUserLimit() {
		return userLimit;
	}

	/**
	 * @param userLimit
	 *            the userLimit to set
	 */
	public void setUserLimit(boolean userLimit) {
		this.userLimit = userLimit;
	}

	/**
	 * @return the user_prmt_limit_num
	 */
	public int getUser_prmt_limit_num() {
		return user_prmt_limit_num;
	}

	/**
	 * @param user_prmt_limit_num
	 *            the user_prmt_limit_num to set
	 */
	public void setUser_prmt_limit_num(int user_prmt_limit_num) {
		this.user_prmt_limit_num = user_prmt_limit_num;
	}

	/**
	 * @return the userStoreLimit
	 */
	public boolean isUserStoreLimit() {
		return userStoreLimit;
	}

	/**
	 * @param userStoreLimit
	 *            the userStoreLimit to set
	 */
	public void setUserStoreLimit(boolean userStoreLimit) {
		this.userStoreLimit = userStoreLimit;
	}

	/**
	 * @return the user_store_limit_num
	 */
	public int getUser_store_limit_num() {
		return user_store_limit_num;
	}

	/**
	 * @param user_store_limit_num
	 *            the user_store_limit_num to set
	 */
	public void setUser_store_limit_num(int user_store_limit_num) {
		this.user_store_limit_num = user_store_limit_num;
	}
}
