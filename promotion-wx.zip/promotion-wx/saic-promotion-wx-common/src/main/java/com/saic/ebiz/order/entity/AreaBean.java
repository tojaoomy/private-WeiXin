/*
 * Copyright (C), 2013-2013, IBM
 * FileName: AreaBean.java
 * Author:   liuxue
 * Date:     2013年11月27日 上午15:33:23
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

/**
 * The Class AreaBean.
 */
public class AreaBean {
    
    //TO DO cityId should be deleted
    /** 城市id. */
    private Long cityId;
    
    /** 城市区域id. */
    private Long areaId;

    /** 城市区域. */
    private String areaName;
    
    /** 当前区域是否显示. */
    private boolean showFlage = false;

    /**
     * Gets the city id.
     * 
     * @return the city id
     */
    public Long getCityId() {
        return cityId;
    }

    /**
     * Sets the city id.
     * 
     * @param cityId the new city id
     */
    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }

    /**
     * Gets the area id.
     * 
     * @return the area id
     */
    public Long getAreaId() {
        return areaId;
    }

    /**
     * Sets the area id.
     * 
     * @param areaId the new area id
     */
    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    /**
     * Gets the area name.
     * 
     * @return the area name
     */
    public String getAreaName() {
        return areaName;
    }

    /**
     * Sets the area name.
     * 
     * @param areaName the new area name
     */
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    /**
     * Checks if is show flage.
     * 
     * @return the showFlage
     */
    public boolean isShowFlage() {
        return showFlage;
    }

    /**
     * Sets the show flage.
     * 
     * @param showFlage the showFlage to set
     */
    public void setShowFlage(boolean showFlage) {
        this.showFlage = showFlage;
    }
    
}
