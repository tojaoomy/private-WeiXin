/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: BrandVO.java
 * Author:   LiHan
 * Date:     2013年12月13日 上午10:39:48
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * 预约试驾品牌车系<br>
 * 〈功能详细描述〉品牌车系下拉框信息.
 * 
 * @author LiHan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class BrandVO {

    /** 品牌Id.  */
    private Long value;

    /** 品牌名称. */
    private String text;

    /** 车系List. */
    private List<SeriesVO> children = new ArrayList<SeriesVO>();

    /**
     * Gets the value.
     * 
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     * 
     * @param value the value to set
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the text.
     * 
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the text.
     * 
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * Gets the children.
     * 
     * @return the children
     */
    public List<SeriesVO> getChildren() {
        return children;
    }

    /**
     * Sets the children.
     * 
     * @param children the children to set
     */
    public void setChildren(List<SeriesVO> children) {
        this.children = children;
    }
}