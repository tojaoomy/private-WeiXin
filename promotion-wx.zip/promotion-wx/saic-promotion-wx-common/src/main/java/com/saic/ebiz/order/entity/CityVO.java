/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: CityVO.java
 * Author:   v_xuxuewen01
 * Date:     2013年12月13日 上午11:40:30
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.util.List;


/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉.
 * 
 * @author v_xuxuewen01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class CityVO {
    
    /** 城市id. */
    private Long value;
    
    /** 中文名称. */
    private String text;
    
    /** 对应省的id. */
    private Long pvalue;
    
    /** 城市下的区域. */
    private List<AreaVO> children;
    
    /**
     * Gets the value.
     * 
     * @return the value
     */
    public Long getValue() {
        return value;
    }
    
    /**
     * Sets the value.
     * 
     * @param value the value to set
     */
    public void setValue(Long value) {
        this.value = value;
    }
    
    /**
     * Gets the text.
     * 
     * @return the text
     */
    public String getText() {
        return text;
    }
    
    /**
     * Sets the text.
     * 
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }
    
    /**
     * Gets the pvalue.
     * 
     * @return the pvalue
     */
    public Long getPvalue() {
        return pvalue;
    }
    
    /**
     * Sets the pvalue.
     * 
     * @param pvalue the pvalue to set
     */
    public void setPvalue(Long pvalue) {
        this.pvalue = pvalue;
    }
    
    /**
     * Gets the children.
     * 
     * @return the children
     */
    public List<AreaVO> getChildren() {
        return children;
    }
    
    /**
     * Sets the children.
     * 
     * @param children the children to set
     */
    public void setChildren(List<AreaVO> children) {
        this.children = children;
    }
}
