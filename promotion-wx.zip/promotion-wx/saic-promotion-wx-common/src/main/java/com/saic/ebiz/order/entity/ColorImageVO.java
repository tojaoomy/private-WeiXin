/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: ColorImageVO.java
 * Author:   xuxuewen
 * Date:     2014年5月21日 上午10:14:26
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xuxuewen
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ColorImageVO {
    /**
     * 活动商品颜色Id
     */
    private Long colorId;
    /**
     * 活动商品颜色名称
     */
    private String colorName;
    
    /** 
     * 图片Id
     */
    private Long imageId;
    /**
     * 图片URL
     */
    private String imageUrl;
    /**
     * @return the colorId
     */
    public Long getColorId() {
        return colorId;
    }
    /**
     * @param colorId the colorId to set
     */
    public void setColorId(Long colorId) {
        this.colorId = colorId;
    }
    /**
     * @return the colorName
     */
    public String getColorName() {
        return colorName;
    }
    /**
     * @param colorName the colorName to set
     */
    public void setColorName(String colorName) {
        this.colorName = colorName;
    }
    /**
     * @return the imageId
     */
    public Long getImageId() {
        return imageId;
    }
    /**
     * @param imageId the imageId to set
     */
    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }
    /**
     * @return the imageUrl
     */
    public String getImageUrl() {
        return imageUrl;
    }
    /**
     * @param imageUrl the imageUrl to set
     */
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    
}
