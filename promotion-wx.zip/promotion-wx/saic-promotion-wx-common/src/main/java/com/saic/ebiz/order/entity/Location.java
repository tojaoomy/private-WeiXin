/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: Location.java
 * Author: zengjianl
 * Date: 2013年12月4日 下午2:30:08
 * Description: //模块目的、功能描述
 * History: //修改记录
 * <author> <time> <version> <desc>
 * 修改人姓名 修改时间 版本号 描述
 */
package com.saic.ebiz.order.entity;

import java.io.Serializable;

/**
 * 地点类<br>
 * 
 * @author zengjianl
 * @since [产品/模块版本] （可选）
 */
public class Location implements Serializable {

    /**
     */
    private static final long serialVersionUID = -3675475524599096114L;
    /**
     *  地点Id
     */
    private String locationId;
    /**
     * 地点名称
     */
    private String locationName;
    
    /**
     * 是否禁用(Y:禁用  N:不禁用)
     */
    private String disableFlag;

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    /**
     * @return the locationName
     */
    public String getLocationName() {
        return locationName;
    }

    /**
     * @param locationName the locationName to set
     */
    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getDisableFlag() {
        return disableFlag;
    }

    public void setDisableFlag(String disableFlag) {
        this.disableFlag = disableFlag;
    }

}
