/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: OrderVO.java
 * Author:   LiuXue
 * Date:     2013年12月12日 上午18:31:32
 * Description://支付
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.math.BigDecimal;

import com.saic.ebiz.order.service.entity.dto.PreOrderQueryCustResultDTO;

/**
 * 订单<br>
 * .
 * 
 * @author LiuXue
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class OrderVO {
    
    /** 订单编号. */
    private String orderId;

    /** 订单金额. */
    private BigDecimal price;

    /** 定单状态. */
    private String status;

    /** 经销商店铺编号. */
    private Long storeId;
    
    /** 商品ID. */
    private Long productId;

    /** 商品名称. */
    private String productName;

    /** 商品描述. */
    private String productDesc;

    /** 会员编号. */
    private Long membNum;

    /** 超时时间限制(单位：“分钟”). */
    private Integer time;
    
    /** 电话号码. */
    private String mobileNo;

    /** 是否超时. */
    private boolean timeOut;

    /** 支付状态. */
    private String payStatus;

    /**
     * Instantiates a new order vo.
     */
    public OrderVO(){
        
    }
    
    /**
     * Instantiates a new order vo.
     * 
     * @param dto the dto
     */
    public OrderVO(PreOrderQueryCustResultDTO dto){
        this.membNum = dto.getUserId();
        this.orderId = dto.getPreOrderId();
        this.payStatus = dto.getPayStatusCode();
        this.price = dto.getDeposit().setScale(2,BigDecimal.ROUND_HALF_UP);
        this.productId = dto.getVelModelId();
        this.status = dto.getStatusCode();
        this.storeId = Long.valueOf(dto.getStoreId());
        this.time =  60;//dto.getTimeOutMinute();
        this.timeOut = dto.isTimeOut();
        this.mobileNo = dto.getMobileNo();
        
    }
    
    /**
     * Gets the getMobile No.
     * 
     * @return the getMobile No
     */
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * Sets the Mobile No.
     * 
     * @param mobileNo the new Mobile No
     */
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    /**
     * Gets the product id.
     * 
     * @return the product id
     */
    public Long getProductId() {
        return productId;
    }

    /**
     * Sets the product id.
     * 
     * @param productId the new product id
     */
    public void setProductId(Long productId) {
        this.productId = productId;
    }

    /**
     * Gets the order id.
     * 
     * @return the order id
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the order id.
     * 
     * @param orderId the new order id
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Gets the price.
     * 
     * @return the price
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * Sets the price.
     * 
     * @param price the new price
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     * 
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
    /**
     * Gets the store id.
     * 
     * @return the store id
     */
    public Long getStoreId() {
        return storeId;
    }

    /**
     * Sets the store id.
     * 
     * @param storeId the new store id
     */
    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the product name.
     * 
     * @return the product name
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the product name.
     * 
     * @param productName the new product name
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Gets the product desc.
     * 
     * @return the product desc
     */
    public String getProductDesc() {
        return productDesc;
    }

    /**
     * Sets the product desc.
     * 
     * @param productDesc the new product desc
     */
    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    /**
     * Gets the memb num.
     * 
     * @return the memb num
     */
    public Long getMembNum() {
        return membNum;
    }

    /**
     * Sets the memb num.
     * 
     * @param membNum the new memb num
     */
    public void setMembNum(Long membNum) {
        this.membNum = membNum;
    }

    /**
     * Gets the time.
     * 
     * @return the time
     */
    public Integer getTime() {
        return time;
    }

    /**
     * Sets the time.
     * 
     * @param time the new time
     */
    public void setTime(Integer time) {
        this.time = time;
    }
    
    /**
     * Gets the time out.
     * 
     * @return the time out
     */
    public boolean getTimeOut() {
        return timeOut;
    }

    /**
     * Sets the time out.
     * 
     * @param timeOut the new time out
     */
    public void setTimeOut(boolean timeOut) {
        this.timeOut = timeOut;
    }

    /**
     * Gets the pay status.
     * 
     * @return the pay status
     */
    public String getPayStatus() {
        return payStatus;
    }

    /**
     * Sets the pay status.
     * 
     * @param payStatus the new pay status
     */
    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }

}
