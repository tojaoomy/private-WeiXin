/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: PreOrderVO.java
 * Author:   v_xuxuewen01
 * Date:     2014年1月20日 下午1:08:05
 * Description: 预订单VO//模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.saic.ebiz.order.utils.RegexUtil;


/**
 * 预订单VO<br> 
 * @author v_xuxuewen01.
 */
public class PreOrderVO {
    /**促销活动id.*/
    private Long promotionId;
    /**活动报名id.*/
    private Long subscriptionId;
    /**权益描述.*/
    private String prmtDesc;
    /** 品牌名称. */
    private String brandName;
    /** 品牌id. */
    private long brandId;
    /** 车系名称. */
    private String seriesName;
    /** 车系id. */
    private long seriesId;
    /** 车型名称. */
    private String productName;
    /** 车型id. */
    private String productId;
    /** 促销产品颜色id. */
    private String colorId;
    /** 颜色的名称. */
    private String colorName;
    /**经销商id.*/
    private Long dealerId;
    /**店铺id.*/
    private Long storeId;
    /** 会员id. */
    private String userId;
    /** 会员名称. */
    @NotBlank(message="姓名不能为空")
    @Length(max = 30, message = "姓名为1-30位中英文字符")
    @Pattern(regexp=RegexUtil.REGEX_EN_ZH_BLANK,message="姓名必须为中文或英文")
    private String userName;
    /** 会员手机号码. */
    @Pattern(regexp=RegexUtil.REGEX_MOBILE,message="手机号码错误")
    private String userTel;
    /**会员邮箱.*/
    private String email;
    /** 省. */
    @NotBlank(message="区域不能为空")
    private String provinceId;
    /** 省名. */
    private String provinceName;
    /** 市. */
    @NotBlank(message="区域不能为空")
    private String cityId;
    /** 市名. */
    private String cityName;
    /** 区名. */
    private String areaId;
    /** 意向金. */
    //@NotBlank(message="意向金不能为空")
    private String deposit;
    /** 是否车贷. */
    private String loanFlag = "N";
    /** 是否需要车险服务. */
    private String needInsuranceFlag = "N";
    /** 是否需要上牌服务. */
    private String registerLicenceFlag = "N";
//    /** 计划到店时间. */
//    @NotEmpty(message="到店时间不能为空")
    private String planArrialTime;
    /** tokenCode */
    private String tokenCode;
    /**客户id,minisit那边需要的参数.*/
    private Long customerId;
    /**礼包信息，minisit那边需要的.*/
    private String benefit;
    /**礼包编码.*/
    private String gift;
    
    /** 礼包邮寄地址省  */
    private String addressProvince;
    
    /** 礼包邮寄地址市  */
    private String addressCity;
    
    /** 礼包邮寄地址区  */
    private String addressArea;
    
    /** 礼包邮寄详细地址 */
    private String receiveAddress;
    
    /** 礼包邮寄地址邮编  */
    private String zipCode;
    
    
    
    /**
     * @return the promotionId
     */
    public Long getPromotionId() {
        return promotionId;
    }
    /**
     * @param promotionId the promotionId to set
     */
    public void setPromotionId(Long promotionId) {
        this.promotionId = promotionId;
    }
    /**
     * @return the brandName
     */
    public String getBrandName() {
        return brandName;
    }
    /**
     * @param brandName the brandName to set
     */
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
    /**
     * @return the seriesName
     */
    public String getSeriesName() {
        return seriesName;
    }
    /**
     * @param seriesName the seriesName to set
     */
    public void setSeriesName(String seriesName) {
        this.seriesName = seriesName;
    }
    /**
     * @return the productName
     */
    public String getProductName() {
        return productName;
    }
    /**
     * @param productName the productName to set
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }
    /**
     * @return the colorId
     */
    public String getColorId() {
        return colorId;
    }
    /**
     * @param colorId the colorId to set
     */
    public void setColorId(String colorId) {
        this.colorId = colorId;
    }
    /**
     * @return the colorName
     */
    public String getColorName() {
        return colorName;
    }
    /**
     * @param colorName the colorName to set
     */
    public void setColorName(String colorName) {
        this.colorName = colorName;
    }
    /**
     * @return the dealerId
     */
    public Long getDealerId() {
        return dealerId;
    }
    /**
     * @param dealerId the dealerId to set
     */
    public void setDealerId(Long dealerId) {
        this.dealerId = dealerId;
    }
    /**
     * @return the storeId
     */
    public Long getStoreId() {
        return storeId;
    }
    /**
     * @param storeId the storeId to set
     */
    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }
    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**
     * @return the userTel
     */
    public String getUserTel() {
        return userTel;
    }
    /**
     * @param userTel the userTel to set
     */
    public void setUserTel(String userTel) {
        this.userTel = userTel;
    }
    /**
     * @return the provinceId
     */
    public String getProvinceId() {
        return provinceId;
    }
    /**
     * @param provinceId the provinceId to set
     */
    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId;
    }
    /**
     * @return the cityId
     */
    public String getCityId() {
        return cityId;
    }
    /**
     * @param cityId the cityId to set
     */
    public void setCityId(String cityId) {
        this.cityId = cityId;
    }
    /**
     * @return the deposit
     */
    public String getDeposit() {
        return deposit;
    }
    /**
     * @param deposit the deposit to set
     */
    public void setDeposit(String deposit) {
        this.deposit = deposit;
    }
    /**
     * @return the loanFlag
     */
    public String getLoanFlag() {
        return loanFlag;
    }
    /**
     * @param loanFlag the loanFlag to set
     */
    public void setLoanFlag(String loanFlag) {
        this.loanFlag = loanFlag;
    }
    /**
     * @return the needInsuranceFlag
     */
    public String getNeedInsuranceFlag() {
        return needInsuranceFlag;
    }
    /**
     * @param needInsuranceFlag the needInsuranceFlag to set
     */
    public void setNeedInsuranceFlag(String needInsuranceFlag) {
        this.needInsuranceFlag = needInsuranceFlag;
    }
    /**
     * @return the registerLicenceFlag
     */
    public String getRegisterLicenceFlag() {
        return registerLicenceFlag;
    }
    /**
     * @param registerLicenceFlag the registerLicenceFlag to set
     */
    public void setRegisterLicenceFlag(String registerLicenceFlag) {
        this.registerLicenceFlag = registerLicenceFlag;
    }
    /**
     * @return the prmtDesc
     */
    public String getPrmtDesc() {
        return prmtDesc;
    }
    /**
     * @param prmtDesc the prmtDesc to set
     */
    public void setPrmtDesc(String prmtDesc) {
        this.prmtDesc = prmtDesc;
    }
    
    /**
     * @return the brandId
     */
    public long getBrandId() {
        return brandId;
    }
    /**
     * @param brandId the brandId to set
     */
    public void setBrandId(long brandId) {
        this.brandId = brandId;
    }
    
    /**
     * @return the seriesId
     */
    public long getSeriesId() {
        return seriesId;
    }
    /**
     * @param seriesId the seriesId to set
     */
    public void setSeriesId(long seriesId) {
        this.seriesId = seriesId;
    }
    /**
     * @return the productId
     */
    public String getProductId() {
        return productId;
    }
    /**
     * @param productId the productId to set
     */
    public void setProductId(String productId) {
        this.productId = productId;
    }
    /**
     * @return the planArrialTime
     */
    public String getPlanArrialTime() {
        return planArrialTime;
    }
    /**
     * @param planArrialTime the planArrialTime to set
     */
    public void setPlanArrialTime(String planArrialTime) {
        this.planArrialTime = planArrialTime;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the provinceName
     */
    public String getProvinceName() {
        return provinceName;
    }
    /**
     * @param provinceName the provinceName to set
     */
    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }
    /**
     * @return the cityName
     */
    public String getCityName() {
        return cityName;
    }
    /**
     * @param cityName the cityName to set
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    /**
     * @return the areaId
     */
    public String getAreaId() {
        return areaId;
    }
    /**
     * @param areaId the areaId to set
     */
    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }
    /**
     * @return the tokenCode
     */
    public String getTokenCode() {
        return tokenCode;
    }
    /**
     * @param tokenCode the tokenCode to set
     */
    public void setTokenCode(String tokenCode) {
        this.tokenCode = tokenCode;
    }
    /**
     * @return the customerId
     */
    public Long getCustomerId() {
        return customerId;
    }
    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
    /**
     * @return the benefit
     */
    public String getBenefit() {
        return benefit;
    }
    /**
     * @param benefit the benefit to set
     */
    public void setBenefit(String benefit) {
        this.benefit = benefit;
    }
    
    /**
	 * @return the gift
	 */
	public String getGift() {
		return gift;
	}
	/**
	 * @param gift the gift to set
	 */
	public void setGift(String gift) {
		this.gift = gift;
	}
	/**
     * @return the subscriptionId
     */
    public Long getSubscriptionId() {
        return subscriptionId;
    }
    /**
     * @param subscriptionId the subscriptionId to set
     */
    public void setSubscriptionId(Long subscriptionId) {
        this.subscriptionId = subscriptionId;
    }
	/**
	 * @return the addressProvince
	 */
	public String getAddressProvince() {
		return addressProvince;
	}
	/**
	 * @param addressProvince the addressProvince to set
	 */
	public void setAddressProvince(String addressProvince) {
		this.addressProvince = addressProvince;
	}
	/**
	 * @return the addressCity
	 */
	public String getAddressCity() {
		return addressCity;
	}
	/**
	 * @param addressCity the addressCity to set
	 */
	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}
	/**
	 * @return the addressArea
	 */
	public String getAddressArea() {
		return addressArea;
	}
	/**
	 * @param addressArea the addressArea to set
	 */
	public void setAddressArea(String addressArea) {
		this.addressArea = addressArea;
	}
	/**
	 * @return the receiveAddress
	 */
	public String getReceiveAddress() {
		return receiveAddress;
	}
	/**
	 * @param receiveAddress the receiveAddress to set
	 */
	public void setReceiveAddress(String receiveAddress) {
		this.receiveAddress = receiveAddress;
	}
	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}
	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
    
}
