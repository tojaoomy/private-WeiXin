/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: PriceLowerVO.java
 * Author:   v_xuxuewen01
 * Date:     2013年12月18日 上午10:24:06
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import com.saic.ebiz.order.utils.RegexUtil;


/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉.
 * 
 * @author v_xuxuewen01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class PriceLowerVO {
    
    /** 品牌id. */
    @NotEmpty(message="品牌不能为空")
    private String brandId;
    
    /** 车系id. */
    @NotEmpty(message="车系不能为空")
    private String seriesId;
    
    /** 车型id. */
    @NotEmpty(message="车型不能为空")
    private String productId;
    
    /** 店铺id. */
    @NotEmpty(message="店铺不能为空")
    private String storeId;
    
    /** 店铺名称. */
    @NotEmpty(message="店铺不能为空")
    private String storeName;
    
    /** 会员名称. */
    private String userName;
    
    /** 会员id. */
    private Long userId;
    
    /** 会员手机号码. */
    @Pattern(regexp=RegexUtil.REGEX_MOBILE,message="手机号码格式错误")
    private String userTel;
    
    /** 省. */
    @NotEmpty(message="区域不能为空")
    private String provinceId;
    
    /** 市. */
    @NotEmpty(message="区域不能为空")
    private String cityId;
    
    /** 区/县. */
    @NotEmpty(message="区域不能为空")
    private String townId;
    
    /**
     * Gets the brand id.
     * 
     * @return the brandId
     */
    public String getBrandId() {
        return brandId;
    }
    
    /**
     * Sets the brand id.
     * 
     * @param brandId the brandId to set
     */
    public void setBrandId(String brandId) {
        this.brandId = brandId;
    }
    
    /**
     * Gets the series id.
     * 
     * @return the seriesId
     */
    public String getSeriesId() {
        return seriesId;
    }
    
    /**
     * Sets the series id.
     * 
     * @param seriesId the seriesId to set
     */
    public void setSeriesId(String seriesId) {
        this.seriesId = seriesId;
    }
    
    /**
     * Gets the product id.
     * 
     * @return the productId
     */
    public String getProductId() {
        return productId;
    }
    
    /**
     * Sets the product id.
     * 
     * @param productId the productId to set
     */
    public void setProductId(String productId) {
        this.productId = productId;
    }
    
    /**
     * Gets the store id.
     * 
     * @return the storeId
     */
    public String getStoreId() {
        return storeId;
    }
    
    /**
     * Sets the store id.
     * 
     * @param storeId the storeId to set
     */
    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }
    
    /**
     * Gets the user name.
     * 
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }
    
    /**
     * Sets the user name.
     * 
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    /**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
     * Gets the user tel.
     * 
     * @return the userTel
     */
    public String getUserTel() {
        return userTel;
    }
    
    /**
     * Sets the user tel.
     * 
     * @param userTel the userTel to set
     */
    public void setUserTel(String userTel) {
        this.userTel = userTel;
    }
    
    /**
     * Gets the province id.
     * 
     * @return the provinceId
     */
    public String getProvinceId() {
        return provinceId;
    }
    
    /**
     * Sets the province id.
     * 
     * @param provinceId the provinceId to set
     */
    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId;
    }
    
    /**
     * Gets the city id.
     * 
     * @return the cityId
     */
    public String getCityId() {
        return cityId;
    }
    
    /**
     * Sets the city id.
     * 
     * @param cityId the cityId to set
     */
    public void setCityId(String cityId) {
        this.cityId = cityId;
    }
    
    /**
     * Gets the store name.
     * 
     * @return the storeName
     */
    public String getStoreName() {
        return storeName;
    }
    
    /**
     * Sets the store name.
     * 
     * @param storeName the storeName to set
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getTownId() {
        return townId;
    }

    public void setTownId(String townId) {
        this.townId = townId;
    }
    
}
