/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: PriceLowerVO.java
 * Author:   v_wuxingya01
 * Date:     2014年2月28日 下午7:16:13
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.saic.ebiz.order.utils.RegexUtil;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉.
 * 
 * @author v_wuxingya01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class PriceLowerVOValidator implements Validator {
    
    /** 真实姓名长度. */
    private static final int REALNAME_MAX = 30;
    
    /** 最小长度. */
    private static final int MIN = 0;

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean supports(Class<?> clazz) {
        return PriceLowerVO.class.equals(clazz);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validate(Object target, Errors errors) {
        PriceLowerVO priceLowerVO = (PriceLowerVO) target;

        validate0(priceLowerVO, errors);
    }

    /**
     * 功能描述: 验证姓名<br>
     * 〈功能详细描述〉.
     * 
     * @param priceLowerVO the price lower vo
     * @param errors the errors
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private void validate0(PriceLowerVO priceLowerVO, Errors errors) {
        /**
         * 客户姓名 可输入中文，英文，数字，最多输入30个字符，大于30个不能继续录入 为空提交时页面Tips提示：请输入姓名
         */
        if (!StringUtils.isNotBlank(priceLowerVO.getUserName())) {
            errors.rejectValue("userName", null, "请输入您的真实姓名");
        } else {
            priceLowerVO.setUserName(blockContent(priceLowerVO.getUserName(), REALNAME_MAX));
            if (!RegexUtil.check(RegexUtil.REGEX_EN_NUM_ZH, priceLowerVO.getUserName())) {
                errors.rejectValue("userName", null, "请输入中文, 英文, 数字");
            } else if (priceLowerVO.getUserName().length() > REALNAME_MAX) {
                errors.rejectValue("userName", null, "最多输入30个字符");
            }
        }
    }

    /**
     * 功能描述: 字符串超过长度截断. <br>
     * 
     * @param content 字符串内容
     * @param maxLength 字符串最大长度
     * @return String 截断后的字符串
     */
    private String blockContent(String content, int maxLength) {
        content = trimSpaceAndJs(content);
        if (content.length() > maxLength) {
            content = content.substring(MIN, maxLength);
        }
        return content;
    }

    /**
     * 
     * 功能描述: 去处属性前后空格. <br>
     * 
     * @param space 带有前后空格的字符串
     * @return String trim之后的字符串
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private String trimSpaceAndJs(String space) {
        Pattern pt = Pattern.compile("^\\s*|\\s*$");
        Matcher mt = pt.matcher(space);
        String result = mt.replaceAll(StringUtils.EMPTY);
        return result.replaceAll("<", "&lt;").replaceAll(">", "&gt;")
                .replaceAll("\"", "&quot;");
    }

}
