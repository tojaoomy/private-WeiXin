/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.order.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author hejian
 *
 */
public class PromotionCityNew {
	/** 中文省份名臣 */
	private String text;
	
	/** 一个省份的所有城市 */
	private List<CityObject> city = new ArrayList<CityObject>();
	
	/** 第一个拼音字母大写 */
	private String FirstCharacter;
	
	/** 省份拼音全称 */
	private String Pinyin;

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @return the city
	 */
	public List<CityObject> getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(List<CityObject> city) {
		this.city = city;
	}

	/**
	 * @return the firstCharacter
	 */
	public String getFirstCharacter() {
		return FirstCharacter;
	}

	/**
	 * @param firstCharacter the firstCharacter to set
	 */
	public void setFirstCharacter(String firstCharacter) {
		FirstCharacter = firstCharacter;
	}

	/**
	 * @return the pinyin
	 */
	public String getPinyin() {
		return Pinyin;
	}

	/**
	 * @param pinyin the pinyin to set
	 */
	public void setPinyin(String pinyin) {
		Pinyin = pinyin;
	}

}
