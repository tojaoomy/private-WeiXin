/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: PromotionModelColor.java
 * Author:   xuxuewen
 * Date:     2014年5月19日 下午6:01:23
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xuxuewen
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class PromotionModelColor {
    
    /**
     * 颜色名称
     */
    private String colorName;
    /**
     *  颜色id
     */
    private long colorId;
    /**
     * 颜色图片地址
     */
    private String colorImgUrl;
    /**
     * @return the colorName
     */
    public String getColorName() {
        return colorName;
    }
    /**
     * @param colorName the colorName to set
     */
    public void setColorName(String colorName) {
        this.colorName = colorName;
    }
    /**
     * @return the colorId
     */
    public long getColorId() {
        return colorId;
    }
    /**
     * @param colorId the colorId to set
     */
    public void setColorId(long colorId) {
        this.colorId = colorId;
    }
    /**
     * @return the colorImgUrl
     */
    public String getColorImgUrl() {
        return colorImgUrl;
    }
    /**
     * @param colorImgUrl the colorImgUrl to set
     */
    public void setColorImgUrl(String colorImgUrl) {
        this.colorImgUrl = colorImgUrl;
    }
    
    
}
