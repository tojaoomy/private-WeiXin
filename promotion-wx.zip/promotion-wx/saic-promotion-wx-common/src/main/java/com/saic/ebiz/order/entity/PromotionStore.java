/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: PromotionStore.java
 * Author:   xuxuewen
 * Date:     2014年5月20日 下午4:37:27
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.math.BigDecimal;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉活动店铺
 *
 * @author xuxuewen
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class PromotionStore {
    /**
     *  店铺Id
     */
    private long storeId;
    /**
     * 店铺名称
     */
    private String storeName;
    /**
     * 地址
     */
    private String address;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 纬度
     */
    private String latitude;
    
    /** deposit 意向金 */
    private BigDecimal deposit;
    
    /** 电话 */
    private String phoneNumber;
    
    /**
	 * 库存
	 */
	private Long stock;
	
	/**
	 * QQ
	 */
	private String qq;
	
    /**
     * @return the storeId
     */
    public long getStoreId() {
        return storeId;
    }
    /**
     * @param storeId the storeId to set
     */
    public void setStoreId(long storeId) {
        this.storeId = storeId;
    }
    /**
     * @return the storeName
     */
    public String getStoreName() {
        return storeName;
    }
    /**
     * @param storeName the storeName to set
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    /**
     * @return the longitude
     */
    public String getLongitude() {
        return longitude;
    }
    /**
     * @param longitude the longitude to set
     */
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    /**
     * @return the latitude
     */
    public String getLatitude() {
        return latitude;
    }
    /**
     * @param latitude the latitude to set
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    /**
     * @return the deposit
     */
    public BigDecimal getDeposit() {
        return deposit;
    }
    /**
     * @param deposit the deposit to set
     */
    public void setDeposit(BigDecimal deposit) {
        this.deposit = deposit;
    }
    
    /**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @return the stock
	 */
	public Long getStock() {
		return stock;
	}

	/**
	 * @param stock the stock to set
	 */
	public void setStock(Long stock) {
		this.stock = stock;
	}

	/**
	 * @return the qq
	 */
	public String getQq() {
		return qq;
	}

	/**
	 * @param qq the qq to set
	 */
	public void setQq(String qq) {
		this.qq = qq;
	}
}
