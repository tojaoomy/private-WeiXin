/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: AreaVO.java
 * Author:   v_xuxuewen01
 * Date:     2013年12月12日 上午10:44:44
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.util.List;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉区域的vo.
 * 
 * @author v_xuxuewen01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ProvinceVO {
    
    /** 省id. */
    private Long value;
    
    /** 省的名称. */
    private String text;

    /** 省下的城市. */
    private List<CityVO> children;

    /**
     * Gets the value.
     * 
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     * 
     * @param value the value to set
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the text.
     * 
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the text.
     * 
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * Gets the children.
     * 
     * @return the children
     */
    public List<CityVO> getChildren() {
        return children;
    }

    /**
     * Sets the children.
     * 
     * @param children the children to set
     */
    public void setChildren(List<CityVO> children) {
        this.children = children;
    }
    
    
}
