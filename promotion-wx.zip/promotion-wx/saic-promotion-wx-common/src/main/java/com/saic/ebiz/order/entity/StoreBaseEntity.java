/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: StoreBaseEntity.java
 * Author:   HeJian
 * Date:     2013年12月13日 上午10:39:48
 * Description: //模块目的、功能描述      
 * History:      
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import com.saic.ebiz.mdm.partner.entity.StoreBaseInfo;


/**
 * 
 * 经销商的基本信息 ： 经销商编号，名称，经营的品牌，电话号码，QQ热线，地址，地理经度纬度，积分
 * 
 * @author hejian
 * 
 * @see StoreBaseInfo
 */

public class StoreBaseEntity extends StoreBaseInfo {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2057664444712528815L;

	/**
	 * 店铺Id
	 */
	private long storeId;
	/**
	 * 店铺名称
	 */
	private String storeName;
	/**
	 * 品牌Id
	 */
	private Long brandId;
	/**
	 * 品牌名称
	 */
	private String brandName;
	/**
	 * 热线电话
	 */
	private String hotLine;
	/**
	 * 地址
	 */
	private String address;
	/**
	 * 经度
	 */
	private String longitude;
	/**
	 * 纬度
	 */
	private String latitude;
	/**
	 * 经销商Id
	 */
	private Long dealerId;
	/**
	 * 经销商名称
	 */
	private String dealerName;
	/**
	 * 城市id
	 */
	private Long cityId;
	/**
	 * 城市区域id
	 */
	private Long districtId;

	/**
	 * 纬度 高德
	 */
	private String latitudeAn;

	/**
	 * 经度 高德
	 */
	private String longitudeAn;

	/**
	 * 经销商积分
	 */
	private Long pointSummary;

	/**
	 * 库存
	 */
	private Long stock;

	/**
	 * QQ
	 */
	private String qq;

	/**
	 * @return the storeId
	 */
	public long getStoreId() {
		return storeId;
	}

	/**
	 * @param storeId
	 *            the storeId to set
	 */
	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	/**
	 * @return the storeName
	 */
	public String getStoreName() {
		return storeName;
	}

	/**
	 * @param storeName
	 *            the storeName to set
	 */
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	/**
	 * @return the brandId
	 */
	public Long getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId
	 *            the brandId to set
	 */
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}

	/**
	 * @return the brandName
	 */
	public String getBrandName() {
		return brandName;
	}

	/**
	 * @param brandName
	 *            the brandName to set
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * @return the hotLine
	 */
	public String getHotLine() {
		return hotLine;
	}

	/**
	 * @param hotLine
	 *            the hotLine to set
	 */
	public void setHotLine(String hotLine) {
		this.hotLine = hotLine;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude
	 *            the longitude to set
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude
	 *            the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the dealerId
	 */
	public Long getDealerId() {
		return dealerId;
	}

	/**
	 * @param dealerId
	 *            the dealerId to set
	 */
	public void setDealerId(Long dealerId) {
		this.dealerId = dealerId;
	}

	/**
	 * @return the cityId
	 */
	public Long getCityId() {
		return cityId;
	}

	/**
	 * @param cityId
	 *            the cityId to set
	 */
	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	/**
	 * @return the districtId
	 */
	public Long getDistrictId() {
		return districtId;
	}

	/**
	 * @param districtId
	 *            the districtId to set
	 */
	public void setDistrictId(Long districtId) {
		this.districtId = districtId;
	}

	/**
	 * @return the dealerName
	 */
	public String getDealerName() {
		return dealerName;
	}

	/**
	 * @param dealerName
	 *            the dealerName to set
	 */
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public String getLatitudeAn() {
		return latitudeAn;
	}

	public void setLatitudeAn(String latitudeAn) {
		this.latitudeAn = latitudeAn;
	}

	public String getLongitudeAn() {
		return longitudeAn;
	}

	public void setLongitudeAn(String longitudeAn) {
		this.longitudeAn = longitudeAn;
	}

	public Long getPointSummary() {
		return pointSummary;
	}

	public void setPointSummary(Long pointSummary) {
		this.pointSummary = pointSummary;
	}

	/**
	 * @return the stock
	 */
	public Long getStock() {
		return stock;
	}

	/**
	 * @param stock
	 *            the stock to set
	 */
	public void setStock(Long stock) {
		this.stock = stock;
	}

	/**
	 * @return the qq
	 */
	public String getQq() {
		return qq;
	}

	/**
	 * @param qq
	 *            the qq to set
	 */
	public void setQq(String qq) {
		this.qq = qq;
	}

}
