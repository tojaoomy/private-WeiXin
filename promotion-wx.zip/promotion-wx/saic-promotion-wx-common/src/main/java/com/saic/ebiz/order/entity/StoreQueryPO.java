/*
 * Copyright (C), 2013-2014, 上汽集团
 * FileName: StoreQueryPO.java
 * Author:   lihaixia
 * Date:     2014年5月4日 上午10:53:31
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.io.Serializable;

/**
 * 〈一句话功能简述〉<br> 
 * 主站查询店铺入参
 *
 * @author lihaixia
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class StoreQueryPO implements Serializable {

    /**
     *  UID
     */
    private static final long serialVersionUID = -4423947884667434639L;
    
    /**
     * 区域ID
     */
    private Long districtId;
    /**
     * 品牌ID
     */
    private Long brandId;
    /**
     * 车系ID
     */
    private Long seriesId;
    
    /**
     * 车型ID
     */
    private Long modelId;
    
    
    /**
     * @return the districtId
     */
    public Long getDistrictId() {
        return districtId;
    }
    /**
     * @param districtId the districtId to set
     */
    public void setDistrictId(Long districtId) {
        this.districtId = districtId;
    }
    /**
     * @return the brandId
     */
    public Long getBrandId() {
        return brandId;
    }
    /**
     * @param brandId the brandId to set
     */
    public void setBrandId(Long brandId) {
        this.brandId = brandId;
    }
    /**
     * @return the seriesId
     */
    public Long getSeriesId() {
        return seriesId;
    }
    /**
     * @param seriesId the seriesId to set
     */
    public void setSeriesId(Long seriesId) {
        this.seriesId = seriesId;
	}

	/**
	 * @return the modelId
	 */
	public Long getModelId() {
		return modelId;
	}

	/**
	 * @param modelId
	 *            the modelId to set
	 */
	public void setModelId(Long modelId) {
		this.modelId = modelId;
	}
    
    

}
