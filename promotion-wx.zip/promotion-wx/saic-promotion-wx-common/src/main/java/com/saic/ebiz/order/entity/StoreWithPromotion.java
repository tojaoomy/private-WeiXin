/*
 * Copyright (C), 2013-2014, 上汽集团
 * FileName: StoreWithPromotion.java
 * Author:   lihaixia
 * Date:     2014年5月4日 上午11:20:32
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.math.BigDecimal;

import com.saic.ebiz.carlib.service.util.PriceConvertUtil;
import com.saic.ebiz.mdm.partner.entity.StoreBaseInfo;

/**
 * 〈一句话功能简述〉<br> 
 * 主站查询店铺结果
 *
 * @author lihaixia
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class StoreWithPromotion extends StoreBaseInfo {

    /**
     *  UID
     */
    private static final long serialVersionUID = -292062648043517738L;
    /**
     * 经销商最低报价
     */
    private BigDecimal minStorePrice;
    /**
     * 经销商最高报价
     */
    private BigDecimal maxStorePrice;
    /**
     * 活动Id
     */
    private Long promotionId;
    /**
     * 活动标题
     */
    private String promotionTitle;
    /**
     * @return the minStorePrice
     */
    public BigDecimal getMinStorePrice() {
        return minStorePrice;
    }

    /**
     * @param minStorePrice the minStorePrice to set
     */
    public void setMinStorePrice(BigDecimal minStorePrice) {
        this.minStorePrice = minStorePrice;
    }

    /**
     * @return the maxStorePrice
     */
    public BigDecimal getMaxStorePrice() {
        return maxStorePrice;
    }

    /**
     * @param maxStorePrice the maxStorePrice to set
     */
    public void setMaxStorePrice(BigDecimal maxStorePrice) {
        this.maxStorePrice = maxStorePrice;
    }
    
    /**
     * @return the promotionId
     */
    public Long getPromotionId() {
        return promotionId;
    }
    /**
     * @param promotionId the promotionId to set
     */
    public void setPromotionId(Long promotionId) {
        this.promotionId = promotionId;
    }
    /**
     * @return the promotionTitle
     */
    public String getPromotionTitle() {
        return promotionTitle;
    }
    /**
     * @param promotionTitle the promotionTitle to set
     */
    public void setPromotionTitle(String promotionTitle) {
        this.promotionTitle = promotionTitle;
    }    
    /**
     * 功能描述: <br>
     * 获取价格的万元格式
     * 
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public BigDecimal getMinStorePriceW() {
        return PriceConvertUtil.conver2W(this.minStorePrice);
    }

    /**
     * 功能描述: <br>
     * 获取价格的万元格式
     * 
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public BigDecimal getMaxStorePriceW() {
        return PriceConvertUtil.conver2W(this.maxStorePrice);
    }
}
