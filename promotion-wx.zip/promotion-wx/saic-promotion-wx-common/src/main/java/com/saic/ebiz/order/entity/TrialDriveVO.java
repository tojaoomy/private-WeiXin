/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: TrialDriveVO.java
 * Author:   LiHan
 * Date:     2013年12月13日 上午10:39:48
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 预约试驾<br>
 * 〈功能详细描述〉预约试驾信息.
 * 
 * @author LiHan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class TrialDriveVO {

    /** 品牌id. */
    private Long brandId;
    
    /** 车系Id. */
    private Long seriesId;
    
    /** 经销商Id. */
    private Long storeId;
    
    /** 经销商名称. */
    @NotEmpty(message="请选择经销商")
    private String storeName;

    /**
     * Gets the brand id.
     * 
     * @return the brandId
     */
    public Long getBrandId() {
        return brandId;
    }

    /**
     * Sets the brand id.
     * 
     * @param brandId the brandId to set
     */
    public void setBrandId(Long brandId) {
        this.brandId = brandId;
    }

    /**
     * Gets the series id.
     * 
     * @return the seriesId
     */
    public Long getSeriesId() {
        return seriesId;
    }

    /**
     * Sets the series id.
     * 
     * @param seriesId the seriesId to set
     */
    public void setSeriesId(Long seriesId) {
        this.seriesId = seriesId;
    }

    /**
     * Gets the store id.
     * 
     * @return the storeId
     */
    public Long getStoreId() {
        return storeId;
    }

    /**
     * Sets the store id.
     * 
     * @param storeId the storeId to set
     */
    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the store name.
     * 
     * @return the storeName
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * Sets the store name.
     * 
     * @param storeName the storeName to set
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }
}