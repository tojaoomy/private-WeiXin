/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: TryDriveVO.java
 * Author:   LiHan
 * Date:     2014年4月17日
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import com.saic.ebiz.order.utils.RegexUtil;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉预约试驾信息.
 * 
 * @author LiHan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class TryDriveVO {
    
    /** 用户id. */
    private Long id;
    
    /** 用户名称. */
    private String userNm;
    
    /** 用户联系方式. */
    @NotEmpty(message = "请输入手机号码")
    @Pattern(regexp=RegexUtil.REGEX_MOBILE, message="手机号码位数有误，请核对")
    private String tel;
    
    /** 车系. */
    private long seriesId;
    
    /** 车系名称. */
    private String seriesName;
    
    /** 省市. */
    @NotEmpty(message="省市不能为空")
    private String province;
    
    /** 区域. */
    @NotEmpty(message="区域不能为空")
    private String city;
    
    /** 品牌ID. */
    private long carId;
    
    /** 经销商名称. */
    private String dealerName;
    
    /** 经销商Id. */
    private long dealerId;
    
    /** 用户Id. */
    private long userId;
    
    /** 性别. */
    private String gender;
    
    /** 用户类型. */
    private String userType;
    
    /** 活动名称. */
    private String activityName;

	/**
	 * @return the activityName
	 */
	public String getActivityName() {
		return activityName;
	}

	/**
	 * @param activityName the activityName to set
	 */
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	/**
	 * @return the userType
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the userId
	 */
	public long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(long userId) {
		this.userId = userId;
	}

	/**
	 * @return the dealerId
	 */
	public long getDealerId() {
		return dealerId;
	}

	/**
	 * @param dealerId the dealerId to set
	 */
	public void setDealerId(long dealerId) {
		this.dealerId = dealerId;
	}

	/**
	 * @return the dealerName
	 */
	public String getDealerName() {
		return dealerName;
	}

	/**
	 * @param dealerName the dealerName to set
	 */
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	/**
	 * @return the carId
	 */
	public long getCarId() {
		return carId;
	}

	/**
	 * @param carId the carId to set
	 */
	public void setCarId(long carId) {
		this.carId = carId;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the province
	 */
	public String getProvince() {
		return province;
	}

	/**
	 * @param province the province to set
	 */
	public void setProvince(String province) {
		this.province = province;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the userNm
	 */
	public String getUserNm() {
		return userNm;
	}

	/**
	 * @param userNm the userNm to set
	 */
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}

	/**
	 * @param tel the tel to set
	 */
	public void setTel(String tel) {
		this.tel = tel;
	}

	/**
	 * @return the seriesId
	 */
	public long getSeriesId() {
		return seriesId;
	}

	/**
	 * @param seriesId the seriesId to set
	 */
	public void setSeriesId(long seriesId) {
		this.seriesId = seriesId;
	}

	/**
	 * @return the seriesName
	 */
	public String getSeriesName() {
		return seriesName;
	}

	/**
	 * @param seriesName the seriesName to set
	 */
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}
}