/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: TryDriveVOValidator.java
 * Author:   LiHan
 * Date:     2014年4月18日
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.entity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.saic.ebiz.order.utils.RegexUtil;

/**
 * 〈一句话功能简述〉验证TryDriveVO<br>
 * 〈功能详细描述〉
 * 
 * @author LiHan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class TryDriveVOValidator implements Validator {
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean supports(Class<?> clazz) {
        return TryDriveVO.class.equals(clazz);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validate(Object target, Errors errors) {
    	TryDriveVO tryDriveVO = (TryDriveVO) target;
        check(tryDriveVO, errors);
    }
    
    /**
     * 功能描述: 姓名校验.<br>
     * 
     * 
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private void check(TryDriveVO tryDriveVO,Errors errors){
    	/**
         * 客户姓名 可输入中文，英文，数字，最多输入30个字符，大于30个不能继续录入 为空提交时页面Tips提示：请输入姓名
         */
        if (StringUtils.isBlank(tryDriveVO.getUserNm())) {
            errors.rejectValue("userNm", null, "请输入您的真实姓名");
        } else if (tryDriveVO.getUserNm().length() > 30) {
            errors.rejectValue("userNm", null, "最多输入30个字符");
        }else if (!RegexUtil.check(RegexUtil.REGEX_EN_NUM_ZH, trimSpaceAndJs(tryDriveVO.getUserNm()))) {
            errors.rejectValue("userNm", null, "请输入中文, 英文, 数字");
        } 
    }

    /**
     * 
     * 功能描述: 去处属性前后空格. <br>
     * 
     * @param space 带有前后空格的字符串
     * @return String trim之后的字符串
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private String trimSpaceAndJs(String space) {
        Pattern pt = Pattern.compile("^\\s*|\\s*$");
        Matcher mt = pt.matcher(space);
        String result = mt.replaceAll(StringUtils.EMPTY);
        return result.replaceAll("<", "&lt;").replaceAll(">", "&gt;")
    		.replaceAll("\"", "&quot;");
    }
}