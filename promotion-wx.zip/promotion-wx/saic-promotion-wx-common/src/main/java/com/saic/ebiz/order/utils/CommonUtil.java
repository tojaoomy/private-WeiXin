/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.order.utils;

import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.framework.url.encrypt.SecurityHelper;

/**
 * 項目中用到共用方法.<br> 
 * @author xuxuewen
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class CommonUtil {
	
	/**
	 * logger.
	 */
	public static Logger  logger = LoggerFactory.getLogger(CommonUtil.class);
	
	/**
	 * 功能描述: 给字符进行md5同向加密<br>
	 * @param str 待加密的字符串.
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String saicMD5(String str){
		String mainToken = null;
		try {
			mainToken = URLEncoder.encode(
					new String(Base64.encodeBase64(SecurityHelper
							.verifyWithMD5(str).getBytes())), "utf-8");
		} catch (Exception e) {
			logger.error("MD5同向加密异常",e);
		}
		return mainToken;
	}
	
	public static boolean propertyEquals(Object obj,String propertyName,String value){
		boolean result = true;
		try {
			String val = BeanUtils.getSimpleProperty(obj, propertyName);
			if(val == null){
				result = false;
			}else if(!val.equals(value)){
				result = false;
			}
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static void main(String[] args) {
		Promotion pro = new Promotion();
		pro.setPromotionCode("EGG");
		System.out.println(propertyEquals(pro, "promotionCode", "egg"));
		System.out.println(propertyEquals(pro, "promotionCode", "EGG"));
	}
}
