/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: PreOrderController.java
 * Author:   hejian
 * Description: 常量
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * 常用变量
 * 
 * @author hejian
 *
 */
public class Constants {
	
	/** 配额模式（1,总配额 2.经销商配额 3,车系配额 4,车系-经销商 配额 5 车型-经销商 配额, 6 车型颜色-经销商 配额） */
	public static final Map<Integer,String> QUOTA_MAP = new HashMap<Integer,String>();
	public final static int TOTAL_QUOTA_MODE = 1;
	public final static int DEALER_QUOTA_MODE = 2;
	public final static int MODEL_QUOTA_MODE = 3;
	public final static int MODEL_DEALER_QUOTA_MODE = 4;
	public final static int SERIES_DEALER_QUOTA_MODE = 5;
	public final static int SERIES_COLOR_DEALER_QUOTA_MODE = 6;
	
	static{
		QUOTA_MAP.put(null, "未配额");
		QUOTA_MAP.put(TOTAL_QUOTA_MODE, "总配额");
		QUOTA_MAP.put(DEALER_QUOTA_MODE, "经销商配额");
		QUOTA_MAP.put(MODEL_QUOTA_MODE, "车系配额");
		QUOTA_MAP.put(MODEL_DEALER_QUOTA_MODE, "车系-经销商 配额");
		QUOTA_MAP.put(SERIES_DEALER_QUOTA_MODE, "车型-经销商 配额");
		QUOTA_MAP.put(SERIES_COLOR_DEALER_QUOTA_MODE, "车型颜色-经销商 配额");
	}
	
}
