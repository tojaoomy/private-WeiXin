/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: CookieRetrieveCity.java
 * Author:   chenliang
 * Date:     2014年1月4日 上午10:36:25
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.ibm.framework.exception.BaseException;

/**
 * 从cookie中获取城市信息.<br> 
 * 如果获取失败则返回默认城市：01，上海.
 *
 * @author chenliang
 */
public class CookieCityUtil {
    
    /** cookie中城市id的key名称. */
    public static final String COOKIE_KEY_CITYID = "city.id";
    public static final String COOKIE_KEY_CITY_ID = "city_id";
    
    /** cookie中城市name的key名称. */
    public static final String COOKIE_KEY_CITYNAME = "city.name";
    public static final String COOKIE_KEY_CITY_NAME = "city_name";
    
    /** 默认城市id. */
    public static final long DEFAULT_CITYID = 310100;
    
    /** 默认城市name. */
    public static final String DEFAULT_CITYNAME = "上海";

    /**
     * 隐藏构造方法.
     */
    private CookieCityUtil() {
        super();
    }

    /**
     * 功能描述: 从cookie中获取城市id<br>
     * 获取失败返回默认城市id：DEFAULT_CITYID = 10.
     * 
     * @param request request参数
     * @return 城市id
     */
    public static long getCityId(HttpServletRequest request) {
        Map<String, String> cookieMap = CookieUtil.cookie2map(request);
        if (StringUtils.isBlank(cookieMap.get(COOKIE_KEY_CITY_ID))) {
        	if (StringUtils.isBlank(cookieMap.get(COOKIE_KEY_CITYID))) { 
                return DEFAULT_CITYID;
        	}else {
                return Long.parseLong(cookieMap.get(COOKIE_KEY_CITYID));
            }
        } else {
            return Long.parseLong(cookieMap.get(COOKIE_KEY_CITY_ID));
        }
    }
    
    /**
     * 功能描述: 从cookie中获取城市name<br>
     * 获取失败返回默认城市名称：DEFAULT_CITYNAME = "上海".
     * 
     * @param request request参数
     * @return 城市name
     */
    public static String getCityName(HttpServletRequest request) {
        Map<String, String> cookieMap = CookieUtil.cookie2map(request);
        if (StringUtils.isBlank(cookieMap.get(COOKIE_KEY_CITY_NAME))) {
	        if (StringUtils.isBlank(cookieMap.get(COOKIE_KEY_CITYNAME))) {
	            return DEFAULT_CITYNAME;
	        } else {
	            try {
	                return URLDecoder.decode(cookieMap.get(COOKIE_KEY_CITYNAME), StandardCharsets.UTF_8.toString());
	            } catch (UnsupportedEncodingException e) {
	                throw new BaseException(e);
	            }
	        }
        } else {
            try {
                return URLDecoder.decode(cookieMap.get(COOKIE_KEY_CITY_NAME), StandardCharsets.UTF_8.toString());
            } catch (UnsupportedEncodingException e) {
                throw new BaseException(e);
            }
        }
    }
}