/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: CookieUtils.java
 * Author:   chenliang
 * Date:     2014年1月4日 上午10:06:16
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.utils;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;


/**
 * Cookie相关的工具类<br>
 * .
 * 
 * @author chenliang
 */
public class CookieUtil {

    /**
     * 默认构造方法.
     */
    private CookieUtil() {
        super();
    }

    /**
     * 将cookies列表转换为Map对象: <br>
     * .
     * 
     * @param request request对象
     * @return 包含cookie的Map
     */
    public static Map<String, String> cookie2map(HttpServletRequest request) {
        Map<String, String> map = new HashMap<String, String>();
        Cookie[] cookies = request.getCookies();

        if (null == cookies) {
            return map;
        }

        for (int i = 0; i < cookies.length; i++) {
            Cookie cookie = cookies[i];
            map.put(cookie.getName(), cookie.getValue());
        }
        return map;
    }

    /**
     * 功能描述: <br>
     * 从cookie获取SessionId。如果不存在的话，就从session中获取， 如果还是不存在的话，就返回空字符串.
     * 
     * @param request request对象
     * @return sessionid
     */
    public static String getSessionid(HttpServletRequest request) {
        Map<String, String> map = CookieUtil.cookie2map(request);
        String id = map.get("JSESSIONID");
        if (StringUtils.isBlank(id)) {
            return request.getSession().getId();
        }
        return id;
    }

}
