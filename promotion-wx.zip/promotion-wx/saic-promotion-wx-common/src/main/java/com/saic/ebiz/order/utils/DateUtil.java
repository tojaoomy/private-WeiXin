/*
 * Copyright (C), 2013-2013, IBM
 * FileName: RegexUtil.java
 * Author:   liyuelong
 * Date:     2013年11月12日 上午10:08:08
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.framework.exception.BaseException;

/**
 * 日期工具类<br>
 * 
 * 此类提供日常开发中常用的日期相差比较<br>
 * 两个日期相差的天、小时、分钟.
 * 
 * @author liyuelong
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public final class DateUtil {

    /** 日期的格式:年月. */
    public static final String DATE_JFP_STR = "yyyyMM";

    /** 日期的格式:年月日，时间. */
    public static final String DATE_FULL_STR = "yyyy-MM-dd HH:mm:ss";

    /** 日期的格式：年月日. */
    public static final String DATE_SMALL_STR = "yyyy-MM-dd";

    /** 日期的格式：年月日时间. */
    public static final String DATE_KEY_STR = "yyMMddHHmmss";

    /** 日志. */
    private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

    /** 60进制时间. */
    private static final int TIME_60 = 60;

    /** 24进制时间. */
    private static final int TIME_24 = 24;

    /** 毫秒. */
    private static final int TIME_1000 = 1000;

    /**
     * 隐藏构造方法.
     */
    private DateUtil() {
        super();
    }

    /**
     * 功能描述: 返回两个日期相差的天数<br>
     * .
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return long 返回两个日期相差的天数
     */
    public static long getDateDifferDays(Date startTime, Date endTime) {
        Calendar c = Calendar.getInstance();
        c.setTime(startTime);
        long l_s = c.getTimeInMillis();
        c.setTime(endTime);
        long l_e = c.getTimeInMillis();
        // 计算差多少天
        return (l_e - l_s) / (TIME_1000 * TIME_24 * TIME_60 * TIME_60);
    }

    /**
     * 功能描述: 返回两个日期相差的小时<br>
     * .
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return long 返回两个日期相差的小时
     */
    public static long getDateDifferHours(Date startTime, Date endTime) {
        Calendar c = Calendar.getInstance();
        c.setTime(startTime);
        long l_s = c.getTimeInMillis();
        c.setTime(endTime);
        long l_e = c.getTimeInMillis();
        // 计算差多少小时
        long differ = l_e - l_s;
        return differ % (TIME_1000 * TIME_60 * TIME_60 * TIME_24) / (TIME_1000 * TIME_60 * TIME_60);
    }

    /**
     * 功能描述: 返回两个日期相差的分钟<br>
     * .
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return long 返回两个日期相差的分钟
     */
    public static long getDateDifferMins(Date startTime, Date endTime) {
        Calendar c = Calendar.getInstance();
        c.setTime(startTime);
        long l_s = c.getTimeInMillis();
        c.setTime(endTime);
        long l_e = c.getTimeInMillis();
        // 计算差多少分钟
        long differ = l_e - l_s;
        return differ % (TIME_1000 * TIME_60 * TIME_60) / (TIME_1000 * TIME_60);
    }

    /**
     * 将日值字符串转换成Date类型.
     * 
     * @param str 参数字符串
     * @param format 格式
     * @return Date 日期
     */
    public static Date parseDateString(String str, String format) {
        if (str == null || str.equals("")) {
            return null;
        }
        Date dt = null;
        DateFormat df = new SimpleDateFormat(format);
        try {
            dt = df.parse(str);
        } catch (ParseException e) {
            LOGGER.error("parseDateString was error !", e);
            throw new BaseException(e);
        }
        return dt;
    }

    /**
     * 使用预设格式提取字符串日期.
     * 
     * @param strDate 日期字符串
     * @return 日期
     */
    public static Date parse(String strDate) {
        return parse(strDate, DATE_FULL_STR);
    }

    /**
     * 功能描述: 使用用户格式提取字符串日期<br>
     * .
     * 
     * @param strDate 日期字符串
     * @param pattern 日期格式
     * @return 日期
     */
    public static Date parse(String strDate, String pattern) {
        SimpleDateFormat df = new SimpleDateFormat(pattern);
        try {
            return df.parse(strDate);
        } catch (ParseException e) {
            LOGGER.error("parse was error !", e);
            throw new BaseException(e);
        }
    }

    /**
     * 功能描述: 使用用户格式提取时间戳日期<br>
     * .
     * 
     * @param longDate 日期时间戳
     * @param pattern 日期格式
     * @return 日期
     */
    public static Date parse(Long longDate, String pattern) {
        SimpleDateFormat df = new SimpleDateFormat(pattern);
        try {
            String strDate = df.format(longDate);
            return df.parse(strDate);
        } catch (ParseException e) {
            LOGGER.error("parse was error !", e);
            throw new BaseException(e);
        }
    }

    /**
     * 两个时间比较.
     * 
     * @param date1 the date1
     * @return 时间差
     */
    public static int compareDateWithNow(Date date1) {
        Date date2 = new Date();
        return date1.compareTo(date2);
    }

    /**
     * 两个时间比较(时间戳比较).
     * 
     * @param date1 the date1
     * @return 时间差
     */
    public static int compareDateWithNow(long date1) {
        long date2 = dateToUnixTimestamp();
        //在当前时间的未来,返回1
        if (date1 > date2) {
            return 1;
        //在当前时间的过去,返回-1
        } else if (date1 < date2) {
            return -1;
        } else {
            return 0;
        }
    }

    /**
     * 获取系统当前时间.
     * 
     * @return 当前时间
     */
    public static String getNowTime() {
        SimpleDateFormat df = new SimpleDateFormat(DATE_FULL_STR);
        return df.format(new Date());
    }

    /**
     * 获取系统当前时间.
     * 
     * @param type the type
     * @return 当前时间
     */
    public static String getNowTime(String type) {
        SimpleDateFormat df = new SimpleDateFormat(type);
        return df.format(new Date());
    }

    /**
     * 获取系统当前计费期.
     * 
     * @return 当前时间
     */
    public static String getJFPTime() {
        SimpleDateFormat df = new SimpleDateFormat(DATE_JFP_STR);
        return df.format(new Date());
    }

    /**
     * 将指定的日期转换成Unix时间戳.
     * 
     * @param date 需要转换的日期 yyyy-MM-dd HH:mm:ss
     * @return long 时间戳
     */
    public static long dateToUnixTimestamp(String date) {
        long timestamp = 0;
        try {
            timestamp = new SimpleDateFormat(DATE_FULL_STR).parse(date).getTime();
        } catch (ParseException e) {
            LOGGER.error("dateToUnixTimestamp was error !", e);
            throw new BaseException(e);
        }
        return timestamp;
    }

    /**
     * 将指定的日期转换成Unix时间戳.
     * 
     * @param date 需要转换的日期 yyyy-MM-dd
     * @param dateFormat the date format
     * @return long 时间戳
     */
    public static long dateToUnixTimestamp(String date, String dateFormat) {
        long timestamp = 0;
        try {
            timestamp = new SimpleDateFormat(dateFormat).parse(date).getTime();
        } catch (ParseException e) {
            LOGGER.error("dateToUnixTimestamp was error !", e);
            throw new BaseException(e);
        }
        return timestamp;
    }

    /**
     * 将当前日期转换成Unix时间戳.
     * 
     * @return long 时间戳
     */
    public static long dateToUnixTimestamp() {
        return new Date().getTime();
    }

    /**
     * 将Unix时间戳转换成日期.
     * 
     * @param timestamp 时间戳
     * @return String 日期字符串
     */
    public static String unixTimestampToDate(long timestamp) {
        SimpleDateFormat sd = new SimpleDateFormat(DATE_FULL_STR);
        sd.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        return sd.format(new Date(timestamp));
    }
}