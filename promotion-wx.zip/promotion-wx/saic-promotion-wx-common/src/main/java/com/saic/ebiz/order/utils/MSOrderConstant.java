/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: MSOrderConstant.java
 * Author:   xuxuewen
 * Date:     2014年7月20日 下午3:47:22
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.utils;

/**
 * msorder 项目常量类.<br> 
 * @author xuxuewen
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class MSOrderConstant {
	
    /**
     * freeMarker全局变量的key：登录状态
     */
    public final static String GLOABFREEMARKKEY_ISLOGIN = "saicebizmsorderislogin";

    /**
     * freeMarker全局变量的key：用户姓名
     */
    public final static String GLOABFREEMARKKEY_USERNAME = "saicebizmsorderuserName";

    /**
     * freeMarker全局变量的key：问候语
     */
    public final static String GLOABFREEMARKKEY_GREETINGS = "saicebizmsordergreetings";
}
