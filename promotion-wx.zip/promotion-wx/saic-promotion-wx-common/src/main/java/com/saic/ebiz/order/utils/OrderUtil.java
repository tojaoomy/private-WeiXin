package com.saic.ebiz.order.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrderUtil {
	public static Logger logger = LoggerFactory.getLogger(CommonUtil.class);

	/**
	 * 
	 * @param params
	 *            待验证的参数
	 * @param token
	 *            传入的Token标志,MD5单向加密
	 * @return
	 */
	public static boolean verifyToken(String params, String token) {
		String exceptToken = CommonUtil.saicMD5(params);
		logger.info("params : { {} } ,except token is {{}}, actual token value is { {} }", params, exceptToken , token);
		return SaicStringUtil.isEqualsStr(exceptToken , token);
	}
}
