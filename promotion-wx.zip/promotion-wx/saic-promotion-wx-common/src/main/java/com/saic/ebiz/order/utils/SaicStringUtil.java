/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: SaicStringUtil.java
 * Author:   xuxuewen
 * Date:     2014年7月14日 下午2:41:17
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.order.utils;

/**
 * 自定义字符串处理工具类<br> 
 * 〈功能详细描述〉
 *
 * @author xuxuewen
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class SaicStringUtil {
	/**
	 * 功能描述: 比较两个字符串是否相等，区别大小写<br>
	 * @param argsOne 待比较字符一
	 * @param argsTwo 待比较字符二
	 * @return  true：相等.
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static boolean isEqualsStr(String argsOne,String argsTwo){
		if(argsOne == null || argsTwo == null){
			return false;
		}
		if(argsOne.equals(argsTwo)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 功能描述: 比较两个字符串是否相等，不区别大小写<br>
	 * @param argsOne 待比较字符一
	 * @param argsTwo 待比较字符二
	 * @return  true：相等.
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static boolean isEqualsStrIgnoreCase(String argsOne,String argsTwo){
		if(argsOne == null || argsTwo == null){
			return false;
		}
		if(argsOne.equalsIgnoreCase(argsTwo)){
			return true;
		}else{
			return false;
		}
	}
}
