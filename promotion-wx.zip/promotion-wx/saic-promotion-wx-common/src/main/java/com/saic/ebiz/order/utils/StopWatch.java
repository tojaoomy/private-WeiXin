/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.order.utils;

/**
 * @author hejian
 *
 */
public class StopWatch {
	private long start;
	
	private int internal = 1000;
	
	public StopWatch() {
		this.start = System.currentTimeMillis();
	}
	
	/**
	 * 重置
	 */
	public void reset(){
		this.start = System.currentTimeMillis();
	}
	
	/**
	 * 获取执行方法或者任务的事件 单位秒
	 * @return 
	 */
	public long duration(){
		long end = System.currentTimeMillis();
		return (end - start) / internal;
	}
}
