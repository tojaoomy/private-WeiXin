/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.entity.response.Article;
import com.saic.ebiz.market.common.entity.response.SendNewsMessage;
import com.saic.ebiz.market.common.entity.response.SendNewsMessage.NewsContent;
import com.saic.ebiz.market.common.entity.response.SendTextMessage;
import com.saic.ebiz.market.common.entity.response.SendTextMessage.TextContent;
import com.saic.ebiz.market.common.enumeration.MessageType;

/**
 * @author hejian
 *
 */
public class CommonUtilTest {
	private static Logger LOGGER = LoggerFactory.getLogger(CommonUtilTest.class);
	private static String openid = "o9987s48vxsQT43pMPwknHylmZCI";
	private static String requestUrl = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=AT";

	public static String getAccessToken(String urlString){
		StringBuilder builder = new StringBuilder();
		try {
			URL url = new URL(urlString);
			URLConnection openConnection = url.openConnection();
			openConnection.setDoOutput(true);
			InputStream inputStream = openConnection.getInputStream();
			BufferedReader bufferedInputStream = new BufferedReader(new InputStreamReader(inputStream));
			String data = null;
			while((data = bufferedInputStream.readLine()) != null){
				builder.append(data);
			}
//			builder.setLength(builder.length() - 1);
			inputStream.close();
			bufferedInputStream.close();
		} catch (MalformedURLException e) {
			LOGGER.error("解析URL失败",e);
		} catch (IOException e) {
			LOGGER.error("IOException", e);
		}
		return builder.toString();
	}
	
	public static String getAccessToken(){
		return JSONObject.parseObject(getAccessToken("http://mgo.pre.chexiang.com/customer/token")).getString("data");
	}
	
	public static void sendMessage(){
		requestUrl = requestUrl.replace("AT", getAccessToken());
		
		/**
		 * 将消息转换为json数据
		 */
		String jsonMessage = JSONObject.toJSONString(buildObject("车享新车测试"));
		
		/**
		 * 发送消息
		 */
		CommonUtil.httpsRequest(requestUrl, "POST", jsonMessage);
	}
	
	public static void sendMessage(String accessToken,String openid, String text){
		requestUrl = requestUrl.replace("AT", accessToken);
		String jsonMessage = JSONObject.toJSONString(buildObject(openid, text));
		CommonUtil.httpsRequest(requestUrl, "POST", jsonMessage);
	}
	
	public static void sendMessage(String accessToken,String openid, String text, MessageTypes type){
		requestUrl = requestUrl.replace("AT", accessToken);
		String jsonMessage = null;
		if(MessageTypes.NEWS.equals(type)){
			jsonMessage = JSONObject.toJSONString(buildObject(openid, buildArticles()));
		}else{
			jsonMessage = JSONObject.toJSONString(buildObject(openid, text));
		}
		System.out.println(jsonMessage);
		CommonUtil.httpsRequest(requestUrl, "POST", jsonMessage);
	}
	
	private static List<Article> buildArticles(){
		List<Article> articles = Lists.newArrayList();
		Article a = new Article();
		a.setTitle("图消息标题");
		a.setDescription("图文消息描述");
		a.setPicurl("http://i3.cximg.com/images/270x180/84bd33606b889b25/20151023/d16516e59cd6423aac24a37d6fad2c7a.png");
		a.setUrl("http://car.chexiang.com");
		articles.add(a);
		a = new Article();
		a.setTitle("车享网图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述");
		a.setDescription("车享文消息<a href=\"http://car.chexiang.com\">测试</a>描述");
//		a.setPicurl("http://i3.cximg.com/images/270x180/84bd33606b889b25/20160301/2c92fa1e7df24196836bec720ac61146.png");
		a.setUrl("http://www.chexiang.com");
		articles.add(a);
		a = new Article();
		a.setTitle("车享网图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述");
		a.setDescription("车享文消息<a href=\"http://car.chexiang.com\">测试</a>描述");
		a.setUrl("http://www.chexiang.com");
		articles.add(a);
		a = new Article();
		a.setTitle("车享网图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述图文消息描述");
		a.setDescription("车享文消息<a href=\"http://car.chexiang.com\">测试</a>描述");
		a.setUrl("http://www.chexiang.com");
		articles.add(a);
		a = new Article();
		a.setTitle("车享网");
		a.setDescription("车享文消息<a href=\"http://car.chexiang.com\">测试</a>描述");
		a.setUrl("http://www.chexiang.com");
		articles.add(a);
		a = new Article();
		a.setTitle("车享网");
		a.setDescription("车享文消息<a href=\"http://car.chexiang.com\">测试</a>描述");
		a.setUrl("http://www.chexiang.com");
		articles.add(a);
		a = new Article();
		a.setTitle("车享网");
		a.setDescription("车享文消息<a href=\"http://car.chexiang.com\">测试</a>描述");
		a.setUrl("http://www.chexiang.com");
		articles.add(a);
		a = new Article();
		a.setTitle("车享网");
		a.setDescription("车享文消息<a href=\"http://car.chexiang.com\">测试</a>描述");
		a.setUrl("http://www.chexiang.com");
		articles.add(a);
		System.out.println(articles.size());
		return articles;
	}
	
	public static Object buildObject(String text){
		SendTextMessage message = new SendTextMessage();
		message.setTouser(openid);
		message.setMsgtype(MessageType.TEXT.code());
		TextContent tc = new SendTextMessage.TextContent();
		tc.setContent(text);
		message.setText(tc);
		return message;
	}
	
	public static Object buildObject(String openid,String text){
		SendTextMessage message = new SendTextMessage();
		message.setTouser(openid);
		message.setMsgtype(MessageType.TEXT.code());
		TextContent tc = new SendTextMessage.TextContent();
		tc.setContent(text);
		message.setText(tc);
		return message;
	}
	
	public static Object buildObject(String openid,List<Article> articles){
		SendNewsMessage message = new SendNewsMessage();
		message.setTouser(openid);
		message.setMsgtype(MessageType.NEWS.code());
		NewsContent nc = new SendNewsMessage.NewsContent();
		nc.setArticles(articles);
		message.setNews(nc);
		return message;
	}
	
	public static void main(String[] args) {
		String accessToken = getAccessToken();
//		String openid = "o9987s9vfOn1_XjmWqlCSPe1j6-Y";//小胖
//		String openid = "o9987syheJw8Rhl-KYzdXUSwe9_Q";//小李子
		String openid = "oTMc8uHwTJ3xz5lvvf0OL1zfFrfY";//ceshi
		for(int i=0; i < 1;i++){
			CommonUtil.sendMessage(accessToken,openid,"你这厮，看招!!!");
		}
	}
	
	static enum MessageTypes{
		NEWS,TEXT,MUSIC,VEDIO
	}
}

