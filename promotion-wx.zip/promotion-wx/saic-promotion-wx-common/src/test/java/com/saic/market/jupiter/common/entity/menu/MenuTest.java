/**
 *
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName : MenuTest.java
 * Author : 何剑
 * Date : 2014年9月21日
 * 
 */
package com.saic.market.jupiter.common.entity.menu;

import net.sf.json.JSONObject;

import org.junit.Test;

import com.saic.ebiz.market.common.entity.menu.Button;
import com.saic.ebiz.market.common.entity.menu.ClickButon;
import com.saic.ebiz.market.common.entity.menu.ComplexButton;
import com.saic.ebiz.market.common.entity.menu.Menu;
import com.saic.ebiz.market.common.entity.menu.ViewButton;


/**
 * @author hejian
 * 
 * @date 2014年9月21日
 */
public class MenuTest {
    @Test
    public void testMenu2Json() {
        ClickButon btn1 = new ClickButon();
        btn1.setName("今日歌曲");
        btn1.setKey("V10001_TODAY_MUSIC");

        ViewButton btn2 = new ViewButton();
        btn2.setName("歌手简介");
        btn2.setUrl("http://www.qq.com");

        ClickButon btn31 = new ClickButon();
        btn31.setName("hello world");
        btn31.setKey("V10001_HELLO_WORLD");

        ClickButon btn32 = new ClickButon();
        btn32.setName("赞一下我们");
        btn32.setKey("V10001_GOOD");

        // 复合按钮包含两个click类型的按钮
        ComplexButton btn3 = new ComplexButton();
        btn3.setName("菜单");
        btn3.setSub_button(new Button[] { btn31, btn32 });
        
        //create menu object
        Menu menu = new Menu();
        menu.setButton(new Button[]{btn1,btn2,btn3});
        //make menu object transform to json String
        String jsonMenu = JSONObject.fromObject(menu).toString();
        System.out.println(jsonMenu);
    }
}
