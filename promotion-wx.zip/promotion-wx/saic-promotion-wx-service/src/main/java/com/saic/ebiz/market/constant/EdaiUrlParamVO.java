package com.saic.ebiz.market.constant;

import java.io.Serializable;

public class EdaiUrlParamVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7860607482955067637L;
	private String name;
	private String mphone;
	private String addr;
	private String velmodelid;
	private String applyid;
	private String dealerid;
	private String client;
	
	
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getApplyid() {
		return applyid;
	}
	public void setApplyid(String applyid) {
		this.applyid = applyid;
	}
	public String getDealerid() {
		return dealerid;
	}
	public void setDealerid(String dealerid) {
		this.dealerid = dealerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMphone() {
		return mphone;
	}
	public void setMphone(String mphone) {
		this.mphone = mphone;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getVelmodelid() {
		return velmodelid;
	}
	public void setVelmodelid(String velmodelid) {
		this.velmodelid = velmodelid;
	}
}