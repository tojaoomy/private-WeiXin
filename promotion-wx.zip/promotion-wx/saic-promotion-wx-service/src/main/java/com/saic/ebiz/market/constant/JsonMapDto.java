package com.saic.ebiz.market.constant;

import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.collect.Maps;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉
 * 
 * @author zhuheng
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class JsonMapDto {
    @JsonIgnore
    /**成功后获得状态码【兼容以前的code】**/
    private static final String SUCCESS = "0";

    /** 失败后获得状态码 **/
    @JsonIgnore
    private static final String FAILE = "1";

    /** 返回的错误编码 **/
    private String errorCode;

    public JsonMapDto() {

    }

    public JsonMapDto(String errorCode) {
        this.errorCode=errorCode;
    }

    private Map<String, Object> result = Maps.newHashMap();

    /**
     * 功能描述: <br>
     * 获取成功
     *
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static JsonMapDto getSuccess(){
        return new JsonMapDto(SUCCESS);
    }
    
    /**
     * 功能描述: <br>
     * 获取失败
     *
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static JsonMapDto getFaile(){
        return new JsonMapDto(FAILE);
    }

    /**
     * @return the errorCode
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode the errorCode to set
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * @return the result
     */
    public Map<String, Object> getResult() {
        return result;
    }

    /**
     * @param result the result to set
     */
    public void setResult(Map<String, Object> result) {
        this.result = result;
    }

}
