package com.saic.ebiz.market.constant;
/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: MemberAuthInfo.java
 * Author:   v_wangzhaolin01
 * Date:     2013年12月30日 下午3:55:22
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉
 * 
 * @author v_wangzhaolin01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class MemberAuthInfo {
    /** userName 用户名 */
    private String userName;
    /** mobilAuthFlag 手机认证状态 0：未认证，1：已认证 */
    private boolean mobileAuthFlag = false;
    /** mobile 手机 */
    private String mobile;

    /** emailAuthFlag 邮箱认证状态 0：未认证，1：已认证 */
    private boolean emailAuthFlag = false;
    /** email 邮件 */
    private String email;

    /** securityFlag 安保设置状态 0：未认证，1：已认证 */
    private boolean securityFlag = false;

    /** securityType 密码强度等级 1:高，2：中，3：低 */
    private Integer securityType;

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile the mobile to set
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return mobilAuthFlag 手机认证状态 0：未认证，1：已认证
     */
    public boolean getMobileAuthFlag() {
        return mobileAuthFlag;
    }

    /**
     * @param mobilAuthFlag 手机认证状态 0：未认证，1：已认证
     */
    public void setMobileAuthFlag(boolean mobilAuthFlag) {
        this.mobileAuthFlag = mobilAuthFlag;
    }

    /**
     * @return emailAuthFlag 邮箱认证状态 0：未认证，1：已认证
     */
    public boolean getEmailAuthFlag() {
        return emailAuthFlag;
    }

    /**
     * @param emailAuthFlag 邮箱认证状态 0：未认证，1：已认证
     */
    public void setEmailAuthFlag(boolean emailAuthFlag) {
        this.emailAuthFlag = emailAuthFlag;
    }

    /**
     * @return the securityFlag
     */
    public boolean isSecurityFlag() {
        return securityFlag;
    }

    /**
     * @param securityFlag the securityFlag to set
     */
    public void setSecurityFlag(boolean securityFlag) {
        this.securityFlag = securityFlag;
    }

    /**
     * @return the securityType
     */
    public Integer getSecurityType() {
        return securityType;
    }

    /**
     * @param securityType the securityType to set
     */
    public void setSecurityType(Integer securityType) {
        this.securityType = securityType;
    }

}
