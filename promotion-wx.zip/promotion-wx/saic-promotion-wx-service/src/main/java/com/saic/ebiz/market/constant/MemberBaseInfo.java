package com.saic.ebiz.market.constant;

/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: MemberBaseInfo.java
 * Author:   v_wangzhaolin01
 * Date:     2013年12月27日 下午4:14:44
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
import java.util.Date;
import javax.validation.constraints.Past;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;



/**
 * 会员信息属性类<br>
 * 
 * @author v_wangzhaolin01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@NotBlank(field="address",preField={"province","city","town"},message="地址格式有误")
public class MemberBaseInfo {
    
    /** userType 会员类型10：个人-普通（默认），11：个人-车主，20：团体 */
    private Integer userType;

    /** source 客户来源的方式（10：网站注册，20：4S店........，且如果对网站注册的来源再进行区分，如好友推荐等，则扩展成11，12等） */
    private Integer source;

    /** userName 注册用户名 */
    private String userName;

    /** userId 会员编号 */
    private Long userId;

    /** realName 会员名称：会员的姓名 */
    @NotBlankPattern(regexp="^[A-Za-z\u4E00-\u9FA5]{2,20}$",message="姓名由2-20个英文或汉字组成")
    private String realName;

    /** nickName 昵称 */
    @NotBlankPattern(regexp="^[-.A-Za-z0-9_\u4E00-\u9FA5]{1,20}$",message="可由1-20位中英文，数字，_， -组成")
    private String nickName;

    /** birthDate 出生日期 ：格式为yyyy-MM-dd */
    @DateTimeFormat(iso=DateTimeFormat.ISO.DATE)
    @Past(message="生日有误")
    private Date birthDate;
    
    /** gender 性别：由数据架构直接约定 */
    private Integer gender;

    /** certType 证件类型：参见代码表 */
    private Integer certType;

    /** certNo 证件号码 */
    @Length(max=30,message="不能超过30位字符")
    @NotBlankPattern(regexp="(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)",message="证件号码格式有误")
    private String certNo;

    /** country 国家 */
    private Integer country;

    /** province 省/直辖市 */
    private Integer province;

    /** city 城市 */
    private Integer city;

    /** town 区县 */
    private Integer town;

    /** address 详细地址 */
    @Length(max=100,message="最多输入100个字符")
    @NotBlankPattern(regexp="^[a-zA-Z\\d\u4e00-\u9fa5]+$",message="地址格式有误")
    private String address;

    /** zipCode 邮编 */
    @Length(max=6,message="不能超过6位字符")
    @NotBlankPattern(regexp="^[1-9]\\d{5}",message="邮政编码有误")
    private String zipCode;

    /** telCountryCode 固话国家号 */
    private String telCountryCode;

    /** telAreaCode 固话区号 */
    private String telAreaCode;

    /** telephone 固话号码 */
    private String telephone;

    /** telExtn 固话分机 */
    private String telExtn;

    /** mobile 手机号 */
    @NotBlankPattern(regexp="^1[3,4,5,7,8]\\d{9}",message="您输入的手机号码格式有误")
    private String mobile;

    /** email 邮箱 */
    @Email(message="您输入的邮箱有误")
    private String email;
    
    /**
     * 对数据做相应的扩容兼容MDM的数据
     */
    /**idNumber对应id*/
    private Long idNumberId;
    /**mobile对应的电话id*/
    private Long mobileId;
    /**email对应的id*/
    private Long emailId;
    /**province,city,district,address,zipCode对应的id*/
    private Long addressId;
    /**身份证验证状态*/
    private boolean identityCardValid=false;
    
    /**
     * @return the identityCardValid
     */
    public boolean isIdentityCardValid() {
        return identityCardValid;
    }

    /**
     * @param identityCardValid the identityCardValid to set
     */
    public void setIdentityCardValid(boolean identityCardValid) {
        this.identityCardValid = identityCardValid;
    }

    /**
     * 用户图像
     */
    private String photoUrl;
    
    /**
     * @return the photoUrl
     */
    public String getPhotoUrl() {
        return photoUrl;
    }

    /**
     * @param photoUrl the photoUrl to set
     */
    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    /**
     * @return the idNumberId
     */
    public Long getIdNumberId() {
        return idNumberId;
    }

    /**
     * @param idNumberId the idNumberId to set
     */
    public void setIdNumberId(Long idNumberId) {
        this.idNumberId = idNumberId;
    }

    /**
     * @return the mobileId
     */
    public Long getMobileId() {
        return mobileId;
    }

    /**
     * @param mobileId the mobileId to set
     */
    public void setMobileId(Long mobileId) {
        this.mobileId = mobileId;
    }

    /**
     * @return the emailId
     */
    public Long getEmailId() {
        return emailId;
    }

    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(Long emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the addressId
     */
    public Long getAddressId() {
        return addressId;
    }

    /**
     * @param addressId the addressId to set
     */
    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    /**
     * @return userType 会员类型10：个人-普通（默认），11：个人-车主，20：团体
     */
    public Integer getUserType() {
        return userType;
    }

    /**
     * @param userType 会员类型10：个人-普通（默认），11：个人-车主，20：团体
     */
    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    /**
     * @return userType 会员类型10：个人-普通（默认），11：个人-车主，20：团体
     */
    public Integer getSource() {
        return source;
    }

    /**
     * @param source 客户来源的方式（10：网站注册，20：4S店........，且如果对网站注册的来源再进行区分，如好友推荐等，则扩展成11，12等）
     */
    public void setSource(Integer source) {
        this.source = source;
    }

    /**
     * @return userName 注册用户名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName 注册用户名
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return 会员编号
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * @param userId 会员编号
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * @return realName 会员的姓名
     */
    public String getRealName() {
        return realName;
    }

    /**
     * @param realName 会员的姓名
     */
    public void setRealName(String realName) {
        this.realName = realName;
    }

    /**
     * @return nickName 昵称
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * @param nickName 昵称
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * @return birthDate 出生日期：格式为yyyy-MM-dd
     */
    public Date getBirthDate() {
        return birthDate;
    }

    /**
     * @param birthDate 出生日期：格式为yyyy-MM-dd
     */
    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * @return gender 性别
     */
    public Integer getGender() {
        return gender;
    }

    /**
     * @param gender 性别 1：男,2：女
     */
    public void setGender(Integer gender) {
        this.gender = gender;
    }

    /**
     * @return certType 证件类型
     */
    public Integer getCertType() {
        return certType;
    }

    /**
     * @param certType 证件类型
     */
    public void setCertType(Integer certType) {
        this.certType = certType;
    }

    /**
     * @return certNo 证件号码
     */
    public String getCertNo() {
        return certNo;
    }

    /**
     * @param certNo 证件号码
     */
    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    /**
     * @return country 国家
     */
    public Integer getCountry() {
        return country;
    }

    /**
     * @param country 国家
     */
    public void setCountry(Integer country) {
        this.country = country;
    }

    /**
     * @return province 省/直辖市
     */
    public Integer getProvince() {
        return province;
    }

    /**
     * @param province 省/直辖市
     */
    public void setProvince(Integer province) {
        this.province = province;
    }

    /**
     * @return city 城市
     */
    public Integer getCity() {
        return city;
    }

    /**
     * @param city 城市
     */
    public void setCity(Integer city) {
        this.city = city;
    }

    /**
     * @return town 区县
     */
    public Integer getTown() {
        return town;
    }

    /**
     * @param town 区县
     */
    public void setTown(Integer town) {
        this.town = town;
    }

    /**
     * @return address 详细地址
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address 详细地址
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return zipCode 邮编
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * @param zipCode 邮编
     */
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * @return telCountryCode 固话国家号
     */
    public String getTelCountryCode() {
        return telCountryCode;
    }

    /**
     * @param telCountryCode 固话国家号
     */
    public void setTelCountryCode(String telCountryCode) {
        this.telCountryCode = telCountryCode;
    }

    /**
     * @return telAreaCode 固话区号
     */
    public String getTelAreaCode() {
        return telAreaCode;
    }

    /**
     * @param telAreaCode 固话区号
     */
    public void setTelAreaCode(String telAreaCode) {
        this.telAreaCode = telAreaCode;
    }

    /**
     * @return telephone 固话号码
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * @param telephone 固话号码
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    /**
     * @return telExtn 固话分机
     */
    public String getTelExtn() {
        return telExtn;
    }

    /**
     * @param telExtn 固话分机
     */
    public void setTelExtn(String telExtn) {
        this.telExtn = telExtn;
    }

    /**
     * @return mobile 手机号
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile 手机号
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    /**
     * @return email 邮箱
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email 邮箱
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
