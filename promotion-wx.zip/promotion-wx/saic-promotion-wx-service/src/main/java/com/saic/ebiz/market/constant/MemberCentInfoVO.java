package com.saic.ebiz.market.constant;


/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: MemberInfoVO.java
 * Author:   lihaixia
 * Date:     2013年11月28日 上午11:08:19
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
/**
 * 〈一句话功能简述〉<br>
 * 会员基本信息视图对象
 * 
 * @author lihaixia
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class MemberCentInfoVO extends MemberInfoVO {

    /**
     * 会员认证信息对象
     */
    private MemberAuthInfo memberAuthInfo;

    /**
     * 构造函数
     */
    public MemberCentInfoVO() {
        memberAuthInfo = new MemberAuthInfo();
    }

    /**
     * @return memberAuthInfo 会员认证信息对象
     */
    public MemberAuthInfo getMemberAuthInfo() {
        return memberAuthInfo;
    }

    /**
     * @param memberAuthInfo 会员认证信息对象
     */
    public void setMemberAuthInfo(MemberAuthInfo memberAuthInfo) {
        this.memberAuthInfo = memberAuthInfo;
    }
}
