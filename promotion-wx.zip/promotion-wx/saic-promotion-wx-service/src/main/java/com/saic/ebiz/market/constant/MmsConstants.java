package com.saic.ebiz.market.constant;

/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: Constant.java
 * Author:   v_wangzhaolin01
 * Date:     2013年12月4日 下午8:54:57
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */

import java.math.BigDecimal;

/**
 * 会员管理系统常量类<br>
 * 定义会员管理系统中使用的业务常量
 * 
 * @author v_wangzhaolin01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public abstract class MmsConstants {

    /** 404错误页面. */
    public static final String REDICT_URL = "redirect:/errorPage404.htm";
    
    /** 用于查询会员信息返回的VO中认证状态字段 已认证\已设置add by sud */
    public static final int IS_AUTH = 1;

    /** 用于查询会员信息返回的VO中认证状态字段 未认证\未设置add by sud */
    public static final int IS_NOT_AUTH = 0;

    /** 会员名称的认证类型 add by sud */
    public static final int AUTH_USER_NAME = 1;

    /** 手机的认证类型 add by sud */
    public static final int AUTH_MOBILE = 2;

    /** 邮箱的认证类型 add by sud */
    public static final int AUTH_EMAIL = 3;

    /** 安保问题设置的标志 add by sud */
    public static final int AUTH_USER_SECURITY = 4;
    
    /** 密码强度等级标志 add by sud */
    public static final int PASSWORD_SECURITY_TYPE = 5;
    
    /** 设置获取map中会员实体的key值*/
    public static final int MEMBER_ENTITY_TYPE = 6;
    
    /** 设置获取map中MemberBaseInfoVO的key值*/
    public static final int MEMBER_BASE_VO_TYPE = 7;

    /** IAM系统认证信息查询方法appId常量参数 add by sud */
    public static final int IAM_APP_ID = 1;
    
    
    /** 一次任务 */
    public static final int TASK_ONCE=0;
    /** 日常任务 */
    public static final int TASK_NORMO=24;
    
    /** 图片计算小数位 */
    public static final int IMG_SCALE=2;
    /** 图片计算100 */
    public static final BigDecimal IMG_PERCENT=BigDecimal.valueOf(100);

    
    public static final float IMAGE_QUALITY=1.0f;
    
    /**
     * 图片类型：JPEG、JPG
     */
    public static final String IMAGE_JPEG_JPG = "FFD8FF";
    /**
     * 图片类型：PNG
     */
    public static final String IMAGE_PNG = "89504E";
    /**
     * 图片类型：GIF
     */
    public static final String IMAGE_GIF = "474946";
}

