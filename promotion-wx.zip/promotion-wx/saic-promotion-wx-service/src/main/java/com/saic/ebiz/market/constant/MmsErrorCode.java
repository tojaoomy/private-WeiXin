/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: MmsErrorCode.java
 * Author:   liyouguo
 * Date:     2013年12月3日 上午11:29:45
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.constant;

/**
 * 会员管理系统错误编码<br>
 * 会员编码规则：系统编码（201）+模块编码（2位，例：00-系统；01-会员中心(0-499,业务模块编码);01-会员中心(500-999,公共模块编码) 02-基本信息管理;03-邀请好友;04-站内信
 * 
 * @author liyouguo
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public final class MmsErrorCode {
    
    /** 私有构造方法*/
    private MmsErrorCode(){
        
    }

    /** --------------------00-系统 ------------------------------------------ */
    /** （调用DAL组件异常） */
    public static final Integer MEMB_CODE_DAL_INVOKE_ERROR = 20100101;

    /** 输入输出流异常 */
    public static final Integer MEMB_CODE_IO_EXCEPTION = 20100102;

    /** 接口输入参数错误 */
    public static final Integer MEMB_CODE_INPARAM_ERROR = 20100103;

    /** --------------------01-会员中心(0-499,业务模块编码) ----------------------- */

    /** --------------------01-会员中心(500-999,公共模块编码) --------------------- */
    /** 查询数据库结果异常 */
    public static final Integer MEMB_CODE_DB_RESULT_EXCEPTION = 20101501;

    /** --------------------02-基本信息管理------------------------------------- */
    /** 调用IAM系统查询会员认证异常 */
    public static final Integer MEMB_CODE_QUERY_AUTH_IN_IAM_ERROR = 20102101;
    
    
    /** 调用会员系统 用户输入异常 */
    public static final Integer MEMB_CODE_NOVALID_INPUT_IN_MMS = 20102102;
    
    
    /** 调用MDM系统 做资产绑定时发现重复资产ID*/
    public static final Integer MEMB_CODE_DUPLICATE_ASSETID_IN_MDM = 20102103;
    
    /** 调用MDM系统 做资产绑定时发现重复资产ID*/
    public static final Integer MEMB_CODE_NULLINPUT_FROM_OUT = 20102103;

    /** --------------------03-邀请好友 --------------------------------------- */
    /** （发送好友邀请异常） */
    public static final Integer MEMB_CODE_INVITE_LETTER_SEND_ERROR = 20103101;

    /** 生成好友签名串异常 */
    public static final Integer MEMB_CODE_GENERATE_INVITE_SIGN_EXCEPTION = 20103102;

    /** --------------------04-站内信----------------------------------------- */
    /** 发送站内信异常 */
    public static final Integer MEMB_CODE_SEND_MEMB_MSG_EXCEPTION = 20104101;
    
    /** --------------------05-客户信息管理 --------------------------------------- */
    /** 创建客户信息失败异常 */
    public static final Integer CUSTOMER_CREATE_FAILED_EXCEPTION = 20105101;
    /** --------------------06-车主认证 --------------------------------------- */
    /** 修改车辆绑定申请异常 */
    public static final Integer VEL_BIND_APPL_UPDATE_EXCEPTION = 20106101;
    /** 新增车辆绑定申请处理异常 */
    public static final Integer VEL_BIND_APPL_PROCESS_SAVE_EXCEPTION = 20106102;
    
    /** 调用短信系统发送短信服务异常 */
    public static final Integer MEMB_CODE_SMS_SERVICE_EXCEPTION = 20106103;
    /** 修改车辆解绑申请异常 */
    public static final Integer VEL_UNBIND_APPL_UPDATE_EXCEPTION = 20106104;
}
