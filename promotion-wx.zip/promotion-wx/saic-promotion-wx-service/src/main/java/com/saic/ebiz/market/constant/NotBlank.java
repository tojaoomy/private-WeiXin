/*
 * Copyright (C), 2013-2014, 上汽集团
 * FileName: UTFLength.java
 * Author:   zhuheng
 * Date:     2014年8月15日 下午1:46:22
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.constant;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import org.hibernate.validator.internal.constraintvalidators.NotBlankValidator;

/**
 * 〈一句话功能简述〉<br>
 * 检测属性是否为空
 * 
 * @author zhuheng
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Documented
@Target({ElementType.TYPE,ElementType.ANNOTATION_TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = NotBlankValidator.class)
public @interface NotBlank {

    String field();  
    
    String[] preField() default {};
    
    String message() default "";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
