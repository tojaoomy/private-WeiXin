/*
 * Copyright (C), 2013-2014, 上汽集团
 * FileName: CheckPatternValidator.java
 * Author:   zhuheng
 * Date:     2014年8月15日 上午11:47:48
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.constant;

import java.util.regex.Matcher;
import java.util.regex.PatternSyntaxException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;


/**
 * 〈一句话功能简述〉<br>
 * 〈非空做校验
 * 
 * @author zhuheng
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class NotBlankPatternValidator implements ConstraintValidator<NotBlankPattern, String> {
    
    private java.util.regex.Pattern pattern;

    public void initialize(NotBlankPattern parameters) {
        NotBlankPattern.Flag flags[] = parameters.flags();
        int intFlag = 0;
        for (NotBlankPattern.Flag flag : flags) {
            intFlag = intFlag | flag.getValue();
        }

        try {
            pattern = java.util.regex.Pattern.compile(parameters.regexp(), intFlag);
        } catch (PatternSyntaxException e) {
            throw new IllegalArgumentException("Invalid regular expression.", e);
        }
    }

    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        if (StringUtils.isBlank(value)) {
            return true;
        }
        Matcher m = pattern.matcher(value);
        return m.matches();
    }

}
