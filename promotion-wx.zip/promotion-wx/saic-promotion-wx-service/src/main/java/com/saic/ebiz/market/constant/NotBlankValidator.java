/*
 * Copyright (C), 2013-2014, 上汽集团
 * FileName: CheckPatternValidator.java
 * Author:   zhuheng
 * Date:     2014年8月15日 上午11:47:48
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.constant;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;


/**
 * 〈一句话功能简述〉<br>
 * 〈非空做校验
 * 
 * @author zhuheng
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class NotBlankValidator implements ConstraintValidator<NotBlank, Object>  {
    
    private String field;
    private String[] preField;
    private String message;
    
    @Override
    public void initialize(NotBlank constraintAnnotation) {
        this.field = constraintAnnotation.field();  
        this.preField = constraintAnnotation.preField();  
        this.message=constraintAnnotation.message();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        
        boolean isValid=true;
        try {
            
            Object verifyFieldValue ;
            for(String fileld:preField){
                verifyFieldValue= PropertyUtils.getProperty(value, fileld);
                isValid=isNotBlank(verifyFieldValue);
               if(!isValid){
                   break;
               }
            }
            
            verifyFieldValue=PropertyUtils.getProperty(value, field);
            if(!isValid && isNotBlank(verifyFieldValue)){
                context.disableDefaultConstraintViolation();  
                context.buildConstraintViolationWithTemplate(message).addNode(field).addConstraintViolation();
            }else{
                isValid=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isValid;
    }
    
    
    private boolean isNotBlank(Object verifyFieldValue){
        if(null!=verifyFieldValue){
            Class<? extends Object>   clazz=verifyFieldValue.getClass();
            if((byte.class.equals(clazz) || Byte.class.equals(clazz))
              || (short.class.equals(clazz) || Short.class.equals(clazz))
              || (int.class.equals(clazz) || Integer.class.equals(clazz))
              || (long.class.equals(clazz)  || Long.class.equals(clazz))){
                if("0".equals(verifyFieldValue.toString())){
                    return false;
                }
            }else if(String.class.equals(clazz)){
                if(StringUtils.isBlank(verifyFieldValue.toString())){
                    return false;
                }
            }
        }
        return true;
    }
  

}
