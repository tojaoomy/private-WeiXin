package com.saic.ebiz.market.constant;

/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: PreOrderQueryBean.java
 * Author:   v_zhuozegang01
 * Date:     2013年12月18日 下午7:06:52
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
import com.saic.ebiz.order.service.entity.dto.PreOrderQueryCustResultDTO;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉.
 * 
 * @author v_zhuozegang01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class PreOrderQueryBean extends PreOrderQueryCustResultDTO {

    /** 序列. */
    private static final long serialVersionUID = 1L;

    /** 车型名称. */
    private String velModelName;

    /** 颜色名称. */
    private String colorName;
    
    /** 颜色图片路径. */
    private String colorUrl;

    /** 经销商店铺名称. */
    private String dealerName;

    /** 手机号码页面显示. */
    private String hidePhoneNum;
    
    /** certType 证件类型：参见代码表 */
    private Integer certType;
    
    /** 证件号码页面显示. */
    private String hideCateNo;

    /** 品牌Id. */
    private Long brandId;
    
    /** 品牌名称 */
    private String brandNameCh;

    /** 车系Id. */
    private Long velSeriesId;
    
    /** 车系名称. */
    private String velSeriesName;

    /** 是否提交了车主认证. */
    private boolean authRequest;
    /** 车型图片url. */
    private String imageUrl;
    /** 是否超时 */
    private String isTimeOutOrIn;

    /** 申请人 */
    private String appName;

    /** 校验认证是否已满 */
    private Integer checkCode;

    /**
     * 订单是否已经经过车主认证 1 表示已认证 空表示未认证
     */
    private String authentication;

    /**
     * 订单是否已评价 1 表示已评价 0表示未评价
     */
    private String iscomment;
    
    /** 是否逾期 */
    private Integer overdue;
    
    private String eDaiUrl;

    public String getBrandNameCh() {
        return brandNameCh;
    }

    public void setBrandNameCh(String brandNameCh) {
        this.brandNameCh = brandNameCh;
    }

    /**
     * @return the checkCode
     */
    public Integer getCheckCode() {
        return checkCode;
    }

    /**
     * @param checkCode the checkCode to set
     */
    public void setCheckCode(Integer checkCode) {
        this.checkCode = checkCode;
    }

    /**
     * Gets the vel model name.
     * 
     * @return the velModelName
     */
    public String getVelModelName() {
        return velModelName;
    }

    /**
     * Sets the vel model name.
     * 
     * @param velModelName the velModelName to set
     */
    public void setVelModelName(String velModelName) {
        this.velModelName = velModelName;
    }

    /**
     * Gets the color name.
     * 
     * @return the colorName
     */
    public String getColorName() {
        return colorName;
    }

    public String getAuthentication() {
        return authentication;
    }

    public void setAuthentication(String authentication) {
        this.authentication = authentication;
    }

    public String getIscomment() {
        return iscomment;
    }

    public void setIscomment(String iscomment) {
        this.iscomment = iscomment;
    }

    /**
     * Sets the color name.
     * 
     * @param colorName the colorName to set
     */
    public void setColorName(String colorName) {
        this.colorName = colorName;
    }

    /**
     * Gets the dealer name.
     * 
     * @return the dealerName
     */
    public String getDealerName() {
        return dealerName;
    }

    /**
     * Sets the dealer name.
     * 
     * @param dealerName the dealerName to set
     */
    public void setDealerName(String dealerName) {
        this.dealerName = dealerName;
    }

    /**
     * Gets the hide phone num.
     * 
     * @return the hidePhoneNum
     */
    public String getHidePhoneNum() {
        return hidePhoneNum;
    }

    /**
     * Sets the hide phone num.
     * 
     * @param hidePhoneNum the hidePhoneNum to set
     */
    public void setHidePhoneNum(String hidePhoneNum) {
        this.hidePhoneNum = hidePhoneNum;
    }

    /**
     * Gets the hide cate no.
     * 
     * @return the hideCateNo
     */
    public String getHideCateNo() {
        return hideCateNo;
    }

    /**
     * Sets the hide cate no.
     * 
     * @param hideCateNo the hideCateNo to set
     */
    public void setHideCateNo(String hideCateNo) {
        this.hideCateNo = hideCateNo;
    }

    /**
     * Gets the brand id.
     * 
     * @return the brandId
     */
    public Long getBrandId() {
        return brandId;
    }

    /**
     * Sets the brand id.
     * 
     * @param brandId the brandId to set
     */
    public void setBrandId(Long brandId) {
        this.brandId = brandId;
    }

    /**
     * Gets the vel series id.
     * 
     * @return the velSeriesId
     */
    public Long getVelSeriesId() {
        return velSeriesId;
    }

    /**
     * Sets the vel series id.
     * 
     * @param velSeriesId the velSeriesId to set
     */
    public void setVelSeriesId(Long velSeriesId) {
        this.velSeriesId = velSeriesId;
    }

    /**
     * @return the authRequest
     */
    public boolean isAuthRequest() {
        return authRequest;
    }

    /**
     * @param authRequest the authRequest to set
     */
    public void setAuthRequest(boolean authRequest) {
        this.authRequest = authRequest;
    }

    /**
     * @return the imageUrl
     */
    public String getImageUrl() {
        return imageUrl;
    }

    /**
     * @param imageUrl the imageUrl to set
     */
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getIsTimeOutOrIn() {
        return isTimeOutOrIn;
    }

    public void setIsTimeOutOrIn(String isTimeOutOrIn) {
        this.isTimeOutOrIn = isTimeOutOrIn;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

	public String getColorUrl() {
		return colorUrl;
	}

	public void setColorUrl(String colorUrl) {
		this.colorUrl = colorUrl;
	}

	public Integer getCertType() {
		return certType;
	}

	public void setCertType(Integer certType) {
		this.certType = certType;
	}

	public Integer getOverdue() {
		return overdue;
	}

	public void setOverdue(Integer overdue) {
		this.overdue = overdue;
	}

	public String getVelSeriesName() {
		return velSeriesName;
	}

	public void setVelSeriesName(String velSeriesName) {
		this.velSeriesName = velSeriesName;
	}

	public String geteDaiUrl() {
		return eDaiUrl;
	}

	public void seteDaiUrl(String eDaiUrl) {
		this.eDaiUrl = eDaiUrl;
	}
    
}
