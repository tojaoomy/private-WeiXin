/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: ServiceCode.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午11:27:38
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.constant;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface ServiceCode<T,K> {
    /***
     * 
     * 功能描述: 获取CODE代码E
     * 根据CODE代码的信息
     *
     * @return T
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public T code();
    /***
     * 
     * 功能描述:获取CODE对应的描述消息
     *
     * @return K
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public K message();
}
