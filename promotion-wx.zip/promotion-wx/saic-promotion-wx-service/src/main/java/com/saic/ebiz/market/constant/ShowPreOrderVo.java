package com.saic.ebiz.market.constant;

public class ShowPreOrderVo {
	
	/**
	 * 订单id
	 */
	private String preOrderId;
	/**
	 * 是否发表评论
	 */
	private Integer isEvaluate;
	
	/**
	 * 是否可以申请赔付
	 */
	private Integer mayCompensate;
	
	/**
	 * 是否申请赔付
	 */
	private Integer isCompensate;
	
	/**
	 * 赔付的状态
	 */
	private Integer cliemStatus;

	
	
	public String getPreOrderId() {
		return preOrderId;
	}

	public void setPreOrderId(String preOrderId) {
		this.preOrderId = preOrderId;
	}

	public Integer getIsEvaluate() {
		return isEvaluate;
	}

	public void setIsEvaluate(Integer isEvaluate) {
		this.isEvaluate = isEvaluate;
	}

	public Integer getMayCompensate() {
		return mayCompensate;
	}

	public void setMayCompensate(Integer mayCompensate) {
		this.mayCompensate = mayCompensate;
	}

	public Integer getIsCompensate() {
		return isCompensate;
	}

	public void setIsCompensate(Integer isCompensate) {
		this.isCompensate = isCompensate;
	}

	public Integer getCliemStatus() {
		return cliemStatus;
	}

	public void setCliemStatus(Integer cliemStatus) {
		this.cliemStatus = cliemStatus;
	}
	
	
}
