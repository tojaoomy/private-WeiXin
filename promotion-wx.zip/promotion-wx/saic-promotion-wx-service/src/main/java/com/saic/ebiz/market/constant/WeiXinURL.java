/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: WeiXinURL.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午11:32:55
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.constant;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public enum WeiXinURL implements URLCode<String> {
    /**获取access token*/
    ACCESS_TOKEN_URL("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&"),
    
    /**获取SNS access token*/
    SNS_ACCESS_TOKEN_URL("https://api.weixin.qq.com/sns/oauth2/access_token?grant_type=authorization_code&"),
    
    /**菜单创建URL*/
    MENU_CREATE_URL("https://api.weixin.qq.com/cgi-bin/menu/create?access_token="),
    /**菜单删除URL*/
    MENU_DELETE_URL("https://api.weixin.qq.com/cgi-bin/menu/delete?access_token="),
    /**菜单查询URL*/
    MENU_QUERY_URL("https://api.weixin.qq.com/cgi-bin/menu/get?access_token="),
    /**发送客服消息:在48小时内不限制发送次数*/
    SEND_MESSAGE("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token="),
    /**身份验证*/
    WECHAT_OAUTH("https://open.weixin.qq.com/connect/oauth2/authorize?"),
    
    /**用户获取access token*/
    USER_ACCESS_TOKEN("https://api.weixin.qq.com/sns/oauth2/access_token?"),
 
    /**用户信息*/
    USER_INFO("https://api.weixin.qq.com/cgi-bin/user/info?access_token="),
    
    /**未关注获取用户信息*/
    SNS_USER_INFO("https://api.weixin.qq.com/sns/userinfo?access_token="),

    /**获取图文群发每日数据*/
    HTTPS_GET_DATACUBE_USERREDSUMMARY("https://api.weixin.qq.com/datacube/getarticlesummary?access_token=ACCESS_TOKEN"),
    
    /**获取图文统计数据*/
    HTTPS_GET_DATACUBE_USERREDHOURS("https://api.weixin.qq.com/datacube/getuserread?access_token=ACCESS_TOKEN");


    /**URL*/
    private String url;
    /**默认构建函数*/
    private WeiXinURL(String url) {
         this.url=url;
    }

    @Override
    public String URL() {
        return this.url;
    }
}
