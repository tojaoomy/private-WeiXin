/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.event.handler;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.event.AuthorizationHandler;

/**
 * 
 * 默认的授权处理：包括两个操作 1. 微信授权 未登录状态设置backUrl 2. 页面跳转 MDM系统已经绑定如何跳转
 * 
 * @author hejian
 * 
 */
@Component
public class DefaultAuthorizationHandler implements AuthorizationHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultAuthorizationHandler.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.saic.ebiz.market.event.AuthorizationHandler#buildBackUrl(javax.servlet
     * .http.HttpServletRequest)
     */
    @Override
    public String buildBackUrl(HttpServletRequest request) {
        String state = getState(request);
        String backUrl = "";
        if (Authorization.index.name().equals(state)) {
            // 首页
            backUrl = "redirect:/" + Authorization.index.name() + ".htm?userId=-1?keyid=index_wx_pmt_yxzc";
        } else if (Authorization.inquiry.name().equals(state)) {
            // 询价页
            backUrl = "redirect:/inquiry/enquiryList/-1/1.htm?keyid=inquiry_wx_pmt_yxzc";
        } else if (Authorization.payment.name().equals(state)) {
            // 支付页 || 如果没获取到当前用户的openId，则通过授权来获取，然后重新跳转到支付页
            // 后面参数加上orderId & openId即可
            String orderId = request.getParameter("orderId");
            LOGGER.info("授权回调的返回的orderId : " + orderId);
            if (StringUtils.isBlank(orderId)) {
                throw new BaseException("授权回调的返回的orderId为空！！！");
            }
            backUrl = "redirect:/pay/prepayment.html?userId=-1&orderId=" + orderId+"&keyid=pay_wx_pmt_yxzc";
        } else if (Authorization.order328.name().equals(state)) {
            // 支付页 || 如果没获取到当前用户的openId，则通过授权来获取，然后重新跳转到支付页
            // 后面参数加上orderId & openId即可
            String orderId = request.getParameter("orderId");
            LOGGER.info("授权回调的返回328的orderId : " + orderId);
            if (StringUtils.isBlank(orderId)) {
                throw new BaseException("授权回调的返回的orderId为空！！！");
            }
            backUrl = "redirect:/pay/prepayorder.html?userId=-1&orderId=" + orderId+"&keyid=pay_wx_pmt_yxzc";
        } else if (Authorization.order.name().equals(state)) {
            // 订单页
            backUrl = "redirect:/myorder/orderList/-1/1.htm?keyid=myorder_wx_pmt_yxzc";
        } else if (Authorization.promotion.name().equals(state)) {
            // 活动页
            String promotionId = request.getParameter("orderId");
            LOGGER.info("授权回调的返回的promotionId : " + promotionId);
            if (StringUtils.isBlank(promotionId)) {
                throw new BaseException("授权回调的返回的promotionId为空！！！");
            }
            backUrl = "redirect:/mobileJieTiBuy/mbjieti/-1/" + promotionId + ".htm?keyid=mobileJieTiBuy_wx_pmt_yxzc";
        } else if (Authorization.payprmt.name().equals(state)) {
            // 活动支付页
            String promotionId = request.getParameter("orderId");
            LOGGER.info("授权回调的返回的promotionId : " + promotionId);
            if (StringUtils.isBlank(promotionId)) {
                throw new BaseException("授权回调的返回的promotionId为空！！！");
            }
            backUrl = "redirect:/payPrmt/prepayprmt.htm?userId=-1&orderId=" + promotionId+"&keyid=payPrmt_wx_pmt_yxzc";
        } else if (Authorization.promotionList.name().equals(state)) {
            // 我的活动页
            backUrl = "redirect:/mypromotion/promotionlist/-1/41/1.htm&keyid=mypromotion_wx_pmt_yxzc";
        } else if (Authorization.xiuqiu.name().equals(state)) {
            // 绣球活动点赞页
            backUrl = "redirect:/hydrangea/praiseHome.htm?userId=-1&keyid=hydrangea_wx_pmt_yxzc";
        } else if (Authorization.xiuqiu_312.name().equals(state)) {
            // 绣球活动点赞页
            backUrl = "redirect:/hydrangea/praise312.htm?userId=-1&keyid=hydrangea_wx_pmt_yxzc";
        } else if (Authorization.xiuqiu_main.name().equals(state)) {
            // 绣球活动首页
            backUrl = "redirect:/hydrangea/main.htm?userId=-1&keyid=hydrangea_wx_pmt_yxzc";
        } else if (Authorization.mggs.name().equals(state)) {
            // MG-GS 页
            backUrl = "redirect:/mg/mg-gs.htm?userId=-1&keyid=mggs_wx_pmt_yxzc";
        }
        else if (Authorization.mg3.name().equals(state)) {
            // MG3页
            backUrl = "redirect:/mg/index.htm?userId=-1&keyid=mg_wx_pmt_yxzc";
        }
        else if (Authorization.promotion518.name().equals(state)) {
            //518活动页
            backUrl = "redirect:/518wx/bcarlist.htm?userId=-1&keyid=518wx_wx_pmt_yxzc";
        }else if(Authorization.mggs2.name().equals(state)){
        	backUrl = "redirect:/mggs/index.htm?userId=-1&keyid=mggs_wx_pmt_yxzc";
        } else if(Authorization.rwwhole.name().equals(state)) {
        	//榮威试驾
        	backUrl = "redirect:/rwwhole/main.htm?userId=-1&keyid=rwwhole_wx_pmt_yxzc";
        } else if(Authorization.rwsouth.name().equals(state)) {
        	//榮威放暑‘价’
        	backUrl = "redirect:/roewe/south.htm?userId=-1&keyid=roewe_wx_pmt_yxzc";
        }else if(Authorization.rwmidsouth.name().equals(state)) {
        	//清凉暑‘价’
        	backUrl = "redirect:/roewe/midsouth.htm?userId=-1&keyid=roewe_wx_pmt_yxzc";
        }else if(Authorization.babajie.name().equals(state)) {
        	//八八节
        	backUrl = "redirect:/babajie/main.htm?userId=-1&keyid=88_wx_preheat_yxzc";
        }else if(Authorization.mgeast.name().equals(state)){
        	backUrl = "redirect:/mgall/eastern.htm?userId=-1&keyid=mgall_wx_pmt_yxzc";
        }else if(Authorization.mgbrand.name().equals(state)){
        	backUrl = "redirect:/mgbrand/index.htm?userId=-1&keyid=mgbrand_wx_pmt_yxzc";
        }else if(Authorization.buycar.name().equals(state)){
        	backUrl = "redirect:/buycar/index.htm?userId=-1&keyid=buycar_wx_pmt_yxzc";
        }else if(Authorization.babajieMain.name().equals(state)){
        	backUrl = "redirect:/babamain/index.htm?userId=-1&keyid=88_wx_mainVenue_yxzc";
        }else if(Authorization.rarea.name().equals(state)){
        	//荣威暑假活动
        	backUrl = "redirect:/roewe/summer.htm?userId=-1&keyid=roewe_wx_pmt_yxzc_rarea";
        }else if(Authorization.lovecar.name().equals(state)){
        	backUrl = "redirect:/carVouchers/index.htm?userId=-1&keyid=yzsgc_wx_promotion_yxzc_xiche";
        }else if(Authorization.warea.name().equals(state)){
        	//荣威暑假活动
        	backUrl = "redirect:/roewe/warea.htm?userId=-1&keyid=roewe_wx_pmt_yxzc_warea";
        }else if(Authorization.mgTwoArea.name().equals(state)){
        	//MG2区区域活动
        	backUrl = "redirect:/mgbrand/mgTwoArea.htm?userId=-1&keyid=mgbrand_wx_pmt_yxzc_mgtwoarea";
        }else if(Authorization.mgFourArea.name().equals(state)){
        	//MG4区区域活动
        	backUrl = "redirect:/mgbrand/mgFourArea.htm?userId=-1&keyid=mgbrand_wx_pmt_yxzc_mgfourarea";
        }else if(Authorization.mgRoewe.name().equals(state)){
        	String groupId = request.getParameter("groupId");
        	LOGGER.info("groupId : "+groupId);
        	
        	//荣威MG区区域活动
        	backUrl = "redirect:/mgbrand/mgRoewe.htm?keyid=mgbrand_wx_pmt_yxzc_mgroewe&groupId="+groupId;
        }else if(Authorization.wxCard.name().equals(state)){
        	String tzhuserId = request.getParameter("tzhUserId");
        	//微信名片活动
        	backUrl = "redirect:/wxcard/show.htm?keyid=wxCard_show&tzhUserId="+tzhuserId;
        }else if(Authorization.wxCardMap.name().equals(state)){
        	String tzhuserId = request.getParameter("tzhUserId");
        	//微信名片活动 地图
        	backUrl = "redirect:/wxcard/cardMap.htm?keyid=wxCard_show&tzhUserId="+tzhuserId;
        }
        
        LOGGER.info("backUrl : " + backUrl);
        return backUrl;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.saic.ebiz.market.event.AuthorizationHandler#buildCustomBackUrl(javax
     * .servlet.http.HttpServletRequest, java.lang.String)
     */
    @Override
    public String buildCustomBackUrl(HttpServletRequest request, String backUrl) {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.saic.ebiz.market.event.AuthorizationHandler#buildView(javax.servlet
     * .http.HttpServletRequest, java.lang.String)
     */
    @Override
    public ModelAndView buildView(HttpServletRequest request, String backUrl, String openId, Long userId) {
        String state = getState(request);
        ModelAndView model = null;
        LOGGER.info("backUrl {" + backUrl + "}");
        String tempUrl = backUrl.replace(ANONYMITY, String.valueOf(userId));
        LOGGER.info("tempUrl {" + tempUrl + "} ");
        if (tempUrl.indexOf("?") > 0) {
            tempUrl += "&openid=" + openId;
        } else {
            tempUrl += "?openid=" + openId;
        }
        if(!tempUrl.contains("userId")){
        	LOGGER.info("未找到用户id");
        	tempUrl += "&userId="+userId;
        	LOGGER.info("添加userId 后 tempUrl : " + tempUrl);
        }
        if (Authorization.index.name().equals(state)) {
            // 跳转到首页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转常规车首页");
            // model = new ModelAndView(tempUrl);
        } else if (Authorization.inquiry.name().equals(state)) {
            // 询价页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转常规车询价页");
            // model = new ModelAndView(tempUrl);
        } else if (Authorization.payment.name().equals(state)) {
            // 支付
            LOGGER.info("openId {" + openId + "} is bounded... 跳转常规车支付页");
            model = new ModelAndView(tempUrl + "&openId=" + openId);
        } else if (Authorization.order328.name().equals(state)) {
            // 支付
            LOGGER.info("openId {" + openId + "} is bounded... 跳转绣球328支付页");
            model = new ModelAndView(tempUrl + "&openId=" + openId);
        } else if (Authorization.order.name().equals(state)) {
            // 我的订单页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转我的订单页");
            // model = new ModelAndView(tempUrl);
        } else if (Authorization.promotion.name().equals(state)) {
            // 活动页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转活动页");
            // model = new ModelAndView(tempUrl);
        } else if (Authorization.payprmt.name().equals(state)) {
            // 活动支付页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转活动支付页");
            model = new ModelAndView(tempUrl + "&openId=" + openId);
        } else if (Authorization.promotionList.name().equals(state)) {
            // 我的活动页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转我的活动页");
        } else if (Authorization.xiuqiu.name().equals(state)) {
            // 绣球328活动首页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转绣球点赞页");
        } else if (Authorization.xiuqiu_312.name().equals(state)) {
            // 绣球328活动首页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转绣球点赞第二波页");
        } else if (Authorization.xiuqiu_main.name().equals(state)) {
            // 绣球328活动首页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转绣球主页");
        } else if (Authorization.mggs.name().equals(state)) {
            // 绣球328活动MG-GS页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转mg-gs页");
        }
        else if (Authorization.mg3.name().equals(state)) {
            // 绣球328活动MG3页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转mg-gs页");
        }
        else if (Authorization.promotion518.name().equals(state)) {
            // 518活动页
            LOGGER.info("openId {" + openId + "} is bounded... 跳转518活动页");
        }
        if (model == null) {
            model = new ModelAndView(tempUrl);
        }
        return model;
    }

    private String getState(HttpServletRequest request) {
        return request.getParameter(Constants.URL_PARAMETER_KEY_STATE);
    }

}
