/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.event.handler;

import org.springframework.stereotype.Component;

import com.ibm.framework.exception.BaseException;
import com.ibm.framework.uts.util.StringUtils;
import com.saic.ebiz.market.event.RedirectHandler;

/**
 * 
 * 登录成功后如何跳转
 * 
 * @author hejian
 *
 */
@Component
public class DefaultRedirectHandler implements RedirectHandler {

	/**
	 * 登录注册成功后跳转处理
	 * 根据backUrl后面的#flag来判断如何跳转
	 * @see DefaultAuthorizationHandler#buildView(javax.servlet.http.HttpServletRequest, String, String, Long) 
	 * @param backUrl 回跳的url
	 * @param userId 用户id
	 */
	@Override
	public String buildBackUrl(String backUrl, Long userId) {
		String result = "";
		//如果backUrl长度小于1并且不包含 #flag抛出异常
		if(StringUtils.isEmpty(backUrl)){
			throw new BaseException("backUrl不正确");
		}
		/*String flag = backUrl.substring(backUrl.indexOf(FLAG) + FLAG.length());
		if(Authorization.payprmt.name().equals(flag)){
		}else{
		}*/
		result = backUrl.replace(ANONYMITY, String.valueOf(userId));
		return result;
	}

	public static void main(String[] args) {
		System.out.println("sfs/sfji/sjflj#flag=promotion".substring("sfs/sfji/sjflj#flag=promotion".indexOf(FLAG) + FLAG.length()));
	}

}
