package com.saic.ebiz.market.event.handler;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.entity.response.Article;
import com.saic.ebiz.market.common.entity.response.NewsMessageReponse;
import com.saic.ebiz.market.common.entity.response.TextMessageReponse;
import com.saic.ebiz.market.common.entity.response.TransferTextMessageReponse;
import com.saic.ebiz.market.common.enumeration.MessageType;
import com.saic.ebiz.market.common.util.ImageUtil;
import com.saic.ebiz.market.common.util.KeyMap;
import com.saic.ebiz.market.common.util.MessageUtil;
import com.saic.ebiz.market.common.util.MyOpenIdTokenUtil;
import com.saic.ebiz.market.event.EventHandler;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.WebAccountInfoService;
import com.saic.ebiz.mdm.entity.WebAccountVO;

/**
 * 用来处理自定义菜单CLICK的请求
 * 
 * @author hejian
 *
 */
@Component
public class EventClickHandler implements EventHandler{
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	/** 返回给用户绑定的内容，包括url */
	private static String template = "亲，您还没有绑定车享账号，\n \n<a href=\"URL_PLACEHOLDER\">点击这里，立即绑定</a> \n\n 绑定成功后您可以尊享车享服务，赶快尝试一下吧！";
	
	/** 询价菜单点击回复的信息  */
	private static String INQUIRY_MESSAGE = "上汽专业砍价团队帮您询最低价.即将上线,敬请期待!!!";

	/** 一口价菜单点击回复的信息  */
	private static String SOLID_PRICE_MESSAGE = "车享平台为您网罗大量上汽低价车源,一口价销售. 即将上线,敬请期待!!!";
	
	private static String CLUB_REPLY = null;
	
	static{
		StringBuilder builder = new StringBuilder("关于车的一切，客官您请随便问！");
		builder.append("\n").append("点击“键盘”按钮，输入您的问题即可~").append("\n")
		.append("举个栗子~").append("\n").append("•新手买车，如何才能选一辆用起来不后悔的车？").append("\n")
		.append("•荣威3601.5L自动豪华版上海地区多少钱？").append("\n")
		.append("•新车首保应该什么时候做？").append("\n")
		.append("•刹车异响怎么办？").append("\n")
		.append("•想换车，旧车如何处理？").append("\n").append("等等等~~~");
		
		CLUB_REPLY = builder.toString();
	}
	
	
    /** 登录URL */
    private static final String LOGIN_URL = "/account/wxlogin.htm?fromType=29&token=";
    
    @Value("${ebiz.wap.web.domain:}")
	private String domain;

    @Autowired
    private MyOpenIdTokenUtil myOpenIdTokenUtil;
    
    @Autowired
    private WebAccountInfoService webAccountInfoService;
    
    @Resource
	private AuthorizationService authorizationService;
    
    @Resource
	private ImageUtil imageUtil;
    
    @Value("${ebiz.wap.web.appId:}")
	private String appId;
    
    /**
     * 
     * @param requestMap
     * @param source 询价 | 订单 | 积分 | 其他 
     * @return
     */
    private TextMessageReponse buildTextMessageReponse(Map<String,String> requestMap,String source){
    	TextMessageReponse textMessage = new TextMessageReponse();
    	// 发送方帐号（open_id）
        String fromUserName = requestMap.get(Constants.FROM_USER_NAME);
        // 公众帐号
        String toUserName = requestMap.get(Constants.TO_USER_NAME);
        // 消息类型
        String msgType = requestMap.get(Constants.MSG_TYPE);
        
        logger.info("接受请求 {}, { 发送方账号 fromUserName(openId) : {}, 公众帐号 toUserName : {},消息类型 msgType : {} }" ,source, fromUserName, toUserName, msgType);

        // 回复文本消息
        textMessage.setToUserName(fromUserName);
        textMessage.setFromUserName(toUserName);
        textMessage.setCreateTime(new Date().getTime());
        textMessage.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_TEXT);
        return textMessage;
    }
    
    /**
     * 
     * @param requestMap
     * @return
     */
    private TransferTextMessageReponse buildTransferMessageReponse(Map<String,String> requestMap){
    	TransferTextMessageReponse message = new TransferTextMessageReponse();
    	// 发送方帐号（open_id）
        String fromUserName = requestMap.get(Constants.FROM_USER_NAME);
        // 公众帐号
        String toUserName = requestMap.get(Constants.TO_USER_NAME);
        // 消息类型
        String msgType = requestMap.get(Constants.MSG_TYPE);
        
        logger.info("接受请求{ 发送方账号 fromUserName(openId) : {}, 公众帐号 toUserName : {},消息类型 msgType : {} }" , fromUserName, toUserName, msgType);
        
        message.setToUserName(fromUserName);
        message.setFromUserName(toUserName);
        message.setCreateTime(new Date().getTime());
        message.setMsgType(MessageUtil.EVENT_TYPE_TRANSFER);
        return message;
    }
    
    /**
     * 
     * @param fromUserName 发送方帐号（open_id）
     * @param toUserName 公众帐号
     * @return token
     */
    private String getToken(String fromUserName,String toUserName){
    	 String uuid = "";
         try {
             uuid = myOpenIdTokenUtil.setOpenIdToken(fromUserName, toUserName);
         } catch (Exception e) {
             e.printStackTrace();
             uuid = "error:获取token失败";
             logger.error("获取token值失败 : " + e.getMessage());
         }
         return uuid;
    }
    
    /**
     * 处理询价购车的菜单
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onInquiryBuyCar(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_INQUIRY_BUY_CAR);
    	//判断是否绑定
//    	boolean isBounding = checkResultBounding(requestMap.get(Constants.FROM_USER_NAME));
    	//返回微信用户的文本内容信息
    	String respContent = INQUIRY_MESSAGE;
//        String uuid = getToken(requestMap.get(Constants.FROM_USER_NAME), requestMap.get(Constants.TO_USER_NAME));
//        if(isBounding){
//        	respContent = "您好，未找到您提交询价记录。";
//        }else{
//        	respContent =  template.replace("URL_PLACEHOLDER", (LOGIN_URL + uuid));
//        }
        logger.info("询价购车查询返回内容信息 : " + respContent);
        textMessage.setContent(respContent);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 处理一口价的菜单
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onSolidPrice(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_SOLID_PRICE);
    	//判断是否绑定
//    	boolean isBounding = checkResultBounding(requestMap.get(Constants.FROM_USER_NAME));
    	//返回微信用户的文本内容信息
    	String respContent = SOLID_PRICE_MESSAGE;
        logger.info("一口价查询返回内容信息 : " + respContent);
        textMessage.setContent(respContent);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 处理询价
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onInquiry(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_INQUIRY);
    	//判断是否绑定
    	boolean isBounding = checkResultBounding(requestMap.get(Constants.FROM_USER_NAME));
    	//返回微信用户的文本内容信息
    	String respContent = "";
        String uuid = getToken(requestMap.get(Constants.FROM_USER_NAME), requestMap.get(Constants.TO_USER_NAME));
        if(isBounding){
        	respContent = "您好，未找到您提交询价记录。";
        }else{
        	respContent =  template.replace("URL_PLACEHOLDER", (domain + LOGIN_URL + uuid));
        }
        logger.info("询价查询返回内容信息 : " + respContent);
        textMessage.setContent(respContent);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 处理订单
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onOrder(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_ORDER);
    	//判断是否绑定
    	boolean isBounding = checkResultBounding(requestMap.get(Constants.FROM_USER_NAME));
    	//返回微信用户的文本内容信息
    	String respContent = "";
        String uuid = getToken(requestMap.get(Constants.FROM_USER_NAME), requestMap.get(Constants.TO_USER_NAME));
        if(isBounding){
        	respContent = "您好，未找到您提交订单记录。";
        }else{
        	respContent =  template.replace("URL_PLACEHOLDER", (domain + LOGIN_URL + uuid));
        }
        logger.info("订单查询返回内容信息 : " + respContent);
        textMessage.setContent(respContent);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 处理积分
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onPoints(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_POINTS);
    	//判断是否绑定
    	boolean isBounding = checkResultBounding(requestMap.get(Constants.FROM_USER_NAME));
    	//返回微信用户的文本内容信息
    	String respContent = "";
        String uuid = getToken(requestMap.get(Constants.FROM_USER_NAME), requestMap.get(Constants.TO_USER_NAME));
        if(isBounding){
        	respContent = "您好，您当前的积分为 0";
        }else{
        	respContent =  template.replace("URL_PLACEHOLDER", (domain + LOGIN_URL + uuid));
        }
        logger.info("积分查询返回内容信息 : " + respContent);
        textMessage.setContent(respContent);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 在线客服转发
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onOnline(Map<String,String> requestMap,HttpServletRequest request){
    	//转发的信息
    	TransferTextMessageReponse textMessage = buildTransferMessageReponse(requestMap);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 处理客服电话
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onPhone(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_PHONE);
        textMessage.setContent("客服电话：4008-020-666");
        logger.info("客服电话：" + textMessage.getContent());
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 处理半价购车
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onHalfButCar(Map<String,String> requestMap,HttpServletRequest request){
    	NewsMessageReponse response = new NewsMessageReponse();
		response.setCreateTime(new Date().getTime());
		response.setFromUserName(requestMap.get(Constants.TO_USER_NAME));
		response.setToUserName(requestMap.get(Constants.FROM_USER_NAME));
		response.setMsgType(MessageType.NEWS.code());
		List<Article> articles = new ArrayList<Article>();
		Article article = new Article();
		article.setTitle("随手拍车享广告，900张洗车券等你领");
		article.setDescription("3月21日起至4月10日，3周时间里，只要您找到并拍下车享宣传广告，无论是地铁车厢、楼宇广告、剧院海报还是上汽经销商的4S店里的宣传品，将照片发在微博上并@车享，带上话题#随手拍车享#，便可参与活动。");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/coupon.jpg"));
		String url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=203676232&idx=1&sn=3c701f412f4be7d211e804a159ce837f#rd";
		article.setUrl(url);
		articles.add(article);
		response.setArticles(articles);
		response.setArticleCount(articles.size());
		return MessageUtil.messageToXml(response);
    }
    
    /**
     * 处理半价购车
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onXiuqiu328(Map<String,String> requestMap,HttpServletRequest request){
    	NewsMessageReponse response = new NewsMessageReponse();
		response.setCreateTime(new Date().getTime());
		response.setFromUserName(requestMap.get(Constants.TO_USER_NAME));
		response.setToUserName(requestMap.get(Constants.FROM_USER_NAME));
		response.setMsgType(MessageType.NEWS.code());
		List<Article> articles = new ArrayList<Article>();
		
		Article article = new Article();
		article.setTitle("车享328周年庆现金半价车车主名单公布");
		article.setDescription("");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/header.jpg"));
		String url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=204310008&idx=1&sn=acb750a416bab3dc64eebf623e1e6259#rd";
		article.setUrl(url);
		articles.add(article);
		
		article = new Article();
		article.setTitle("车享328周年庆第一期4999元旅游礼包获奖名单公布");
		article.setDescription("");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/prize_4_8.jpg"));
		url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=204310008&idx=2&sn=739a6cfacbec9e5b3c287f1d0d343ca6#rd";
		article.setUrl(url);
		articles.add(article);
		
		article = new Article();
		article.setTitle("车享328周年庆OBD宝盒获奖名单公布");
		article.setDescription("");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/prize_4_8.jpg"));
		url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=204310008&idx=3&sn=c177efc6389b2ab891a0ea86231412e9#rd";
		article.setUrl(url);
		articles.add(article);
		
		article = new Article();
		article.setTitle("车享328周年庆现权益半价车车主名单公布");
		article.setDescription("");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/prize_4_8.jpg"));
		url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=204492265&idx=1&sn=4150021f00562590e3e14f8a8df1315c#rd";
		article.setUrl(url);
		articles.add(article);
		
		article = new Article();
		article.setTitle("车享328周年庆第二期4999元旅游礼包获奖名单公布");
		article.setDescription("");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/prize_4_8.jpg"));
		url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=204492265&idx=3&sn=f26d0bb512c2c7a57e04ce8757f462b0#rd";
		article.setUrl(url);
		articles.add(article);
		
		response.setArticles(articles);
		response.setArticleCount(articles.size());
		return MessageUtil.messageToXml(response);
    }
    
    /**
     * 处理半价购车
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onWeiBo(Map<String,String> requestMap,HttpServletRequest request){
    	NewsMessageReponse response = new NewsMessageReponse();
		response.setCreateTime(new Date().getTime());
		response.setFromUserName(requestMap.get(Constants.TO_USER_NAME));
		response.setToUserName(requestMap.get(Constants.FROM_USER_NAME));
		response.setMsgType(MessageType.NEWS.code());
		List<Article> articles = new ArrayList<Article>();
		Article article = new Article();
		article.setTitle("3月20至3月25日微博转发有奖活动中奖公布");
		article.setDescription("3月20日至3月25日微博转发有奖活动中奖公布，含：车享阵营有奖转发、倒计时5、4、3天的转发中奖名单。");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/prize.jpg"));
		String url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=203930885&idx=1&sn=7adebb440e37e5298e2ba26d733f3037#rd";
		article.setUrl(url);
		articles.add(article);
		article = new Article();
		article.setTitle("3月20日至3月29日微博活动中奖名单公布");
		article.setDescription("");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/prize_4_8.jpg"));
		url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=204250724&idx=1&sn=717500db730fbf585f335aec3051538d#rd";
		article.setUrl(url);
		articles.add(article);
		response.setArticles(articles);
		response.setArticleCount(articles.size());
		return MessageUtil.messageToXml(response);
    }
    
    /**
     * 处理半价购车
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onWeiXin(Map<String,String> requestMap,HttpServletRequest request){
    	NewsMessageReponse response = new NewsMessageReponse();
		response.setCreateTime(new Date().getTime());
		response.setFromUserName(requestMap.get(Constants.TO_USER_NAME));
		response.setToUserName(requestMap.get(Constants.FROM_USER_NAME));
		response.setMsgType(MessageType.NEWS.code());
		List<Article> articles = new ArrayList<Article>();
		Article article = new Article();
		article.setTitle("3月23日至3月31日微信活动中奖公布");
		article.setDescription("");
		article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/game.jpg"));
		String url = "http://mp.weixin.qq.com/s?__biz=MzAwNzA0NTYyMw==&mid=204250724&idx=2&sn=61e64d6acca3907f0cbf886cc15aa0cb#rd";
		article.setUrl(url);
		articles.add(article);
		response.setArticles(articles);
		response.setArticleCount(articles.size());
		return MessageUtil.messageToXml(response);
    }
    
    /**
     * 处理文本消息回复
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    @SuppressWarnings("unused")
	private String onCommonMessage(Map<String,String> requestMap,HttpServletRequest request,String contentMessage){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_OTHERS);
        textMessage.setContent(contentMessage);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 处理其他类型的处理
     * 
     * @param requestMap
     * 			微信发送过来的参数信息map
     * @param request
     * 			HttpServletRequest
     * @return
     * 			返回XML格式的内容。
     */
    private String onOthers(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_OTHERS);
        textMessage.setContent("目前系统异常，如需帮助，请点击右边联系客服的在线咨询。");
        logger.info(textMessage.getContent());
        return MessageUtil.messageToXml(textMessage);
    }
    
    private String onClub(Map<String,String> requestMap,HttpServletRequest request){
    	TextMessageReponse textMessage = buildTextMessageReponse(requestMap, Source.SOURCE_CLUB);
        textMessage.setContent(CLUB_REPLY);
        return MessageUtil.messageToXml(textMessage);
    }
    
    /**
     * 获取绑定信息
     * 
     * @param fromUserName openid
     * @return
     */
    public List<WebAccountVO> checkBounding(String fromUserName) {
        WebAccountVO webAccountVO = new WebAccountVO();
        webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE);
        webAccountVO.setNumber(fromUserName);
        //查询来源是车享购微信号
        webAccountVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));
        
        logger.info(" ---------- 开始调用webAccountInfoService.findWebAccountByCondition---------- fromUserName = "+fromUserName);
        logger.info(" ---------- 开始调用webAccountInfoService.findWebAccountByCondition---------- WebAccountVO = " + JSONObject.toJSONString(webAccountVO));
        List<WebAccountVO> webAccountVOList = webAccountInfoService.findWebAccountByCondition(webAccountVO);
        logger.info("返回列表 : " + JSONObject.toJSONString(webAccountVOList));
        logger.info(" ---------- 结束调用webAccountInfoService.findWebAccountByCondition---------- ");
        
        return webAccountVOList;
    }

    /**
     * 
     * @param fromUserName fromUserName openid
     * 
     * @return true 该用户已绑定 false 未绑定
     * 	
     */
    public boolean checkResultBounding(String fromUserName) {
        List<WebAccountVO> webAccountVOList = checkBounding(fromUserName);
        boolean isBounding = false;
        if (null != webAccountVOList && webAccountVOList.size() > 0) {
            isBounding = true;
        }
        return isBounding;
    }
    
    private static class Source{
    	public static final String SOURCE_INQUIRY_BUY_CAR = "询价购车";
    	public static final String SOURCE_SOLID_PRICE = "一口价";
    	public static final String SOURCE_INQUIRY = "询价";
    	public static final String SOURCE_ORDER   = "订单";
    	public static final String SOURCE_POINTS  = "积分";
    	public static final String SOURCE_PHONE   = "客服电话";
    	public static final String SOURCE_CLUB   = "车知道";
    	public static final String SOURCE_OTHERS  = "其它";
    }

	@Override
	public String handler(Map<String, String> requestMap,
			HttpServletRequest request) {
		String eventKey = requestMap.get(Constants.REQUEST_PARAMETER_EVENT_KEY).trim();
        logger.info("用户点击了 eventKey = " + eventKey );
        if (eventKey.equals(KeyMap.CUSTOMER_PRICE)) {
        	//我的询价
        	return onInquiry(requestMap, request);
        } else if(eventKey.equals(KeyMap.INQUIRY_BUY_CAR)){
        	//询价购车 
        	return onInquiryBuyCar(requestMap, request);
        } else if(eventKey.equals(KeyMap.SOLID_PRICE)){
        	//一口价
        	return onSolidPrice(requestMap, request);
        } else if (eventKey.equals(KeyMap.CUSTOMER_ORDER)) {
        	//我的订单
        	return onOrder(requestMap, request);
        } else if (eventKey.equals(KeyMap.CUSTOMER_POINTS)) {
        	//我的积分
        	return onPoints(requestMap, request);
        } else if (eventKey.equals(KeyMap.SERVICE_ONLINE)) {
        	//在线咨询   (转接多客服)
        	return onOnline(requestMap, request);
        } else if(eventKey.equals(KeyMap.SERVICE_PHONE)){
        	//客服电话
        	return onPhone(requestMap, request);
        } else if(eventKey.equals(KeyMap.HALF_BUY_CAR)){
        	//半价购车
        	return onHalfButCar(requestMap, request);
        } else if(eventKey.equals(KeyMap.PROMOTION_WEIBO)){
        	//微博图文消息
        	return onWeiBo(requestMap, request);
        } else if(eventKey.equals(KeyMap.PROMOTION_WEIXIN)){
        	//微信图文消息
        	return onWeiXin(requestMap, request);
        } else if(eventKey.equals(KeyMap.PROMOTION_328)){
        	//普通活动点击回复文本内容
//        	return onCommonMessage(requestMap, request, "精彩活动敬请期待");
        	return onXiuqiu328(requestMap, request);
        } else if(eventKey.equals(KeyMap.CLUB)){
        	//车知道回复
        	return onClub(requestMap, request);
        } else{
        	return onOthers(requestMap, request);
        }
	}
}
