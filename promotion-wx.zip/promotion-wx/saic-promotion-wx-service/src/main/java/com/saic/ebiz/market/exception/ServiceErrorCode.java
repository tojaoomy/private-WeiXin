/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: ServiceErrorCode.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午11:25:29
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.exception;

import com.saic.ebiz.market.constant.ServiceCode;

/**
 * 接口异常代码定义<br> 
 * 定义接口连接错误、连接成功、
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public enum ServiceErrorCode implements ServiceCode<String, String>{
    HTTP_ENCODING("S000001","HTTP　编码出错"),
    HTTP_IO("S000002","HTTP　编码出错"),
    HTTP_SECURITY("S000003","SSL加密失败"),
    HTTP_PROTOCOL("A000002","接口连接HTTP Client 连接协议出错"),
    CLASS_NOTFOUND("A000004","接口请求初化失败"),
    CLASS_NOTFOUND_FORAMTTER("A000005","接口请解析类初化失败"),
    URL_ENCODE("S000007","URL 参数编码"),
    XML_REDER("A000006","xml文件读取出错"),
    BEAN_COPY("S000008","复制对象出错");
    ;
    /**异常CODE*/
    private String code;
    /**异常描述*/
    private String  message;
    /***
     * 默认构造函数
     * @param code 代码
     * @param message  描述
     */
    private ServiceErrorCode(String code,String message){
        this.code=code;
        this.message=message;
    }
    
    /**
     * {@inheritDoc}
     */
    public String code() {
        return this.code;
    }

    /**
     * {@inheritDoc}
     */
    public String message() {
        return this.message;
    }
}
