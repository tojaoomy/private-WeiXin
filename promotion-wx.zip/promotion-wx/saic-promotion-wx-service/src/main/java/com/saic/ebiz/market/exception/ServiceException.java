/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: ServiceException.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午11:25:41
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.exception;

import com.ibm.framework.exception.BaseException;

/**
 * 服务类 Exception<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ServiceException extends BaseException{
    /**
     */
    private static final long serialVersionUID = 5394151053509734598L;
    /**服务错误代码*/
    private  ServiceErrorCode serviceErrorCode;
    /**默认构造函数*/
    public ServiceException() {
         super();
    }
    /**
     * @param errorCode 错误代码
     */
    public ServiceException(ServiceErrorCode serviceErrorCode) {
        super(serviceErrorCode.code());
        this.serviceErrorCode = serviceErrorCode;
    }
    
    public  ServiceException(ServiceErrorCode serviceErrorCode,Throwable e){
        super(serviceErrorCode.code(),e);
        this.serviceErrorCode=serviceErrorCode;
    }
    
    
    
    /* (non-Javadoc)
     * @see java.lang.Throwable#getMessage()
     */
    @Override
    public String getMessage() {
        StringBuilder sb=new StringBuilder();
        sb.append(super.getMessage());
        sb.append(",");
        sb.append(this.serviceErrorCode.message());
        return sb.toString();
    }
    /**
     * @return the serviceErrorCode
     */
    public ServiceErrorCode getServiceErrorCode() {
        return serviceErrorCode;
    }
}
