/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.ArrayList;
import java.util.List;

import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.entity.AreaSerialVO;
import com.saic.ebiz.market.entity.CitySerialVO;
import com.saic.ebiz.market.entity.CityVO;
import com.saic.ebiz.market.entity.DistrictVO;
import com.saic.ebiz.market.entity.ProvinceSerialVO;
import com.saic.ebiz.market.entity.ProvinceVO;

/**
 * @author hejian
 *
 */
public abstract class AbstractAeraService implements AreaService {

	/** 得到所有省的code. */
    private static String allProvince = "999999";
    
	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.AreaService#getAllProvinces()
	 */
	@Override
	public List<ProvinceVO> getAllProvinces() {
		List<ProvinceVO> provinceVOList = new ArrayList<ProvinceVO>();
        //得到所有的省
        List<DataItemBean> provinceList = ConstantCodeService.getRegionListByParentCode(allProvince);
        for (DataItemBean dataItemBean : provinceList) {
            ProvinceVO provinceVO = new ProvinceVO();
            provinceVO.setCode(Long.valueOf(dataItemBean.getCode()));
            provinceVO.setName(dataItemBean.getName());
            List<DataItemBean> cityList = ConstantCodeService.getRegionListByParentCode(dataItemBean.getCode());
            if(cityList != null){
                List<CityVO> children = new ArrayList<CityVO>();
                for (DataItemBean city : cityList) {
                    CityVO cityVO = new CityVO();
                    cityVO.setCode(Long.valueOf(city.getCode()));
                    cityVO.setName(city.getName());
                    cityVO.setPvalue(Long.valueOf(dataItemBean.getCode()));
                    List<DataItemBean> areaList = ConstantCodeService
                            .getRegionListByParentCode(city.getCode());
                    List<DistrictVO> areaVOList = new ArrayList<DistrictVO>();
                    if (areaList != null) {
                        for (DataItemBean area : areaList) {
                        	DistrictVO districtVO = new DistrictVO();
                        	districtVO.setPvalue(Long.valueOf(city.getCode()));
                            districtVO.setText(area.getName());
                            districtVO.setValue(Long.valueOf(area.getCode()));
                            areaVOList.add(districtVO);
                        }
                    }
                    cityVO.setChildren(areaVOList);
                    children.add(cityVO);
                }
                provinceVO.setChildren(children);  
            }
            provinceVOList.add(provinceVO);
        }
        return provinceVOList;
	}
	
	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.AreaService#getAllProvinceSerials()
	 */
	@Override
	public List<ProvinceSerialVO> getAllProvinceSerials() {
		List<ProvinceSerialVO> provinceVOList = new ArrayList<ProvinceSerialVO>();
        //得到所有的省
        List<DataItemBean> provinceList = ConstantCodeService.getRegionListByParentCode(allProvince);
        for (DataItemBean dataItemBean : provinceList) {
        	ProvinceSerialVO provinceVO = new ProvinceSerialVO();
            provinceVO.setCode(Long.valueOf(dataItemBean.getCode()));
            provinceVO.setName(dataItemBean.getName());
            List<DataItemBean> cityList = ConstantCodeService.getRegionListByParentCode(dataItemBean.getCode());
            if(cityList != null){
                List<CitySerialVO> children = new ArrayList<CitySerialVO>();
                for (DataItemBean city : cityList) {
                    CitySerialVO cityVO = new CitySerialVO();
                    cityVO.setCode(Long.valueOf(city.getCode()));
                    cityVO.setName(city.getName());
                    cityVO.setPvalue(Long.valueOf(dataItemBean.getCode()));
                    List<DataItemBean> areaList = ConstantCodeService
                            .getRegionListByParentCode(city.getCode());
                    List<AreaSerialVO> areaVOList = new ArrayList<AreaSerialVO>();
                    if (areaList != null) {
                        for (DataItemBean area : areaList) {
                        	AreaSerialVO districtVO = new AreaSerialVO();
                        	districtVO.setCode(Long.valueOf(area.getCode()));
                            districtVO.setName(area.getName());
                            districtVO.setPvalue(Long.valueOf(city.getCode()));
                            areaVOList.add(districtVO);
                        }
                    }
                    cityVO.setChildren(areaVOList);
                    children.add(cityVO);
                }
                provinceVO.setChildren(children);  
            }
            provinceVOList.add(provinceVO);
        }
        return provinceVOList;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.AreaService#getProvinceByCityId(java.lang.Long)
	 */
	@Override
	public ProvinceVO getProvinceByCityId(Long cityId) {
		DataItemBean dataItemBean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
		ProvinceVO provinceVO = new ProvinceVO();
		if (dataItemBean != null) {
			provinceVO.setValue(Long.valueOf(dataItemBean.getParentCode()));
			provinceVO.setText(dataItemBean.getParentName());
			CityVO cityVO = new CityVO();
			cityVO.setText(dataItemBean.getName());
			cityVO.setValue(Long.valueOf(dataItemBean.getCode()));
			cityVO.setPvalue(Long.valueOf(dataItemBean.getParentCode()));
			//根据城市id获取所有的县区列表
			List<DataItemBean> areaList = ConstantCodeService.getRegionListByParentCode(dataItemBean.getCode());
            List<DistrictVO> areaVOList = new ArrayList<DistrictVO>();
            if (areaList != null) {
                for (DataItemBean area : areaList) {
                	DistrictVO districtVO = new DistrictVO();
                	districtVO.setPvalue(Long.valueOf(dataItemBean.getCode()));
                    districtVO.setText(area.getName());
                    districtVO.setValue(Long.valueOf(area.getCode()));
                    areaVOList.add(districtVO);
                }
            }
            cityVO.setChildren(areaVOList);
			List<CityVO> cities = new ArrayList<CityVO>();
			cities.add(cityVO);
			provinceVO.setChildren(cities);
		}else{
			return null;
		}
		return provinceVO;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.AreaService#getProvinceByPromotionId(java.lang.Long)
	 */
	@Override
	public List<ProvinceVO> getProvinceByPromotionId(Long promotionId) {
		List<ProvinceVO> results = new ArrayList<ProvinceVO>();
		//TBD waiting for interfaces
		List<Long> cityIdLists = new ArrayList<Long>();
		for(Long cityId : cityIdLists){
			results.add(getProvinceByCityId(cityId));
		}
		return results;
	}

	@Override
	public List<ProvinceVO> getProvinceByPromotionIdAndVichealModelId(
			Long promotionId, Long vichealModelId) {
		return null;
	}

	@Override
	public abstract List<ProvinceVO> getProvinceByMarkeyType(Integer marketType);

}
