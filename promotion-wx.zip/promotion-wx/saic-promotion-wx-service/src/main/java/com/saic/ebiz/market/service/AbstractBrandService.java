/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.framework.web.freemarker.MultiDomUrl;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.carlib.service.client.BrandClient;
import com.saic.ebiz.carlib.service.client.VelColorClient;
import com.saic.ebiz.carlib.service.client.VelModelInfoClient;
import com.saic.ebiz.carlib.service.client.VelSeriesClient;
import com.saic.ebiz.carlib.service.entity.VelBrand;
import com.saic.ebiz.carlib.service.entity.VelColor;
import com.saic.ebiz.carlib.service.entity.VelModel;
import com.saic.ebiz.carlib.service.entity.VelModelColorExt;
import com.saic.ebiz.carlib.service.entity.VelSeries;
import com.saic.ebiz.market.entity.BrandVO;
import com.saic.ebiz.market.entity.ColorImageVO;
import com.saic.ebiz.market.entity.SeriesVO;
import com.saic.ebiz.market.entity.VehicleModelVO;
import com.saic.ebiz.market.service.BrandService;

import freemarker.template.TemplateModelException;

/**
 * @author hejian
 * 
 */
public abstract class AbstractBrandService implements BrandService {
	private Logger log = LoggerFactory.getLogger(getClass());

	/** The multiple domain image url . */
	@Resource
	protected MultiDomUrl fmImgUrl;
	/**
	 * 品牌客户端
	 */
	@Resource
	protected BrandClient brandClient;

	/**
	 * 车系客户端
	 */
	@Resource
	protected VelSeriesClient seriesClient;

	/**
	 * 车型客户端
	 */
	@Resource
	protected VelModelInfoClient velModelInfoClient;

	/**
	 * 车型颜色的图片
	 */
	@Autowired
	protected VelColorClient velColorClient;

	@Override
	public List<BrandVO> getAllBrands() {
		Map<Long, VelBrand> brands = this.brandClient.findAllBrands();
		List<BrandVO> brandVOList = new ArrayList<BrandVO>();
		Collection<VelBrand> values = brands.values();
		for(VelBrand brand : values){
			brandVOList.add(findBrandById(brand.getVelBrandId()));
		}
		return brandVOList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.saic.ebiz.market.service.BrandService#getBrandsByPromotionId(java
	 * .lang.Long)
	 */
	@Override
	public List<BrandVO> getBrandsByPromotionId(Long promotionId) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.saic.ebiz.market.service.BrandService#getBrandsByPromotionIdAndCityId
	 * (java.lang.Long, java.lang.Long)
	 */
	@Override
	public List<BrandVO> getBrandsByPromotionIdAndCityId(Long promotionId,
			Long cityId) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.saic.ebiz.market.service.BrandService#
	 * getBrandsByPromotionIdAndCityIdAndModelId(java.lang.Long, java.lang.Long,
	 * java.lang.Long)
	 */
	@Override
	public BrandVO getBrandsByPromotionIdAndCityIdAndModelId(
			Long promotionId, Long cityId, Long modelId) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 
	 * @param brandId 品牌id
	 * @return 品牌对象
	 */
	@Override
	public BrandVO findBrandById(Long brandId) {
		VelBrand brand = this.brandClient.findBrandById(brandId);
		BrandVO brandVO = new BrandVO();
		//品牌id
		brandVO.setId(brand.getVelBrandId());
		//品牌名称
		brandVO.setName(brand.getVelBrandChsName());
		//TBD need confirmation
		brandVO.setDefaultImage();
		//获取该品牌下所有的车系
		Map<Long, VelSeries> series = seriesClient.findSeriesByBrandId(brandId);
		List<SeriesVO> children = new ArrayList<SeriesVO>();
		Collection<VelSeries> values = series.values();
		for(VelSeries serie : values){
			children.add(getSeriesVOByVelSeries(serie));
		}
		brandVO.setSeries(children);
		return brandVO;
	}

	/**
	 * 通过车系获取SeriesVO
	 * @param seriesId 车系id
	 * @return
	 */
	public SeriesVO findSeriesById(Long seriesId) {
		return getSeriesVOByVelSeries(this.seriesClient.findSeriesById(seriesId));
	}
	
	/**
	 * 通过VelSeries对象构建SeriesVO
	 * @param series
	 * @return
	 */
	private SeriesVO getSeriesVOByVelSeries(VelSeries series){
		SeriesVO seriesVO = new SeriesVO();
		//车系id
		seriesVO.setId(series.getVelSeriesId());
		//车系名称
		seriesVO.setName(series.getVelSeriesChsName());
		//TBD 获取该品牌下所有的车型
		//TBD 颜色id列表
		Set<Long> colorIdSet ;
		Map<Long, VelModel> map = seriesClient.findVelModelsBySeriesId(series.getVelSeriesId());
		Collection<VelModel> values = map.values();
		List<VehicleModelVO> children = new ArrayList<VehicleModelVO>();
		for(VelModel model : values){
			VehicleModelVO modelVO = getVehicleModelVOByVelModel(model);
			colorIdSet = new BrandMock().mockColorSet(model.getVelModelId());
			Iterator<Long> it = colorIdSet.iterator();
			while(it.hasNext()){
				modelVO.getColors().add(getVelColorImage(getVelColorByColorId(it.next())));
			}
			children.add(modelVO);
		}
//		seriesVO.setVehicleModels(children);
		return seriesVO;
	}
	
	public VehicleModelVO getVehicleModelVOByVelModelId(Long modelId){
		return getVehicleModelVOByVelModel(this.velModelInfoClient.findVelModelById(modelId));
	}
	
	/**
	 * 通过VelModel交换VehicleModelVO
	 * @param model 车型模型
	 * @return
	 */
	private VehicleModelVO getVehicleModelVOByVelModel(VelModel model){
		log.info("VelModel : " + JSONObject.toJSONString(model));
		VehicleModelVO modelVO = new VehicleModelVO();
		modelVO.setId(model.getVelModelId());
		modelVO.setName(model.getVelModelService());
		modelVO.setSeriesId(model.getVelSeriesId());
		return modelVO;
	}
	
	/**
	 * 一般我们会根据车型(查询数据库)获取颜色列表，
	 * 逐一遍历获取对应VelColor对象。
	 * @param colorId 颜色id
	 * @return
	 */
	private VelColor getVelColorByColorId(Long colorId){
		return velColorClient.findColorByColorId(colorId);
	}
	
	private ColorImageVO getVelColorImage(VelColor velColor){
		log.info("VelColor : " + JSONObject.toJSONString(velColor));
		ColorImageVO colorImageVO = new ColorImageVO();
		if(velColor == null)
			return null;
		colorImageVO.setId(velColor.getVelColorId());
		colorImageVO.setName(velColor.getVelColorChsName());
		colorImageVO.setImageId(velColor.getColorImgId());
		colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
		log.info("ColorImageVO : " + JSONObject.toJSONString(colorImageVO));
		return colorImageVO;
	}
	
	/**
	 * 本地工具类: 功能描述: 设置图片路径<br>
	 * 
	 * @param velColorImgPath
	 * @return
	 * @throws TemplateModelException
	 */
	private String addPath(String velColorImgPath) {
		List<String> args = new ArrayList<String>();
		args.add("/26x12" + velColorImgPath);
		String result = "";
		try {
			result = String.valueOf(fmImgUrl.exec(args));
		} catch (TemplateModelException e) {
			log.error("图片路径设置失败");
		}
		return result;
	}


	public VelModelColorExt findModelById(Long vehicleModelId) {
		return this.velModelInfoClient.findModelWithColorById(vehicleModelId);
	}
	
	private class BrandMock {
		private Set<Long> mockColorSet(Long vehicleModelId){
			Set<Long> colorIdSet = new HashSet<Long>();
			//1180012  2014款 Cross POLO 手动
			//冰炫金 6882 风格红 6883 劲酷黑 6884 魅光蓝 6885 锐利银 6886
//			colorIdSet.add(6882L);
//			colorIdSet.add(6883L);
//			colorIdSet.add(6884L);
//			colorIdSet.add(6885L);
//			colorIdSet.add(6886L);

			colorIdSet.add(176L);
			colorIdSet.add(177L);
			colorIdSet.add(178L);
			colorIdSet.add(179L);
			colorIdSet.add(180L);
			colorIdSet.add(181L);
			return colorIdSet;
		}
	}

}
