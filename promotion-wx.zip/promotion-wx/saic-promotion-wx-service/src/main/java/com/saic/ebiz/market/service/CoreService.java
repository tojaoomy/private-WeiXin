/**
 *
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName : CoreService.java
 * Author : 何剑
 * Date : 2014年9月21日
 * 
 */
package com.saic.ebiz.market.service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ibm.framework.uts.util.StringUtils;
import com.meidusa.fastjson.JSONObject;
import com.meidusa.toolkit.common.util.Base64;
import com.saic.ebiz.freemarker.MultiDomUrlForDynamicImages;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.entity.response.Article;
import com.saic.ebiz.market.common.entity.response.NewsMessageReponse;
import com.saic.ebiz.market.common.entity.response.TextMessageReponse;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.enumeration.MessageType;
import com.saic.ebiz.market.common.util.ImageUtil;
import com.saic.ebiz.market.common.util.MessageUtil;
import com.saic.ebiz.market.common.util.MyOpenIdTokenUtil;
import com.saic.ebiz.market.common.util.WXLoggerMutator;
import com.saic.ebiz.market.event.handler.EventClickHandler;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.ebiz.promotion.service.api.IWxService;
import com.saic.ebiz.promotion.service.entity.WxOperLogEntity;
import com.saike.osier.solrClient.QuestionOnlineSolrService;
import com.saike.osier.solrClient.vo.QuestionNumFoundSolrVO;
import com.saike.osier.solrClient.vo.QuestionSolrVO;

/**
 * @author hejian
 * @date 2014年9月21日
 */
@Component
public class CoreService {
	// 日志
	private Logger logger = LoggerFactory.getLogger(CoreService.class);

	@Value("${ebiz.wap.web.domain:}")
	private String domain;

	@Autowired
	private EventClickHandler handler;

	@Autowired
	private WebAccountInfoService webAccountInfoService;
	
	@Autowired
	private MyOpenIdTokenUtil myOpenIdTokenUtil;
	
	@Resource
	private AuthorizationService authorizationService;
	
	@Resource
	private ImageUtil imageUtil;
	
	@Autowired
	private MultiDomUrlForDynamicImages dynamicImages;

	/** 游戏情景二维码7  */
	private static final String GAME_ID = "7";
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@Resource
	private IWxService iWxService;
	
	@Autowired
	private QuestionOnlineSolrService solrService;
	
	/**
	 * 
	 * @Title:处理微信发来的请求
	 * @param request
	 * @return
	 */
	public String processRequest(HttpServletRequest request,
			Map<String, String> requestMap) {
		// xml模板内容
		String respMessage = null;
		String respContent = "";
		TextMessageReponse textMessage = new TextMessageReponse();
		try {
			// xml请求解析
			// Map<String, String> requestMap = MessageUtil.parseXml(request);

			// 发送方帐号（open_id）
			String fromUserName = requestMap.get(Constants.FROM_USER_NAME);
			// 公众帐号
			String toUserName = requestMap.get(Constants.TO_USER_NAME);
			// 消息类型
			String msgType = requestMap.get(Constants.MSG_TYPE);

			logger.info(
					"接受请求  { 发送方账号 fromUserName(openId) : {}, 公众帐号 toUserName : {},消息类型 msgType : {} }",
					fromUserName, toUserName, msgType);

			// 回复文本消息
			textMessage.setToUserName(fromUserName);
			textMessage.setFromUserName(toUserName);
			textMessage.setCreateTime(new Date().getTime());
			textMessage.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_TEXT);
			
			WxOperLogEntity enLogEntity = new WxOperLogEntity();
			//微信公众号id
			enLogEntity.setOfficialAccount(toUserName);
			enLogEntity.setOpenId(fromUserName);
			enLogEntity.setMsgType(msgType);
			enLogEntity.setCreateTime(new Date());

			// 文本消息
			if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_TEXT)) {
			    //获取当前用户的openId
                Object obj = requestMap.get("Content");
                WXLoggerMutator.logContentMessage(enLogEntity, requestMap);
                if(obj != null){
                    String content = (String)obj;
                    if("#获取openid#".equals(content)){
                        respContent = fromUserName;
                    }else if(content.length() > 2 && content.startsWith("#") && content.endsWith("#")){
                    	if(content.equals("#2014年3月28日#") || content.equals("#15000辆#") || content.equals("#60万#")){
                    		respContent = "答案正确";
                    	}else{
                    		respContent = "答案错误";
                    	}
                    }else if(content.contains("一路到家")){
                        respContent = "感谢您预约车享\"一路到家\"送车服务！我们 工作人员将会在72小时内将与您取得联系，敬请留意！";
                    }else if(content.trim().equals("1")){
                        respContent = "<a href='http://m.car.chexiang.com/'>车享新车</a>";
                    }else if(content.trim().equals("2")){
                        respContent = "<a href='http://car.chexiang.com/promotion/index.htm'>每周特价车</a>";
                    }else {
                    	QuestionNumFoundSolrVO searchResult = solrService.search(content, 0, 9,false);
                    	if(searchResult == null || searchResult.getNumFound() == 0){
                    		respContent = "哈，难倒我了，我问问车知道将48小时内回复。";
                    	}else{
                    		NewsMessageReponse response = new NewsMessageReponse();
        					response.setCreateTime(new Date().getTime());
        					response.setFromUserName(toUserName);
        					response.setToUserName(fromUserName);
        					response.setMsgType(MessageType.NEWS.code());
        					List<QuestionSolrVO> list = searchResult.getQuestionVO();
        					List<Article> articles = new ArrayList<Article>();
        					if(list != null && !list.isEmpty()){
        						for(int i=0; i < list.size(); i++){
        							QuestionSolrVO q = list.get(i);
        							Article article = new Article();
        							article.setTitle(q.getTitle());
        							article.setDescription(q.getTitle());
        							if(i == 0){
        								article.setPicurl(dynamicImages.exec(Arrays.asList("images/club/news_message_title_pic.jpg")).toString());
        							}else{
        								article.setPicurl(dynamicImages.exec(Arrays.asList("images/club/news_message_slide_pic.jpg")).toString());
        							}
        							article.setUrl(domain + "club/detail.htm?questionId=" + q.getId());
        							articles.add(article);
        						}
        					}
        					//最后一条信息给用户提问
        					Article article = new Article();
							article.setTitle("没有我想要的，帮我解决");
							article.setDescription("没有我想要的，帮我解决");
							article.setPicurl(dynamicImages.exec(Arrays.asList("images/club/ask_question.jpg")).toString());
							article.setUrl(domain + "club/help.htm?content=" + Base64.encode(content.getBytes()) + "&openid=" + fromUserName);
							articles.add(article);
        					
        					response.setArticles(articles);
        					response.setArticleCount(articles.size());
        					return MessageUtil.messageToXml(response);
                    	}
                    }
                }else{
                    respContent = "您发送的是文本消息";
                }
			}
			// 图片消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_IMAGE)) {
				respContent = "您发送的是图片消息！";
				WXLoggerMutator.logImageMessage(enLogEntity, requestMap);
			}
			// 地理位置消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_LOCATION)) {
				 respContent = "您发送的是地理位置消息！";
				 WXLoggerMutator.logLocationMessage(enLogEntity, requestMap);
			}
			// 链接消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_LINK)) {
				respContent = "您发送的是链接消息！";
				WXLoggerMutator.logLinkMessage(enLogEntity, requestMap);
			}
			// 音频消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_VOICE)) {
				respContent = "您发送的是音频消息！";
				WXLoggerMutator.logVoiceMessage(enLogEntity, requestMap);
			}
			// 视频消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_VIDEO)) {
				respContent = "您发送的是视频消息！";
				WXLoggerMutator.logVideoMessage(enLogEntity, requestMap);
			}
			// 事件推送
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_EVENT)) {
				// 事件类型
				String eventType = requestMap
						.get(Constants.REQUEST_PARAMETER_EVENT);
				// 订阅
				if (eventType.equals(MessageUtil.EVENT_TYPE_SUBSCRIBE)) {
					WXLoggerMutator.logEventSubscribe(enLogEntity, requestMap);
					logger.info("记录关注的记录信息" + JSONObject.toJSONString(enLogEntity));
//					iWxService.createOperLog(enLogEntity);
					respContent = "您好，欢迎关注车享新车服务号。回复1查看车享新车，回复2查看周周特价车最新活动车型。如有任何疑问可输入您的问题，并以“？”结尾。";
				}
				// 取消订阅
				else if (eventType.equals(MessageUtil.EVENT_TYPE_UNSUBSCRIBE)) {
					// 取消订阅后用户再收不到公众号发送的消息，因此不需要回复消息
					List<WebAccountVO> webAccountVOList = handler
							.checkBounding(fromUserName);
					for (WebAccountVO webAccountVO : webAccountVOList) {
						logger.info("删除webAccountId : "
								+ webAccountVO.getWebAccountId());
						webAccountInfoService.deleteWebAccount(webAccountVO
								.getWebAccountId());
					}
					logger.info("openid : {} 取消关注 ", fromUserName);
					WXLoggerMutator.logEventUnsubscribe(enLogEntity, requestMap);
				}
				// 自定义菜单点击事件
				else if (eventType.equals(MessageUtil.EVENT_TYPE_SCAN)) {
					logger.info("扫描事件");
					WXLoggerMutator.logEventScan(enLogEntity, requestMap);
					//情景二维码扫描
					//免费送车
					String eventKey = requestMap.get("EventKey");
					logger.info("eventKey : " + eventKey);
					logger.info("StringUtils.hasText(eventKey) : {}, GAME_ID.equals(sourceId) : {}",StringUtils.hasText(eventKey),GAME_ID.equals(eventKey));
					if(StringUtils.hasText(eventKey)){
						String sourceId = eventKey;
						//是否是数字类型
						if(!NumberUtils.isNumber(eventKey)){
							sourceId = eventKey.substring(eventKey.lastIndexOf("_") + 1);
						}
						logger.info("sourceId : " + sourceId);
						if(GAME_ID.equals(sourceId)){
							NewsMessageReponse response = new NewsMessageReponse();
							response.setCreateTime(new Date().getTime());
							response.setFromUserName(toUserName);
							response.setToUserName(fromUserName);
							response.setMsgType(MessageType.NEWS.code());
							List<Article> articles = new ArrayList<Article>();
							Article article = new Article();
							article.setTitle("买车享半价，拼了就知道！");
							article.setDescription("触手可及的半价车,有哪些品牌,你造吗?有哪些车型你造吗？快来一拼究竟");
							article.setPicurl(imageUtil.getImageUrl("xiuqiu_328/game.png"));
							String redirect_uri = domain + "/oauth/sns.htm";
							String url = authorizationService.buildAuthorizationLink(appId, redirect_uri, Scope.snsapi_userinfo);
							url = url.replace("STATE", Authorization.moucheng_.name());
							article.setUrl(url);
							articles.add(article);
							response.setArticles(articles);
							response.setArticleCount(articles.size());
							iWxService.createOperLog(enLogEntity);
							return MessageUtil.messageToXml(response);
						}
					}
				} else if (eventType.equals(MessageUtil.EVENT_TYPE_LOCATION)) {
					logger.info("地理事件");
//					WXLoggerMutator.logEventLocation(enLogEntity, requestMap);
				} else if (eventType.equals(MessageUtil.EVENT_TYPE_CLICK)) {
					WXLoggerMutator.logEventClick(enLogEntity, requestMap);
					iWxService.createOperLog(enLogEntity);
					return handler.handler(requestMap, request);
				} else if (eventType.equals(MessageUtil.EVENT_TYPE_VIEW)) {
					logger.info("点击菜单点击事件");
					//视图菜单点击事件去响应登录页面不可行，所以这个事件的逻辑处理不需要。
			    	/*//判断是否绑定
			    	boolean isBounding = handler.checkResultBounding(requestMap.get(Constants.FROM_USER_NAME));
			    	logger.info("when click view isBounding : " + isBounding);
			    	//返回微信用户的文本内容信息
			        String uuid = getToken(requestMap.get(Constants.FROM_USER_NAME), requestMap.get(Constants.TO_USER_NAME));
			        if(!isBounding){
			        	respContent =  PropertiesUtil.TEMPLATE.replace("URL_PLACEHOLDER", (PropertiesUtil.LOGIN_URL + uuid));
			        	logger.info("询价查询返回内容信息 : " + respContent);
			        	textMessage.setContent(respContent);
			        	return MessageUtil.messageToXml(textMessage);
			        }*/
					WXLoggerMutator.logEventView(enLogEntity, requestMap);
				}
			}
			logger.info("微信日志统计 : " + JSONObject.toJSONString(enLogEntity));
			iWxService.createOperLog(enLogEntity);
		} catch (Exception e) {
			logger.error("---消息回复异常--：" + e.getMessage());
//			respContent = e.getMessage();
		}
		logger.info("textMessage.setContent(respContent)  : " + respContent);
		textMessage.setContent(respContent);
		respMessage = MessageUtil.messageToXml(textMessage);
		return respMessage;
	}
	
	/*private String getToken(String fromUserName,String toUserName){
   	 String uuid = "";
        try {
            uuid = myOpenIdTokenUtil.setOpenIdToken(fromUserName, toUserName);
        } catch (Exception e) {
            e.printStackTrace();
            uuid = "error:获取token失败";
            logger.error("获取token值失败 : " + e.getMessage());
        }
        return uuid;
   }*/

	/**
	 * emoji表情转换(hex -> utf-16)
	 * 
	 * @param hexEmoji
	 * @return
	 */
	public static String emoji(int hexEmoji) {
		return String.valueOf(Character.toChars(hexEmoji));
	}
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		String content = Base64.encode("328活动，还有呢？".getBytes());
		content = URLEncoder.encode(content,"UTF-8");
		System.out.println(content);
		content = "MzI45rS75Yqo77yM6L+Y5pyJ5ZGi77yf";
		content = URLDecoder.decode(content,"UTF-8");
		System.out.println(content);
//		System.out.println(new String(Base64.decode(content)));
	}
}

