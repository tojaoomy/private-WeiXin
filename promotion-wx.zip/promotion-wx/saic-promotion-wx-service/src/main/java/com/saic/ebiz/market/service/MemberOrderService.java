package com.saic.ebiz.market.service;

/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: MemberOrderService.java
 * Author:   v_zhuozegang01
 * Date:     2013年12月12日 上午10:37:11
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
import java.util.List;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.saic.ebiz.market.constant.MemberCentInfoVO;
import com.saic.ebiz.market.constant.PreOrderQueryBean;

/**
 * 〈一句话功能简述〉我的订单<br>
 * 〈功能详细描述〉.
 * 
 * @author v_zhuozegang01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface MemberOrderService {

    /**
     * 功能描述: 查询我的订单下所有的订单信息<br>
     * 〈功能详细描述〉.
     * 
     * @param map 业务参数
     * @param page the page
     * @return 订单信息集合
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public PaginationResult<List<PreOrderQueryBean>> queryAllOrderByParmes(Long userId ,Pagination page);
    
    
    /**
     * 功能描述:根据订单id查询订单贷款信息 <br>
     * 〈功能详细描述〉.
     * 
     * @param orderId 订单id
     * @return 订单bean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public PreOrderQueryBean queryOrderDetailByEDai(String orderId);
    
    /**
     * 功能描述:根据会员id和订单id查询订单明细 <br>
     * 〈功能详细描述〉.
     * 
     * @param orderId 订单id
     * @param userId 会员id
     * @return 订单bean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public PreOrderQueryBean queryOrderDetailByParmes(String orderId,long userId);
    
    /**
     * 功能描述: 根据会员id获取会员的基本信息.<br>
     * 〈功能详细描述〉
     * 
     * @param userId 会员id
     * @return MemberCentInfoVO
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public MemberCentInfoVO queryUserBeanByUserId(long userId);
    /**
     * 功能描述:查询车主订单认证状态 <br>
     * 〈功能详细描述.
     * 
     * @author yzq
     * @param orderList 用户下所有的订单
     * @param userId 用户ID
     * @return 用户下挂接认证状态的订单
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public List<PreOrderQueryBean> queryApplPreOrder(List<PreOrderQueryBean> orderList, Long userId);
    
}
