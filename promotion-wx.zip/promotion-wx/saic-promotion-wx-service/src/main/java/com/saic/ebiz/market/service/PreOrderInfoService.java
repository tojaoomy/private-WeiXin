package com.saic.ebiz.market.service;

import java.util.List;

import com.saic.ebiz.order.entity.AreaBean;
import com.saic.ebiz.order.service.entity.PreOrder;
import com.saic.ebiz.order.service.exception.PreOrderQuotaLackException;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionSubscription;

public interface PreOrderInfoService {
	/**
     * 订单生成.
     * 
     * @param preOrder the pre order
     * @param subscriptionId the subscription id
     * @return the string
     * @throws PreOrderQuotaLackException the pre order quota lack exception
     */
    public String createPreOrder(PreOrder preOrder,long subscriptionId,Long promotionId) throws PreOrderQuotaLackException ;
    
    /**
     * 功能描述:根据城市id得到区域list. <br>
     * 
     * @param cityId the city id
     * @return list
     */
    public List<AreaBean> selectAreaByCity(Long cityId);
    
    /**
     * 功能描述: 功能描述:订单创建完成，回调子站接口 //参数：userId,subscritionId,orderId;.
     * 
     * @param userId 用户id
     * @param subscriptionId 活动报名id
     * @param orderId 订单id
     */
    public void createFollowOrder(long userId, long subscriptionId, String orderId,long prmtMdseId);
    /**
     * 
     * 功能描述: <br>
     * 〈功能详细描述〉得到报名信息：手机号和权益
     *.
     * @param subscriptionId
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public PromotionSubscription getPromotionSubscription(Long subscriptionId);
    
    
    public  Promotion getPromotion(long promotionId);
}
