package com.saic.ebiz.market.service;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.saic.ebiz.mdm.api.WebAccountService;
import com.saic.ebiz.mdm.entity.WebAccountVO;

/**
 * Copyright (C), 2014-1-10, 上汽电商有限公司 基盘用户验证
 * 
 * @version 1.0
 * @date 2014-7-1
 */
@Component
public class WebAccountInfoClient {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private WebAccountService webAccountService;

	/**
	 * 根据OPEN_ID查询信息
	 * @param webAccountVO
	 * @return
	 */
	public List<WebAccountVO> findWebAccountByCondition(WebAccountVO webAccountVO) {
		return webAccountService.findWebAccountByCondition(webAccountVO);
	}
	
	/**
	 * 删除用户绑定
	 * @param webAccountVO
	 * @return
	 */
	public int deleteWebAccount(long webAccountId) {
		try {
			webAccountService.deleteWebAccount(webAccountId);
			logger.info("逻辑删除WebAccount {} 成功 ！！！" , webAccountId);
			return 1;
		} catch (Exception e) {
			logger.error("逻辑删除WebAccount {} 失败 ！！！" , webAccountId);
			return -1;
		}
		
	}
	
	

}
