package com.saic.ebiz.market.service;

import java.util.List;

import com.saic.ebiz.mdm.entity.WebAccountVO;


/**
 * Copyright (C), 2014-04-30, 上汽电商有限公司 基盘客户接口
 * 
 * @version 1.0
 * @date 2014-04-30
 */
public interface WebAccountInfoService {
	
	/**
	 * 查询微信用户是否已绑定
	 * @param webAccountVO
	 * @return
	 */
	public List<WebAccountVO> findWebAccountByCondition(WebAccountVO webAccountVO);
	
	
	/**
	 * 查询微信用户是否已绑定
	 * @param webAccountId 
	 * @return
	 */
	public int deleteWebAccount(long webAccountId);
}
