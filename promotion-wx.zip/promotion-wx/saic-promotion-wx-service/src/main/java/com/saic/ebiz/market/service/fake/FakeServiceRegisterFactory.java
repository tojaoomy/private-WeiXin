/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.fake;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * @author hejian
 *
 */
public class FakeServiceRegisterFactory implements BeanFactoryAware,ApplicationContextAware,InitializingBean,BeanDefinitionRegistryPostProcessor,BeanFactoryPostProcessor,BeanPostProcessor {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
//	private AbstractApplicationContext context;
	
	private String[] fakeClazzes;
	
	/**
	 * @return the fakeClazzes
	 */
	public String[] getFakeClazzes() {
		return fakeClazzes;
	}

	/**
	 * @param fakeClazzes the fakeClazzes to set
	 */
	public void setFakeClazzes(String[] fakeClazzes) {
		if(fakeClazzes != null)
		this.fakeClazzes = Arrays.copyOf(fakeClazzes, fakeClazzes.length);
	}

	private BeanFactory beanFactory;
	
	private Map<Class<?>,Object> fackeBeanMap = new ConcurrentHashMap<Class<?>,Object>();

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		if(beanFactory instanceof AutowireCapableBeanFactory){
//			AutowireCapableBeanFactory factory = (AutowireCapableBeanFactory)beanFactory;
			for(String clazz : fakeClazzes){
				logger.info("需要mock的服务className : " + clazz);
				//获取接口的名称
				Class<?> clz = Class.forName(clazz);
				Class<?> interfaceClass = clz.getInterfaces()[0];
				logger.info("获取真实mock的类名 : " + interfaceClass.getCanonicalName());
//				Object obj = factory.autowire(clz, AutowireCapableBeanFactory.AUTOWIRE_BY_NAME, false);
				Object obj = new RootBeanDefinition(clz);
				/*Object object = null;
				try {
					object = beanFactory.getBean(interfaceClass);
				} catch (Exception e) {
					e.printStackTrace();
				}
				if(obj != null){
					System.out.println(clazz + "对象不为空");
					factory.destroyBean(object);
					System.out.println(clazz + "对象删除成功");
				}else{
					obj = factory.getBean(firstLetterToLowerCase(interfaceClass.getSimpleName()));
					if(obj != null){
						System.out.println(firstLetterToLowerCase(interfaceClass.getSimpleName()) + "对象不为空");
						factory.destroyBean(object);
						System.out.println(firstLetterToLowerCase(interfaceClass.getSimpleName()) + "对象删除成功");
					}
				}*/
				fackeBeanMap.put(interfaceClass, obj);
			}
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.BeanFactoryAware#setBeanFactory(org.springframework.beans.factory.BeanFactory)
	 */
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.BeanFactoryPostProcessor#postProcessBeanFactory(org.springframework.beans.factory.config.ConfigurableListableBeanFactory)
	 */
	@Override
	public void postProcessBeanFactory(
			ConfigurableListableBeanFactory beanFactory) throws BeansException {
		/*Iterator<Entry<Class<?>,Object>> it = fackeBeanMap.entrySet().iterator();
		while(it.hasNext()){
			Entry<Class<?>,Object> entry = it.next();
			Class<?> clazz = entry.getKey();
			System.out.println("remove bean name : " + firstLetterToLowerCase(clazz.getSimpleName()));
			registry.removeBeanDefinition(firstLetterToLowerCase(clazz.getSimpleName()));
			fa.removeBeanDefinition(firstLetterToLowerCase(clazz.getSimpleName()));
			String beanName = firstLetterToLowerCase(clazz.getSimpleName());
			registry.registerBeanDefinition(beanName, (BeanDefinition)entry.getValue());
			fa.registerSingleton(beanName, entry.getValue());
		}*/
	}
	
	public static String firstLetterToLowerCase(String str){
		if(str == null || str.length() == 0){
			return str;
		}
		return str.substring(0,1).toLowerCase() + str.substring(1);
	}

	public static void main(String[] args) {
		System.out.println(firstLetterToLowerCase(null));
		System.out.println(firstLetterToLowerCase(""));
		System.out.println(firstLetterToLowerCase("aabbCCCC"));
		System.out.println(firstLetterToLowerCase("IGlobalService"));
		System.out.println("MockIGlobalService".replace("Mock", ""));
		System.out.println(Long.class.getName());
		System.out.println(Long.class.getSimpleName());
	}

	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
//		this.context = (AbstractApplicationContext) applicationContext;
//		AutowireCapableBeanFactory beanFactory = context.getAutowireCapableBeanFactory();
		
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor#postProcessBeanDefinitionRegistry(org.springframework.beans.factory.support.BeanDefinitionRegistry)
	 */
	@Override
	public void postProcessBeanDefinitionRegistry(
			BeanDefinitionRegistry registry) throws BeansException {
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessBeforeInitialization(java.lang.Object, java.lang.String)
	 */
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessAfterInitialization(java.lang.Object, java.lang.String)
	 */
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		return null;
	}
}
