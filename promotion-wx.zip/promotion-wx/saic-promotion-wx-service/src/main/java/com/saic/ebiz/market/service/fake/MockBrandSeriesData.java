///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import com.meidusa.fastjson.JSONObject;
//import com.saic.ebiz.market.entity.BrandVO;
//import com.saic.ebiz.market.entity.SeriesVO;
//
///**
// * @author hejian
// *
// */
//public abstract class MockBrandSeriesData {
//	
//	private static List<BrandVO> brandData = new ArrayList<BrandVO>();
//	
//	private static List<SeriesVO> seriesData = new ArrayList<SeriesVO>();
//	
//	public static Map<Long,List<SeriesVO>> brandMap = new HashMap<Long,List<SeriesVO>>();
//	
//	static{
//		buildBrandData();
//		buildSeriesData();
//	}
//	
//	private static void buildBrandData(){
//		BrandVO brand = new BrandVO();
//		brand.setId(1L);
//		brand.setName("大众");
//		brand.setDefaultImage();
//		brandData.add(brand);
//		brandMap.put(brand.getId(), new ArrayList<SeriesVO>());
//		
//		brand = new BrandVO();
//		brand.setId(2L);
//		brand.setName("斯柯达");
//		brand.setDefaultImage();
//		brandData.add(brand);
//		brandMap.put(brand.getId(), new ArrayList<SeriesVO>());
//	}
//	
//	private static void buildSeriesData(){
//		//大众
//		SeriesVO seriesVO = new SeriesVO();
//		seriesVO.setBrandId(1L);
//		seriesVO.setId(16L);
//		seriesVO.setName("Cross Polo");
//		brandMap.get(seriesVO.getBrandId()).add(seriesVO);
//		seriesData.add(seriesVO);
//		
//		seriesVO = new SeriesVO();
//		seriesVO.setBrandId(1L);
//		seriesVO.setId(17L);
//		seriesVO.setName("Polo GTI");
//		brandMap.get(seriesVO.getBrandId()).add(seriesVO);
//		seriesData.add(seriesVO);
//		
//		seriesVO = new SeriesVO();
//		seriesVO.setBrandId(1L);
//		seriesVO.setId(18L);
//		seriesVO.setName("朗行");
//		brandMap.get(seriesVO.getBrandId()).add(seriesVO);
//		seriesData.add(seriesVO);
//		
//		seriesVO = new SeriesVO();
//		seriesVO.setBrandId(2L);
//		seriesVO.setId(70L);
//		seriesVO.setName("昕动");
//		brandMap.get(seriesVO.getBrandId()).add(seriesVO);
//		seriesData.add(seriesVO);
//		
//		seriesVO = new SeriesVO();
//		seriesVO.setBrandId(2L);
//		seriesVO.setId(64L);
//		seriesVO.setName("昊锐");
//		brandMap.get(seriesVO.getBrandId()).add(seriesVO);
//		seriesData.add(seriesVO);
//		
//		seriesVO = new SeriesVO();
//		seriesVO.setBrandId(2L);
//		seriesVO.setId(25L);
//		seriesVO.setName("明锐");
//		brandMap.get(seriesVO.getBrandId()).add(seriesVO);
//		seriesData.add(seriesVO);
//	}
//	
//	public static List<BrandVO> getBrandData(){
//		return brandData;
//	}
//	
//	public static List<SeriesVO> getSeriesData(){
//		return seriesData;
//	}
//	
//	public static List<SeriesVO> getByBrandId(Long brandId){
//		return brandMap.get(brandId);
//	}
//	
//	public static void main(String[] args) {
//		System.out.println(JSONObject.toJSONString(getBrandData()));
//		System.out.println(JSONObject.toJSONString(getSeriesData()));
//		System.out.println(JSONObject.toJSONString(getByBrandId(1L)));
//		System.out.println(JSONObject.toJSONString(getByBrandId(2L)));
//	}
//	
//}
