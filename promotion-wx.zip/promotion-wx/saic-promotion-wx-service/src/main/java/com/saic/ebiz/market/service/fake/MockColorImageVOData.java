///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.atomic.AtomicLong;
//
//import com.meidusa.fastjson.JSONObject;
//import com.saic.ebiz.market.entity.ColorImageVO;
//
///**
// * @author hejian
// *
// */
//public abstract class MockColorImageVOData {
//	private static final List<ColorImageVO> data = new ArrayList<ColorImageVO>();
//	
//	private static final AtomicLong id = new AtomicLong(0);
//	
//	private static Map<Long,String> colorMap = new HashMap<Long,String>();
//	
//	private static Map<Long,ColorImageVO> dataMap = new HashMap<Long,ColorImageVO>();
//	
//	static{
//		colorMap.put(1L, "蓝色");
//		colorMap.put(2L, "红色");
//		colorMap.put(3L, "黄色");
//		colorMap.put(4L, "宝绿色");
//		buildData();
//	}
//	
//	private static void buildData(){
//		for(int i=1;i<5;i++){
//			ColorImageVO colorImageVO = new ColorImageVO();
//			colorImageVO.setId(id.incrementAndGet());
//			colorImageVO.setImageId(id.get());
//			colorImageVO.setImageUrl("colors/" + id.get() + ".png");
//			colorImageVO.setName(colorMap.get(id.get()));
//			data.add(colorImageVO);
//			dataMap.put(id.get(), colorImageVO);
//		}
//	}
//	
//	public static void add(ColorImageVO colorImageVO){
//		data.add(colorImageVO);
//		dataMap.put(colorImageVO.getId(), colorImageVO);
//	}
//	
//	public static ColorImageVO getDataById(Long id){
//		return dataMap.get(id);
//	}
//	
//	public static List<ColorImageVO> getAllData(){
//		return data;
//	}
//	
//	public static void main(String[] args) {
//		System.out.println(JSONObject.toJSONString(getAllData()));
//	}
//}
