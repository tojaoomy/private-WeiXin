///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.math.BigDecimal;
//
//import com.saic.ebiz.promotion.service.vo.routine.GlobalRule;
//
///**
// * @author hejian
// *
// */
//public abstract class MockGlobalRuleData {
//	private static final GlobalRule GLOBAL_RULE = new GlobalRule();
//	
//	static{
//		buildData();
//	}
//	
//	public static GlobalRule getGlobalRule(){
//		return GLOBAL_RULE;
//	}
//
//	/**
//	 * 
//	 */
//	private static void buildData() {
//		GLOBAL_RULE.setDeposit(new BigDecimal(99.99));
//		GLOBAL_RULE.setChexiangDeposit(new BigDecimal(499));
//		GLOBAL_RULE.setGlobalGift("免费洗车、代驾服务、加油优惠");
//		GLOBAL_RULE.setMaxCarNum(2);
//		GLOBAL_RULE.setMaxDealerNum(3);
//	}
//}
