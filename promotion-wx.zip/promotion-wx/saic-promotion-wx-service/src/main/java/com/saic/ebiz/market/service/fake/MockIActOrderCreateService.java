///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.util.UUID;
//
//import com.saic.ebiz.promotion.service.api.IActOrderCreateService;
//import com.saic.ebiz.promotion.service.commons.exception.IllegalActOrderUserException;
//import com.saic.ebiz.promotion.service.entity.ActOrderEntity;
//import com.saic.ebiz.promotion.service.vo.RoutineCarOrder;
//
///**
// * @author hejian
// *
// */
//public class MockIActOrderCreateService implements IActOrderCreateService {
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IActOrderCreateService#createActOrder(com.saic.ebiz.promotion.service.entity.ActOrderEntity)
//	 */
//	@Override
//	public String createActOrder(ActOrderEntity order)
//			throws IllegalActOrderUserException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IActOrderCreateService#createRoutineCarOrder(com.saic.ebiz.promotion.service.vo.RoutineCarOrder)
//	 */
//	@Override
//	public String createRoutineCarOrder(RoutineCarOrder routineCarOrder)
//			throws IllegalActOrderUserException {
//		return UUID.randomUUID().toString();
//	}
//
//}
