///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import org.springframework.stereotype.Service;
//
//import com.saic.ebiz.promotion.service.api.routine.IGlobalRuleService;
//import com.saic.ebiz.promotion.service.vo.routine.GlobalRule;
//
///**
// * @author hejian
// *
// */
//@Service
//public class MockIGlobalRuleService implements IGlobalRuleService {
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IGlobalRuleService#saveGlobalRule(com.saic.ebiz.promotion.service.vo.routine.GlobalRule)
//	 */
//	@Override
//	public void saveGlobalRule(GlobalRule globalRule) {
//		// TODO Auto-generated method stub
//
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IGlobalRuleService#findGlobalRule()
//	 */
//	@Override
//	public GlobalRule findGlobalRule() {
//		return MockGlobalRuleData.getGlobalRule();
//	}
//
//}
