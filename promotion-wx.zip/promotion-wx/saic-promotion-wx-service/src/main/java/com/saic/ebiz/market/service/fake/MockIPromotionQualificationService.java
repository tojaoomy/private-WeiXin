///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.TreeMap;
//
//import com.ibm.framework.dal.pagination.Pagination;
//import com.ibm.framework.dal.pagination.PaginationResult;
//import com.saic.ebiz.market.entity.SeriesVO;
//import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
//import com.saic.ebiz.promotion.service.commons.exception.ValidationException;
//import com.saic.ebiz.promotion.service.vo.CxgMerchandiseVO;
//import com.saic.ebiz.promotion.service.vo.PromotionQualification;
//import com.saic.ebiz.promotion.service.vo.PromotionQualificationQuery;
//import com.saic.ebiz.promotion.service.vo.PromotionStoreQuery;
//import com.saic.ebiz.promotion.service.vo.QualificationVO;
//import com.saic.ebiz.promotion.service.vo.RoutineMerchandiseVO;
//import com.saic.ebiz.promotion.service.vo.routine.StoreResult;
//
///**
// * @author hejian
// *
// */
//public class MockIPromotionQualificationService implements
//		IPromotionQualificationService {
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getPromotionQualificationByPromotionId(java.lang.Long)
//	 */
//	@Override
//	public List<PromotionQualification> getPromotionQualificationByPromotionId(
//			Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getPromotionQualificationByPromotionId(java.lang.Long, boolean)
//	 */
//	@Override
//	public List<PromotionQualification> getPromotionQualificationByPromotionId(
//			Long promotionId, boolean withNames) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getPromotionQualificationByPromotionId(java.lang.Long, boolean, java.lang.Integer)
//	 */
//	@Override
//	public List<PromotionQualification> getPromotionQualificationByPromotionId(
//			Long promotionId, boolean withNames, Integer count) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getPromotionQualificationByPromotionIds(java.util.List)
//	 */
//	@Override
//	public List<PromotionQualification> getPromotionQualificationByPromotionIds(
//			List<Long> promotionIds) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getPromotionQualification(java.lang.Long)
//	 */
//	@Override
//	public PromotionQualification getPromotionQualification(Long qualificationId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#queryPromotionQualificationList(com.saic.ebiz.promotion.service.vo.PromotionQualificationQuery, com.ibm.framework.dal.pagination.Pagination)
//	 */
//	@Override
//	public PaginationResult<List<PromotionQualification>> queryPromotionQualificationList(
//			PromotionQualificationQuery queryParam, Pagination pagination) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getPromotionStoreList(com.saic.ebiz.promotion.service.vo.PromotionStoreQuery, com.ibm.framework.dal.pagination.Pagination)
//	 */
//	@Override
//	public PaginationResult<List<PromotionQualification>> getPromotionStoreList(
//			PromotionStoreQuery query, Pagination pagination) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#saveQualificationWithSeriesMap(java.lang.Long, java.util.Map)
//	 */
//	@Override
//	public void saveQualificationWithSeriesMap(Long promotionId,
//			Map<Long, QualificationVO> velSeriesQualificationMap)
//			throws ValidationException {
//		// TODO Auto-generated method stub
//
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#saveQualificationWithList(java.lang.Long, java.util.List)
//	 */
//	@Override
//	public void saveQualificationWithList(Long promotionId,
//			List<PromotionQualification> qualifications) {
//		// TODO Auto-generated method stub
//
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelSeriesQualificationMap(java.lang.Long)
//	 */
//	@Override
//	public Map<Long, QualificationVO> getVelSeriesQualificationMap(
//			Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getCityMapByMarketType(java.lang.Integer)
//	 */
//	@Override
//	public Map<Long, List<Long>> getCityMapByMarketType(Integer marketType) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelBrandMapByMarketType(java.lang.Long, java.lang.Integer)
//	 */
//	@Override
//	public List<Long> getVelBrandMapByMarketType(Long cityId, Integer marketType) {
//		List<Long> brandIdList = new ArrayList<Long>(); 
//		brandIdList.addAll(MockBrandSeriesData.brandMap.keySet());
//		return brandIdList;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelSeriesMapByMarketType(java.lang.Long, java.lang.Long, java.lang.Integer)
//	 */
//	@Override
//	public List<Long> getVelSeriesMapByMarketType(Long cityId, Long brandId,
//			Integer marketType) {
//		List<Long> seriesIdList = new ArrayList<Long>();
//		List<SeriesVO> temp = MockBrandSeriesData.brandMap.get(brandId);
//		for(SeriesVO data : temp){
//			seriesIdList.add(data.getId());
//		}
//		return seriesIdList;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getCityMapByPromotionId(java.lang.Long)
//	 */
//	@Override
//	public TreeMap<Long, List<Long>> getCityMapByPromotionId(Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getCityMapByPromotionIdVelModelId(java.lang.Long, java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public TreeMap<Long, List<Long>> getCityMapByPromotionIdVelModelId(
//			Long promotionId, Long velModelId, Long colorId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelBrandMapByPromotionId(java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public List<Long> getVelBrandMapByPromotionId(Long cityId, Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelSeriesMapByPromotionId(java.lang.Long, java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public List<Long> getVelSeriesMapByPromotionId(Long cityId, Long brandId,
//			Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#queryCxgMerchandiseByCombinedCondition(java.lang.Long, java.lang.Long, java.lang.Long, java.lang.Long, boolean, com.ibm.framework.dal.pagination.Pagination)
//	 */
//	@Override
//	public PaginationResult<List<CxgMerchandiseVO>> queryCxgMerchandiseByCombinedCondition(
//			Long promotionId, Long cityId, Long velBrandId, Long velSeriesId,
//			boolean availableOnly, Pagination page) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#queryRoutineMerchandiseByCombinedCondition(java.lang.Integer, java.lang.Long, java.lang.Long, java.lang.Long, boolean, com.ibm.framework.dal.pagination.Pagination)
//	 */
//	@Override
//	public PaginationResult<List<RoutineMerchandiseVO>> queryRoutineMerchandiseByCombinedCondition(
//			Integer marketType, Long cityId, Long velBrandId, Long velSeriesId,
//			boolean availableOnly, Pagination page) {
//		List<RoutineMerchandiseVO> vos = MockRoutineCarVOData.getData();
//		List<RoutineMerchandiseVO> result = new ArrayList<RoutineMerchandiseVO>();
//		for(RoutineMerchandiseVO vo : vos){
//			if(vo.getVelSeriesId().equals(velSeriesId)){
//				result.add(vo);
//			}
//		}
//		return new PaginationResult<List<RoutineMerchandiseVO>>(result, new Pagination());
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#queryStoreByCombinedCondition(java.lang.Long, java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<StoreResult>> queryStoreByCombinedCondition(Long cityId,
//			Long routineCarId, Long colorId) {
//		Map<Long,List<StoreResult>> data = new HashMap<Long, List<StoreResult>>();
//		List<StoreResult> storeIds = new ArrayList<StoreResult>();
//		StoreResult storeResult = new StoreResult();
//		storeResult.setStoreId(224L);
//		storeResult.setPrmtMdseId(11L);
//		//上海安吉斯铭东安
//		storeIds.add(storeResult);
//		//上海交运起元汽车
//		storeResult = new StoreResult();
//		storeResult.setStoreId(1670L);
//		storeResult.setPrmtMdseId(2L);
//		storeIds.add(storeResult);
//		//上海锦江汽车
//		storeResult = new StoreResult();
//		storeResult.setStoreId(1685L);
//		storeResult.setPrmtMdseId(2L);
//		storeIds.add(storeResult);
//		//上海徐汇区
//		data.put(310104L, storeIds);
//		///////////////////////////
//		storeIds = new ArrayList<StoreResult>();
//		//上海冠松
//		storeResult = new StoreResult();
//		storeResult.setStoreId(774L);
//		storeResult.setPrmtMdseId(5L);
//		storeIds.add(storeResult);
//		//上海强生汽车
//		storeResult = new StoreResult();
//		storeResult.setStoreId(1708L);
//		storeResult.setPrmtMdseId(4L);
//		storeIds.add(storeResult);
//		//上海普陀区
//		data.put(310107L, storeIds);
//		return data;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelBrandSeriesMap(java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getVelBrandSeriesMap(Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelSeriesModelMap(java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getVelSeriesModelMap(Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getVelModelColorMap(java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getVelModelColorMap(Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getCityStoresMap(java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getCityStoresMap(Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getBackupCityStoresMap(java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getBackupCityStoresMap(Long promotionId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getCityStoresMapByVelSeriesId(java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getCityStoresMapByVelSeriesId(
//			Long promotionId, Long velSeriesId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getCityStoresMapByVelModelId(java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getCityStoresMapByVelModelId(Long promotionId,
//			Long velModelId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getCityStoresMapByVelModelIdAndColorId(java.lang.Long, java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public Map<Long, List<Long>> getCityStoresMapByVelModelIdAndColorId(
//			Long promotionId, Long velModelId, Long colorId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getQualificationWithProvinceCtiy(java.lang.Long, java.lang.Long, java.lang.Long)
//	 */
//	public List<PromotionQualification> getQualificationWithProvinceCtiy(
//			Long promotionId, Long provinceId, Long cityId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getBackupStores(java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public List<Long> getBackupStores(Long arg0, Long arg1) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#getQualificationWithProvinceCtiy(java.lang.Long, java.lang.Long, java.lang.Long, boolean)
//	 */
//	@Override
//	public List<PromotionQualification> getQualificationWithProvinceCtiy(
//			Long arg0, Long arg1, Long arg2, boolean arg3) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IPromotionQualificationService#saveQualificationWithCity(java.lang.Long, java.lang.Long, java.lang.Long, java.util.List)
//	 */
//	@Override
//	public void saveQualificationWithCity(Long arg0, Long arg1, Long arg2,
//			List<PromotionQualification> arg3) {
//		// TODO Auto-generated method stub
//		
//	}
//
//}
