///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.lang.reflect.InvocationTargetException;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.apache.commons.beanutils.BeanUtils;
//
//import com.ibm.framework.dal.pagination.Pagination;
//import com.ibm.framework.dal.pagination.PaginationResult;
//import com.saic.ebiz.market.entity.ColorImageVO;
//import com.saic.ebiz.promotion.service.api.routine.IRoutineCarService;
//import com.saic.ebiz.promotion.service.vo.RoutineMerchandiseVO;
//import com.saic.ebiz.promotion.service.vo.routine.RoutineCar;
//import com.saic.ebiz.promotion.service.vo.routine.RoutineCarQuery;
//
///**
// * @author hejian
// *
// */
//public class MockIRoutineCarService implements IRoutineCarService {
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#createRoutineCar(com.saic.ebiz.promotion.service.vo.routine.RoutineCar)
//	 */
//	@Override
//	public List<Long> createRoutineCar(RoutineCar routineCar) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#updateRoutineCar(com.saic.ebiz.promotion.service.vo.routine.RoutineCar)
//	 */
//	@Override
//	public boolean updateRoutineCar(RoutineCar routineCar) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#queryRoutineCarByPage(com.saic.ebiz.promotion.service.vo.routine.RoutineCarQuery, com.ibm.framework.dal.pagination.Pagination)
//	 */
//	@Override
//	public PaginationResult<List<RoutineCar>> queryRoutineCarByPage(
//			RoutineCarQuery routineCarQuery, Pagination page) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#queryRoutineCarByDealerWithPage(com.saic.ebiz.promotion.service.vo.routine.RoutineCarQuery, com.ibm.framework.dal.pagination.Pagination)
//	 */
//	@Override
//	public PaginationResult<List<RoutineCar>> queryRoutineCarByDealerWithPage(
//			RoutineCarQuery routineCarQuery, Pagination page) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#findRoutineCarById(java.lang.Long)
//	 */
//	@Override
//	public RoutineCar findRoutineCarById(Long routineCarId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#findRoutineCarDetailByIds(java.util.List)
//	 */
//	@Override
//	public List<RoutineCar> findRoutineCarDetailByIds(List<Long> routineCarIds) {
//		List<RoutineCar> routineCarList = new ArrayList<RoutineCar>();
//		for(Long routineCarId : routineCarIds){
//			RoutineMerchandiseVO merchandiseVO = MockRoutineCarVOData.carMap.get(routineCarId);
//			RoutineCar routineCar = new RoutineCar();
//			exchangeData(routineCar, merchandiseVO);
//			routineCarList.add(routineCar);
//		}
//		return routineCarList;
//	}
//	
//	public List<RoutineMerchandiseVO> findRoutineCarDetailByIds(Long ... routineCarIds) {
//		List<RoutineMerchandiseVO> routineCarList = new ArrayList<RoutineMerchandiseVO>();
//		for(Long routineCarId : routineCarIds){
//			routineCarList.add(MockRoutineCarVOData.carMap.get(routineCarId));
//		}
//		return routineCarList;
//	}
//	
//	private void exchangeData(RoutineCar routineCar,RoutineMerchandiseVO routineMerchandiseVO){
//		try {
//			BeanUtils.copyProperties(routineCar, routineMerchandiseVO);
//			String[] colorIdArray = routineMerchandiseVO.getColorIdList().split(" ");
//			List<ColorImageVO> colorImageVOs = new ArrayList<ColorImageVO>();
//			if(colorIdArray.length > 0){
//				for(String colorId : colorIdArray){
//					colorImageVOs.add(MockColorImageVOData.getDataById(Long.valueOf(colorId)));
//				}
//			}
//			StringBuilder builder = new StringBuilder();
//			for(ColorImageVO vo : colorImageVOs){
//				builder.append(vo.getName()).append("、");
//			}
//			List<Long> ids = new ArrayList<Long>();
//			for(String colorId : routineMerchandiseVO.getColorIdList().split(" ")){
//				ids.add(Long.valueOf(colorId));
//			}
//			routineCar.setColorIds(ids);
//			routineCar.setColorNameList(builder.substring(0, builder.length() - 1));
//			routineCar.setVelModelName(routineMerchandiseVO.getTitle());
//			routineCar.setGuidePrice(routineMerchandiseVO.getMsrp());
//		} catch (IllegalAccessException e) {
//			e.printStackTrace();
//		} catch (InvocationTargetException e) {
//			e.printStackTrace();
//		}
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#deleteRoutineCar(java.lang.Long, java.lang.Long, java.lang.String)
//	 */
//	@Override
//	public boolean deleteRoutineCar(Long arg0, Long arg1, String arg2) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#findRoutineCarNum()
//	 */
//	@Override
//	public Long findRoutineCarNum() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#findStoreIdForRoutineCar(java.lang.Long, java.lang.Long, java.lang.Long)
//	 */
//	@Override
//	public List<Long> findStoreIdForRoutineCar(Long arg0, Long arg1, Long arg2) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#findVelModelIdForRoutineCar(java.lang.Long)
//	 */
//	@Override
//	public List<Long> findVelModelIdForRoutineCar(Long arg0) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#findVelModelIdForRoutineCarByStoreId(java.lang.Long)
//	 */
//	@Override
//	public List<Long> findVelModelIdForRoutineCarByStoreId(Long arg0) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.routine.IRoutineCarService#findVelSeriesIdForRoutineCar(java.lang.Long)
//	 */
//	@Override
//	public List<Long> findVelSeriesIdForRoutineCar(Long arg0) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//}
