///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.saic.ebiz.promotion.service.api.IShoppingCartService;
//import com.saic.ebiz.promotion.service.vo.RoutineMerchandiseVO;
//import com.saic.ebiz.promotion.service.vo.ShoppingCartVO;
//
///**
// * @author hejian
// *
// */
//public class MockIShoppingCartService implements IShoppingCartService {
//
//	public void put(Long userId, Long routineCarId) {
//		MockShoppingCartData.put(userId, routineCarId);
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IShoppingCartService#loadContent(java.lang.String, java.lang.String)
//	 */
//	@Override
//	public List<ShoppingCartVO> loadContent(String keyId, String cityId) {
//		List<ShoppingCartVO> data = new ArrayList<ShoppingCartVO>();
//		List<Long> routineCarIds = MockShoppingCartData.load(Long.valueOf(keyId));
//		for(Long routineCarId : routineCarIds){
//			ShoppingCartVO cart = new ShoppingCartVO();
//			RoutineMerchandiseVO merchandise = MockRoutineCarVOData.carMap.get(routineCarId);
//			cart.setCoverImgId(merchandise.getCoverImgId());
//			cart.setCoverImgUrl(merchandise.getCoverImgUrl());
//			cart.setRoutineCarId(routineCarId);
//			cart.setTitle(merchandise.getTitle());
//			data.add(cart);
//		}
//		return data;
//	}
//
//	@Override
//	public void put(String keyId, String cityId, Long routineCarId) {
//		MockShoppingCartData.put(Long.valueOf(keyId), routineCarId);
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IShoppingCartService#remove(java.lang.String, java.lang.Long)
//	 */
//	@Override
//	public void remove(String keyId, Long routineCarId) {
//		MockShoppingCartData.remove(Long.valueOf(keyId), routineCarId);
//	}
//
//	/* (non-Javadoc)
//	 * @see com.saic.ebiz.promotion.service.api.IShoppingCartService#removeAll(java.lang.String)
//	 */
//	@Override
//	public void removeAll(String keyId) {
//		MockShoppingCartData.empty(Long.valueOf(keyId));
//	}
//
//	@Override
//	public List<ShoppingCartVO> replaceKeyAndGet(String arg0, String arg1,
//			String arg2) {
//		return null;
//	}