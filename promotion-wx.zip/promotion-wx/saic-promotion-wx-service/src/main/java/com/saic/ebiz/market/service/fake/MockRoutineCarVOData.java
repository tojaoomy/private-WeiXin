///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.atomic.AtomicLong;
//
//import com.meidusa.fastjson.JSONObject;
//import com.saic.ebiz.promotion.service.vo.RoutineMerchandiseVO;
//
///**
// * @author hejian
// *
// */
//public abstract class MockRoutineCarVOData {
//	private static final AtomicLong id = new AtomicLong(0);
//	
//	//活动号
//	private static final AtomicLong promotionId = new AtomicLong(0);
//
//	//批次号
//	private static final AtomicLong batchId = new AtomicLong(0);
//	
//	private static List<RoutineMerchandiseVO> data = new ArrayList<RoutineMerchandiseVO>();
//	
//	public static Map<Long,RoutineMerchandiseVO> carMap = new HashMap<Long,RoutineMerchandiseVO>();
//	
//	static{
//		buildData();
//	}
//	
//	private static void buildData(){
//		RoutineMerchandiseVO merchandiseVO = new RoutineMerchandiseVO();
//		merchandiseVO.setPromotionId(promotionId.incrementAndGet());
//		merchandiseVO.setRoutineCarId(id.incrementAndGet());
//		merchandiseVO.setAvgSave(new BigDecimal("2.9"));
//		merchandiseVO.setAvgTakeCarPeriod(13);
//		merchandiseVO.setBatchDesc("6个月长龄库存车");
//		merchandiseVO.setBatchGift("买车即送Iphone6一台");
//		merchandiseVO.setBatchNo(String.valueOf(batchId.incrementAndGet()));
//		merchandiseVO.setCarType(1);
//		merchandiseVO.setCoverImgId(id.get());
//		merchandiseVO.setCoverImgUrl("cars/dazhong.jpg");
//		merchandiseVO.setIsPriceDiffCommit(1);
//		merchandiseVO.setMsrp(new BigDecimal("14.99"));
//		merchandiseVO.setTotalMembers(33l);
//		merchandiseVO.setTotalMembersShow(88l);
//		merchandiseVO.setPriceDiffCommitPeriod(3);
//		merchandiseVO.setColorIdList("1 3");
//		merchandiseVO.setVelBrandId(1L);
//		merchandiseVO.setVelSeriesId(18L);
//		merchandiseVO.setVelModelId(1180010L);
//		merchandiseVO.setTitle("大众_朗行_2014款 1.6L 自动运动版");
//		data.add(merchandiseVO);
//		carMap.put(id.get(), merchandiseVO);
//		
//		merchandiseVO = new RoutineMerchandiseVO();