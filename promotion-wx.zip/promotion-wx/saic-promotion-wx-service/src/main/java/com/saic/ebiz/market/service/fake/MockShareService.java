//package com.saic.ebiz.market.service.fake;
//
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//import com.ibm.framework.dal.pagination.Pagination;
//import com.ibm.framework.dal.pagination.PaginationResult;
//import com.saic.ebiz.comment.service.vo.EvaluationVO;
//
//public class MockShareService {
//
//	/** 客户手机 */
//	private static final String MOBILE = "18521599872";
//	/** 评论内容 */
//    private static final String CONTENT = "本人纯屌丝，需要一辆性价比高，看起来又高富帅一些的车，看了很久都没找到，在享买车上看到了荣威550，而且价格太便宜了，询问下来只要市场价的80%";
//	/** 评论星级 */
//	/** 分享时间(翻译) */
//	private static final java.util.Date CREATETIME = new Date();
//	/** 购买车型(询价单号查询) */
//    /**
//     * 图片CMS URL
//     */
//    private static final String PICURL = "images/cars/RV550.jpg";
//    
//    private static List<EvaluationVO> voList = null;
//   
//    private static PaginationResult<List<EvaluationVO>> result = new PaginationResult<List<EvaluationVO>>();
//  
//    private static Pagination page = new Pagination();
//    
//    static{
//    	buildData();
//    }
//
//	private static void buildData() {
//		voList = new ArrayList<EvaluationVO>();
//		/**
//		 * 大众
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(1l);
//			vo.setVelBrand("大众");
//			voList.add(vo);
//		}
//		/**
//		 * 斯柯达
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(2l);
//			vo.setVelBrand("斯柯达");
//			voList.add(vo);
//		}
//		/**
//		 * 别克
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(3l);
//			vo.setVelBrand("别克");
//			voList.add(vo);
//		}
//		/**
//		 * 雪佛兰
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(4l);
//			vo.setVelBrand("雪佛兰");
//			voList.add(vo);
//		}
//		/**
//		 * 凯迪拉克
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(5l);
//			vo.setVelBrand("凯迪拉克");
//			voList.add(vo);
//		}
//		/**
//		 * 荣威
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(6l);
//			vo.setVelBrand("荣威");
//			voList.add(vo);
//		}
//		/**
//		 * MG
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(7l);
//			vo.setVelBrand("MG");
//			voList.add(vo);
//		}
//		/**
//		 * 宝骏
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(8l);
//			vo.setVelBrand("宝骏");
//			voList.add(vo);
//		}
//		/**
//		 * 五菱
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(9l);
//			vo.setVelBrand("五菱");
//			voList.add(vo);
//		}
//		/**
//		 * 上汽大通
//		 */
//		for (int i = 0; i < 5; i++) {
//			EvaluationVO vo = new EvaluationVO();
//			vo.setContent(CONTENT);
//			vo.setMobile(MOBILE);
//			vo.setScore(i);
//			vo.setCreateTime(CREATETIME);
//			vo.setPicUrl(PICURL);
//			vo.setVelBrandId(10l);
//			vo.setVelBrand("上汽大通");
//			voList.add(vo);
//		}
//		
//		page.setCurrentPage(1);
//		result.setPagination(page);
//		result.setR(voList);
//	}
//	
//	public static PaginationResult<List<EvaluationVO>> getData(Long brandId){
//		PaginationResult<List<EvaluationVO>> data = new PaginationResult<List<EvaluationVO>>();
//		page.setCurrentPage(1);
//		data.setPagination(page);
//		List<EvaluationVO> voList = new ArrayList<EvaluationVO>();
//		List<EvaluationVO> list = result.getR();
//		for (EvaluationVO vo : list) {
//			if(vo.getVelBrandId() == brandId){
//				voList.add(vo);
//			}
//		}
//		data.setR(voList);
//		return data;
//	}
//}
