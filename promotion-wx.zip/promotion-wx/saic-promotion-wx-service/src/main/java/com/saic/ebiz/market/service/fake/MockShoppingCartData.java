///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * 
// */
//package com.saic.ebiz.market.service.fake;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import com.meidusa.fastjson.JSONObject;
//
///**
// * @author hejian
// * 
// */
//public class MockShoppingCartData {
//
//	private static final Map<Long, List<Long>> data = new HashMap<Long, List<Long>>();
//
//	static{
//		buildData();
//	}
//	
//	/**
//	 * 
//	 */
//	private static void buildData() {
//		Set<Long> ids = MockRoutineCarVOData.carMap.keySet();
//		Iterator<Long> it = ids.iterator();
//		while(it.hasNext()){
//			put(10257L,it.next());
//		}
//	}
//
//	public static void put(Long userId, Long routineCarId) {
//		if (data.get(userId) != null) {
//			if(data.get(userId).size() > 1){
//				return;
//			}else{
//				List<Long> ids = new ArrayList<Long>();
//				ids.addAll(data.get(userId));
//				ids.add(routineCarId);
//				data.put(userId, ids);
//			}
//		} else {
//			List<Long> ids = new ArrayList<Long>();
//			ids.add(routineCarId);
//			data.put(userId, ids);
//		}
//	}
//	
//	public static void remove(Long userId, Long routineCarId) {
//		List<Long> ids =  data.get(userId);
//		if (ids == null || ids.size() == 0) {
//				return;
//		} else {
//			List<Long> tmp = new ArrayList<Long>();
//			ids.remove(routineCarId);
//			tmp.addAll(ids);
//			data.put(userId, ids);
//		}
//	}
//	
//	public static void empty(Long userId){
//		data.remove(userId);
//	}
//	
//	public static List<Long> load(Long userId){
//		List<Long> ids = new ArrayList<Long>();
//		ids.addAll(data.get(userId));
//		return ids;
//	}
//	
//	public static void main(String[] args) {
//		System.out.println(JSONObject.toJSONString(data));
//	}
//}
