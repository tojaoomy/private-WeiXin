/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.saic.ebiz.cms.service.api.IImageExtService;
import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.entity.user.UserBean;
import com.saic.ebiz.market.common.util.RegexUtil;
import com.saic.ebiz.market.service.AccountService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.api.WebAccountService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.ebiz.mdm.metadata.MDMConstants;
import com.saic.sso.client.SSOClient;
import com.saic.sso.client.entity.LoginInfo;

;

/**
 * 用户账户登入登出服务<br>
 */
@Service("accountServiceImpl")
public class AccountServiceImpl implements AccountService {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    /** 用户接口. */
    @Resource
    private IUserService iUserService;

//    /** 商品试图接口. */
//    @Resource(name = "SpreadServiceImpl")
//    private SpreadService spreadService;

    /** 富文本接口. */
    @Resource
    private IImageExtService iImageExtService;

    /** The i member info service. */
    @Resource(name = "userService")
    private UserService userService;

    @Resource
    private  WebAccountService webAccountService;
    /** SSO单点登陆接口. */
    @Autowired
    private SSOClient ssoClient;

    /** 邀请好友接口. */
    @Resource(name = "userService")
    private UserService iInviteFriendService;

    
    /**
     * {@inheritDoc}
     */
    @Override
    public UserBaseInfoVO getMemberinfoByuserId(String usrid) {    
    	//mem=userService.findMembInfo(Long.parseLong(usrid), "");
		UserBaseInfoVO mem	=userService.findBaseInfoByUserId(Long.parseLong(usrid));
        return mem;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public LoginInfo userLogin(int appCode, String aliasName, String password, boolean autoLogin,
            HttpServletRequest request, HttpServletResponse response) {
        String md5Pass = DigestUtils.md5Hex(password);
        String name = aliasName.replaceAll("&lt;","<" ).replaceAll("&gt;", ">")
                .replaceAll("&quot;", "\"");
        LoginInfo loginInfo = ssoClient.login(appCode,name, md5Pass, autoLogin, request, response);
        return loginInfo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LoginInfo userLoginnew(int appCode, String aliasName, String password, boolean autoLogin,
            HttpServletRequest request, HttpServletResponse response) {
        //String md5Pass = DigestUtils.md5Hex(password);
        String name = aliasName.replaceAll("&lt;","<" ).replaceAll("&gt;", ">")
                .replaceAll("&quot;", "\"");
        LoginInfo loginInfo = ssoClient.login(appCode,name, password, autoLogin, request, response);
        return loginInfo;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean userLogout(long userId, HttpServletRequest request, HttpServletResponse response) {
        boolean result = false;
        try {
            result = ssoClient.logout(request, response);
        } catch (Exception e) {
            logger.error("ssoClient.logout was error !", e);
        }
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BindingResult validateUserLogin(UserBean userBean, BindingResult result) {
        if (null == userBean.getUserName() || "".equals(userBean.getUserName())) {
            result.rejectValue("userName", null, "用户名必须填写!");
        }
        if (null == userBean.getPassword() || "".equals(userBean.getPassword())) {
            result.rejectValue("password", null, "密码必须填写!");
        }
        if (null == userBean.getCheckCode() || "".equals(userBean.getCheckCode())) {
            result.rejectValue("checkCode", null, "验证码必须填写!");
        }
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BindingResult validateUserRegister(UserBean userBean, BindingResult result) {
    	//账户名验证
    	  if (null == userBean.getUserName() || "".equals(userBean.getUserName())) {
	            result.rejectValue("userName", null, "用户名必须填写!");
	        } else if (!userBean.getUserName().matches(RegexUtil.REGEX_USERNAME)) {
	            result.rejectValue("userName", null, "用户名格式有误!");
	        }   
        if (null == userBean.getPassword() || "".equals(userBean.getPassword())) {
            result.rejectValue("password", null, "密码必须填写!");
        } else if (!userBean.getPassword().matches(RegexUtil.REGEX_PASSWORD)) {
            result.rejectValue("password", null, "密码格式不正确!");
        }
        if (null == userBean.getNewPassword() || "".equals(userBean.getNewPassword())) {
            result.rejectValue("newPassword", null, "确认密码必须填写!");
        } else if (!userBean.getPassword().equals(userBean.getNewPassword())) {
            result.rejectValue("newPassword", null, "两次输入的密码不一致!");
        }
        if (null == userBean.getCheckCode() || "".equals(userBean.getCheckCode())) {
            result.rejectValue("checkCode", null, "验证码必须填写!");
        }
        
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BindingResult validateUserRegisterByaliasType(UserBean userBean, BindingResult result) {
    	//账户名验证
    	if(userBean.getUserNameType()==3){ //用户名
	        if (null == userBean.getUserName() || "".equals(userBean.getUserName())) {
	            result.rejectValue("userName", null, "用户名必须填写!");
	        } else if (!userBean.getUserName().matches(RegexUtil.REGEX_USERNAME)) {
	            result.rejectValue("userName", null, "用户名格式有误!");
	        }
    	}else if(userBean.getUserNameType()==2){//邮箱
    		if (null == userBean.getUserName() || "".equals(userBean.getUserName().trim())) {
	            result.rejectValue("userName", null, "用户名必须填写!");
	        } else{
	        	if(!userBean.getUserName().trim().matches(RegexUtil.REGEX_EMAIL)){
	        		  result.rejectValue("userName", null, "邮箱格式不正确!");  
	        	}
	        }
    	}else if(userBean.getUserNameType()==1){//手机
    		 if (null == userBean.getUserName() || "".equals(userBean.getUserName().trim())) {
    			 result.rejectValue("userName", null, "手机号必须填写!");
    		 }else{
    			 if(!userBean.getUserName().trim().matches(RegexUtil.REGEX_MOBILE)){
	             result.rejectValue("userName", null, "手机格式不正确!");  
	        	}
    		 }
    	}else{//前端没有区分类型
    		//userBean.setUserNameType(3);
    		result.rejectValue("userName", null, "未知类型的账户信息!");
    	}
    	
        if (null == userBean.getPassword() || "".equals(userBean.getPassword())) {
            result.rejectValue("password", null, "密码必须填写!");
        } else if (!userBean.getPassword().matches(RegexUtil.REGEX_PASSWORD)) {
            result.rejectValue("password", null, "密码格式不正确!");
        }
        if (null == userBean.getNewPassword() || "".equals(userBean.getNewPassword())) {
            result.rejectValue("newPassword", null, "确认密码必须填写!");
        } else if (!userBean.getPassword().equals(userBean.getNewPassword())) {
            result.rejectValue("newPassword", null, "两次输入的密码不一致!");
        }
        if (null == userBean.getCheckCode() || "".equals(userBean.getCheckCode())) {
            result.rejectValue("checkCode", null, "验证码必须填写!");
        }
        
        return result;
    }
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO userRegister(String userName, String passWord, int aliasType, int appId, int createType, int securityType) {
        String md5Pass = DigestUtils.md5Hex(passWord);
        return iUserService.normalReg(userName, md5Pass, aliasType, appId, createType, securityType);
    }

    
    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO userRegisterforEmailAndPhone(String userName, String passWord, String checkcode,int aliasType, int appId, int createType, int securityType,String authURL) {
        String md5Pass = DigestUtils.md5Hex(passWord);
        try {
	        if(aliasType==3){
	        	return iUserService.normalRegForUMS(userName, md5Pass, "", aliasType, appId, createType, securityType, authURL);
	        }else{
	        	return iUserService.normalRegForUMS(userName, md5Pass, checkcode, aliasType, appId, createType, securityType,"");
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
        return null;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO aliasNameIsUsed(String aliasName, int aliasType, int appId) {
        return iUserService.aliasNameIsUsed(aliasName, 1, 1);
    }
    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO aliasNameIsUsedByaliasType(String aliasName, int aliasType, int appId) {
        return iUserService.aliasNameIsUsed(aliasName, aliasType, appId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String loginPageImage() {
        String imageUrl = "";
        //这个版本不需实现
//        try {
//            List<MainStationSpreadVO> vos = spreadService.loginPageImage();
//            if (vos != null && vos.size() != 0) {
//                MainStationSpreadVO vo = vos.get(0);
//                List<Long> ids = new ArrayList<Long>();
//                ids.add(vo.getImgId());
//                List<Image> images = iImageExtService.findImgs(ids);
//                if (images != null && images.size() != 0) {
//                    imageUrl = images.get(0).getPath();
//                }
//            }
//        } catch (Exception e) {
//            logger.error("loginPageImage was error !", e);
//        }
        return imageUrl;
    }

    @Override
    public Long getLoginStatus(HttpServletRequest request) {
        return ssoClient.getLoginStatus(request);
    }

    @Override
    public Integer friendReg(UserBaseInfoVO userBaseInfoVO) {
		return null;
//        Integer result = 102;
//        try {
//            result = iInviteFriendService.friendReg(friendRegVO);
//        } catch (DBResultException e) {
//            logger.error("iInviteFriendService.friendReg was error ! MD5 = " + friendRegVO.getMd5Str() + " userId = "
//                    + friendRegVO.getRegUserId(), e);
//        } catch (InParamException e) {
//            logger.error("iInviteFriendService.friendReg was error ! MD5 = " + friendRegVO.getMd5Str() + " userId = "
//                    + friendRegVO.getRegUserId(), e);
//        }
//        return result;
    }

	@Override
	public boolean addWinxinOpenIDAndUserIdReleation(long userid,String openId) {
		boolean result=false;
		 com.saic.ebiz.mdm.entity.WebAccountVO wv=new com.saic.ebiz.mdm.entity.WebAccountVO();
		 wv.setUserId(userid);
		 wv.setNumber(openId);
		 wv.setCreatedBy("29");
		 wv.setStatus(MDMConstants.GLOBAL_STATUS.EFFECTIVE.getCode());
		 //车享购微信来源号29
		 wv.setSource(29);
		 wv.setVerification(MDMConstants.GLOBAL_VERIFICATION.TRUE.getCode());
		 wv.setType(Constants.MDM_USER_SAIC_TYPE);
		try {
			webAccountService.addWebAccount(wv);
			result=true;
		} catch (Exception e) {
			logger.error("addWinxinOpenIDAndUserIdReleation ...Error", e);
			result=false;
		}
		 
		return result;
	}
	@Override
	public List<WebAccountVO> findWebAccountByCondition(WebAccountVO wv) {
		List<WebAccountVO>  wvs=(List<WebAccountVO>) webAccountService.findWebAccountByCondition(wv);
		return wvs;
	}

	

}
