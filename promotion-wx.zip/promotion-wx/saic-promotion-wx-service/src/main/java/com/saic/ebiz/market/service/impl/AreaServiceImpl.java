/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import jetbrick.pinyin.ChinesePinyin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.entity.CityVO;
import com.saic.ebiz.market.entity.DistrictVO;
import com.saic.ebiz.market.entity.PinyinCityEntity;
import com.saic.ebiz.market.entity.ProvinceVO;
import com.saic.ebiz.market.service.AbstractAeraService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;

/**
 * @author hejian
 *
 */
@Service("areaService")
public class AreaServiceImpl extends AbstractAeraService {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	/**
	 * 特殊城市
	 * 	根据拼音的库，对于多音字处理还不完善
	 */
	private static Map<String,String> specialCity = null;
	
	static{
		specialCity = new HashMap<String, String>();
		specialCity.put("重庆", "chongqing");
	}
	
	@Resource
	private IPromotionQualificationService iPromotionQualificationService;
	
	private ChinesePinyin chinesePinyin = ChinesePinyin.getInstance();
	
	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.AbstractAeraService#getProvinceByMarkeyType(java.lang.Integer)
	 */
	@Override
	public List<ProvinceVO> getProvinceByMarkeyType(Integer marketType) {
		logger.info("AreaServiceImpl =》getProvinceByMarkeyType --- MarketType : " + marketType);
		List<ProvinceVO> result = new ArrayList<ProvinceVO>();
		//根据活动类型取得对应的城市map(key=provinceId, value=cityId的集合)
		Map<Long,List<Long>> data = iPromotionQualificationService.getCityMapByMarketType(marketType);
		//////mock data
//		Map<Long,List<Long>> data = new HashMap<Long, List<Long>>();
//		List<Long> list = new ArrayList<Long>();
//		list.add(310100L);
//		data.put(310000L, list);
		///////
		
		Long provinceId = null;
		for(Entry<Long, List<Long>> entry : data.entrySet()){
			ProvinceVO provinceVO = new ProvinceVO();
			//遍历map，获取provinceId
			provinceId = entry.getKey();
			List<Long> cityIds = entry.getValue();
			//设置省份信息
			DataItemBean provinceBean = ConstantCodeService.getRegionInfo(String.valueOf(provinceId));
			if(provinceBean != null){
				provinceVO.setValue(provinceId);
				provinceVO.setText(provinceBean.getName());
			}
			//设置城市的信息
			for(Long cityId : cityIds){
				DataItemBean cityBean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
				if(cityBean != null){
					CityVO cityVO = new CityVO();
					cityVO.setValue(cityId);
					cityVO.setText(cityBean.getName());
					cityVO.setPvalue(Long.valueOf(cityBean.getParentCode()));
					provinceVO.getChildren().add(cityVO);
				}
			}
			result.add(provinceVO);
		}
		logger.info("AreaServiceImpl =》getProvinceByMarkeyType --- 返回 List<ProvinceVO> : " + JSONObject.toJSONString(result));
		return result;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.AreaService#getDistrictWithStoreByMapData(java.util.Map)
	 */
	@Override
	public List<DistrictVO> getDistrictWithStoreByMapData(
			Map<Long, List<Long>> map) {
		// TODO Auto-generated method stub
		return null;
	}

	/* 
	 * 1. 首先通过活动类型查找所有的城市
	 * 2. 再通过map来分类所有的城市
	 * 3. 最后通过list排序
	 * 
	 * (non-Javadoc)
	 * @see com.saic.ebiz.market.service.AreaService#getPinyinCity(java.lang.Integer)
	 */
	@Override
	public List<PinyinCityEntity> getPinyinCity(Integer marketType) {
		List<ProvinceVO> data = this.getProvinceByMarkeyType(marketType);
		List<CityVO> cityList = new ArrayList<CityVO>();
		List<PinyinCityEntity> result = new ArrayList<PinyinCityEntity>();
		Map<String,List<CityVO>> medium = new HashMap<String,List<CityVO>>();
		for(ProvinceVO provinceVO : data){
			cityList.addAll(provinceVO.getChildren());
		}
		String cityNameWithout = "";
		String firstLetter = "";
		for(CityVO cityVO : cityList){
			cityNameWithout = cityVO.getText().replace("市", "");
			if(specialCity.containsKey(cityNameWithout)){
				//首字母
				firstLetter = specialCity.get(cityNameWithout).substring(0, 1);
			}else{
				firstLetter = chinesePinyin.getFullPinyin(cityNameWithout).substring(0, 1);
			}
			//构造map
			if(medium.containsKey(firstLetter)){
				medium.get(firstLetter).add(cityVO);
			}else{
				List<CityVO> mapCityList = new ArrayList<CityVO>();
				mapCityList.add(cityVO);
				medium.put(firstLetter, mapCityList);
			}
		}
		//iterate map to construct List
		Set<Map.Entry<String,List<CityVO>>> set = medium.entrySet();
		Iterator<Map.Entry<String,List<CityVO>>> it = set.iterator();
		while(it.hasNext()){
			//make sure lower case
			firstLetter = it.next().getKey().toLowerCase();
			PinyinCityEntity cityEntity = new PinyinCityEntity();
			cityEntity.setFirstLetter(firstLetter);
			cityEntity.setCities(medium.get(firstLetter));
			result.add(cityEntity);
		}
		Collections.sort(result,new Comparator<PinyinCityEntity>() {
			public int compare(PinyinCityEntity o1, PinyinCityEntity o2) {
				return o1.getFirstLetter().compareTo(o2.getFirstLetter());
			}
        });
		return result;
	}

}
