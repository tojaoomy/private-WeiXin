/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.util.MyOpenIdTokenUtil;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.service.WebAccountInfoService;
import com.saic.ebiz.mdm.entity.WebAccountVO;

/**
 * @author hejian
 *
 */
@Service
public class BoundingServiceImpl implements BoundingService {
	
private Logger logger = LoggerFactory.getLogger(getClass());
	

    @Autowired
    private MyOpenIdTokenUtil myOpenIdTokenUtil;
    
    @Autowired
    private WebAccountInfoService webAccountInfoService;

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.BoudingService#checkBounding(java.lang.String)
	 */
	@Override
	public List<WebAccountVO> checkBounding(String fromUserName) {
		WebAccountVO webAccountVO = new WebAccountVO();
		webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE);
		webAccountVO.setNumber(fromUserName);
		// 查询来源是车享购微信号
		webAccountVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));

		logger.info(" ---------- 开始调用webAccountInfoService.findWebAccountByCondition---------- fromUserName = " + fromUserName);
		logger.info(" ---------- 开始调用webAccountInfoService.findWebAccountByCondition---------- WebAccountVO = "
				+ JSONObject.toJSONString(webAccountVO));
		List<WebAccountVO> webAccountVOList = webAccountInfoService.findWebAccountByCondition(webAccountVO);
		logger.info("返回列表 : " + JSONObject.toJSONString(webAccountVOList));
		logger.info(" ---------- 结束调用webAccountInfoService.findWebAccountByCondition---------- ");

		return webAccountVOList;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.BoudingService#checkResultBounding(java.lang.String)
	 */
	@Override
	public boolean checkResultBounding(String fromUserName) {
		List<WebAccountVO> webAccountVOList = checkBounding(fromUserName);
        boolean isBounding = false;
        if (null != webAccountVOList && webAccountVOList.size() > 0) {
            isBounding = true;
        }
        return isBounding;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.BoundingService#getBoundingUserId(java.lang.String)
	 */
	@Override
	public String getBoundingUserId(String fromUserName) {
		List<WebAccountVO> webAccountVOList = checkBounding(fromUserName);
        if (null != webAccountVOList && webAccountVOList.size() > 0) {
            return String.valueOf(webAccountVOList.get(0).getUserId());
        }
		return "";
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.BoundingService#deleteWebAccount(java.lang.String)
	 */
	@Override
	public boolean deleteWebAccountByOpenId(String fromUserName) {
		List<WebAccountVO> webAccountVOList = checkBounding(fromUserName);
		for (WebAccountVO webAccountVO : webAccountVOList) {
			logger.info("删除 webAccountId : " + webAccountVO.getWebAccountId());
			webAccountInfoService.deleteWebAccount(webAccountVO
					.getWebAccountId());
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.BoundingService#deleteWebAccountByUserId(java.lang.Long)
	 */
	@Override
	public boolean deleteWebAccountByUserId(Long userId) {
		WebAccountVO webAccountVO = new WebAccountVO();
		webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE);
		webAccountVO.setUserId(userId);
		// 查询来源是车享购微信号
		webAccountVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));

		logger.info(" ---------- 开始调用webAccountInfoService.findWebAccountByCondition---------- userId = " + userId);
		logger.info(" ---------- 开始调用webAccountInfoService.findWebAccountByCondition---------- WebAccountVO = "
				+ JSONObject.toJSONString(webAccountVO));
		List<WebAccountVO> webAccountVOList = webAccountInfoService.findWebAccountByCondition(webAccountVO);
		logger.info("返回列表 : " + JSONObject.toJSONString(webAccountVOList));
		logger.info(" ---------- 结束调用webAccountInfoService.findWebAccountByCondition ---------- ");
		for (WebAccountVO account : webAccountVOList) {
			logger.info("删除 webAccountId : " + account.getWebAccountId());
			webAccountInfoService.deleteWebAccount(account.getWebAccountId());
		}
		return true;
	}

	/**
     * 根据用户id在mdm系统查找绑定的openid
     * @param userId 用户id
     * @return 微信服务号openid
     */
    public String getOpenIdByUserId(Long userId){
    	WebAccountVO webAccountVO = new WebAccountVO();
		webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE
				);
		webAccountVO.setUserId(userId);
		webAccountVO.setStatus(1);
		// 车享购微信来源
		webAccountVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));
		List<WebAccountVO> accountByCondition = this.webAccountInfoService
				.findWebAccountByCondition(webAccountVO);
		logger.info("BoundingServiceImpl =》getOpenIdByUserId 根据用户 id : {}, 返回 {}", userId,JSONObject.toJSONString(accountByCondition));
		
		String openId = null;
		if(accountByCondition != null && accountByCondition.size()>0) {
		    openId = accountByCondition.get(0).getNumber();
		}
		
		return openId;
		
		//没找到或者找到多条提示失败
//		if (accountByCondition == null || accountByCondition.size() == 0
//				|| accountByCondition.size() > 1) {
//			logger.error("未找到openid");
//			return null;
//		}else{
//			return accountByCondition.get(0).getNumber();
//		}
		
    }

}
