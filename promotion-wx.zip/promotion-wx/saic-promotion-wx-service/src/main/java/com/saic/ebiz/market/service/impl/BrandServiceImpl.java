/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.carlib.service.entity.VelBrand;
import com.saic.ebiz.carlib.service.entity.VelSeries;
import com.saic.ebiz.market.entity.BrandVO;
import com.saic.ebiz.market.entity.SeriesVO;
import com.saic.ebiz.market.service.AbstractBrandService;
import com.saic.ebiz.market.service.RoutineCarService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;

/**
 * @author hejian
 * 
 */
@Service("brandService")
public class BrandServiceImpl extends AbstractBrandService implements ApplicationContextAware{
	private Logger log = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IPromotionQualificationService iPromotionQualificationService;
	
	@Resource
	private RoutineCarService routineCarService;
	
	@Override
	public List<BrandVO> getBrandsByMarketType(Integer marketType, Long cityId) {
		log.info("BrandServiceImpl => getBrandsByMarketType marketType : {} , cityId : {}", marketType, cityId);
		List<BrandVO> brandList = new ArrayList<BrandVO>();
		//获取品牌id的列表
		List<Long> brandIdList = iPromotionQualificationService.getVelBrandMapByMarketType(cityId, marketType);
		////////
		for(Long brandId : brandIdList){
			VelBrand brand = this.brandClient.findBrandById(brandId);
			BrandVO brandVO = new BrandVO();
			//品牌id
			brandVO.setId(brand.getVelBrandId());
			//品牌名称
			brandVO.setName(brand.getVelBrandChsName());
			brandVO.setDefaultImage();
			brandVO.getSeries().addAll(getSeriesByMarketType(marketType, cityId, brandId));
			brandList.add(brandVO);
		}
		log.info("BrandServiceImpl => getBrandsByMarketType 返回 List<BrandVO> : " + JSONObject.toJSONString(brandList));
		return brandList;
	}

	@Override
	public List<SeriesVO> getSeriesByMarketType(Integer marketType,
			Long cityId, Long brandId) {
		log.info("BrandServiceImpl => getSeriesByMarketType marketType : {} , cityId : {}, brandId : {}", marketType, cityId, brandId);
		List<SeriesVO> seriesList = new ArrayList<SeriesVO>();
		//获取车系id的列表
		List<Long> seriesIdList = iPromotionQualificationService.getVelSeriesMapByMarketType(cityId, brandId,marketType);
		
		for(Long seriesId : seriesIdList){
			VelSeries velSeries=this.seriesClient.findSeriesById(seriesId);
			SeriesVO seriesVO = new SeriesVO();
			//车系id
			seriesVO.setId(velSeries.getVelSeriesId());
			//车系名称
			seriesVO.setName(velSeries.getVelSeriesChsName());
			seriesVO.setBrandId(brandId);
			seriesVO.setBrandName(this.brandClient.findBrandNameById(brandId));
			//不一次性加载所有的数据 BUGFIX
			/*List<RoutineCarVO> routineCars = routineCarService.findConventionalVehicleByPromotionIdSeriesIdColorId(MarketType.ROUTINE.code(), cityId, brandId, seriesId, true, new Pagination());
			log.info("routineCarService.findConventionalVehicleByPromotionIdSeriesIdColorId ###### 返回数据 : " + JSONObject.toJSONString(routineCars));
			seriesVO.setRoutineCars(routineCars);*/
			seriesList.add(seriesVO);
		}
		log.info("BrandServiceImpl => getSeriesByMarketType 返回 List<SeriesVO> : " + JSONObject.toJSONString(seriesList));
		return seriesList;
	}

	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
	}
}
