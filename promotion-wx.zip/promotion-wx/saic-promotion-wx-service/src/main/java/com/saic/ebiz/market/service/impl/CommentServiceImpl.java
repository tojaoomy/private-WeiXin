/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.saic.ebiz.market.entity.Comment;
import com.saic.ebiz.market.entity.CommentVO;
import com.saic.ebiz.market.service.CommentService;

/**
 * 评价服务实现
 * 
 * 1.通过品牌来获取评价
 * 2.保存用户评价
 * 
 * @author hejian
 *
 */
public class CommentServiceImpl implements CommentService {

	/**
	 * @param size 获取评价数目大小
	 * @param brandIds 品牌id集合
	 * 
	 */
	@Override
	public List<CommentVO> getCommentByBrandIds(int size, Long... brandIds) {
		
		return Mock.getCommentByBrandIds(10, 1L);
	}

	/* 
	 * 保存用户的评价
	 */
	@Override
	public void saveComment(Comment comment) {
		
	}
	
	public static class Mock{
		public static List<CommentVO> getCommentByBrandIds(int size, Long... brandIds) {
			List<CommentVO> result = new ArrayList<CommentVO>();
			CommentVO comment = new CommentVO();
			comment.setBrandId(1L);
			comment.setBrandName("大众");
			comment.setSeriesId(11L);
			comment.setSeriesName("朗行");
			comment.setMobile("18721432848");
			comment.setRoutineCarId(1L);
			comment.setInquireOrderId(20141016L);
			comment.setScore(5d);
			comment.setUserId(1111L);
			comment.setUserRealName("学籍");
			comment.setVehicleModelId(111L);
			return result;
		}
	}

}
