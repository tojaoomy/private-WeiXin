/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.iam.service.entity.AcctAliasVO;
import com.saic.ebiz.iam.service.entity.AuthInfoVO;
import com.saic.ebiz.iam.service.entity.QuestionVO;
import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.iam.service.exception.AccountNotFoundException;
import com.saic.ebiz.market.common.entity.user.SecretSecurityBean;
import com.saic.ebiz.market.common.entity.user.UserBean;
import com.saic.ebiz.market.service.FindPassWordService;

/**
 * 〈一句话功能简述〉找回密码<br>
 * 〈功能详细描述〉 用户可以通过已通过验证的短信、邮件或者密保问题来实现找回密码.
 * 
 */
@Service("findPassWordServiceImpl")
public class FindPassWordServiceImpl implements FindPassWordService {
    
    /** The Constant LOGGER. */
    //private static final Logger LOGGER = LoggerFactory.getLogger(MemberCenterServiceImpl.class);

    /** The i user service. */
    @Resource
    private IUserService iUserService;

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO aliasNameIsUsed(String aliasName, int aliasType, int appCode, SecretSecurityBean ssb, UserBean userBean) {
        // 判断帐号别名是否存在
        ResponseVO responseVO = iUserService.aliasNameIsUsed(aliasName, aliasType, appCode);
        if (responseVO == null ) {
            responseVO = new ResponseVO();
        }
        if (responseVO.getRtnCode() == 101) {
            responseVO.setErrMsg("用户名不存在!");
            responseVO.setRtnCode(9);
            return responseVO;
        }
        
        int phone = 1, email = 2, question = 4, total = 0;
        // 获取用户验证信息 
        try {
            AuthInfoVO authInfoVO = iUserService.getAuthInfo(aliasName, 0, 1);
//            responseVO.setUserId((int)authInfoVO.getResVO().getUserId());
            if (authInfoVO != null) {
                for (AcctAliasVO acctAliasVO : authInfoVO.getAuthList()) {
                    // 2:手机， 3:邮箱
                    if (acctAliasVO.getAliasType() == 2) {
                        // 手机验证
                        total += phone;
                        if (userBean != null) {
                            // 设置手机号码
                            userBean.setPhoneNum(acctAliasVO.getAliasName()); 
                        }
                    } else if (acctAliasVO.getAliasType() == 3) {
                        // 邮件验证
                        total += email;
                        if (userBean != null) {
                            // 设置邮箱号码
                            userBean.setBindEmail(acctAliasVO.getAliasName()); 
                        }
                    }
                }
                // 个人密保问题状态
                if (authInfoVO.getSecurityList() != null && authInfoVO.getSecurityList().size() > 0) {
                    // 密保验证
                    total += question;
                    if (ssb != null && authInfoVO.getSecurityList().size() == 3) {
                            ssb.setQuestionOneId(authInfoVO.getSecurityList().get(0).getQueId().intValue());
                            ssb.setQuestionOne(authInfoVO.getSecurityList().get(0).getQueContent());
                            ssb.setQuestionOneValue(authInfoVO.getSecurityList().get(0).getQueAns());
                            ssb.setQuestionTwoId(authInfoVO.getSecurityList().get(1).getQueId().intValue());
                            ssb.setQuestionTwo(authInfoVO.getSecurityList().get(1).getQueContent());
                            ssb.setQuestionTwoValue(authInfoVO.getSecurityList().get(1).getQueAns());
                            ssb.setQuestionThreeId(authInfoVO.getSecurityList().get(2).getQueId().intValue());
                            ssb.setQuestionThree(authInfoVO.getSecurityList().get(2).getQueContent());
                            ssb.setQuestionThreeValue(authInfoVO.getSecurityList().get(2).getQueAns());
                    }
                }
            }
        } catch (Exception e) {
        //    LOGGER.error("iam-jar getAuthInfo was error !", e);
        }
        ResponseVO rvo = new ResponseVO();
        rvo.setUserId(responseVO.getUserId());
        
        switch (total) {
            case 0:
                rvo.setRtnCode(1);
                rvo.setErrMsg("不绑定任何验证！");
                break;
            case 1:
                rvo.setRtnCode(2);
                rvo.setErrMsg("绑定手机！");
                break;
            case 2:
                rvo.setRtnCode(3);
                rvo.setErrMsg("绑定邮箱！");
                break;
            case 3:
                rvo.setRtnCode(5);
                rvo.setErrMsg("绑定手机和邮箱！");
                break;
            case 4:
                rvo.setRtnCode(4);
                rvo.setErrMsg("绑定密保问题！");
                break;
            case 5:
                rvo.setRtnCode(6);
                rvo.setErrMsg("绑定手机和密保！");
                break;
            case 6:
                rvo.setRtnCode(7);
                rvo.setErrMsg("绑定邮箱和密保！");
                break;
            case 7:
                rvo.setRtnCode(8);
                rvo.setErrMsg("绑定手机、邮箱和密保！");
                break;
            default:
                break;
        } 
       return rvo;

    }
    

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO aliasNameIsUsed(String aliasName, int aliasType, int appCode) {
        return aliasNameIsUsed(aliasName, aliasType, appCode, null, null);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO updatePasswd(Long acctId, String newPasswd, int securityType) {
        ResponseVO rvo = iUserService.updatePasswd(acctId, 1, DigestUtils.md5Hex(newPasswd), securityType);
        if (rvo == null) {
            rvo = new ResponseVO();
            // 100:密码修改成功,101:密码修改失败
            rvo.setRtnCode(101);
        }
        return rvo; 
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseVO verifySecurityInfo(Long acctId, SecretSecurityBean security, int queId, String queContent) {
        ResponseVO rvo = new ResponseVO();
        List<QuestionVO> securityList = new ArrayList<QuestionVO>();
        QuestionVO questionVO = new QuestionVO();
        questionVO.setQueId(security.getQuestionOneId());
        questionVO.setQueAns(security.getQuestionOneValue());
        securityList.add(questionVO);
        questionVO = new QuestionVO();
        questionVO.setQueId(security.getQuestionTwoId());
        questionVO.setQueAns(security.getQuestionTwoValue());
        securityList.add(questionVO);
        questionVO = new QuestionVO();
        questionVO.setQueId(security.getQuestionThreeId());
        questionVO.setQueAns(security.getQuestionThreeValue());
        securityList.add(questionVO);
        try {
            rvo = iUserService.verifySecurityInfo(acctId, securityList);
        } catch (AccountNotFoundException e) {
          //  LOGGER.error("账户不存在", e);
        }
        return rvo;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void setUserBeanInfo(UserBean userBean) {
        String mobil = userBean.getPhoneNum();
        String mail = userBean.getBindEmail();
        // 设置手机信息
        if (mobil != null && mobil.length() > 7) {
            // 手机号4-7位为*号
            userBean.setHidePhone(mobil.substring(0, 3) + "****" + mobil.substring(7));
        }
        
        // 设置邮箱信息
        if (mail != null && mail.indexOf("@") > 0) {
            // 邮箱号@前三位为*，不足三位，则全部为*
            String part = mail.substring(0, mail.indexOf("@"));
            if (part.length() > 3) {
                userBean.setPartMail(part.substring(0, part.length() - 3) + "***" + mail.substring(mail.indexOf("@")));
            } else {
                userBean.setPartMail("***" + mail.substring(mail.indexOf("@")));
            }
        }
    }
}
