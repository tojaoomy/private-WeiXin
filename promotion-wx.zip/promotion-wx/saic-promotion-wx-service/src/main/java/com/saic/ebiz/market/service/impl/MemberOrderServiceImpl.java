package com.saic.ebiz.market.service.impl;
/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: MemberOrderServiceImplMock.java
 * Author:   v_zhuozegang01
 * Date:     2013年12月12日 上午10:45:22
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.carlib.service.client.BrandClient;
import com.saic.ebiz.carlib.service.client.VelColorClient;
import com.saic.ebiz.carlib.service.client.VelImgClient;
import com.saic.ebiz.carlib.service.client.VelModelInfoClient;
import com.saic.ebiz.carlib.service.client.VelSeriesClient;
import com.saic.ebiz.carlib.service.entity.VelAttrImg;
import com.saic.ebiz.carlib.service.entity.VelColor;
import com.saic.ebiz.carlib.service.entity.VelModel;
import com.saic.ebiz.cms.service.api.IImageExtService;
import com.saic.ebiz.cms.service.api.IRTFExtService;
import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.iam.service.entity.AcctAliasVO;
import com.saic.ebiz.iam.service.entity.AuthInfoVO;
import com.saic.ebiz.market.constant.EdaiUrlParamVO;
import com.saic.ebiz.market.constant.MemberAuthInfo;
import com.saic.ebiz.market.constant.MemberBaseInfo;
import com.saic.ebiz.market.constant.MemberCentInfoVO;
import com.saic.ebiz.market.constant.MmsConstants;
import com.saic.ebiz.market.constant.MmsErrorCode;
import com.saic.ebiz.market.constant.PreOrderQueryBean;
import com.saic.ebiz.market.service.MemberOrderService;
import com.saic.ebiz.market.util.DESUtils;
import com.saic.ebiz.mdm.api.IDentityCardService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.IdentityCardVO;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.mdm.metadata.MDMConstants;
import com.saic.ebiz.mdm.partner.client.StoreClient;
import com.saic.ebiz.mdm.partner.entity.StoreDetailInfo;
import com.saic.ebiz.order.service.api.PreOrderQueryService;
import com.saic.ebiz.order.service.entity.dto.PreOrderPmfDetailDTO;
import com.saic.ebiz.order.service.entity.dto.PreOrderQueryCustParamDTO;
import com.saic.ebiz.order.service.entity.dto.PreOrderQueryCustResultDTO;


/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉.
 * 
 * @author v_zhuozegang01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class MemberOrderServiceImpl implements MemberOrderService {

    @Resource
    private IRTFExtService iRTFExtService;

    /** 查询订单接口服务. */
    @Resource
    private PreOrderQueryService preOrderQueryService;


    /** 图片服务类. */
    @Resource
    private IImageExtService iImageExtService;

    /** 用户. */
    @Resource
    private IUserService iUserService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private IDentityCardService iDentityCardService;

    /** 日至服务. */
    private static final Logger logger = LoggerFactory.getLogger(MemberOrderServiceImpl.class);

    /** * 品牌客户端 */
    @Resource
    private BrandClient brandClient;
    /** * 车系客户端. */
    @Resource
    private VelSeriesClient velSeriesClient;
    /** * 车型客户端. */
    @Resource
    private VelModelInfoClient velModelInfoClient;
    /** * 车型图片客户端. */
    @Resource
    private VelImgClient velImgClient;
    /** * 颜色客户端. */
    @Resource
    private VelColorClient velColorClient;
    /** * 经销商客户端. */
    @Autowired
    private StoreClient storeClient;
    
    //秘钥
    private @Value("${ebiz.ms.crypt.des.key}") String desKey;
    
    //好车e贷 url
    private @Value("${ebiz.ms.haochedai.chexiang.url}") String haocxUrl;
    
    //好车e贷适用的车型ids
    private @Value("${ebiz.ms.haochedai.modelids}") String modelIds;
    

    // 认证标识
    /** The Constant AUTHENTICATION. */
    private static final String AUTHENTICATION = "1";

    /** 认证状态 2 表示已认证. */
    private static final int STATUS = 2;

    /** 评价状态：1：已评价. */
    private static final String EVALUATE_FLAG_DONE = "1";

    /** 标记消息首次发送. */
    private static final int SEND_MES_NUM_ZREO = 0;

    /**
     * 功能描述: 查询我的所有订单.<br>
     * 〈功能详细描述〉
     * 
     * @param map 参数
     * @param pageNo 分页
     * @return PaginationResult
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public PaginationResult<List<PreOrderQueryBean>> queryAllOrderByParmes(Long userId, Pagination pageNo) {
        // 接口返回数据集合
        PaginationResult<List<PreOrderQueryCustResultDTO>> pageResultlist = null;
        // 用于传递参数的bean
        PreOrderQueryCustParamDTO porBean = new PreOrderQueryCustParamDTO();
        porBean.setUserId(userId);
        // 调用接口查询所有的订单信息
        try {
            pageResultlist = preOrderQueryService.getCustRelOrderList(porBean, pageNo);
        } catch (Exception e) {
            logger.error("调用查询订单接口出错", e);
        }

        List<PreOrderQueryBean> listQurey = new ArrayList<PreOrderQueryBean>();
        if (pageResultlist != null) {
            for (PreOrderQueryCustResultDTO pb : pageResultlist.getR()) {
                PreOrderQueryBean proBean = new PreOrderQueryBean();
                // 订单编号
                proBean.setPreOrderId(pb.getPreOrderId());

                if (String.valueOf(pb.isTimeOut()).equals("true")) {
                    proBean.setIsTimeOutOrIn("Y");
                } else {
                    proBean.setIsTimeOutOrIn("N");
                }

                // 订单生成时间
                proBean.setCreateTime(pb.getCreateTime());
                // 车型id
                proBean.setVelModelId(pb.getVelModelId());
                // 车型相关资料
                VelModel veBean = null;
                if (pb.getVelModelId() != null) {
                    veBean = this.queryCarModelByCarId(pb.getVelModelId());
                    if (veBean == null) {
                        proBean.setVelModelName(null);
                        proBean.setBrandId(1L);
                        proBean.setBrandNameCh(null);
                        proBean.setVelSeriesId(1L);
                    } else {
                        proBean.setVelModelName(veBean.getVelModelName());
                        proBean.setBrandId(veBean.getVelBrandId());
                        proBean.setBrandNameCh(this.queyBrandNameById(veBean.getVelBrandId()));
                        proBean.setVelSeriesId(veBean.getVelSeriesId());
                    }
                }
                // 车型图片路径
                if (pb.getVelModelId() != null) {
                    VelAttrImg im = null;
                    im = this.queryImageByCarId(pb.getVelModelId());
                    if (im != null) {
                        proBean.setImageUrl(im.getImgPath());
                    } else {
                        proBean.setImageUrl(null);
                    }
                }
                // 车型颜色
                proBean.setColorId(pb.getColorId());
                VelColor verColor = null;
                if (pb.getColorId() != null) {
                    verColor = this.queryColorById(pb.getColorId());
                    if (verColor == null) {
                        proBean.setColorName(null);
                    } else {
                        proBean.setColorName(verColor.getVelColorChsName());
                        proBean.setColorUrl(verColor.getVelColorImgPath());
                    }
                } else {
                    proBean.setColorName(null);
                }
                // 是否车贷
                proBean.setLoanFlag(pb.getLoanFlag());
                // 是否车险
                proBean.setNeedInsuranceFlag(pb.getNeedInsuranceFlag());
                // 是否上牌
                proBean.setRegisterLicenceFlag(pb.getRegisterLicenceFlag());
                // 定金
                proBean.setDeposit(pb.getDeposit());
                // 经销商
                proBean.setStoreId(pb.getStoreId());
                //车系名称
                if (proBean.getVelSeriesId() != null ) {         	         	
                	proBean.setVelSeriesName(this.queyVelSeriesNameById(proBean.getVelSeriesId()));
                }
                //有经销商Id就显示经销商
                if (pb.getStoreId() != null ) {         	         	
                    proBean.setDealerName(this.queyStoreNameById(pb.getStoreId()));
                }
                // 预订单状态编码
                proBean.setStatusCode(pb.getStatusCode());
                // 支付时间
                proBean.setPayTime(pb.getPayTime());
                // 订单类型
                proBean.setType(pb.getType());
                proBean.setInquiryOrderId(pb.getInquiryOrderId());
                // 支付状态
                proBean.setPayStatusCode(pb.getPayStatusCode());
                // 计划到店时间
                proBean.setPlanArrivalTime(pb.getPlanArrivalTime());
                // 数量
                proBean.setAmount(pb.getAmount());
                // 用户
                proBean.setUserId(pb.getUserId());
                proBean.setPrmtDesc(pb.getPrmtDesc());
                proBean.setMarketType(pb.getMarketType());
                proBean.setRefundStatus(pb.getRefundStatus());
                proBean.setRefundStatusMsg(pb.getRefundStatusMsg());
                proBean.setO2oStatus(pb.getO2oStatus());
                proBean.setO2oStatusMsg(pb.getO2oStatusMsg());
                if (pb.getUserId() != null) {
                	MemberCentInfoVO vo = this.queryUserBeanByUserId(pb.getUserId());
                	proBean.setUserName(pb.getUserName());
                	proBean.setMobileNo(pb.getMobileNo());
                	//TODO:过滤符合由好车e贷平台车型及经销商
                	if(pb.getStatusCode().equals("30")){
                		String[] modelid = modelIds.split(",");
                    	for (int i = 0; i < modelid.length; i++) {
        					if(modelid[i].equals(pb.getVelModelId().toString())){
        						proBean.seteDaiUrl(parseEdaiUrl(proBean,vo));
        						break;
        					}
        				}
                	}
                }
                listQurey.add(proBean);
            }
            return  new PaginationResult<List<PreOrderQueryBean>>(listQurey,pageResultlist.getPagination()) ;
        }
        return  new PaginationResult<List<PreOrderQueryBean>>(listQurey,new Pagination()) ;
    }

    
    /**
     * 功能描述: 我的订单贷款详情.<br>
     * 〈功能详细描述〉
     * 
     * @param orderId 订单编号
     * @return PreOrderQueryBean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public PreOrderQueryBean queryOrderDetailByEDai(String orderId) {
        PreOrderQueryBean pro = new PreOrderQueryBean();
        PreOrderPmfDetailDTO proBean = null;
        // 调用接口获取订单明细详情参数
        try {
            proBean = preOrderQueryService.getPmfSettlePreOrder(orderId);
        } catch (Exception e) {
            logger.error("调用接口获取订单明细详情参数异常", e);
        }
        if (proBean != null) {
            pro.setCreateTime(proBean.getCreateTime());
            pro.setDealerId(proBean.getDealerId());
            pro.setStoreId(proBean.getStoreId());
            pro.setDeposit(proBean.getDeposit());
            pro.setPayStatusCode(proBean.getPayStatusCode());
            pro.setPreOrderId(proBean.getPreOrderId());
            pro.setO2oStatus(proBean.getO2oStatus());
            pro.setO2oStatusMsg(proBean.getO2oStatusMsg());
            pro.setStatusCode(proBean.getStatusCode());
            pro.setType(proBean.getType());
            pro.setVelModelId(proBean.getVelModelId());
        	pro.setPrmtDesc(proBean.getPrmtDesc());
            pro.setMobileNo(proBean.getMobileNo());
            if (proBean.getUserId() != null) {
            	pro.setUserId(Long.valueOf(proBean.getUserId()));
            	pro.setUserName(proBean.getCustName());
            	pro.setMobileNo(proBean.getMobileNo());
            	MemberCentInfoVO vo = this.queryUserBeanByUserId(Long.valueOf(proBean.getUserId()));
            	//TODO:过滤符合由好车e贷平台车型及经销商
            	if(proBean.getStatusCode().equals("13")){
            		String[] modelid = modelIds.split(",");
                	for (int i = 0; i < modelid.length; i++) {
    					if(modelid[i].equals(proBean.getVelModelId().toString())){
    						pro.seteDaiUrl(parseEdaiUrl(pro,vo));
    						break;
    					}
    				}
            	}
            }
        }
        return pro;
    }
    
    /**
     * 功能描述: 我的订单详情.<br>
     * 〈功能详细描述〉
     * 
     * @param orderId 订单编号
     * @param userId 用户
     * @return PreOrderQueryBean
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public PreOrderQueryBean queryOrderDetailByParmes(String orderId, long userId) {
        PreOrderQueryBean pro = new PreOrderQueryBean();
        PreOrderQueryCustResultDTO proBean = null;
        // 调用接口获取订单明细详情参数
        try {
            proBean = preOrderQueryService.getCustRelMembNumPreOrder(orderId, userId);
        } catch (Exception e) {
            logger.error("调用接口获取订单明细详情参数异常", e);
        }
        if (proBean != null) {
            pro.setAmount(proBean.getAmount());
            pro.setAppName(proBean.getUserName());
            pro.setColorId(proBean.getColorId());
            pro.setCreateTime(proBean.getCreateTime());
            pro.setDealerId(proBean.getDealerId());
            pro.setStoreId(proBean.getStoreId());
            pro.setMarketType(proBean.getMarketType());
            pro.setDeposit(proBean.getDeposit());
            pro.setLoanFlag(proBean.getLoanFlag());
            pro.setNeedInsuranceFlag(proBean.getNeedInsuranceFlag());
            pro.setPayStatusCode(proBean.getPayStatusCode());
            pro.setPayTime(proBean.getPayTime());
            pro.setPlanArrivalTime(proBean.getPlanArrivalTime());
            pro.setPreOrderId(proBean.getPreOrderId());
            pro.setRegisterLicenceFlag(proBean.getRegisterLicenceFlag());
            pro.setRefundStatus(proBean.getRefundStatus());
            pro.setRefundStatusMsg(proBean.getRefundStatusMsg());
            pro.setO2oStatus(proBean.getO2oStatus());
            pro.setO2oStatusMsg(proBean.getO2oStatusMsg());
            pro.setArriveTime(proBean.getArriveTime());
            pro.setStatusCode(proBean.getStatusCode());
            pro.setTimeOutMinute(proBean.getTimeOutMinute());
            pro.setType(proBean.getType());
            pro.setInquiryOrderId(proBean.getInquiryOrderId());
            pro.setUserId(proBean.getUserId());
            pro.setVelModelId(proBean.getVelModelId());
        	pro.setPrmtDesc(proBean.getPrmtDesc());
            pro.setUserName(proBean.getUserName());
            pro.setMobileNo(proBean.getMobileNo());
            pro.setBatchGift(proBean.getBatchGift());
            pro.setGlobalGift(proBean.getGlobalGift());
            pro.setCarType(proBean.getCarType());
            if (String.valueOf(proBean.isTimeOut()).equals("true")) {
                pro.setIsTimeOutOrIn("Y");
            } else {
                pro.setIsTimeOutOrIn("N");
            }
            //颜色图片路径
            VelColor color = null;
            color = velColorClient.findColorByColorId(proBean.getColorId());
            if(color != null){
            	pro.setColorName(color.getVelColorChsName());
            	pro.setColorUrl(color.getVelColorImgPath());
            }
            // 车型图片路径
            VelAttrImg im = null;
            im = this.queryImageByCarId(proBean.getVelModelId());
            if (im != null) {
                pro.setImageUrl(im.getImgPath());
            } else {
                pro.setImageUrl(null);
            }
            // 车型相关资料
            VelModel veBean = null;
            veBean = this.queryCarModelByCarId(proBean.getVelModelId());
            if (veBean != null) {
                pro.setVelModelName(veBean.getVelModelName());
                pro.setBrandId(veBean.getVelBrandId());
                pro.setVelSeriesId(veBean.getVelSeriesId());
                pro.setBrandNameCh(this.queyBrandNameById(veBean.getVelBrandId()));
            }
            //车系名称
            if (pro.getVelSeriesId() != null ) {         	         	
            	pro.setVelSeriesName(this.queyVelSeriesNameById(pro.getVelSeriesId()));
            }
            //经销商名称
            if (proBean.getStoreId() != null ) {         	         	
                pro.setDealerName(this.queyStoreNameById(proBean.getStoreId()));
            }
            if (proBean.getUserId() != null) {
            	MemberCentInfoVO vo = this.queryUserBeanByUserId(proBean.getUserId());
            	pro.setCertType(vo.getMemberBaseInfo().getCertType());
            	pro.setHideCateNo(vo.getMemberBaseInfo().getCertNo());
            	//TODO:过滤符合由好车e贷平台车型及经销商
            	if(proBean.getStatusCode().equals("30")){
            		String[] modelid = modelIds.split(",");
                	for (int i = 0; i < modelid.length; i++) {
    					if(modelid[i].equals(proBean.getVelModelId().toString())){
    						pro.seteDaiUrl(parseEdaiUrl(pro,vo));
    						break;
    					}
    				}
            	}
            }
        }

        return pro;
    }

    
    /**
     * 功能描述: 根据会员id获取会员的基本信息.<br>
     * 〈功能详细描述〉
     * 
     * @param userId 会员id
     * @return MemberCentInfoVO
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public MemberCentInfoVO queryUserBeanByUserId(long userId) {
    	MemberCentInfoVO vo = new MemberCentInfoVO();
        logger.info("findMembCentInfo()获取或创建会员基本信息,入参会员编码={}：" + userId);
        
        vo.setMemberBaseInfo(findMemberInfo(userId));
        vo.setMemberAuthInfo(findMemberAuthInfo(userId));
        return vo;
    }
    
    /**
     * 
     * 功能描述: <br>
     * 查询会员基本信息
     *
     * @param userId 会员编号
     * @return MemberEntity 会员基本信息实体
     * @see 无
     * @since 无
     */
    private MemberBaseInfo findMemberInfo(long userId) {
        MemberBaseInfo entity = new MemberBaseInfo();
        entity.setUserId(userId);
        /****封装MemberEntity对象****/
        UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(userId);
        entity.setUserType(userBaseInfoVO.getType());
        entity.setUserId(userBaseInfoVO.getUserId());
        entity.setRealName(userBaseInfoVO.getName());
        entity.setNickName(userBaseInfoVO.getNickName());
        entity.setGender(userBaseInfoVO.getSexualty());
        entity.setBirthDate(userBaseInfoVO.getBirthday());
        entity.setCertNo(userBaseInfoVO.getIdNumber());
        entity.setIdNumberId(userBaseInfoVO.getIdNumberId());
        entity.setMobile(userBaseInfoVO.getMobile());
        entity.setMobileId(userBaseInfoVO.getMobileId());
        entity.setEmail(userBaseInfoVO.getEmail());
        entity.setEmailId(userBaseInfoVO.getEmailId());
        entity.setProvince(userBaseInfoVO.getProvince());
        entity.setCity(userBaseInfoVO.getCity());
        entity.setTown(userBaseInfoVO.getDistrict());
        entity.setAddress(userBaseInfoVO.getAddress());
        entity.setAddressId(userBaseInfoVO.getAddressId());
        entity.setZipCode(userBaseInfoVO.getZipCode());
        entity.setPhotoUrl(userBaseInfoVO.getPhotoUrl());
        entity.setIdentityCardValid(isValidIdentitiyCard(entity.getIdNumberId()));
        return entity;
    }
    
    public MemberAuthInfo findMemberAuthInfo(Long userId) {
        //存放从IAM查询得到的AcctAliasVO对象
        MemberAuthInfo memberAuthInfo=new MemberAuthInfo();
        try {
            logger.info("getAuthInfo()方法开始请求IAM服务获取认证信息，入参会员编码userId={}：" + userId);
            /**调用IAM系统方法,第三个参数appId赋值为1*/
            AuthInfoVO authInfoVO = iUserService.getAuthInfo(null, userId, MmsConstants.IAM_APP_ID);
            logger.info("getAuthInfo()方法请求IAM服务后获取到的会员认证信息={}" + authInfoVO.getAuthList());
            /**查询IAM系统,获取会员认证信息*/
            if (CollectionUtils.isNotEmpty(authInfoVO.getAuthList())){
                boolean auth=false;
                for(AcctAliasVO acctAliasVO:authInfoVO.getAuthList()){
                    auth=(MmsConstants.IS_AUTH==acctAliasVO.getStatus());
                    switch(acctAliasVO.getAliasType()){
                        case MmsConstants.AUTH_USER_NAME:
                            memberAuthInfo.setUserName(acctAliasVO.getAliasName());
                            break;
                        case MmsConstants.AUTH_MOBILE:
                            memberAuthInfo.setMobile(acctAliasVO.getAliasName());
                            memberAuthInfo.setMobileAuthFlag(auth);
                            break;
                        case MmsConstants.AUTH_EMAIL:
                            memberAuthInfo.setEmail(acctAliasVO.getAliasName());
                            memberAuthInfo.setEmailAuthFlag(auth);
                            break;
                    }
                }
            }
            
            memberAuthInfo.setSecurityFlag(CollectionUtils.isNotEmpty(authInfoVO.getSecurityList()));
            memberAuthInfo.setSecurityType(authInfoVO.getSecurityType());
        }catch(Exception e){
            logger.error("调用方法{} 异常,错误信息：{} 【 {}】","getAuthInfo", MmsErrorCode.MEMB_CODE_QUERY_AUTH_IN_IAM_ERROR,   e.getMessage());
        }
        return memberAuthInfo;
    }
    
    /**
     * 功能描述: <br>
     * 身份证是否验证
     *
     * @param idNumberId
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private boolean isValidIdentitiyCard(Long idNumberId){
        if(null==idNumberId){
            return false;
        }
        IdentityCardVO identityCardVO= iDentityCardService.findIdentityCardById(idNumberId);
        return (null!=identityCardVO &&  MDMConstants.GLOBAL_VERIFICATION.TRUE.getCode().equals(identityCardVO.getVerification()));
    }
    
    /**
     * 功能描述: 根据车型ID获取车型的相关信息.<br>
     * 〈功能详细描述〉
     * 
     * @param carId 车型
     * @return VelModelDropDownItem
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */

    private VelModel queryCarModelByCarId(long carId) {
        VelModel veBean = null;
        // 调用接口服务获取车型的信息
        veBean = velModelInfoClient.findVelModelById(carId);
        return veBean;
    }
    
    
    /**
     * 功能描述: 根据车型ID获取车型的图片.<br>
     * 〈功能详细描述〉
     * 
     * @param carId 车型
     * @return VelModelDropDownItem
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private VelAttrImg queryImageByCarId(long carId) {
        return velImgClient.findCoverVelImageExtById(carId);
    }

    /**
     * 功能描述: 根据颜色ID获取车型的颜色.<br>
     * 〈功能详细描述〉
     * 
     * @param colorId 颜色
     * @return VelSeriesColorImage
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private VelColor queryColorById(long colorId) {
        // 调用车辆颜色服务接口
        return velColorClient.findColorByColorId(colorId);
    }

    /**
     * 功能描述: 获取经销商.<br>
     * 〈功能详细描述〉
     * 
     * @param storeId the store id
     * @return StoreDropDownItem
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private String queyStoreNameById(long storeId) {
        // 调用经销商服务接口
        return storeClient.findStoreNamebyId(storeId);
    }

    /**
     * 功能描述: 获取车系名称.<br>
     * 〈功能详细描述〉
     * 
     * @param velSeriesId the velSeries id
     * @return VelSeriesName
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private String queyVelSeriesNameById(long velSeriesId) {
    	return velSeriesClient.findSeriesById(velSeriesId).getVelSeriesChsName();
    }
    
    
    /**
     * 功能描述: 获取品牌名称.<br>
     * 〈功能详细描述〉
     * 
     * @param brandId the brand id
     * @return brandName
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private String queyBrandNameById(long brandId) {
    	return brandClient.findBrandById(brandId).getVelBrandChsName();
    }
    
   
    
    /**
     * 功能描述: 根据图片id获取图片路径.<br>
     * 〈功能详细描述〉
     * 
     * @param imageId 图片
     * @return the string
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String queryImage(Long imageId) {
        // 图片路径
        String pathUrl = "";
        try {
            List<com.saic.ebiz.cms.service.vo.Image> imageList = iImageExtService.findImgs(Lists.newArrayList(imageId));
            if (CollectionUtils.isNotEmpty(imageList)) {
                pathUrl = imageList.get(SEND_MES_NUM_ZREO).getPath();
            }
        } catch (Exception e) {
            logger.error("调用获取图片接口异常", e);
        }
        
        return pathUrl;
    }
  
    /**
     * {@inheritDoc}
     */
    public List<PreOrderQueryBean> queryApplPreOrder(List<PreOrderQueryBean> orderList, Long userId) {
        List<PreOrderQueryBean> list = new ArrayList<PreOrderQueryBean>();
        for (PreOrderQueryBean preOrderQueryBean : orderList) {
            String orderId = preOrderQueryBean.getPreOrderId();
            // 默认尚未提交认证申请
            preOrderQueryBean.setAuthRequest(true);
            preOrderQueryBean.setCheckCode(STATUS);
            preOrderQueryBean.setAuthentication(AUTHENTICATION);
            // 设置评价状态
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("userId", userId);
            params.put("itemId", orderId);
            preOrderQueryBean.setIscomment(EVALUATE_FLAG_DONE);
            list.add(preOrderQueryBean);
        }
        return list;
    }
    private String parseEdaiUrl(PreOrderQueryBean pb,MemberCentInfoVO mv){
    	EdaiUrlParamVO urlParam = new EdaiUrlParamVO();
    	urlParam.setName(null!=pb.getUserName()?pb.getUserName():(null!=mv.getMemberBaseInfo().getRealName()?mv.getMemberBaseInfo().getRealName():""));
    	urlParam.setMphone(null!=pb.getMobileNo()?pb.getMobileNo():(null!=mv.getMemberBaseInfo().getMobile()?mv.getMemberBaseInfo().getMobile():""));
    	urlParam.setVelmodelid(null!=pb.getVelModelId()?pb.getVelModelId().toString():"");
    	urlParam.setAddr(null!=mv.getMemberBaseInfo().getAddress()?mv.getMemberBaseInfo().getAddress():"");
    	urlParam.setApplyid(String.valueOf(System.currentTimeMillis()).concat(pb.getPreOrderId()));
    	urlParam.setClient("wechat");
    	String dealerCode="";
    	if(null!=pb.getStoreId()){
    		StoreDetailInfo storeBean = storeClient.findStoreDetailByStoreId(Long.valueOf(pb.getStoreId()));
    		dealerCode = storeBean.getDelaerCode();
    	}
    	urlParam.setDealerid(dealerCode);
    	String encryptJson="";
		try {
			encryptJson = DESUtils.encrypt(JSONObject.toJSONString(urlParam), desKey);
			encryptJson = haocxUrl+encryptJson;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
    	return encryptJson;
    }
  
}
