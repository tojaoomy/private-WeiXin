/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.framework.web.freemarker.MultiDomUrl;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.carlib.service.client.BrandClient;
import com.saic.ebiz.carlib.service.client.VelColorClient;
import com.saic.ebiz.carlib.service.client.VelModelInfoClient;
import com.saic.ebiz.carlib.service.client.VelSeriesClient;
import com.saic.ebiz.carlib.service.entity.VelColor;
import com.saic.ebiz.carlib.service.entity.VelModelColorExt;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.entity.InquiryOrderVO;
import com.saic.ebiz.market.service.OrderService;
import com.saic.ebiz.mdm.partner.client.StoreClient;
import com.saic.ebiz.mdm.partner.entity.StoreBaseInfo;
import com.saic.ebiz.order.entity.BrandVO;
import com.saic.ebiz.order.entity.ColorImageVO;
import com.saic.ebiz.order.entity.ProductVO;
import com.saic.ebiz.order.entity.PromotionCity;
import com.saic.ebiz.order.entity.PromotionStore;
import com.saic.ebiz.order.entity.SeriesVO;
import com.saic.ebiz.promotion.service.api.IPreOrderPromotionService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionMerchandiseService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.api.IQuotaFacadeService;
import com.saic.ebiz.promotion.service.vo.CxgMerchandiseVO;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionMerchandise;
import com.saic.ebiz.promotion.service.vo.PromotionQualification;
import com.saic.ebiz.promotion.service.vo.StoreVO;

import freemarker.template.TemplateModelException;

/**
 * @author hejian
 * 
 */
@Service("orderService")
public class OrderServiceImpl implements OrderService {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
//	/** 缓存接口. */
//	@Resource(name = "springRedisClient")
//	private IRedisClient redisClient;

    /** The fm img url. */
    @Resource
    private MultiDomUrl fmImgUrl;
    
    //venus接口
    /**
     * 活动客户端
     */
    @Resource
    private IPromotionService iPromotionService;
    /**
     * 品牌客户端
     */
    @Resource
    private BrandClient brandClient;
    /**
     * 车系客户端
     */
    @Resource
    private VelSeriesClient velSeriesClient;
    
    /**
     * 车型客户端
     */
    @Resource
    private VelModelInfoClient velModelInfoClient;
    
    /**
     * 车型颜色的图片
     */
    @Autowired
    private VelColorClient velColorClient;
    
    /** 检查配额新服务接口 */
    @Autowired
    private IQuotaFacadeService quotaFacadeService;
    
    @Resource
    private IPromotionMerchandiseService iPromotionMerchandiseService;
    
    /** 获取新活动扩展信息 */
	@Resource
	private IPromotionExtendService iPromotionExtendService;
	
	@Resource
	private IPreOrderPromotionService iPreOrderPromotionService;
	
	@Resource
	private IPromotionQualificationService iPromotionQualificationService;
    
    @Resource(name="storeClient")
    private StoreClient storeClient;
    
    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getPromotionBrand(long)
     */
//    public List<PromotionBrand> getPromotionBrand(long promotionID) {
//        List<PromotionBrand> promotionBrandList = new ArrayList<PromotionBrand>();
//        List<PromotionMerchandise> tempList = getPromotionMerchandiseList(promotionID);
//        Set<Long> brandIdSet = new HashSet<Long>();
//        for(PromotionMerchandise promotionMerchandise : tempList){
//            long brandId = promotionMerchandise.getVelBrandId();
//            if(!brandIdSet.contains(brandId)){
//                brandIdSet.add(brandId);
//                PromotionBrand promotionBrand = new PromotionBrand();
//                promotionBrand.setBrandId(brandId);
//                promotionBrand.setBrandName(brandClient.findBrandNameById(brandId));
//                promotionBrandList.add(promotionBrand);
//            }
//        }
//        return promotionBrandList;
//    }

    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getPromotionSeries(long)
     */
//    public List<PromotionSeries> getPromotionSeries(long promotionID,long brandId) {
//        List<PromotionSeries> promotionSeriesList = new ArrayList<PromotionSeries>();
//        List<PromotionMerchandise> tempList = getPromotionMerchandiseList(promotionID);
//        Set<Long> seriesIdSet = new HashSet<Long>();
//        for(PromotionMerchandise promotionMerchandise : tempList){
//            long seriesId = promotionMerchandise.getVelSeriesId();
//            if(!seriesIdSet.contains(seriesId)&&promotionMerchandise.getVelBrandId().compareTo(brandId)==0){
//                seriesIdSet.add(seriesId);
//                PromotionSeries promotionSeries = new PromotionSeries();
//                promotionSeries.setSeriesId(seriesId);
//                promotionSeries.setSeriesName(velSeriesClient.findSeriesNameById(seriesId));
//                promotionSeriesList.add(promotionSeries);
//            }
//        }
//        return promotionSeriesList;
//    }

    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getPromotionModel(long)
     */
//    public List<PromotionModel> getPromotionModel(long promotionID,long seriesId) {
//        List<PromotionModel> promotionModelList = new ArrayList<PromotionModel>();
//        List<PromotionMerchandise> tempList = getPromotionMerchandiseList(promotionID);
//        Set<Long> modelIdSet = new HashSet<Long>();
//        for(PromotionMerchandise promotionMerchandise : tempList){
//            long modelId = promotionMerchandise.getVelModelId();
//            if(!modelIdSet.contains(modelId)&&promotionMerchandise.getVelSeriesId().compareTo(seriesId)==0){
//                modelIdSet.add(modelId);
//                PromotionModel modelSeries = new PromotionModel();
//                modelSeries.setModelId(modelId);
//                modelSeries.setModelName(velModelInfoClient.findModelNameById(modelId));
//                promotionModelList.add(modelSeries);
//            }
//        }
//        return promotionModelList;
//    }

    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getPromotionModelColor(long)
     */
//    public List<PromotionModelColor> getPromotionModelColor(long promotionID,long modelId) {
//        List<PromotionModelColor> promotionModelColorList = new ArrayList<PromotionModelColor>();
//        List<PromotionMerchandise> tempList = getPromotionMerchandiseList(promotionID);
//        Set<Long> modelColorIdSet = new HashSet<Long>();
//        for(PromotionMerchandise promotionMerchandise : tempList){
//            long tempModelId = promotionMerchandise.getVelModelId();
//            Long colorID = promotionMerchandise.getColorId();
//            if(colorID != null){
//                long tempColorId = Long.valueOf(colorID);
//                if(!modelColorIdSet.contains(tempColorId)&&tempModelId==modelId){
//                    modelColorIdSet.add(tempColorId);
//                    PromotionModelColor promotionModelColor = new PromotionModelColor();
//                    promotionModelColor.setColorId(tempColorId);
//                    VelColor velColor = velColorClient.findColorByColorId(tempColorId);
//                    promotionModelColor.setColorName(velColor.getVelColorChsName());
//                    promotionModelColor.setColorImgUrl(velColor.getVelColorImgPath());
//                    promotionModelColorList.add(promotionModelColor);
//                }
//             //得到全部颜色
//            }else{
//                VelModelColorExt velModelColorExt = velModelInfoClient.findModelWithColorById(modelId);
//                List<VelColor> list = velModelColorExt.getVelColors();
//                for (VelColor velColor : list) {
//                    long tempColorId = velColor.getVelColorId();
//                    if(!modelColorIdSet.contains(tempColorId)){
//                        modelColorIdSet.add(tempColorId);
//                        PromotionModelColor promotionModelColor = new PromotionModelColor();
//                        promotionModelColor.setColorId(tempColorId);
//                        promotionModelColor.setColorName(velColor.getVelColorChsName());
//                        promotionModelColor.setColorImgUrl(velColor.getVelColorImgPath());
//                        promotionModelColorList.add(promotionModelColor);
//                    }
//                }
//            }
//           
//        }
//        return promotionModelColorList;
//    }

    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getPromotionCity()
     */
//    @Override
//    public List<PromotionCity> getPromotionCity(long promotionID,long productId,long colorId) {
//        List<StoreBaseInfo> storeBaseInfoList = getPromStroeBaseInfo(promotionID,productId,colorId);
//        List<PromotionCity> promotionCityList= new ArrayList<PromotionCity>();
//        Set<Long> storeIdSet = new HashSet<Long>();
//        for (StoreBaseInfo storeBaseInfo : storeBaseInfoList) {
//            long cityId = storeBaseInfo.getCityId();
//            if(storeIdSet.contains(cityId)){
//                continue;
//            }
//            storeIdSet.add(cityId);
//            PromotionCity promotionCity = new PromotionCity();
//            promotionCity.setValue(cityId);
//            //拿到城市的名称
//            String cityName = ConstantCodeService.getRegionNameByCode(String.valueOf(cityId));
//            promotionCity.setText(cityName);
//            promotionCityList.add(promotionCity);
//        }
//        return promotionCityList;
//    }
    
    
    @Override
	public List<PromotionCity> getCityOnly(Long promotionId,Long vehicleModelId,Long colorId){
		Map<Long,List<Long>> provinceCityMap = iPromotionQualificationService.getCityMapByPromotionIdVelModelId(promotionId, vehicleModelId,colorId);
		Collection<List<Long>> values = provinceCityMap.values();
		//存放所有的城市ID
		List<Long> cityIdList = new ArrayList<Long>();
		Iterator<List<Long>> it = values.iterator();
		while(it.hasNext()){
			cityIdList.addAll(it.next());
		}
		//根据城市ID排序，以防出现乱序的情形
		Collections.sort(cityIdList);
		List<PromotionCity> cities = new ArrayList<PromotionCity>();
		for(Long cityId : cityIdList){
			DataItemBean dataItemBean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
			if (dataItemBean != null) {
				PromotionCity cityVO = new PromotionCity();
				cityVO.setText(dataItemBean.getName());
				cityVO.setValue(Long.valueOf(dataItemBean.getCode()));
				//设置省份为-1和上面同步
				cities.add(cityVO);
			}
		}
		return cities;
	}

    @Override
	public List<PromotionStore> getDealerStoreList(Long promotionId,
			Long vehicleModelId, Long colorId,Long cityId) {
		BigDecimal deposit = getPromotionDeposit(promotionId);
		// call interface provided by others PS:
		List<StoreVO> stores = this.iPreOrderPromotionService.getStoreListByPrmtModelColor(promotionId, vehicleModelId, colorId);
		List<PromotionStore> storeList = new ArrayList<PromotionStore>();
		
		StoreBaseInfo store = null;
		for (StoreVO entity : stores) {
			try {
				//if findStoresByStoresIds 返回空list，会报异常信息
				store = this.storeClient.findStoresByStoresIds(entity.getStoreId()).get(0);
			} catch (Exception ex) {
				ex.printStackTrace();
				this.log.info("storeClient.findStoresByStoresIds 返回空list");
				continue;
			}
			
			PromotionStore promotionStore = new PromotionStore();
			promotionStore.setAddress(store.getAddress());
			promotionStore.setLatitude(store.getLatitude());
			promotionStore.setLongitude(store.getLongitude());
			promotionStore.setStoreId(store.getStoreId());
			promotionStore.setStoreName(store.getStoreName());
			promotionStore.setDeposit(deposit);
			promotionStore.setPhoneNumber(store.getHotLine());
			promotionStore.setStock(entity.getAvailableNum());
			promotionStore.setQq(entity.getQq());
			
			long storeCityId = store.getCityId();
			//only is this city,add to list
			if (storeCityId == cityId) {
				storeList.add(promotionStore);
			}
		}
		this.log.info("车享购获取经销商列表:",JSONObject.toJSONString(storeList));
		return storeList;
	}

    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getPromotionDeposit(long, long)
     */
    @Override
    public BigDecimal getPromotionDeposit(long promotionID) {
    	return iPromotionExtendService.findPromotionExtendByPromotionId(promotionID).getDeposit();
    }

    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getModelList(long)
     */
    @Override
    public List<BrandVO> getModelList(Promotion promotion,long subscriptionId){
    	Integer modeType = promotion.getQuotaMode();
        log.info("配额模式  : " + (modeType == null ? "-1 " : (modeType + " ")) +  Constants.QUOTA_MAP.get(modeType));
        if(modeType == null){
        	modeType = -1;
        }
        List<BrandVO> brandVOs = null;
        switch(modeType){
        	//总配额模式
        	case Constants.TOTAL_QUOTA_MODE :
        		brandVOs =  getModelAtTotalQuoatMode(promotion,subscriptionId);
        		break;
        	default :
        		brandVOs = getModelAtSeriesColorDealerQuoatMode(promotion);
        }
        return brandVOs;
    }

    
    @SuppressWarnings("deprecation")
	private List<BrandVO> getModelAtTotalQuoatMode(Promotion promotion,long subscriptionId){
    	//秒杀和拍卖时，使用getPromotionWithQualification()方法
    	//该方法必须获取qualification资格信息
//    	promotion = this.iPromotionService.getPromotionExt(promotion.getPromotionId(), true, false, true);
    	
    	//总配额模式需要查询所有的PromotionQualifacation
    	promotion = this.iPromotionService.getPromotionExt(promotion.getPromotionId(), true, false,true);
    	
    	List<BrandVO> brandVOList = new ArrayList<BrandVO>();
    	List<SeriesVO> seriesVOList = new ArrayList<SeriesVO>();
    	List<ProductVO> productVOList = new ArrayList<ProductVO>();
    	Map<Long,ProductVO> productVOMap = new HashMap<Long,ProductVO>();
    	Map<Long,SeriesVO> seriesVOMap = new HashMap<Long,SeriesVO>();
    	//check null pointer
    	if(promotion.getPromotionMerchandises() == null || promotion.getPromotionMerchandises().size() == 0){
    		return null;
    	}
		Long prmtMdseId = promotion.getPromotionMerchandises().get(0).getPrmtMdseId();
		int availableNum = quotaFacadeService.findAvailableNum(prmtMdseId.intValue());
		log.info("-=-=-=-=-=-=-=-=-=-=-可用配额剩余 : " + availableNum);
		if(availableNum < 1){
			return null;
    	}
    	List<PromotionQualification> promotionQualifications = promotion.getPromotionQualifications();
    	//品牌ID集合
    	Set<Long> brandIds = new HashSet<Long>();
    	//车系ID集合
    	Set<Long> seriesIds = new HashSet<Long>();
    	//车型ID集合
    	Set<Long> modelIds = new HashSet<Long>();
    	
    	//匹配所有的车型
    	for (PromotionQualification promotionQualification : promotionQualifications) {
            long modelId = promotionQualification.getVelModelId();
            if(modelIds.contains(modelId)){
                continue;
            }
            String modelName = velModelInfoClient.findModelNameById(modelId);
            ProductVO productVO = new ProductVO();
            productVO.setValue(modelId);
            productVO.setText(modelName);
            //设置该车型所有的颜色
            productVO.setChildren(getColorImageVOListByPromotionQualification(modelId,promotionQualifications));
            productVOList.add(productVO);
            productVOMap.put(modelId, productVO);
            modelIds.add(modelId);
        }
    	
    	//设置所有的车系
    	for (PromotionQualification promotionQualification : promotionQualifications) {
    		long seriesId = promotionQualification.getVelSeriesId();
    		if(seriesIds.contains(seriesId)){
    			continue;
    		}
    		SeriesVO seriesVO = new SeriesVO();
    		seriesVO.setText(velSeriesClient.findSeriesNameById(seriesId));
    		seriesVO.setValue(seriesId);
    		seriesVO.setChildren(getProductVOList(seriesId,promotionQualifications,productVOMap));
    		seriesVOList.add(seriesVO);
    		seriesVOMap.put(seriesId, seriesVO);
    		seriesIds.add(seriesId);
    	}
    	
    	//设置所有的品牌
    	for(PromotionQualification pq : promotionQualifications){
    		Long brandId = pq.getVelBrandId();
    		if(brandIds.contains(brandId)){
    			continue;
    		}
    		BrandVO brandVO = new BrandVO();
    		brandVO.setValue(pq.getVelBrandId());
            brandVO.setText(brandClient.findBrandNameById(pq.getVelBrandId()));
            brandVO.setChildren(getSeriesVOList(brandId,promotionQualifications,seriesVOMap));
            brandVOList.add(brandVO);
            brandIds.add(brandId);
    	}
    	return brandVOList;
    }
    
    
    private List<BrandVO> getModelAtSeriesColorDealerQuoatMode(Promotion promotion){
        //从右向左。先获取所有的车型数据，在通过车型的车系，再查询品牌
        Set<Long> modelIdSets = new HashSet<Long>();
        List<ProductVO> productChildren = new ArrayList<ProductVO>();
        List<CxgMerchandiseVO> merchandiseList = iPromotionQualificationService.getVelModelColorForCxgBySeries(promotion.getPromotionId(),null,null);
    	if(merchandiseList==null || merchandiseList.size()==0){
        	return null;
        }
        for(CxgMerchandiseVO cxgMerchandiseVO : merchandiseList){
        	Long modelId = cxgMerchandiseVO.getVelModelId();
        	if(!modelIdSets.contains(modelId)){
        		//设置所有的车型
        		modelIdSets.add(modelId);
        		//为了后面，遍历品牌方便获取PromotionMerchandise
        		String modelName = velModelInfoClient.findModelNameById(modelId);
                log.info("modelName == " + modelName);
                ProductVO productVO = new ProductVO();
                productVO.setValue(modelId);
                productVO.setText(modelName);
                productVO.setSeriesId(cxgMerchandiseVO.getVelSeriesId());
                productVO.setBrandId(cxgMerchandiseVO.getVelBrandId());
                //通过车型获取所有的颜色
                List<Long> colorIds = this.iPromotionQualificationService.getVelModelColorMap(promotion.getPromotionId()).get(modelId);
                //颜色配额的过滤
                List<Long> temp = new ArrayList<Long>();
                for (int i = 0; i < colorIds.size(); i++) {
                	List<StoreVO> stores = this.iPreOrderPromotionService.getStoreListByPrmtModelColor(promotion.getPromotionId(), modelId, colorIds.get(i));
                	if(stores != null && stores.size() > 0){
                		temp.add(colorIds.get(i));
                	}
				}
              //设置所有该车型的颜色
                productVO.setChildren(getColorImageVOList(modelId,temp));
                productChildren.add(productVO);
        	}
        }
        
        List<SeriesVO> children = new ArrayList<SeriesVO>();
        Map<Long,List<ProductVO>> productVOMap = new HashMap<Long, List<ProductVO>>();
        //根据车系id做一棵树
        for(ProductVO productVO : productChildren){
        	if(productVOMap.containsKey(productVO.getSeriesId())){
        		productVOMap.get(productVO.getSeriesId()).add(productVO);
        	}else{
        		List<ProductVO> productVOList = new ArrayList<ProductVO>();
        		productVOList.add(productVO);
        		productVOMap.put(productVO.getSeriesId(),productVOList);
        	}
        }
        
        //然后遍历车系列表，获取所有的车型数据
        Iterator<Long> it = productVOMap.keySet().iterator();
        while(it.hasNext()){
        	SeriesVO seriesVO = new SeriesVO();
        	Long id = it.next();
            seriesVO.setValue(id);
            seriesVO.setText(velSeriesClient.findSeriesNameById(id));
            seriesVO.setChildren(productVOMap.get(id));
            //车系的品牌id肯定相同
            seriesVO.setBrandId(productVOMap.get(id).get(0).getBrandId());
            children.add(seriesVO);
        }
        
        List<BrandVO> brandVOList = new ArrayList<BrandVO>();
        Map<Long,List<SeriesVO>> seriesVOMap = new HashMap<Long, List<SeriesVO>>();
        
        //根据品牌遍历
        for(SeriesVO seriesVO : children){
        	if(seriesVOMap.containsKey(seriesVO.getBrandId())){
        		seriesVOMap.get(seriesVO.getBrandId()).add(seriesVO);
        	}else{
        		List<SeriesVO> seriesVOList = new ArrayList<SeriesVO>();
        		seriesVOList.add(seriesVO);
        		seriesVOMap.put(seriesVO.getBrandId(),seriesVOList);
        	}
        }
        
        Iterator<Long> ite = seriesVOMap.keySet().iterator();
        while(ite.hasNext()){
        	BrandVO brandVO = new BrandVO();
        	Long id = ite.next();
            brandVO.setValue(id);
            brandVO.setText(brandClient.findBrandNameById(id));
            brandVO.setChildren(seriesVOMap.get(id));
            //车系的品牌id肯定相同
            brandVOList.add(brandVO);
        }
        
        return brandVOList;
	}
    
    
    private List<ProductVO> getProductVOList(long seriesId,
			List<PromotionQualification> promotionQualifications,
			Map<Long, ProductVO> productVOMap) {
    	Set<Long> productSet = new HashSet<Long>();
    	List<ProductVO> productVOList = new ArrayList<ProductVO>();
    	Long tempSeriesId;
    	for (PromotionQualification promotionQualification : promotionQualifications) {
    		tempSeriesId = promotionQualification.getVelSeriesId();
    		if(tempSeriesId.equals(seriesId)){
    			Long modelId = promotionQualification.getVelModelId();
    			if(productSet.contains(modelId)){
    				continue;
    			}
    			if(modelId != null){
    				productVOList.add(productVOMap.get(modelId));
    			}
    			productSet.add(modelId);
    		}
    	}
		return productVOList;
	}
    
    private List<SeriesVO> getSeriesVOList(Long brandId,
			List<PromotionQualification> promotionQualifications,
			Map<Long, SeriesVO> seriesVOMap) {
    	Set<Long> seriesSet = new HashSet<Long>();
    	List<SeriesVO> seriesVOList = new ArrayList<SeriesVO>();
    	Long tempBrandId;
    	for (PromotionQualification promotionQualification : promotionQualifications) {
    		tempBrandId = promotionQualification.getVelBrandId();
    		if(tempBrandId.equals(brandId)){
    			Long seriesId = promotionQualification.getVelSeriesId();
    			if(seriesSet.contains(seriesId)){
    				continue;
    			}
    			if(seriesId != null){
    				seriesVOList.add(seriesVOMap.get(seriesId));
    			}
    			seriesSet.add(seriesId);
    		}
    	}
		return seriesVOList;
	}
    
    public List<ColorImageVO> getColorImageVOList(Long modelId,List<Long> colorIds){
        List<ColorImageVO> children = new ArrayList<ColorImageVO>();
        //设置当前车型的颜色
        if( colorIds== null || colorIds.size() == 0){
        	 //这个车型的全部颜色已经放入，
            VelModelColorExt velModelColorExt = velModelInfoClient.findModelWithColorById(modelId);
            List<VelColor> list = velModelColorExt.getVelColors();
            for (VelColor velColor : list) {
            	ColorImageVO colorImageVO = new ColorImageVO();
                colorImageVO.setColorId(velColor.getVelColorId());
                colorImageVO.setColorName(velColor.getVelColorChsName());
                colorImageVO.setImageId(velColor.getColorImgId());
                colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
                children.add(colorImageVO);
            }
        }else{
        	for (Long colorId : colorIds) {
        		if (colorId != null) {
        			ColorImageVO colorImageVO = new ColorImageVO();
        			VelColor velColor = velColorClient.findColorByColorId(colorId);
        			colorImageVO.setColorId(velColor.getVelColorId());
        			colorImageVO.setColorName(velColor.getVelColorChsName());
        			colorImageVO.setImageId(velColor.getColorImgId());
        			colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
        			children.add(colorImageVO);
        		}
        	}
        }
        return children;
    }
    
    /* (non-Javadoc)
     * @see com.saic.ebiz.msweb.service.OrderService#getPromotionMerchandise(long, long, long, long)
     */
    
    
    //DOTO  以下全部是工具类
    /** 本地根据类
     * 功能描述: 根据传入的活动id、车型id、颜色id得到店铺的list<br>
     * @param promotionID 活动id
     * @param productId 车型id
     * @param colorId 颜色id
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public List<StoreBaseInfo> getPromStroeBaseInfo(long promotionID,long productId,long colorId){
//        List<StoreBaseInfo> resultStoreBaseInfo = new ArrayList<StoreBaseInfo>();
//        //商品list
//        List<PromotionMerchandise> tempList = getPromotionMerchandiseList(promotionID);
//        Set<Long> storeIdSet = new HashSet<Long>();
//        for (PromotionMerchandise promotionMerchandise : tempList) {
//            long tempProductId = promotionMerchandise.getVelModelId();
//            long storeId = promotionMerchandise.getStoreId();
//            Long tempColorId = promotionMerchandise.getColorId();
//            //如果店铺已经包含,直接到下一个店铺
//            if(storeIdSet.contains(storeId)){
//                continue;
//            }else{
//                //车型匹配
//                if(tempProductId == productId){
//                    //如果颜色id为null说明当前店铺适合所有颜色  如果颜色id部位null，那么店铺需要和当前选择的颜色匹配
//                    if(tempColorId == null ||Long.compare(colorId, tempColorId)==0){
//                        resultStoreBaseInfo.addAll(storeClient.findStoresByStoresIds(storeId));
//                        storeIdSet.add(storeId);
//                    }
//                }                
//            }
//        }        
//        return resultStoreBaseInfo;
//    }
//    
    /**
     * 本地工具类
     * 功能描述: 得到活动商品信息<br>
     * @param promotionID 活动id
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    public List<PromotionMerchandise> getPromotionMerchandiseList(long promotionID){
//        Promotion promotion = iPromotionService.getPrmtMdseInfoForModel(promotionID);
//        if(promotion==null){
//            String error = "活动详情查询失败....";
//            log.error(error);
//            throw new BaseException(error);
//        }else{
//            list = promotion.getPromotionMerchandises();
//            if(list == null || list.size()==0){
//                String error = "活动关联商品详情查询失败....";
//                log.error(error);
//                throw new BaseException(error);
//            }else{
//              //配额过滤
//                List<PromotionMerchandise> tempList = new ArrayList<PromotionMerchandise>();
//                for (Iterator<PromotionMerchandise> iterator = list.iterator(); iterator.hasNext();) {
//                    PromotionMerchandise promotionMerchandise = iterator.next();
//                    //有足够的配额
//                    if(promotionMerchandise.getAvailableNum()>0){
//                        tempList.add(promotionMerchandise);
//                    }
//                }
//                return tempList;
//            }
//        }
//    }
//    
    
    @SuppressWarnings("unused")
	private List<ColorImageVO> getColorImageVOListByPromotionQualification(PromotionQualification promotionQualification){
    	Set<Long> colorIdSet = new HashSet<Long>();
    	List<ColorImageVO> children = new ArrayList<ColorImageVO>();
		ColorImageVO colorImageVO = null;
		//车型id
		@SuppressWarnings("deprecation")
		Long colorId = promotionQualification.getColorId();
		//颜色没有配，那么显示全部颜色
		if(colorId == null ){
			//这个车型的全部颜色已经放入，
			VelModelColorExt velModelColorExt = velModelInfoClient.findModelWithColorById(promotionQualification.getVelModelId());
			List<VelColor> list = velModelColorExt.getVelColors();
			for (VelColor velColor : list) {
				if(colorIdSet.contains(velColor.getVelColorId())){
					continue;
				}
				colorImageVO = new ColorImageVO();
				colorImageVO.setColorId(velColor.getVelColorId());
				colorImageVO.setColorName(velColor.getVelColorChsName());
				colorImageVO.setImageId(velColor.getColorImgId());
				colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
				children.add(colorImageVO);
				colorIdSet.add(velColor.getVelColorId());
			}
			//颜色配置了，检查颜色是否已经加入
		}else if(!colorIdSet.contains(colorId)){
			colorImageVO = new ColorImageVO();
			VelColor velColor = velColorClient.findColorByColorId(colorId);
			colorImageVO.setColorId(velColor.getVelColorId());
			colorImageVO.setColorName(velColor.getVelColorChsName());
			colorImageVO.setImageId(velColor.getColorImgId());
			colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
			children.add(colorImageVO);
			colorIdSet.add(velColor.getVelColorId()); 
		}
    	return children;
    }
    
    public List<ColorImageVO> getColorImageVOListByPromotionQualification(long modelId,List<PromotionQualification> promotionQualificationList){
    	Set<Long> colorIdSet = new HashSet<Long>();
    	List<ColorImageVO> children = new ArrayList<ColorImageVO>();
    	//设置当前车型的颜色
    	for (PromotionQualification promotionQualification : promotionQualificationList) {
    		
    		ColorImageVO colorImageVO = null;
    		//车型id
    		long tempModelId = promotionQualification.getVelModelId();
    		
    		//与当前车型相同，开始设置当前车型的颜色
    		if(tempModelId == modelId){
    			@SuppressWarnings("deprecation")
				Long modelColorId = promotionQualification.getColorId();
    			
    			//颜色没有配，那么显示全部颜色
    			if(modelColorId == null ){
    				//这个车型的全部颜色已经放入，
    				VelModelColorExt velModelColorExt = velModelInfoClient.findModelWithColorById(tempModelId);
    				List<VelColor> list = velModelColorExt.getVelColors();
    				for (VelColor velColor : list) {
    					if(colorIdSet.contains(velColor.getVelColorId())){
    						continue;
    					}
    					colorImageVO = new ColorImageVO();
    					colorImageVO.setColorId(velColor.getVelColorId());
    					colorImageVO.setColorName(velColor.getVelColorChsName());
    					colorImageVO.setImageId(velColor.getColorImgId());
    					colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
    					children.add(colorImageVO);
    					colorIdSet.add(velColor.getVelColorId());
    				}
    				//颜色配置了，检查颜色是否已经加入
    			}else{
    				long tempmodelColorId = Long.valueOf(modelColorId);
    				//包含跳过
    				if(colorIdSet.contains(tempmodelColorId)){
    					continue;
    					//否则加入
    				}else{
    					colorImageVO = new ColorImageVO();
    					VelColor velColor = velColorClient.findColorByColorId(tempmodelColorId);
    					colorImageVO.setColorId(velColor.getVelColorId());
    					colorImageVO.setColorName(velColor.getVelColorChsName());
    					colorImageVO.setImageId(velColor.getColorImgId());
    					colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
    					children.add(colorImageVO);
    					colorIdSet.add(velColor.getVelColorId()); 
    				}
    			}
    		}
    	}        
    	return children;
    }
    
    /**
     * 
     * 功能描述: 工具类，加工车型的颜色<br>
     * @param modelId 车型id
     * @param promotionMerchandiseList 车型集合
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public List<ColorImageVO> getColorImageVOList(long modelId,List<PromotionMerchandise> promotionMerchandiseList){
        Set<Long> colorIdSet = new HashSet<Long>();
        List<ColorImageVO> children = new ArrayList<ColorImageVO>();
        //设置当前车型的颜色
        for (PromotionMerchandise promotionModelColor : promotionMerchandiseList) {
            
            ColorImageVO colorImageVO = null;
            //车型id
            long tempModelId = promotionModelColor.getVelModelId();
            
            //与当前车型相同，开始设置当前车型的颜色
            if(tempModelId == modelId){
                Long modelColorId = promotionModelColor.getColorId();
                
                //颜色没有配，那么显示全部颜色
                if(modelColorId == null){
                  //这个车型的全部颜色已经放入，
                    VelModelColorExt velModelColorExt = velModelInfoClient.findModelWithColorById(tempModelId);
                    List<VelColor> list = velModelColorExt.getVelColors();
                    for (VelColor velColor : list) {
                        if(colorIdSet.contains(velColor.getVelColorId())){
                            continue;
                        }
                        colorImageVO = new ColorImageVO();
                        colorImageVO.setColorId(velColor.getVelColorId());
                        colorImageVO.setColorName(velColor.getVelColorChsName());
                        colorImageVO.setImageId(velColor.getColorImgId());
                        colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
                        children.add(colorImageVO);
                        colorIdSet.add(velColor.getVelColorId());
                    }
                //颜色配置了，检查颜色是否已经加入
                }else{
                   long tempmodelColorId = Long.valueOf(modelColorId);
                    //包含跳过
                    if(colorIdSet.contains(tempmodelColorId)){
                        continue;
                    //否则加入
                    }else{
                        colorImageVO = new ColorImageVO();
                        VelColor velColor = velColorClient.findColorByColorId(tempmodelColorId);
                        colorImageVO.setColorId(velColor.getVelColorId());
                        colorImageVO.setColorName(velColor.getVelColorChsName());
                        colorImageVO.setImageId(velColor.getColorImgId());
                        colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
                        children.add(colorImageVO);
                        colorIdSet.add(velColor.getVelColorId()); 
                    }
                }
            }
        }        
        return children;
    }
    
    /**
     * 本地工具类:
     * 功能描述: 设置图片路径<br>
     * @param velColorImgPath
     * @return
     * @throws TemplateModelException
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String addPath(String velColorImgPath){
        List<String> args = null;
            args = new ArrayList<String>();
            args.add("/26x12"+velColorImgPath);
            String result = "";
            try {
                result = String.valueOf(fmImgUrl.exec(args));
            } catch (TemplateModelException e) {
               log.error("图片路径设置失败");
            }
        return result;
    }
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.saic.ebiz.market.order.Order#placeOrder(com.saic.ebiz.market.entity
	 * .InquiryOrderVO)
	 */
	@Override
	public String placeOrder(InquiryOrderVO inquiryOrderVO) throws Exception {
		String orderCode = null;
		// 因为订单失效时间1小时,在缓存中放置报名号，失效时间1小时
		// 为的是防止同一个商品重复下单
		//1 if the key was set 0 if the key was not set
//		if (redisClient.setnx(CacheUtil.getOrderCacheKey(inquiryOrderVO.get), inquiryOrderVO.getUserId() + COLON + inquiryOrderVO.getSubscriptionId()) == 1) {
//			try {
//				orderCode = Mock.mock();
//				log.info("调用服务 preOrderCreateService.createPreOrder预生成订单号: ", orderCode);
//				if (orderCode != null) {
//					redisClient.setex(CacheUtil.getOrderCacheKey(inquiryOrderVO.getSubscriptionId()),
//							Constants.ORDER_VALID_TIME, inquiryOrderVO.getUserId() + COLON + inquiryOrderVO.getSubscriptionId());
//					log.info("报名号成功放入redis>>" + CacheUtil.getOrderCacheKey(inquiryOrderVO.getSubscriptionId()));
//					redisClient.setex(CacheUtil.getOrderCacheKey(orderCode), Constants.ORDER_VALID_TIME,
//							(CacheUtil.getOrderCacheKey(inquiryOrderVO.getSubscriptionId())));
//					log.info("订单号成功放入redis>>" + CACHE_KEY + orderCode);
//				}
//			} catch (Exception e) {
//				log.error("配额不足", e.getMessage());
//				// 清除redis cache
//				redisClient.del(CacheUtil.getOrderCacheKey(inquiryOrderVO.getSubscriptionId()));
//				throw e;
//			}
//		} else {
//			log.warn(" 报名号{}已经下过单，需要去订单中心支付或取消订单 ", inquiryOrderVO.getSubscriptionId());
//			orderCode = Constants.ORDER_EXISTS_CODE;
//		}
		return orderCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.saic.ebiz.market.order.Order#cancleOrder(java.lang.Long)
	 */
	@Override
	public boolean cancleOrder(Long orderId) {
		return false;
	}
	

}
