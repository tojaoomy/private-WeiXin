package com.saic.ebiz.market.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.saic.framework.redis.client.IRedisClient;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.service.PreOrderInfoService;
import com.saic.ebiz.order.entity.AreaBean;
import com.saic.ebiz.order.service.api.PreOrderCreateService;
import com.saic.ebiz.order.service.entity.PreOrder;
import com.saic.ebiz.order.service.exception.PreOrderQuotaLackException;
import com.saic.ebiz.promotion.service.api.IFollowOrderForMainSiteService;
import com.saic.ebiz.promotion.service.api.IFollowOrderService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.commons.constants.RedisConstants;
import com.saic.ebiz.promotion.service.vo.ActOrderQueryResultDTO;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionSubscription;

public class PreOrderInfoServiceImpl implements PreOrderInfoService {
	 /**
     * 服务优化后的接口，获取促销的详细信息
     */
    @Resource
    private IPromotionService iPromotionService;


    /** The pre order create service. */
    @Resource
    private PreOrderCreateService preOrderCreateService;
    /** 子站回调接口. */
    @Resource
    private IFollowOrderForMainSiteService iFollowOrderForMainSiteService;
    /**缓存接口.*/
    @Resource(name="springRedisClient")
    private IRedisClient springRedisClient;
    @Resource
    private IFollowOrderService iFollowOrderService;
//    
//    /** 订单提交时间间隔. */
//    private static final int ORDER_INTERVAL = 3600;//3600

    /** The log. */
    Logger log = LoggerFactory.getLogger(PreOrderInfoServiceImpl.class);

    /**
     * {@inheritDoc}
     * 
     * @throws PreOrderQuotaLackException
     */
    @Override
    public String createPreOrder(PreOrder preOrder,long subscriptionId,Long promotionId) throws PreOrderQuotaLackException {
        String res = null;
        //缓存中不存在,执行订单创建流程
        if(!(springRedisClient.exists("ms:order:interval:"+String.valueOf(subscriptionId),Constants.REDIS_NAME_SPACE))){
            try {
            	Promotion promotion = this.iPromotionService.getPromotion(promotionId);
            	ActOrderQueryResultDTO actOrderQueryResultDTO = this.iFollowOrderService.getActOrderInfo(promotion.getPromotionId(), preOrder.getUserId());
            	res = preOrderCreateService.createPreOrderWithActOrder(preOrder, actOrderQueryResultDTO.getActOrderId());
                if(res != null){
                	springRedisClient.setex("ms:order:interval:"+String.valueOf(subscriptionId),Constants.REDIS_NAME_SPACE,RedisConstants.EXPIRE_TIME_ONE_HOUR, String.valueOf(preOrder.getPrmtActId()));
                    log.info("报名号成功放入redis>>"+"ms:order:interval:"+String.valueOf(subscriptionId));
                    springRedisClient.setex("ms:order:interval:"+res,Constants.REDIS_NAME_SPACE, RedisConstants.EXPIRE_TIME_ONE_HOUR, "ms:order:interval:"+String.valueOf(subscriptionId));
                    log.info("订单号成功放入redis>>"+"ms:order:interval:"+res);
                }
            } catch (PreOrderQuotaLackException e) {
                log.info("配额不足", e);
                throw e;
            }
        }else{
            log.info(preOrder.getPrmtMdseId()+"is exist");
            res = "-1";
        }
        return res;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<AreaBean> selectAreaByCity(Long cityId) {
        List<DataItemBean> list = ConstantCodeService.getRegionListByParentCode(cityId.toString());
        if (list == null || list.size() == 0) {
            return null;
        }
        List<AreaBean> areaBeanList = new ArrayList<AreaBean>();
        for (DataItemBean curLocation : list) {
            AreaBean tmpAreaBean = new AreaBean();
            tmpAreaBean.setAreaId(Long.valueOf(curLocation.getCode()));
            tmpAreaBean.setAreaName(curLocation.getName());
            areaBeanList.add(tmpAreaBean);
        }
        return areaBeanList;
    }

    /**
     * 功能描述:订单创建完成，回调子站接口 //参数：userId,subscritionId,orderId;.
     * 
     * @param userId the user id
     * @param subscriptionId the subscription id
     * @param orderId the order id
     */
    public void createFollowOrder(long userId, long subscriptionId, String orderId,long prmtMdseId) {
        iFollowOrderForMainSiteService.createFollowOrder(userId, subscriptionId, orderId,prmtMdseId);
    }

    /* (non-Javadoc)
     * @see com.saic.ebiz.service.order.intf.PreOrderInfoService#getPromotionSubscription(java.lang.Long)
     */
    @Override
    public PromotionSubscription getPromotionSubscription(Long subscriptionId) {
       return iFollowOrderForMainSiteService.getPromtionSubscriptionById(subscriptionId);
    }

    @Override
    public Promotion getPromotion(long promotionId) {
    	@SuppressWarnings("deprecation")
		Promotion promotion = iPromotionService.getPromotionExt(promotionId, true, false);
		return promotion;
    }
}
