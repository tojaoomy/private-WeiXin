/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.ibm.framework.uts.util.StringUtils;
import com.ibm.framework.web.freemarker.MultiDomUrl;
import com.saic.ebiz.carlib.service.client.VelColorClient;
import com.saic.ebiz.carlib.service.client.VelModelInfoClient;
import com.saic.ebiz.carlib.service.entity.VelColor;
import com.saic.ebiz.carlib.service.entity.VelModelColorExt;
import com.saic.ebiz.market.common.util.ImageUtil;
import com.saic.ebiz.market.entity.ColorImageVO;
import com.saic.ebiz.market.entity.RoutineCarVO;
import com.saic.ebiz.market.service.RoutineCarService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
import com.saic.ebiz.promotion.service.api.routine.IRoutineCarService;
import com.saic.ebiz.promotion.service.vo.RoutineMerchandiseVO;
import com.saic.ebiz.promotion.service.vo.routine.RoutineCar;

import freemarker.template.TemplateModelException;

/**
 * @author hejian
 *
 */
@Service("routineCarService")
public class RoutineCarServiceImpl implements RoutineCarService{
	
	private Logger log = LoggerFactory.getLogger(getClass());

	@Resource
	private IPromotionQualificationService iPromotionQualificationService;
	
	@Resource
	private IRoutineCarService iRoutineCarService;
	
	/**
     * 车型颜色的图片
     */
    @Autowired
    private VelColorClient velColorClient;
    
    /**
     * 车型客户端
     */
    @Resource
    private VelModelInfoClient velModelInfoClient;

	/** The multiple domain image url . */
    @Resource
    private MultiDomUrl fmImgUrl;
	
	@Override
	public List<RoutineCarVO> findConventionalVehicleByPromotionIdSeriesIdColorId(
			Integer marketType, Long cityId,Long brandId, Long seriesId,
			boolean availableOnly, Pagination page) {
		List<RoutineCarVO> routineCars = new ArrayList<RoutineCarVO>();
//		mock();
		PaginationResult<List<RoutineMerchandiseVO>> result = iPromotionQualificationService.queryRoutineMerchandiseByCombinedCondition(marketType, cityId, brandId, seriesId, availableOnly, page);
		List<RoutineMerchandiseVO> data= result.getR();
		for(RoutineMerchandiseVO merchandise : data){
			routineCars.add(exchangeData(merchandise));
		}
		//或许结果集的分页对象
		Pagination resultPage = result.getPagination();
		page.setCurrentPage(resultPage.getCurrentPage());
		page.setPagesize(resultPage.getPagesize());
		page.setTotalRows(resultPage.getTotalRows());
		return routineCars;
	}
	
	private RoutineCarVO exchangeData(RoutineMerchandiseVO merchandise){
		RoutineCarVO routineCar = new RoutineCarVO();
		routineCar.setRoutineCarId(merchandise.getRoutineCarId());
		routineCar.setBrandId(merchandise.getVelBrandId());
		//暂时未查询品牌名称
		routineCar.setSeriesId(merchandise.getVelSeriesId());
		routineCar.setVehicleModelId(merchandise.getVelModelId());
		//TBD 沟通再加一个属性title_mobile 
//		routineCar.setVehicleModelName(merchandise.getTitle());
		routineCar.setVehicleModelName(velModelInfoClient.findModelNameById(merchandise.getVelModelId()));
		routineCar.setCarType(merchandise.getCarType());
		routineCar.setBatchNum(merchandise.getBatchNo());
		routineCar.setBatchDescription(merchandise.getBatchDesc());
		//订单显示的数目，不一定是真实数字
		routineCar.setNumOfOrder(merchandise.getTotalMembersShow().intValue());
		//厂商指导价
		routineCar.setMarketPrice(merchandise.getMsrp());
		//车享购平均优惠
		routineCar.setAvgSave(merchandise.getAvgSave());
		//车享购平均提车周期
		routineCar.setPeriodOfPickUP(Long.valueOf(merchandise.getAvgTakeCarPeriod()));
		//封面图片
		routineCar.setCoverImgId(merchandise.getCoverImgId());
		routineCar.setCoverImgUrl(ImageUtil.getStaticImageUrl(ImageUtil.DEFAULT_RESOLUTION, merchandise.getCoverImgUrl()));
		//设置差价承诺
		routineCar.setIsPriceDiffCommit(merchandise.getIsPriceDiffCommit());
		routineCar.setPriceDiffCommitPeriod(merchandise.getPriceDiffCommitPeriod());
		//车享批次礼
		routineCar.setBatchGift(merchandise.getBatchGift());
		setColor(routineCar,merchandise);
		/*if(Mock.isAppMock() && Mock.isDevMock()){
			setMockColor(routineCar,merchandise);
		}else{
			setColor(routineCar,merchandise);
		}*/
		routineCar.setColorDisplay(setColorDisplay(routineCar));
		return routineCar;
	}
	
	/*private void setMockColor(RoutineCarVO routineCar,RoutineMerchandiseVO merchandise){
		String[] colorIdArray = merchandise.getColorIdList().split(" ");
		if(colorIdArray.length > 0){
			for(String colorId : colorIdArray){
				routineCar.getColors().add(MockColorImageVOData.getDataById(Long.valueOf(colorId)));
			}
		}
	}*/
	
	private void setColor(RoutineCarVO routineCar,RoutineMerchandiseVO merchandise){
		//如果为空
		if(StringUtils.isEmpty(merchandise.getColorIdList())){
			VelModelColorExt color = velModelInfoClient.findModelWithColorById(routineCar.getVehicleModelId());
			if(color == null || color.getVelColors() == null || color.getVelColors().size() == 0){
				return;
			}else{
				for(VelColor velColor : color.getVelColors()){
					routineCar.getColors().add(setVelColorImage(velColor));
				}
			}
		}else{
			String[] colorIdArray = merchandise.getColorIdList().split(",");
			if(colorIdArray.length > 0){
				for(String colorId : colorIdArray){
					VelColor velColor = velColorClient.findColorByColorId(Long.valueOf(colorId));
					routineCar.getColors().add(setVelColorImage(velColor));
				}
			}
		}
	}
	
	private String setColorDisplay(RoutineCarVO routineCar){
		StringBuilder builder = new StringBuilder();
		List<ColorImageVO> colorImageVOs = routineCar.getColors();
		VelModelColorExt color = velModelInfoClient.findModelWithColorById(routineCar.getVehicleModelId());
		//如果返回的颜色列表和车型库的颜色数量一样多，则显示全部颜色的字符串
		if(color.getVelColors().size() == colorImageVOs.size()){
			return "全部颜色";
		}
		for(ColorImageVO vo : colorImageVOs){
			if(vo != null){
				builder.append(vo.getName()).append("、");
			}
		}
		if(builder.length() > 0){
			return builder.substring(0, builder.length() -1);
		}
		return builder.toString();
	}
	
	private ColorImageVO setVelColorImage(VelColor velColor){
		try {
			ColorImageVO colorImageVO = new ColorImageVO();
			colorImageVO.setId(velColor.getVelColorId());
			colorImageVO.setName(velColor.getVelColorChsName());
			colorImageVO.setImageId(velColor.getColorImgId());
			colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
			return colorImageVO;
		} catch (Exception e) {
			return null;
		}
	}

	/**
     * 本地工具类:
     * 功能描述: 设置图片路径<br>
     * @param velColorImgPath
     * @return
     * @throws TemplateModelException
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String addPath(String velColorImgPath){
        List<String> args = new ArrayList<String>();
        args.add("/26x12"+velColorImgPath);
        String result = "";
        try {
            result = String.valueOf(fmImgUrl.exec(args));
        } catch (TemplateModelException e) {
           log.error("图片路径设置失败");
        }
        return result;
    }

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.RoutineCarService#findRoutineCarByUserId(java.util.List)
	 */
	@Override
	public List<RoutineCarVO> findRoutineCar(List<Long> routineCarIds) {
//		mock();
		List<RoutineCarVO> routineCarVOs = new ArrayList<RoutineCarVO>();
		List<RoutineCar> data = iRoutineCarService.findRoutineCarDetailByIds(routineCarIds);
		for(RoutineCar car : data){
			RoutineCarVO routineCarVO = new RoutineCarVO();
			try {
				BeanUtils.copyProperties(routineCarVO, car);
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
			
			routineCarVO.setMarketPrice(car.getGuidePrice());
			routineCarVO.setBatchDescription(car.getBatchDesc());
			routineCarVO.setColorDisplay(car.getColorNameList());
//			routineCarVO.setVehicleModelName(car.getVelModelName());
			//显示品牌 + 车系 + 车型
			routineCarVO.setVehicleModelName(car.getPageTitle());
			routineCarVO.setPeriodOfPickUP(car.getAvgTakeCarPeriod().longValue());
			routineCarVO.setNumOfOrder(car.getTotalMembersShow().intValue());
			routineCarVO.setPromotionId(car.getPromotionId());
			routineCarVO.setBrandId(car.getVelBrandId());
			routineCarVO.setSeriesId(car.getVelSeriesId());
			routineCarVO.setVehicleModelId(car.getVelModelId());
			routineCarVO.setCoverImgUrl(ImageUtil.getStaticImageUrl(ImageUtil.DEFAULT_RESOLUTION, car.getCoverImgUrl()));
			routineCarVOs.add(routineCarVO);
			//因为丁志刚接口getColorIds()与getColorIdList()返回的值不一致
			List<Long> colorIds = new ArrayList<Long>();
			for(String colorId : car.getColorIdList().split(",")){
				try {
					colorIds.add(Long.parseLong(colorId));
				} catch (NumberFormatException e) {
					log.error("Long.parseLong error : " + e.getMessage());
				}
			}
			car.setColorIds(colorIds);
			//如果取到颜色列表为空，取车型库所有的颜色
			if(CollectionUtils.isEmpty(car.getColorIds())){
				VelModelColorExt color = velModelInfoClient.findModelWithColorById(car.getVelModelId());
				if(color == null || color.getVelColors() == null || color.getVelColors().size() == 0){
					return routineCarVOs;
				}else{
					for(VelColor velColor : color.getVelColors()){
						routineCarVO.getColors().add(setVelColorImage(velColor));
					}
				}
			//否则根据颜色id取
			}else{
				for(Long colorId : car.getColorIds()){
					VelColor velColor = velColorClient.findColorByColorId(colorId);
					routineCarVO.getColors().add(setVelColorImage(velColor));
				}
			}
			/*if(Mock.isAppMock() && Mock.isDevMock()){
				for(Long colorId : car.getColorIds()){
					routineCarVO.getColors().add(MockColorImageVOData.getDataById(colorId));
				}
			}else{
				for(Long colorId : car.getColorIds()){
					VelColor velColor = velColorClient.findColorByColorId(colorId);
					routineCarVO.getColors().add(setVelColorImage(velColor));
				}
			}*/
		}
		return routineCarVOs;
	}

}
