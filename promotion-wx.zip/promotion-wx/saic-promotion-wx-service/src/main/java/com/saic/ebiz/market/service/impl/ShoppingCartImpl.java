/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.util.ImageUtil;
import com.saic.ebiz.market.entity.ShoppingCart;
import com.saic.ebiz.market.service.ShoppingCartService;
import com.saic.ebiz.promotion.service.api.IShoppingCartService;
import com.saic.ebiz.promotion.service.vo.ShoppingCartVO;

/**
 * @author hejian
 *
 */
@Service
public class ShoppingCartImpl implements ShoppingCartService, ApplicationContextAware{
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IShoppingCartService iShoppingCartService;
	
	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.ShoppingCart#put(java.lang.Long, java.lang.Long)
	 */
	@Override
	public boolean put(Long userId,Long cityId, Long routineCarId) {
		boolean result = true;
		logger.info("ShoppingCartImpl => put ######## user : {} ,cityId : {} routineCarId : {} ", userId, cityId, routineCarId);
		try {
			iShoppingCartService.put(String.valueOf(userId),String.valueOf(cityId), routineCarId);
		} catch (Exception e) {
			result = false;
			logger.error("异常" + e.getMessage());
//			throw new RuntimeException(e.getMessage());
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.ShoppingCart#remove(java.lang.Long, java.lang.Long)
	 */
	@Override
	public boolean remove(Long userId,Long cityId, Long routineCarId) {
		boolean result = true;
		logger.info("ShoppingCartImpl => remove ######## user : {} ,cityId : {} routineCarId : {} ", userId, cityId, routineCarId);
		try {
			iShoppingCartService.remove(String.valueOf(userId), routineCarId);
		} catch (Exception e) {
			result = false;
			logger.error("异常" + e.getMessage());
//			throw new RuntimeException(e.getMessage());
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.ShoppingCart#empty(java.lang.Long)
	 */
	@Override
	public boolean empty(Long userId,Long cityId) {
		boolean result = true;
		logger.info("ShoppingCartImpl => empty ######## user : {},cityId : {} ", userId,cityId);
		try {
			List<ShoppingCartVO> cart = iShoppingCartService.loadContent(String.valueOf(userId),String.valueOf(cityId));
			for(ShoppingCartVO cartVO : cart){
				iShoppingCartService.remove(String.valueOf(userId), cartVO.getRoutineCarId());
			}
		} catch (Exception e) {
			result = false;
			logger.error("异常" + e.getMessage());
//			throw new RuntimeException(e.getMessage());
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.ShoppingCartService#loadByUserId(java.lang.Long)
	 */
	@Override
	public List<ShoppingCart> loadByUserId(Long userId,Long cityId) {
		logger.info("ShoppingCartImpl => loadByUserId ######## user : {},cityId : {} ", userId,cityId);
		List<ShoppingCart> shoppingCart = new ArrayList<ShoppingCart>();
		List<ShoppingCartVO> cart = iShoppingCartService.loadContent(String.valueOf(userId),String.valueOf(cityId));
		if(cart != null && cart.size() > 0){
			for(ShoppingCartVO cartVO : cart){
				ShoppingCart shoppingCartVO = new ShoppingCart();
				try {
					BeanUtils.copyProperties(shoppingCartVO, cartVO);
					shoppingCartVO.setCoverImgUrl(ImageUtil.getStaticImageUrl(ImageUtil.DEFAULT_RESOLUTION, cartVO.getCoverImgUrl()));
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
				shoppingCart.add(shoppingCartVO);
			}
		}
		logger.info("ShoppingCartImpl => loadByUserId ######## 返回 : {}", JSONObject.toJSONString(shoppingCart));
		return shoppingCart;
	}
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.market.service.ShoppingCartService#empty(java.lang.Long)
	 */
	@Override
	public boolean empty(String userId) {
		try {
			iShoppingCartService.removeAll(userId);
		} catch (Exception e) {
			logger.error("用户userId : {} 清空购物车异常 ：{}",userId,e.getMessage());
			return false;
		}
		return true;
	}
	
}
