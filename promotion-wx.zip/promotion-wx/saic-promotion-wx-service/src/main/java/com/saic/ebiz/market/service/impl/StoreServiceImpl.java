/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.entity.DistrictVO;
import com.saic.ebiz.market.service.StoreService;
import com.saic.ebiz.mdm.partner.client.StoreClient;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
import com.saic.ebiz.promotion.service.vo.routine.StoreResult;

/**
 * @author hejian
 * 
 */
@Service("storeServiceImpl")
public class StoreServiceImpl implements StoreService {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IPromotionQualificationService iPromotionQualificationService;

	/** 店铺客户端服务 */
	@Resource
	private StoreClient storeClient;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.saic.ebiz.market.service.StoreService#getStoreByCreterial(java.lang
	 * .Long, java.lang.Long, java.lang.Long)
	 */
	@Override
	public List<DistrictVO> getStoreByCreterial(Long cityId, Long promotionId,
			Long colorId) {
		logger.info("cityId : {},promitionId : {}, colorId : {} ", cityId,
				promotionId, colorId);
		List<DistrictVO> districtVOs = new ArrayList<DistrictVO>();
		Map<Long, List<StoreResult>> data = this.iPromotionQualificationService.queryStoreByCombinedCondition(cityId, promotionId, colorId);
		Iterator<Entry<Long, List<StoreResult>>> it = data.entrySet().iterator();
		while (it.hasNext()) {
			Entry<Long, List<StoreResult>> entry = it.next();
			DistrictVO districtVO = new DistrictVO();
			// 获取区item
			DataItemBean district = ConstantCodeService.getRegionInfo(String
					.valueOf(entry.getKey()));
			districtVO.setValue(Long.valueOf(district.getCode()));
			districtVO.setText(district.getName());
			districtVO.setPvalue(Long.valueOf(district.getParentCode()));
			List<StoreResult> storeResultList = entry.getValue();
			List<Long> storeIds = new ArrayList<Long>();
			for(StoreResult result : storeResultList){
				storeIds.add(result.getStoreId());
				districtVO.getStoreMerchainseMap().put(String.valueOf(result.getStoreId()), result.getPrmtMdseId());
			}
			districtVO.getChildren().addAll(this.storeClient.findStoresByStoresIds(storeIds.toArray(new Long[0])));
			districtVOs.add(districtVO);
		}
		logger.info("getStoreByCreterial ###### 返回 : "
				+ JSONObject.toJSONString(districtVOs));
		return districtVOs;
	}

}
