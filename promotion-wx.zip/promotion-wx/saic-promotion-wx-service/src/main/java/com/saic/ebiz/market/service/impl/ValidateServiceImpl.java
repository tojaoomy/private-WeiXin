/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.saic.ebiz.iam.service.api.IAccountService;
import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.iam.service.entity.AcctAliasVO;
import com.saic.ebiz.iam.service.entity.AuthInfoVO;
import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.iam.service.exception.AccountNotFoundException;
import com.saic.ebiz.iam.service.exception.AcctAliasNameIsExistException;
import com.saic.ebiz.iam.service.exception.ArgumentException;
import com.saic.ebiz.iam.service.exception.MailSendException;
import com.saic.ebiz.market.common.entity.user.BasicPersonalInfoBean;
import com.saic.ebiz.market.service.ValidateService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;

@Service("validateServiceImpl")
public class ValidateServiceImpl implements ValidateService {

    /** 认证访问管理系统. */
    @Resource
    private IAccountService iAccountService;

    /** 认证访问管理系统. */
    @Resource
    private IUserService iUserService;

    /** 邀请好友接口. */
//    @Resource
//    private IInviteFriendService iInviteFriendService;
    /** 邀请好友接口. */
    @Resource(name="userService")
    private UserService userService;
    /** 日至服务. */
    private static final Logger logger = LoggerFactory.getLogger(ValidateServiceImpl.class);
    /** 字符串截断值、返回值. */
    private static final int SUB_RETURN_NUM = 0;
    /** 字符串截断、返回值. */
    private static final int SUB_RETURN_TYPE = 1;
    /** 字符串截断、返回值. */
    private static final int SUB_RET_NUM = 2;
    /** 字符串截断、比较值. */
    private static final int SUB_CONP_TYPE = 3;
    /** 字符串截断. */
    private static final int SUB_NUM = 7;
    /** 接口返回成功数值100. */
    private static final int VENUS_SUCC_NUM = 100;
    /** 接口返回状态值101. */
    private static final int VENUS_LOWER_NUM = 101;
    /** 接口返回状态值102. */
    private static final int VENUS_ERROR_NUM = 102;
    private static final String gmailAdress = "gmail.com";
    
    private static final String FIND_PASSWORD_BY_EMAIL_TEMP="013";

    /**
     * 功能描述: begin: 验证邮件.<br>
     * 
     * @param userId 用户id
     * @param emailAddress 邮件地址
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public void toValidateEmail(long userId, String emailAddress) {

    }

    /**
     * 功能描述: 手机验证.<br>
     * 
     * @param phoneNumber 手机号码
     * @return BasicPersonalInfoBean 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public BasicPersonalInfoBean toValidatePhone(String phoneNumber) {
        BasicPersonalInfoBean evb = new BasicPersonalInfoBean();

        StringBuilder sb = new StringBuilder();
        phoneNumber=   phoneNumber.substring(SUB_RETURN_NUM, SUB_CONP_TYPE);
        phoneNumber=    phoneNumber.substring(8);

        sb.append(phoneNumber.substring(SUB_RETURN_NUM, SUB_CONP_TYPE)).append("****")
                .append(phoneNumber.substring(SUB_NUM));

        evb.setPartHidePhone(sb.toString());

        return evb;
    }

    /**
     * 功能描述: 获取邮箱注册网站.<br>
     * 
     * @param emailAddress 邮箱注册网站
     * @return BasicPersonalInfoBean 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public BasicPersonalInfoBean toGetHandEmailByParmes(String emailAddress) {
        BasicPersonalInfoBean evb = new BasicPersonalInfoBean();

        String[] strArr = emailAddress.split("@");
        int k = strArr.length;

        StringBuilder sb = new StringBuilder();
        StringBuilder sb1 = new StringBuilder();

        if (strArr != null && k > SUB_RETURN_TYPE) {
            String lastStr = strArr[SUB_RETURN_TYPE];
            if (gmailAdress.equals(lastStr)) {
                sb.append("gmail.google.com");
                String beforStr;
                if (strArr[0].length() == 1) {
                    beforStr = strArr[0].replace(strArr[0], "*");
                    sb1.append(beforStr).append("@").append(lastStr);
                } else if (strArr[0].length() == 2) {
                    beforStr = strArr[0].replaceAll(strArr[0], "**");
                    sb1.append(beforStr).append("@").append(lastStr);
                } else {
                    beforStr = strArr[0].substring(0, strArr[0].length() - 3);
                    sb1.append(beforStr).append("***").append("@").append(lastStr);
                }
            } else {
                // 拼接邮箱注册网站
                sb.append("mail.");
                sb.append(lastStr);
                String beforStr;
                if (strArr[SUB_RETURN_NUM].length() == SUB_RETURN_TYPE) {
                    beforStr = strArr[SUB_RETURN_NUM].replace(strArr[SUB_RETURN_NUM], "*");
                    sb1.append(beforStr).append("@").append(lastStr);
                } else if (strArr[SUB_RETURN_NUM].length() == SUB_RET_NUM) {
                    beforStr = strArr[SUB_RETURN_NUM].replaceAll(strArr[SUB_RETURN_NUM], "**");
                    sb1.append(beforStr).append("@").append(lastStr);
                } else {
                    beforStr = strArr[SUB_RETURN_NUM].substring(SUB_RETURN_NUM, strArr[SUB_RETURN_NUM].length()
                            - SUB_CONP_TYPE);
                    sb1.append(beforStr).append("***").append("@").append(lastStr);
                }
            }
        }

        String webEmail = sb.toString();
        String partEmail = sb1.toString();

        evb.setPartHideEmail(partEmail);
        evb.setRegisterWebsit(webEmail);

        return evb;
    }

    /**
     * 功能描述: 校验输入的邮箱或手机号码是否可用.<br>
     * 
     * @param aliasName 帐户别名
     * @param aliasType 类型
     * @param appCode 验证
     * @return int 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toFrontCheckPhoneOrEma(String aliasName, int aliasType, int appCode) {
        // 接口服务方法，当返回值为100：已存在
        ResponseVO rv = iUserService.aliasNameIsUsed(aliasName, aliasType, appCode);
        if (rv != null && rv.getRtnCode() == VENUS_SUCC_NUM) {
            return SUB_RETURN_NUM;
        }
        return SUB_RETURN_TYPE;
    }

    /**
     * 功能描述: 发送验证邮件服务.<br>
     * 
     * @param acctId 用户
     * @param email 邮箱
     * @param templateID 邮件模板
     * @param authURL 跳转验证链接
     * @return int 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toReqAuthMail(long acctId, String email, String templateID, String authURL) {
        // 接口服务方法，当返回值为100：发送成功
        logger.error("--------------------------------");
        logger.error("接口传递参数用户id ：" + acctId);
        logger.error("接口传递参数验证的邮箱帐号：" + email);
        logger.error("接口传递参数验证的邮箱模板id：" + templateID);
        logger.error("接口传递参数验证的邮箱链接地址：" + authURL);
        ResponseVO rv = null;
        try {
            rv = iAccountService.reqAuthMail(acctId, email, templateID, authURL);
            logger.error("邮件发送状态" + rv.getRtnCode());
        } catch (ArgumentException e) {
            logger.error("调用iAccountService.reqAuthMail失败：" + e.getMessage());
        } catch (MailSendException e) {
            logger.error("调用iAccountService.reqAuthMail失败：" + e.getMessage());
        }
        // 1成功 0不成功
        if (rv != null && rv.getRtnCode() == VENUS_SUCC_NUM) {
            return SUB_RETURN_TYPE;
        }
        return SUB_RETURN_NUM;
    }

    /**
     * 功能描述: 发送手机、邮箱验证码.<br>
     * 
     * @param acctId 用户
     * @param authType 1:用户名，2:手机， 3:邮箱
     * @param authInfo 手机、邮箱
     * @param complateId 模板
     * @return int 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toReqCheckCode(long acctId, int authType, String authInfo, String complateId) {
        // 发送验证码服务类接口
        ResponseVO vo = null;
        try {
            vo = iAccountService.getAuthCode(acctId, authType, authInfo, complateId);
            logger.info("手机: {}, 验证码: {}", authInfo, vo.getResult());
        } catch (Exception e) {
            logger.error("调用发送验证码服务类接口异常", e);
        }
        // 100 发送成功
        if (vo != null && vo.getRtnCode() == VENUS_SUCC_NUM) {
            return SUB_RETURN_TYPE;
        }
        return SUB_RETURN_NUM;
    }

    @Override
    public void toReqCheckCodeForUms(int authType, String valueNum, String temStyle) {
        try {
            ResponseVO vo = iAccountService.getAuthCodeForUMS(authType, valueNum, temStyle);
            System.out.println(vo.getResult());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 功能描述: 车主认证发送手机、邮箱验证码.<br>
     * 
     * @param acctId 用户
     * @param authType 0:用户名，1:手机， 2:邮箱
     * @param authInfo 手机、邮箱
     * @param complateId 模板
     * @param activeTime the active time
     * @return int 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toReqCheckCodeByApp(long acctId, int authType, String authInfo, String complateId, int activeTime) {
        // 发送验证码服务类接口
        ResponseVO vo = null;
        try {
            vo = iAccountService.getAuthCodeByApp("mc", acctId, authType, authInfo, complateId, activeTime);
            logger.debug("手机: {}, 验证码: {}", authInfo, vo.getResult());
        } catch (Exception e) {
            logger.error("调用发送验证码服务类接口异常", e);
        }
        // 100 发送成功
        if (vo != null && vo.getRtnCode() == VENUS_SUCC_NUM) {
            return SUB_RETURN_TYPE;
        }
        return SUB_RETURN_NUM;
    }

    /**
     * 功能描述: 主车认证校验手机、验证码有效性.<br>
     * 
     * @param userId 用户
     * @param inputCode 验证码
     * @param authInfo 手机、邮箱
     * @return int 返回值类型
     * @throws ArgumentException ArgumentException
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toAuthCheckCodeByApp(long userId, String inputCode, String authInfo) throws ArgumentException {
        ResponseVO rv = null;
        try {
            rv = iAccountService.verifyAuthCodeByApp("mc", userId, inputCode, authInfo);
        } catch (ArgumentException e) {
            logger.error("iAccountService.verifyAuthCodeByApp was error", e);
        }
        if (rv == null) {
            return SUB_RETURN_NUM;
        } else {
            // 100 验证成功 101 验证失败 102 验证码失效-已过期
            if (rv.getRtnCode() == VENUS_LOWER_NUM) {
                return SUB_RETURN_NUM;
            } else if (rv.getRtnCode() == VENUS_ERROR_NUM) {
                return SUB_RET_NUM;
            }
            return SUB_RETURN_TYPE;
        }
    }

    /**
     * 功能描述: 校验手机、验证码有效性.<br>
     * 
     * @param userId 用户
     * @param authType 0:用户名，1:手机， 2:邮箱
     * @param inputCode 验证码
     * @param authInfo 手机、邮箱
     * @param createType 模板
     * @return int 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toAuthCheckCode(long userId, int authType, String inputCode, String authInfo, int createType) {
        ResponseVO rv = null;
        try {
            rv = iAccountService.verifyAuthCode(userId, authType, inputCode, authInfo);
        } catch (ArgumentException e) {
            logger.error("iAccountService.verifyAuthCode was error", e);
        } catch (AcctAliasNameIsExistException e) {
            logger.error("iAccountService.verifyAuthCode was error", e);
        }
        if (rv == null) {
            return SUB_RETURN_NUM;
        } else {
            // 100 验证成功 101 验证失败 102 验证码失效-已过期
            if (rv.getRtnCode() == VENUS_LOWER_NUM) {
                return SUB_RETURN_NUM;
            } else if (rv.getRtnCode() == VENUS_ERROR_NUM) {
                return SUB_RET_NUM;
            }
            return SUB_RETURN_TYPE;
        }

    }

    /**
     * 功能描述: 验证密码是否正确.<br>
     * 
     * @param userId 用户
     * @param appId 验证id
     * @param aliasName 别名
     * @param password 密码
     * @return int 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toCheckPass(long userId, int appId, String aliasName, String password) {
        // 采用MD5加密
        String mdPass = DigestUtils.md5Hex(password);
        // 验证密码是否正确
        ResponseVO vo = null;
        try {
            vo = iUserService.validatePassword(userId, appId, aliasName, mdPass);
        } catch (AccountNotFoundException e) {
            logger.error("iUserService.validatePassword was error", e);
        } catch (ArgumentException e) {
            logger.error("iUserService.validatePassword was error", e);
        }
        if (vo == null) {
            return SUB_RETURN_TYPE;
        } else {
            // 100验证成功
            if (vo.getRtnCode() == VENUS_SUCC_NUM) {
                return SUB_RETURN_NUM;
            }
            return SUB_RETURN_TYPE;
        }

    }

    /**
     * 功能描述: 验证邮件验证链接是否正确，并邦定该邮箱.<br>
     * 
     * @param userId 用户
     * @param authCode 验证码
     * @param createType 类型
     * @return String 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public String toVerifyAuthMailAndBind(String userId, String authCode, int createType) {
        // 验证邮件验证链接是否正确 100验证成功 101验证不成功
        ResponseVO vo = null;
        logger.error("传递的参数userId:" + userId);
        logger.error("传递的参数authCode:" + authCode);
        logger.error("传递的参数createType:" + createType);
        try {
            vo = iAccountService.verifyAuthMailAndBind(userId, authCode, createType);
           
        } catch (ArgumentException e) {
            logger.error("接口异常" + e.getMessage());
            if (e != null) {
                return "0" + "," + "0";
            }
        } catch (AcctAliasNameIsExistException e) {
            logger.error("接口异常" + e.getMessage());
            if (e != null) {
                return "0" + "," + "0";
            }
        } catch (MailSendException e) {
            logger.error("接口异常" + e.getMessage());
            if (e != null) {
                return "0" + "," + "0";
            }
        }
        if (vo != null && vo.getRtnCode() == VENUS_SUCC_NUM && (String.valueOf(vo.getUserId())) != null) {
        	 logger.error("验证状态code:" + vo.getRtnCode());
            return "1" + "," + vo.getUserId() + "," + vo.getEmail();
        } else {
            return "0";
        }
    }

    /**
     * 功能描述: 验证邮件验证链接是否正确，并邦定该邮箱.<br>
     * 
     * @param userId 用户
     * @param authCode 验证码
     * @param createType 类型
     * @return String 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public String toBindAndActiveMail(String userId, String authCode, int createType) {
        // 验证邮件验证链接是否正确 100验证成功 101验证不成功
        ResponseVO vo = null;
        logger.error("传递的参数userId:" + userId);
        logger.error("传递的参数authCode:" + authCode);
        logger.error("传递的参数createType:" + createType);
        try {
            vo = iUserService.bindAndActiveMail(userId, authCode);

        } catch (ArgumentException e) {
            logger.error("接口异常" + e.getMessage());
            if (e != null) {
                return "0" + "," + "0";
            }
        } catch (MailSendException e) {
            logger.error("接口异常" + e.getMessage());
            if (e != null) {
                return "0" + "," + "0";
            }
        }
        if (vo != null && vo.getRtnCode() == VENUS_SUCC_NUM && (String.valueOf(vo.getUserId())) != null) {
        	logger.error("验证状态code:" + vo.getRtnCode());
            return "1" + "," + vo.getUserId() + "," + vo.getEmail() + "," + vo.getPassword();
        } else {
            return "0";
        }
    }

    /**
     * 功能描述: 校验手机或者邮箱校验码,成功之后增加或者更新帐号别名.<br>
     * 
     * @param userId 用户
     * @param authType 验证类型认证类型-->1:用户名，2:手机， 3:邮箱…
     * @param inputCode 用户输入的验证码
     * @param authInfo 手机或者邮箱号
     * @param createType 1
     * @return String 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public int toVerifyAuthCodeAndBind(long userId, int authType, String inputCode, String authInfo, int createType) {
        ResponseVO vo = null;
        try {
        	if (7 == createType) {
        		 vo = iAccountService.verifyAuthCodeAndBind(userId, authType, inputCode, authInfo, createType);
			}else{
				vo = iAccountService.verifyAuthCodeAndBind(userId, authType, inputCode, authInfo, SUB_RETURN_TYPE);
			}
        } catch (ArgumentException e) {
            e.printStackTrace();
            logger.error("iAccountService.verifyAuthCodeAndBind was error", e);
        } catch (AcctAliasNameIsExistException e) {
            e.printStackTrace();
        } catch (MailSendException e) {
            e.printStackTrace();
        }
        if (vo == null) {
            return SUB_RETURN_NUM;
        } else {
            // 调用接口返回值 100成功 101验证码错误 102验证码过期
            if (vo.getRtnCode() == VENUS_LOWER_NUM) {
                return SUB_RETURN_NUM;
            }
            if (vo.getRtnCode() == VENUS_ERROR_NUM) {
                return SUB_RET_NUM;
            }
            return SUB_RETURN_TYPE;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getUserIdForUserName(String aliasName) {
        String userId = "";
        if (StringUtils.isNotBlank(aliasName)) {
            try {
                AuthInfoVO vo = iUserService.getAuthInfo(aliasName, 0, 1);
                if (vo != null && vo.getResVO() != null) {
                    userId = String.valueOf(vo.getResVO().getUserId());
                }
            } catch (Exception e) {
                logger.error("iam-jar getAuthInfo was error !", e);
            }
        }
        return userId;
    }

    /**
     * 功能描述: 获取已认证的信息.<br>
     * 
     * @param aliasName 帐户别名
     * @param userId 用户id
     * @param appId 应用ID,注册来源的应用ID号，1：B2C电商主站应用
     * @param tempId 模板id 2手机 3邮箱
     * @return String 返回值类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @Override
    public String toGetResultNum(String aliasName, long userId, int appId, String tempId) {
        // 返回已认证的结果信息
        String resultNum = "0";
        AuthInfoVO vo = null;
        try {
            vo = iUserService.getAuthInfo(aliasName, userId, appId);
        } catch (ArgumentException e) {
            logger.error("iUserService.getAuthInfo was error", e);
        } catch (AccountNotFoundException e) {
            logger.error("iUserService.getAuthInfo was error", e);
        }
        if (vo == null) {
            resultNum = "0";
        } else {
            // 获取返回是否有帐号信息
            ResponseVO rvo = vo.getResVO();
            // 100有帐号 101没有帐号
            if (rvo.getRtnCode() == VENUS_SUCC_NUM) {
                List<AcctAliasVO> listAvo = vo.getAuthList();
                for (AcctAliasVO acctAliasVO : listAvo) {
                    // 1表示用户名
                    if ("1".equals(tempId)) {
                        if (acctAliasVO.getAliasType() == SUB_RETURN_TYPE) {
                            resultNum = acctAliasVO.getAliasName();
                            break;
                        }
                    }
                    // 2表示手机
                    if ("2".equals(tempId)) {
                        if (acctAliasVO.getAliasType() == SUB_RET_NUM) {
                            resultNum = acctAliasVO.getAliasName();
                            break;
                        }
                    }
                    // 3表示邮箱
                    if ("3".equals(tempId)) {
                        if (acctAliasVO.getAliasType() == SUB_CONP_TYPE) {
                            resultNum = acctAliasVO.getAliasName();
                            break;
                        }
                    }
                }
            } else {
                resultNum = "0";
            }
        }
        return resultNum;
    }

    /**
     * 功能描述: 发送邀请好友邮件.<br>
     * 
     * @param userId 用户
     * @param friendEmail 邮箱地址
     * @param inviteURL 邀请注册链接
     * @return boolean 返回类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    @Override
//    public boolean sendInviteEmail(long userId, String friendEmail, String inviteURL) {
//        boolean result = false;
//        try {
//            iInviteFriendService.sendInviteEmail(userId, friendEmail, inviteURL);
//            result = true;
//        } catch (InParamException e) {
//            logger.error("mms jar iInviteFriendService.sendInviteEmail was error !", e);
//        } catch (InviteLetterSendException e) {
//            logger.error("mms jar iInviteFriendService.sendInviteEmail was error !", e);
//        } catch (InviteSignGenerateException e) {
//            logger.error("mms jar iInviteFriendService.sendInviteEmail was error !", e);
//        }
//        return result;
//    }

    /**
     * 功能描述: 发送邀请好友邮件.<br>
     * 
     * @param userId 用户
     * @return InviteSignVO 返回类型
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
//    @Override
//    public InviteSignVO getInviteSign(long userId) {
//        InviteSignVO vo = null;
//        try {
//            vo = iInviteFriendService.getInviteSign(userId);
//        } catch (InParamException e) {
//            logger.error("mms jar iInviteFriendService.getInviteSign was error !", e);
//        } catch (InviteSignGenerateException e) {
//            logger.error("mms jar iInviteFriendService.getInviteSign was error !", e);
//        }
//        return vo;
//    }

    @Override
    public ResponseVO accountIsExist(String aliasName, int aliasType, int appId) {
        ResponseVO rvo = iUserService.aliasNameIsUsed(aliasName, aliasType, appId);
        return rvo;
    }

    @Override
    public void getAuthInfo(String userName, Long userId, int i, BasicPersonalInfoBean bpibean) {
        try {
            AuthInfoVO authInfoVO = iUserService.getAuthInfo(userName, userId, i);
            if (authInfoVO != null) {
                for (AcctAliasVO acctAliasVO : authInfoVO.getAuthList()) {
                    // 2:手机， 3:邮箱

                    if (acctAliasVO.getAliasType() == 2) {
                        // 设置手机号码
                        bpibean.setMobile(acctAliasVO.getAliasName());
                        bpibean.setUserId(acctAliasVO.getUserId());

                    } else if (acctAliasVO.getAliasType() == 3) {
                        // 设置邮箱号码
                        bpibean.setEmail(acctAliasVO.getAliasName());
                        bpibean.setUserId(acctAliasVO.getUserId());
                    } else if (acctAliasVO.getAliasType() == 1) {
                        bpibean.setName(acctAliasVO.getAliasName());
                    }

                }
                // 个人密保问题状态
            }
            // bpibean.setName(authInfoVO.getResVO().getUserName());
            // findPassWordService.setUserBeanInfo(userBean);
        } catch (ArgumentException e) {
            logger.error("iam jar iUserService.getAuthInfo was error !", e);
        } catch (AccountNotFoundException e) {
            logger.error("iam jar iUserService.getAuthInfo was error !", e);
        }

    }

 //   @Override
//    public boolean updateNickNameByUserName(String userName, String nickname) {
//        boolean bool = false;
//        try {
//            userService.updateNickNameByUserName(userName, nickname);
//            bool = true;
//            return bool;
//        } catch (InParamException e) {
//            e.printStackTrace();
//            bool = false;
//        }
//        return bool;
//    }

    @Override
    public ResponseVO validateActiveEmail(String authInfo, String validateCode) {
        ResponseVO rvo = null;
        try {
            rvo = iAccountService.validateEmailByUpdatePW(authInfo, validateCode);
        } catch (ArgumentException e) {
            logger.error("iam jar iAccountService.validateActiveEmail was error !", e);
        }

        return rvo;
    }

    @Override
    public Boolean sendFindPwdEmail(String authURL, String email, String typeId) {
        ResponseVO rvo = null;

        try {
            rvo = iAccountService.reqUpdatePWEmailByActive(email, authURL, ValidateServiceImpl.FIND_PASSWORD_BY_EMAIL_TEMP);
        } catch (ArgumentException e) {
            logger.error("iam jar iAccountService.reqUpdatePWEmailByActive was error !", e);
        } catch (MailSendException e) {
            logger.error("iam jar iAccountService.reqUpdatePWEmailByActive was error !", e);
        }
        if (rvo != null && rvo.getRtnCode() == VENUS_SUCC_NUM) {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }

    @Override
    public Boolean compareNewPwordWithOld(String userName, String newpw) {
        ResponseVO rvo = null;
        try {
            rvo = iUserService.compareNewPwordWithOld(userName, DigestUtils.md5Hex(newpw));
        } catch (AccountNotFoundException e) {
            logger.error("iam jar iAccountService.compareNewPwordWithOld was error !", e);
        }
        if (rvo != null && rvo.getRtnCode() == VENUS_SUCC_NUM) {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;

    }

    @Override
    public int toReqCheckCodeByMobile(int authType, String authInfo, String templateID) {
//        ResponseVO codeVo=null;
        //iUserService.normalRegForUMS(aliasName, passwd, inputCode, aliasType, appId, createType, securityType, authURL)
        
        return 0;
    }



	@Override
	public boolean sendInviteEmail(long userId, String friendEmail,
			String inviteURL) {
		return false;
	}

	@Override
	public UserBaseInfoVO getInviteSign(long userId) {
		return null;
	}



	@Override
	public boolean updateNickNameByUserName(String userName, String nickname) {
		return false;
	}

	@Override
	public boolean updateNickNameByUserid(String userId, String nickname) {
		boolean result=false;
		try {
			userService.updateUserNickName(Long.parseLong(userId), nickname);
			result=true;
		} catch (Exception e) {
			logger.error("call updateNickNameByUserid error...", e);
			//e.printStackTrace();
			result=false;
		}
		return result;
	}

}
