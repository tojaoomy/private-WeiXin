package com.saic.ebiz.market.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.saic.ebiz.market.service.WebAccountInfoClient;
import com.saic.ebiz.market.service.WebAccountInfoService;
import com.saic.ebiz.mdm.entity.WebAccountVO;

/**
 * 微信
 * 
 * @version 1.0
 * @date 2014-04-30
 */
@Service("webAccountInfoService")
public class WebAccountInfoServiceImpl implements WebAccountInfoService {

	@Resource
	private WebAccountInfoClient webAccountInfoClient;

	/**
	 * 查询微信用户是否已绑定
	 * @param webAccountVO
	 * @return
	 */
	public List<WebAccountVO> findWebAccountByCondition(WebAccountVO webAccountVO) {
		return webAccountInfoClient.findWebAccountByCondition(webAccountVO);
	}
	
	
	/**
	 * 查询微信用户是否已绑定
	 * @param webAccountId 
	 * @return
	 */
	public int deleteWebAccount(long webAccountId) {
		return webAccountInfoClient.deleteWebAccount(webAccountId);
	}
	
	
	
	

}
