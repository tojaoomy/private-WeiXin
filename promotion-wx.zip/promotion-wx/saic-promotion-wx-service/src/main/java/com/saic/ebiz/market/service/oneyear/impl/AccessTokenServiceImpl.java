/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: AccessTokenServiceImpl.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午11:01:03
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.service.oneyear.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.component.wx.job.TicketJob;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.constant.WeiXinURL;
import com.saic.ebiz.market.oneyear.entity.UserAccessToken;
import com.saic.ebiz.market.oneyear.service.AccessTokenService;
import com.saic.ebiz.market.util.HttpKit;
import com.saic.ebiz.market.util.URLUtil;
import com.saic.ebiz.market.util.json.JSONParser;
import com.saic.framework.redis.client.IRedisClient;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class AccessTokenServiceImpl implements AccessTokenService {
    
    private static Logger logger = LoggerFactory.getLogger(AccessTokenServiceImpl.class); 
    
    /**  二进制的redis. */
    @Resource
    private IRedisClient springRedisClient;
    
    /**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 bdf9bedfd1e36dc2797cddc02847cb88
	 * 测试账号        04a4ea410735b9a134d41ed29ce64699
	 * 
	 */
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
    
	@Autowired
    private TicketJob ticketJob;
	
    /**
     * {@inheritDoc}
     */
    @Override
    public String getAccessToken() {
        
        return ticketJob.getToken();
//        Map<String,String> params=new HashMap<String,String>();
//        params.put("appid",appId);
//        params.put("secret",appSecret);
//        String result=HttpKit.get(WeiXinURL.ACCESS_TOKEN_URL.URL(), params);
//        logger.info("result:{}",result);
//        Map<String, Object> map = JSONObject.parseObject(result);
//        String accessToken=map.get("access_token").toString();
//        Integer expiresIn=(Integer) map.get("expires_in");
//        logger.info("accessToken:{},expiresIn:{}",accessToken,expiresIn);
//        return  accessToken;
    }
    
    public String getSNSAccessToken(String code) {
        Map<String,String> params=new HashMap<String,String>();
        params.put("appid",appId);
        params.put("secret",appSecret);
        params.put("code",code);
        String result=HttpKit.get(WeiXinURL.SNS_ACCESS_TOKEN_URL.URL(), params);
        logger.info("result:{}",result);
        Map<String, Object> map = JSONObject.parseObject(result);
        String accessToken=map.get("access_token").toString();
        Integer expiresIn=(Integer) map.get("expires_in");
        logger.info("accessToken:{},expiresIn:{}",accessToken,expiresIn);
        return  accessToken;
    }
    
    
    
    

    
    /**
     * {@inheritDoc}
     */
    @Override
    public UserAccessToken getUserAccessToken(String sessionId, String code) {
        if(StringUtils.isEmpty(code)){
            return null;
        }
        Map<String,String> params=new HashMap<String,String>();
        params.put("appid",appId);
        params.put("secret",appSecret);
        params.put("code",code);
        params.put("grant_type","authorization_code");
        String result=HttpKit.get(WeiXinURL.USER_ACCESS_TOKEN.URL(), params);
        logger.info("result:{}",result);
        UserAccessToken  userAccessToken=JSONParser.toStringObject(result,UserAccessToken.class);
        if(StringUtils.isEmpty(userAccessToken.getOpenid())){
            return null;
        }
        springRedisClient.setex("userAccessToken",Constants.REDIS_NAME_SPACE,2*60*60,result);//放到缓存2小时
       
        return userAccessToken;
    }
    
    //网页授权
    public String auth(String redirectUrl) {
        StringBuilder url=new StringBuilder();
        url.append(WeiXinURL.WECHAT_OAUTH.URL());
        url.append("appid=");
        url.append(appId);
        url.append("&redirect_uri=");
        url.append(URLUtil.encode(redirectUrl));
        url.append("&response_type=code");
        url.append("&scope=snsapi_userinfo");//snsapi_userinfo （弹出授权页面，可通过openid拿到昵称、性别、所在地。并且，即使在未关注的情况下，只要用户授权，也能获取其信息）
        url.append("&state=00#wechat_redirect");
        return url.toString();
    }
    
    
    //base授权
    public String baseAuth(String redirectUrl) {
        StringBuilder url=new StringBuilder();
        url.append(WeiXinURL.WECHAT_OAUTH.URL());
        url.append("appid=");
        url.append(appId);
        url.append("&redirect_uri=");
        url.append(URLUtil.encode(redirectUrl));
        url.append("&response_type=code");
        url.append("&scope=snsapi_base");
        url.append("&state=00#wechat_redirect");
        return url.toString();
    }

}
