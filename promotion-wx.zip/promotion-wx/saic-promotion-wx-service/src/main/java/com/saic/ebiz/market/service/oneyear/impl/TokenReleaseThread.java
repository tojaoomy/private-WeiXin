package com.saic.ebiz.market.service.oneyear.impl;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.saic.ebiz.market.common.constant.Constants;
import com.saic.framework.redis.client.IRedisClient;

/**
 * 商品配额等待锁解除线程类<br>
 * 提供商品配额令牌解锁功能，线程类
 * 
 * 
 * @author meizhiqing
 * @since [商品视图与服务/version=1]
 */
public class TokenReleaseThread implements Runnable {

    private IRedisClient springRedisClient;

    private static TokenReleaseThread tokenReleaseThread = null;

    private static ExecutorService execService = Executors.newSingleThreadExecutor();

    public static synchronized TokenReleaseThread getInstance(IRedisClient springRedisClient) {
        if (tokenReleaseThread == null) {
            tokenReleaseThread = new TokenReleaseThread(springRedisClient);
            if (!execService.isShutdown()) {
                execService.execute(tokenReleaseThread);
            }
        }
        return tokenReleaseThread;
    }

    private TokenReleaseThread(IRedisClient springRedisClient) {
        super();
        this.springRedisClient = springRedisClient;
    }

    @Override
    public void run() {
        long waitPeriod = 30000;
        while (true) {
            springRedisClient.del(UserInfoServiceImpl.ACCESS_TOKEN_PERMISSION_KEY,Constants.REDIS_NAME_SPACE);
            try {
				Thread.sleep(waitPeriod);// 线程睡眠一个时长，减低redis请求压力
            } catch (InterruptedException e) {
            }
        }
    }

}
