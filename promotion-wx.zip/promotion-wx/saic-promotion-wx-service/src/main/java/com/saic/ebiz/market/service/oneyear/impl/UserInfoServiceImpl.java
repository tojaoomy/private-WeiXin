/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: UserInfoServiceImpl.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午10:12:41
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.service.oneyear.impl;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.constant.WeiXinURL;
import com.saic.ebiz.market.oneyear.entity.UserInfo;
import com.saic.ebiz.market.oneyear.service.AccessTokenService;
import com.saic.ebiz.market.oneyear.service.UserInfoService;
import com.saic.ebiz.market.util.HttpKit;
import com.saic.ebiz.market.util.json.JSONParser;
import com.saic.ebiz.promotion.service.commons.constants.RedisConstants;
import com.saic.framework.redis.client.IRedisClient;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */

@Service
public class UserInfoServiceImpl implements UserInfoService{
    private static Logger logger = LoggerFactory.getLogger(UserInfoServiceImpl.class); 
    
    /**缓存微信access-token*/
    public static final String WX_ACCESS_TOKEN_KEY = "WX_ACCESS_TOKEN_KEY";
    
    public static final int WX_ACCESS_TOKEN_EXPIRE_TIME = 90*60;
    
    /**取微信access-token的redis令牌*/
    public static final String ACCESS_TOKEN_PERMISSION_KEY = "ACCESS_TOKEN_PERMISSION_KEY";
    
    public static final String ACCESS_TOKEN_PERMISSION_VALUE = "ACQUIRED";
    
    /**取微信access-token的redis令牌失效时间（秒）*/
    public static final int ACCESS_TOKEN_PERMISSION_EXPIRE_TIME = 15;
    
    private static final Lock access_lock = new ReentrantLock();
    
    private static final Condition access_condition = access_lock.newCondition();
    
    /** 缓存接口. */
    @Resource(name = "springRedisClient")
    private IRedisClient redisClient;
  
    @Resource
    private AccessTokenService accessTokenService;
    
    public UserInfo getUserInfo(String openId) {
        StringBuilder requestURL=new StringBuilder(WeiXinURL.USER_INFO.URL());
        String accessToken = null;
        if(redisClient.exists(WX_ACCESS_TOKEN_KEY,Constants.REDIS_NAME_SPACE)){
            accessToken = redisClient.get(WX_ACCESS_TOKEN_KEY,Constants.REDIS_NAME_SPACE,null);
        }
        if(accessToken == null){
            try {
                while(!acquireTokenFromRedis()){
                    access_condition.await();
                }
                access_lock.lock();
                TokenReleaseThread.getInstance(redisClient);
                if(redisClient.exists(WX_ACCESS_TOKEN_KEY,Constants.REDIS_NAME_SPACE)){
                    accessToken = redisClient.get(WX_ACCESS_TOKEN_KEY,Constants.REDIS_NAME_SPACE,null);
                }else{
                    accessToken = accessTokenService.getAccessToken();
                }
            } catch (Exception e) {
                logger.info("获取access-token失败！！");
                logger.error(e.getMessage());
            }finally{
                if(accessToken != null){
                    redisClient.set(WX_ACCESS_TOKEN_KEY,Constants.REDIS_NAME_SPACE, accessToken,RedisConstants.EXPIRE_TIME_NEVER);
                    redisClient.expire(WX_ACCESS_TOKEN_KEY,Constants.REDIS_NAME_SPACE,WX_ACCESS_TOKEN_EXPIRE_TIME);
                }
                redisClient.del(ACCESS_TOKEN_PERMISSION_KEY,Constants.REDIS_NAME_SPACE);
                access_lock.unlock();
            }
        }
        requestURL.append(accessToken);
        requestURL.append("&openid=");
        requestURL.append(openId);
        requestURL.append("&lang=zh_CN");   
        String result=HttpKit.get(requestURL.toString());
        logger.info("requestURL:{},result:{}",requestURL.toString(),result);
        return  JSONParser.toStringObject(result,UserInfo.class);
    }
    
    
    public UserInfo getSNSUserInfo(String openId,String token) {
        StringBuilder requestURL=new StringBuilder(WeiXinURL.SNS_USER_INFO.URL());
        requestURL.append(token);
        requestURL.append("&openid=");
        requestURL.append(openId);
        requestURL.append("&lang=zh_CN");   
        String result=HttpKit.get(requestURL.toString());
        logger.info("requestURL:{},result:{}",requestURL.toString(),result);
        return  JSONParser.toStringObject(result,UserInfo.class);
    }
    
    private boolean acquireTokenFromRedis(){
        boolean result = false;
        long retValue = 0;
        try {
            retValue = redisClient.setnx(ACCESS_TOKEN_PERMISSION_KEY,Constants.REDIS_NAME_SPACE, ACCESS_TOKEN_PERMISSION_VALUE);
            } catch (Exception e) {
            	logger.error(e.getMessage());
            }
        if (retValue == 1) {
            redisClient.expire(ACCESS_TOKEN_PERMISSION_KEY,Constants.REDIS_NAME_SPACE, ACCESS_TOKEN_PERMISSION_EXPIRE_TIME);
            result = true;
        }
        // 当且仅当当前线程抢到redis令牌后，返回true，否则false
        return result;
    }
}
