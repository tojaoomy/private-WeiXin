package com.saic.ebiz.market.service.wiki;

import java.util.Map;
import com.meidusa.venus.annotations.Service;

import com.meidusa.venus.annotations.Endpoint;
/**
 * 图文统计
 * @author liqiaoyan
 *
 */
@Service(name = "iDataStatisticsService", description = "车享购服务号图文数据分析", version = 1)
public interface IDataStatisticsService{
	/**
	 * 
	 * @Title: addImageTextReportData 
	 * @Description: 添加图文统计数据
	 * @param map  
	 * @return int
	 */
	public abstract int addImageTextReportData(Map<String, Object> map);

	/**
	 * 获取图文统计信息
	 * @return
	 * @throws Exception
	 */
    @Endpoint(name = "getImageTextReportData")
	public int getImageTextReportData() throws Exception;
}
