package com.saic.ebiz.market.service.wiki.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.meidusa.fastjson.JSON;
import com.saic.ebiz.component.wx.util.CommonUtil;
import com.saic.ebiz.market.common.util.PropertiesUtil;
import com.saic.ebiz.market.oneyear.service.AccessTokenService;
import com.saic.ebiz.market.service.wiki.IDataStatisticsService;
import com.saic.ebiz.promotion.service.api.IWxImageTextReportDataService;
import com.saic.ebiz.promotion.service.vo.WxImageTextReportDataVo;
/**
 * 数据统计
 * @author liqiaoyan
 *
 */
public class DataStatisticsServiceImp implements IDataStatisticsService {
	/**
	 * articlesummary 图文每日数
	 */
	private final static String ARTICLESUMMARY = "articlesummary";
	/**
	 * readhour图文统计分时数
	 */
	private final static String READHOUR = "readhour";
	
	private Logger log = LoggerFactory.getLogger(DataStatisticsServiceImp.class);
	
	@Resource
	private AccessTokenService  accessTokenService;
	
    @Resource
    private IWxImageTextReportDataService iWxImageTextReportDataService;
	
	@Override
	public int addImageTextReportData(Map<String, Object> map){
		int sum=0;
		if(map==null) return sum ;
		String outputStr = JSON.toJSONString(map);
		String token = accessTokenService.getAccessToken();
		String summaryUrl = PropertiesUtil.HTTPS_DATACUBE_GETARTICLESUMMARY.replace("ACCESS_TOKEN", token);
		String hourUrl = PropertiesUtil.HTTPS_DATACUBE_GETUSERREAD.replace("ACCESS_TOKEN", token);
		log.info("lqy--ImageTextReportService--addImageTextReportData--in:parms:"+outputStr+" token:"+token+" requrl：summaryUrl:"+summaryUrl+" hourUrl:"+hourUrl);
		JSONArray jsonArraysummary=null;
		JSONArray jsonArrayhour=null;
		try {
			JSONObject jsonsummary = CommonUtil.httpsRequest(summaryUrl, "POST", outputStr);
			JSONObject jsonhour = CommonUtil.httpsRequest(hourUrl, "POST", outputStr);
			jsonArraysummary = jsonsummary!=null?jsonsummary.getJSONArray("list"):null;
			jsonArrayhour = jsonhour!=null?jsonhour.getJSONArray("list"):null;
			insertDataReport(jsonArraysummary,ARTICLESUMMARY);
			insertDataReport(jsonArrayhour,READHOUR);
			sum=1;
		} catch (Exception e) {
			log.info("lqy--ImageTextReportService--addImageTextReportData--Exception:"+e);
		}
		log.info("lqy--ImageTextReportService--addImageTextReportData--result--articlesummary:"+(jsonArraysummary!=null?jsonArraysummary.size():0)+",readhour:"+(jsonArrayhour!=null?jsonArrayhour.size():0));
		return sum;
	}
	
	/**
	 * 获取图文统计数据（每日图文文统计数+分时图文统计数）
	 */
	@Override
	public int getImageTextReportData() throws Exception {
		Calendar cal = Calendar.getInstance(); 
        cal.add(Calendar.DATE,-1); 
        String yesterday = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("begin_date", yesterday);
		map.put("end_date", yesterday);
		log.info("lqy--ImageTextReportService--getImageTextReportData--result--yesterday:"+yesterday);
		return addImageTextReportData(map);
	}
	
	/**
	 * 
	 * @Title: insertDataReport 
	 * @Description: 图文数据入库
	 * @param jsonArray
	 * @param type
	 */
	private void insertDataReport(JSONArray jsonArray,String type) {
		if(jsonArray!=null){
			log.info("lqy--ImageTextReportService--insertDataReport--jsonArray:"+jsonArray.toString()+" type:"+type);
			List<WxImageTextReportDataVo> imagetexts=JSON.parseArray(jsonArray.toString(), WxImageTextReportDataVo.class) ;
			log.info("lqy--ImageTextReportService--insertDataReport--imagetexts.size:"+imagetexts.size());
			for (WxImageTextReportDataVo imageTextReportVo : imagetexts) {
				imageTextReportVo.setReport_type(type);
				try {
					iWxImageTextReportDataService.saveWxImageTextReportData(imageTextReportVo);
				} catch (Exception e) {
					log.info("lqy--ImageTextReportService--insertDataReport--Exception:"+e.getMessage());
					e.printStackTrace();
				}
			}
}
	}
	
}
