package com.saic.ebiz.market.util;
import org.apache.commons.lang3.StringUtils;

import sun.misc.BASE64Decoder;

/**
 * Base64加密/解密
 * 
 * @version 1.0.0
 */
public class Base64Operate {
	/**
	 * base64加密
	 * 
	 * @param String
	 *            str
	 * @return String
	 */
	@SuppressWarnings("deprecation")
	public static String getBASE64(String str) {
		if (StringUtils.isEmpty(str))
			return null;
		return (new sun.misc.BASE64Encoder()).encode(java.net.URLEncoder
				.encode(str).getBytes()).replaceAll("\r|\n",""); 
	}

	/**
	 * base64解密
	 * 
	 * @param String
	 *            str
	 * @return String
	 */
	@SuppressWarnings("deprecation")
	public static String getFromBASE64(String str) {
		if (StringUtils.isEmpty(str))
			return null;
		BASE64Decoder decoder = new BASE64Decoder();
		try {
			byte[] b = decoder.decodeBuffer(str);
			return java.net.URLDecoder.decode(new String(b)).replaceAll("\r|\n","");
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 测试函数
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String str = getBASE64("~系统测试用户123131312312313213212313系统测试用户123131312312313213212313~");
		System.out.println("stringtoBASE64 ->  " + str);
		System.out.println("stringfromBASE64 -> " + getFromBASE64(str));

	}
}

