package com.saic.ebiz.market.util;
import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import org.apache.commons.codec.binary.Base64;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.constant.EdaiUrlParamVO;

/**
 * 〈一句话功能简述〉上汽集团车享DES加解密工具类<br>
 * 〈功能详细描述〉.
 * 
 * @author v_lijian
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class DESUtils {
	private final static String DES = "DES";
	private final static String UTF_8="UTF-8"; 
    public static void main(String[] args) throws Exception {
//        String data = "李健4545";
        String key = "raven!@#$%";
//        System.err.println(encrypt(data, key));
//        System.err.println(decrypt(encrypt(data, key), key));
        EdaiUrlParamVO urlParam = new EdaiUrlParamVO();
        urlParam.setName("张三");
    	urlParam.setMphone("13128742313");
    	urlParam.setVelmodelid("327322");
    	urlParam.setAddr("中国上海");
    	String str = JSONObject.toJSONString(urlParam);
    	System.err.println(str);
    	System.err.println(encrypt(str, key));
    	System.err.println(decrypt(encrypt(str, key), key));
    	System.err.println(decrypt("jM9qZxbYwBsIFN8UB%2F3sSZe8F7nJZItTpq8GaeuJff3S4v27VYXP5G6HJKM501SmFyFBg7gGWs8%3D", key));
    }
     
    /**
     * Description 根据键值进行加密
     * @param data
     * @param key  加密键byte数组
     * @return
     * @throws Exception
     */
    public static String encrypt(String data, String key) throws Exception {
        byte[] bt = encrypt(data.getBytes(UTF_8), key.getBytes(UTF_8));
        String strs = new String(Base64.encodeBase64(bt),UTF_8);
        return urlEncode(strs);
    }
    
    /**
     * Description url字符串进行处理
     * @param data
     * @return
     * @throws Exception
     */
    private static String urlEncode(String data) throws Exception {
    	if (data == null)
            return null;
        String strs = URLEncoder.encode(data, UTF_8);
        return strs;
    }
 
    /**
     * Description 根据键值进行解密
     * @param data
     * @param key  加密键byte数组
     * @return
     * @throws IOException
     * @throws Exception
     */
    public static String decrypt(String data, String key) throws IOException,
            Exception {
        if (data == null)
            return null;
        String tmpStr = urlDecode(data);
        byte[] buf = Base64.decodeBase64(tmpStr);
        byte[] bt = decrypt(buf,key.getBytes(UTF_8));
        return new String(bt);
    }
 
    
    /**
     * Description url字符串进行处理
     * @param data
     * @return
     * @throws Exception
     */
    private static String urlDecode(String data) throws Exception {
    	if (data == null)
            return null;
        String strs = URLDecoder.decode(data, UTF_8);
        return strs;
    }
    
    /**
     * Description 根据键值进行加密
     * @param data
     * @param key  加密键byte数组
     * @return
     * @throws Exception
     */
    private static byte[] encrypt(byte[] data, byte[] key) throws Exception {
        // 生成一个可信任的随机数源
        SecureRandom sr = new SecureRandom();
 
        // 从原始密钥数据创建DESKeySpec对象
        DESKeySpec dks = new DESKeySpec(key);
 
        // 创建一个密钥工厂，然后用它把DESKeySpec转换成SecretKey对象
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
        SecretKey securekey = keyFactory.generateSecret(dks);
 
        // Cipher对象实际完成加密操作
        Cipher cipher = Cipher.getInstance(DES);
 
        // 用密钥初始化Cipher对象
        cipher.init(Cipher.ENCRYPT_MODE, securekey, sr);
 
        return cipher.doFinal(data);
    }
     
     
    /**
     * Description 根据键值进行解密
     * @param data
     * @param key  加密键byte数组
     * @return
     * @throws Exception
     */
    private static byte[] decrypt(byte[] data, byte[] key) throws Exception {
        // 生成一个可信任的随机数源
        SecureRandom sr = new SecureRandom();
 
        // 从原始密钥数据创建DESKeySpec对象
        DESKeySpec dks = new DESKeySpec(key);
 
        // 创建一个密钥工厂，然后用它把DESKeySpec转换成SecretKey对象
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
        SecretKey securekey = keyFactory.generateSecret(dks);
 
        // Cipher对象实际完成解密操作
        Cipher cipher = Cipher.getInstance(DES);
 
        // 用密钥初始化Cipher对象
        cipher.init(Cipher.DECRYPT_MODE, securekey, sr);
 
        return cipher.doFinal(data);
    }
}
