package com.saic.ebiz.market.util;

import freemarker.ext.beans.BeansWrapper;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;

public class FreemarkerUtils {
    
    @SuppressWarnings("rawtypes")  
    public static TemplateModel getStaticModel(Class clz) {  
          BeansWrapper wrapper = BeansWrapper.getDefaultInstance();  
    try {  
          return wrapper.getStaticModels().get(clz.getName());  
        } catch (TemplateModelException e) {  
          e.printStackTrace();  
        }  
          return null;  
        }  
    
}
