/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: HttpKit.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午11:06:40
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.protocol.HTTP;
import org.springframework.util.CollectionUtils;

import com.saic.ebiz.market.constant.Charset;
import com.saic.ebiz.market.exception.ServiceErrorCode;
import com.saic.ebiz.market.exception.ServiceException;
import com.saic.ebiz.market.oneyear.entity.Attachment;

/**
 * https 请求 微信为https的请求<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class HttpKit {
    /**编码*/
    private static final String DEFAULT_CHARSET =Charset.UFT8.code();
    /**GET请求*/
    private static final String GET =HttpGet.METHOD_NAME; // GET
    /**POST请求*/
    public static final String POST =HttpPost.METHOD_NAME;// POST
    /**HTTP　请求参数问号 ?*/
    public  static final String QUESTION_MARK="?";
    /**ampersand &*/
    public  static final String   AMPERS_AND="&";
    /**等号=*/
    public static final String EQUALS_SIGN="=";
    /**
     * 初始化http请求参数
     * 
     * @param url
     * @param method
     * @param headers
     * @return
     * @throws IOException
     */
    private static HttpURLConnection initHttp(String url, String method,
            Map<String, String> headers) throws IOException {
        URL _url = new URL(url);
        HttpURLConnection http = (HttpURLConnection) _url.openConnection();
        // 连接超时
        http.setConnectTimeout(25000);
        // 读取超时 --服务器响应比较慢，增大时间
        http.setRequestMethod(method);
        http.setRequestProperty(HTTP.CONTENT_TYPE,HttpContentType.DEFAULT_FORM.code());
        http.setRequestProperty(HTTP.USER_AGENT,
                "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36");
        if (null != headers && !headers.isEmpty()) {
            for (Entry<String, String> entry : headers.entrySet()) {
                http.setRequestProperty(entry.getKey(), entry.getValue());
            }
        }
        http.setDoOutput(true);
        http.setDoInput(true);
        http.connect();
        return http;
    }

    /**
     * 初始化http请求参数
     * 
     * @param url
     * @param method
     * @return
     * @throws IOException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchProviderException
     * @throws KeyManagementException
     */
    private static HttpsURLConnection initHttps(String url, String method,
            Map<String, String> headers) throws IOException,
            NoSuchAlgorithmException, NoSuchProviderException,
            KeyManagementException {
        TrustManager[] tm = { new MyX509TrustManager() };
//        System.setProperty("https.protocols", "SSLv3");
        SSLContext sslContext = SSLContext.getInstance("TLS", "SunJSSE");
        sslContext.init(null, tm, new java.security.SecureRandom());
        // 从上述SSLContext对象中得到SSLSocketFactory对象
        SSLSocketFactory ssf = sslContext.getSocketFactory();
        URL _url = new URL(url);
        HttpsURLConnection http = (HttpsURLConnection) _url.openConnection();
        // 设置域名校验
        http.setHostnameVerifier(new HttpKit().new TrustAnyHostnameVerifier());
        // 连接超时
        http.setConnectTimeout(25000);
        // 读取超时 --服务器响应比较慢，增大时间
        http.setReadTimeout(25000);
        http.setRequestMethod(method);
        http.setRequestProperty(HTTP.CONTENT_TYPE,HttpContentType.DEFAULT_FORM.code());
        http.setRequestProperty(HTTP.USER_AGENT,
                "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36");
        if (null != headers && !headers.isEmpty()) {
            for (Entry<String, String> entry : headers.entrySet()) {
                http.setRequestProperty(entry.getKey(), entry.getValue());
            }
        }
        http.setSSLSocketFactory(ssf);
        http.setDoOutput(true);
        http.setDoInput(true);
        http.connect();
        return http;
    }

    /**
     * 
     * @description 功能描述: get 请求
     * @return 返回类型:
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    public static String get(String url, Map<String, String> params,
            Map<String, String> headers) throws KeyManagementException,
            NoSuchAlgorithmException, NoSuchProviderException,IOException {
        HttpURLConnection http = null;
        if (isHttps(url)) {
            http = initHttps(initParams(url, params), GET, headers);
        } else {
            http = initHttp(initParams(url, params), GET, headers);
        }
        InputStream in = http.getInputStream();
        BufferedReader read = new BufferedReader(new InputStreamReader(in,
                DEFAULT_CHARSET));
        String valueString = null;
        StringBuffer bufferRes = new StringBuffer();
        while ((valueString = read.readLine()) != null) {
            bufferRes.append(valueString);
        }
        read.close();
        in.close();
        if (http != null) {
            http.disconnect();// 关闭连接
        }
        return bufferRes.toString();
    }

    /**
     * 
     * @description 功能描述: get 请求
     * @return 返回类型:
     */
    public static String get(String url){
        return get(url, null);
    }

    /**
     * 
     * @description 功能描述: get 请求
     * @return 返回类型:
     * @throws IOException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @throws UnsupportedEncodingException
     */
    public static String get(String url, Map<String, String> params){
        String  str=null;
        try{
            str=get(url, params, null);
        }catch(IOException e){
            throw new ServiceException(ServiceErrorCode.HTTP_IO, e);
        } catch (KeyManagementException e) {
            throw new ServiceException(ServiceErrorCode.HTTP_SECURITY, e);
        } catch (NoSuchAlgorithmException e) {
            throw new ServiceException(ServiceErrorCode.HTTP_SECURITY, e);
        } catch (NoSuchProviderException e) {
            throw new ServiceException(ServiceErrorCode.HTTP_SECURITY, e);
        }
        return str;
    }

    /**
     * @description 功能描述: POST 请求
     * @return 返回类型:
     * @throws IOException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    public static String post(String url, String params)
            throws KeyManagementException, NoSuchAlgorithmException,
            NoSuchProviderException, IOException {
        HttpURLConnection http = null;
        if (isHttps(url)) {
            http = initHttps(url, POST, null);
        } else {
            http = initHttp(url, POST, null);
        }
        OutputStream out = http.getOutputStream();
        out.write(params.getBytes(DEFAULT_CHARSET));
        out.flush();
        out.close();

        InputStream in = http.getInputStream();
        BufferedReader read = new BufferedReader(new InputStreamReader(in,DEFAULT_CHARSET));
        String valueString = null;
        StringBuffer bufferRes = new StringBuffer();
        while ((valueString = read.readLine()) != null) {
            bufferRes.append(valueString);
        }
        read.close();
        in.close();
        if (http != null) {
            http.disconnect();// 关闭连接
        }
        return bufferRes.toString();
    }

    /**
     * 上传媒体文件
     * 
     * @param url
     * @param params
     * @param file
     * @return
     * @throws IOException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchProviderException
     * @throws KeyManagementException
     */
    public static String upload(String url, File file) throws IOException,
            NoSuchAlgorithmException, NoSuchProviderException,
            KeyManagementException {
        String BOUNDARY = "----WebKitFormBoundaryiDGnV9zdZA1eM1yL"; // 定义数据分隔线
        StringBuffer bufferRes = null;
        URL urlGet = new URL(url);
        URLConnection urlConnection = urlGet.openConnection();
        if(urlConnection == null){
        	return null;
        }
        HttpURLConnection conn = (HttpURLConnection) urlConnection;
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false);
        conn.setRequestMethod(HttpPost.METHOD_NAME);
        conn.setRequestProperty("connection", "Keep-Alive");
        conn.setRequestProperty(
                "user-agent",
                "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36");
        conn.setRequestProperty("Charsert", "UTF-8");
        conn.setRequestProperty("Content-Type",
                "multipart/form-data; boundary=" + BOUNDARY);

        OutputStream out = new DataOutputStream(conn.getOutputStream());
        byte[] end_data = ("\r\n--" + BOUNDARY + "--\r\n").getBytes();// 定义最后数据分隔线
        StringBuilder sb = new StringBuilder();
        sb.append("--");
        sb.append(BOUNDARY);
        sb.append("\r\n");
        sb.append("Content-Disposition: form-data;name=\"media\";filename=\""
                + file.getName() + "\"\r\n");
        sb.append("Content-Type:application/octet-stream\r\n\r\n");
        byte[] data = sb.toString().getBytes();
        out.write(data);
        DataInputStream fs = new DataInputStream(new FileInputStream(file));
        int bytes = 0;
        byte[] bufferOut = new byte[1024];
        while ((bytes = fs.read(bufferOut)) != -1) {
            out.write(bufferOut, 0, bytes);
        }
        out.write("\r\n".getBytes()); // 多个文件时，二个文件之间加入这个
        fs.close();
        out.write(end_data);
        out.flush();
        out.close();

        // 定义BufferedReader输入流来读取URL的响应
        InputStream in = conn.getInputStream();
        BufferedReader read = new BufferedReader(new InputStreamReader(in,
                DEFAULT_CHARSET));
        String valueString = null;
        bufferRes = new StringBuffer();
        while ((valueString = read.readLine()) != null) {
            bufferRes.append(valueString);
        }
        read.close();
        in.close();
        // 关闭连接
        conn.disconnect();
        return bufferRes.toString();
    }

    /**
     * 下载资源
     * 
     * @param url
     * @return
     * @throws IOException
     */
    public static Attachment download(String url) throws IOException {
        Attachment att = new Attachment();
        HttpURLConnection conn = initHttp(url, GET, null);
        if (conn.getContentType().equalsIgnoreCase("text/plain")) {
            // 定义BufferedReader输入流来读取URL的响应
            InputStream in = conn.getInputStream();
            BufferedReader read = new BufferedReader(new InputStreamReader(in,DEFAULT_CHARSET));
            String valueString = null;
            StringBuffer bufferRes = new StringBuffer();
            while ((valueString = read.readLine()) != null) {
                bufferRes.append(valueString);
            }
            att.setError(bufferRes.toString());
            read.close();
            in.close();
        } else {
            BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
            String ds = conn.getHeaderField("Content-disposition");
            String fullName = ds.substring(ds.indexOf("filename=\"") + 10,ds.length() - 1);
            String relName = fullName.substring(0, fullName.lastIndexOf("."));
            String suffix = fullName.substring(relName.length() + 1);
            att.setFullName(fullName);
            att.setFileName(relName);
            att.setSuffix(suffix);
            att.setContentLength(conn.getHeaderField("Content-Length"));
            att.setContentType(conn.getHeaderField(HTTP.CONTENT_TYPE));
            att.setFileStream(bis);
        }
        return att;
    }

    /**
     * 功能描述: 构造请求参数
     * 
     * @return 返回类型:
     * @throws UnsupportedEncodingException
     */
    public static String initParams(String url, Map<String, String> params){
        if (CollectionUtils.isEmpty(params)) {
            return url;
        }
        StringBuilder sb = new StringBuilder(url);
        if (url.indexOf(QUESTION_MARK) == -1) {
            sb.append(QUESTION_MARK);
        }
        try{
            sb.append(map2Url(params));
        }catch(UnsupportedEncodingException e){
            throw new ServiceException(ServiceErrorCode.HTTP_ENCODING,e);
        }
        return sb.toString();
    }

    /**
     * map构造url
     * 
     * @return 返回类型:
     * @throws UnsupportedEncodingException
     */
    public static String map2Url(Map<String, String> paramToMap)
            throws UnsupportedEncodingException {
        if (null == paramToMap || paramToMap.isEmpty()) {
            return null;
        }
        StringBuffer url = new StringBuffer();
        boolean isfist = true;
        for (Entry<String, String> entry : paramToMap.entrySet()) {
            if (isfist) {
                isfist = false;
            } else {
                url.append(AMPERS_AND);
            }
            url.append(entry.getKey()).append("=");
            String value = entry.getValue();
            if (StringUtils.isNotEmpty(value)) {
                url.append(URLEncoder.encode(value, DEFAULT_CHARSET));
            }
        }
        return url.toString();
    }

    /**
     * 检测是否https
     * 
     * @param url
     */
    private static boolean isHttps(String url) {
        return url.startsWith("https");
    }

    /**
     * https 域名校验
     * 
     * @param url
     * @param params
     * @return
     */
    public class TrustAnyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) {
            return true;// 直接返回true
        }
    }

    public static void main(String[] args) {
        String fname = "dsasdas.mp4";
        String s = fname.substring(0, fname.lastIndexOf("."));
        String f = fname.substring(s.length() + 1);
        System.out.println(f);
    }
}

/**
 * 证书管理
 */
class MyX509TrustManager implements X509TrustManager {

    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType)
            throws CertificateException {
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType)
            throws CertificateException {
    }
}
