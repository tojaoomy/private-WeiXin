package com.saic.ebiz.market.util;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.saic.ebiz.market.common.util.CommonUtil;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmtDetail;

public class StringUtils2 {

    public static Long toLong(String str) {
        if(StringUtils.isBlank(str)) {
            return null;
        }
        
        return Long.valueOf(str);
    }
    /**
     * 
     *   一句话功能简述 <br>
     * 〈加密微信昵称〉
     *
     * @param nickname
     * @return    属性参数
     *  String    返回信息  
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String encodeNickName(String nickname){
    	if(nickname!=null){
    		return Base64Operate.getBASE64(CommonUtil.encodeURL(nickname));
    	}else{
    		return null;
    	}
    }
    
    /**
     * 
     *   一句话功能简述 <br>
     * 〈解密微信昵称〉
     *
     * @param nickname    加密昵称
     *  String    返回信息
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String decodeNickName(String nickname){
    	if(nickname!=null){
			   return CommonUtil.decodeURL(Base64Operate.getFromBASE64( nickname));
    		}else{
    			return null;
    		}
    }
    
    /**
     * 
     *   一句话功能简述 <br>
     * 〈解密微信昵称〉
     *
     * @param WxPrmtDetail    属性参数
     *  void    返回信息
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static void decodeNickName(List<WxPrmtDetail> WxPrmtDetail){
    	if(WxPrmtDetail!=null)
    	for (int i = 0; i < WxPrmtDetail.size(); i++) {
    		if(WxPrmtDetail.get(i).getFriendNickname()!=null){
			String dename = CommonUtil.decodeURL(Base64Operate.getFromBASE64( WxPrmtDetail.get(i).getFriendNickname()));
			WxPrmtDetail.get(i).setFriendNickname(dename);
    		}
		}
    }
    
    public static void main(String args[]) {//余祖国
        System.out.println("解码:"+StringUtils2.decodeNickName("JTI1RTUlMjU4RCUyNTk3"));
        //System.out.println("编码"+StringUtils2.encodeNickName("余祖国"));
    }
}
