package com.saic.ebiz.market.util;

public class UserDeviceUtil {

	/**
	 * 判断用户端设备类型
	 * @param userAgent
	 * @return   1：pc   2：移动设备
	 */
	public static int getDeviceType(String userAgent){
		int type = 2;
		if(userAgent.contains("windows")){
			type = 1;
		}
		return type;
	}
}
