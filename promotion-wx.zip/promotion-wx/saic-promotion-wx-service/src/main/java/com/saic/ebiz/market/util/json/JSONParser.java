/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: JSONParser.java
 * Author:   xiejuan
 * Date:     2014年11月6日 上午11:36:31
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.util.json;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


import com.meidusa.fastjson.JSON;
import com.meidusa.fastjson.serializer.SerializeConfig;
import com.meidusa.fastjson.serializer.SimpleDateFormatSerializer;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class JSONParser implements Serializable {

    /**
     */
    private static final long serialVersionUID = 1L;
    
    private static SerializeConfig mapping = new SerializeConfig();

    static {
        mapping.put(Date.class, new SimpleDateFormatSerializer("yyyy-MM-dd"));
    }
    
    /**
     * 根据
     * @param datePattern  日期格式
     * */
    private static SerializeConfig config(String datePattern) {
        SerializeConfig mapping = new SerializeConfig();
        mapping.put(Date.class, new SimpleDateFormatSerializer(datePattern));
        mapping.put(java.sql.Date.class, new SimpleDateFormatSerializer(datePattern));
        mapping.put(Timestamp.class, new SimpleDateFormatSerializer(datePattern));
        return mapping;
    }
    
    /**
     * 根据解析JSON字符
     * @param object
     * */
    public static String toJSONString(Object object) {
        return JSON.toJSONString(object);
    }
    
    /***
     * 将对象解析为JSON
     * @param object 
     * @param datePattern
     * @return String
     * */
    public static String toJSONString(Object object,String datePattern){
        return JSON.toJSONString(object,config(datePattern));
    }
    
    /***
     * 
     * 功能描述:将jsonString字符串转换为对象 <br>
     * 〈功能详细描述〉
     *
     * @param jsonStr
     * @param clazz
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static <T> T  toStringObject(String jsonStr,Class<T> clazz){
         return JSON.parseObject(jsonStr, clazz);
    }
}
