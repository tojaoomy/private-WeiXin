package com.saic.ebiz.market.vo;

import com.saic.ebiz.market.common.entity.authentication.SNSUserInfo;

public class WxAuthInfo {
	private Long userId;
    private SNSUserInfo snsUserInfo;
    
    /** 如果redirectUrl不为空，需要重定向到微信去授权 */
    private String redirectUrl;

    

	/**
     * @return the sNSUserInfo
     */
    public SNSUserInfo getSNSUserInfo() {
        return snsUserInfo;
    }

    /**
     * @param sNSUserInfo the sNSUserInfo to set
     */
    public void setSNSUserInfo(SNSUserInfo snsUserInfo) {
        this.snsUserInfo = snsUserInfo;
    }

    /**
     * @return the redirectUrl
     */
    public String getRedirectUrl() {
        return redirectUrl;
    }

    /**
     * @param redirectUrl the redirectUrl to set
     */
    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "WxAuthInfo [userId=" + userId + ", snsUserInfo=" + snsUserInfo + ", redirectUrl=" + redirectUrl + "]";
    }

    /**
     * @return the userId
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    
}
