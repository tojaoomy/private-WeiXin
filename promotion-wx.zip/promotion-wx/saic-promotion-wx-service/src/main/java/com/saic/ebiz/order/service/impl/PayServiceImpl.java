/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.order.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.order.service.PayService;
import com.saic.ebiz.pmf.service.api.Gateway;
import com.saic.ebiz.pmf.service.api.PaymentService;
import com.saic.ebiz.pmf.service.entity.dto.CallbackDTO;
import com.saic.ebiz.pmf.service.entity.dto.PayDTO;
import com.saic.ebiz.pmf.wrapper.VenusGatewayWrapper;

/**
 * . 订单支付服务<br>
 *
 */
@Service("payServiceImpl")
public class PayServiceImpl implements PayService {
    
    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(PayServiceImpl.class);
    
    /** The payment service. */
    @Resource
    private PaymentService paymentService;
    
    /** The gateway. */
    @Resource
    private Gateway gateway;
    
    /**
     * . {@inheritDoc}
     * @param pay the pay
     * @return the string
     * @see com.saic.ebiz.service.pay.intf.PayService#payment(pay)
     */

    @Override
    public String payment(final PayDTO pay) {
        String url = "";
        LOGGER.info("PayServiceImpl:payment:pay:" + JSONObject.toJSONString(pay));
        VenusGatewayWrapper venusGatewayWrapper = new VenusGatewayWrapper(gateway);
        url = venusGatewayWrapper.invoke(pay,String.class);
        LOGGER.info("PayServiceImpl:payment:url:" + url);
        return url;
    }

    /**
     * . {@inheritDoc}
     * 
     * @param url the url
     * @param type the type
     * @return the string
     * @see com.saic.ebiz.service.pay.intf.updatePaymentAndCallBack#verifyInfo(url , type)
     */
    @Override
    public String updatePaymentAndCallBack(Map<String, String> params , String type) {
        LOGGER.info("PayServiceImpl:verifyInfo:url:" + JSONObject.toJSONString(params));
        LOGGER.info("PayServiceImpl:verifyInfo:type:" + type);
        CallbackDTO dto = new CallbackDTO();
        dto.setProvider("alipay");
        dto.setService("mainsitecallback");
        dto.setParams(params);
        dto.setType(type);
        VenusGatewayWrapper venusGatewayWrapper = new VenusGatewayWrapper(gateway);
        String resultStr = venusGatewayWrapper.invoke(dto,String.class);
        LOGGER.info("resultStr>>>"+resultStr);
        return resultStr;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String appUpdatePaymentAndCallBack(Map<String, String> params, String type) {
        LOGGER.info("app--PayServiceImpl:verifyInfo:url:" + JSONObject.toJSONString(params));
        LOGGER.info("app--PayServiceImpl:verifyInfo:type:" + type);
        CallbackDTO dto = new CallbackDTO();
        dto.setProvider("alipay");
        dto.setService("mobileappcallback");
        dto.setParams(params);;
        dto.setType(type);
        VenusGatewayWrapper venusGatewayWrapper = new VenusGatewayWrapper(gateway);
        String resultStr = venusGatewayWrapper.invoke(dto,String.class);
        return resultStr;
    }

}
