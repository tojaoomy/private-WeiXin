/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.order.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.order.service.SaicOrderService;
import com.saic.ebiz.order.service.api.PreOrderCreateService;
import com.saic.ebiz.order.service.entity.PreOrder;
import com.saic.ebiz.order.service.exception.PreOrderQuotaLackException;
import com.saic.framework.redis.client.IRedisClient;

/**
 * @author hejian
 *
 */
@Service("saicOrderServiceImpl")
public class SaicOrderServiceImpl implements SaicOrderService {

	private final Logger log = LoggerFactory.getLogger(getClass());
	
	/** 订单有效期 一个小时. */
	private static final int ORDER_INTERVAL = 60*60;
	
	/** Redis 缓存的Key组成*/
	private static final String CACHE_KEY = "ms:order:interval:";
	
	/** 冒号分隔符  */
	private static final String COLON = ":";
	
	/** 生成预订单服务 */
    @Resource
    private PreOrderCreateService preOrderCreateService;
    
	/**缓存接口.*/
    @Resource(name="springRedisClient")
    private IRedisClient springRedisClient;
    
	/* (non-Javadoc)
	 * @see com.saic.ebiz.msweb.service.SaicOrderService#createPreOrder(com.saic.ebiz.order.service.entity.PreOrder, java.lang.Long, java.lang.Long)
	 */
	@Override
	public String createPreOrder(PreOrder preOrder, Long subscriptionId) throws PreOrderQuotaLackException {
		String orderCode = null;
		//因为订单失效时间1小时,在缓存中放置报名号，失效时间1小时
		//为的是防止同一个商品重复下单
		//但是假如业务允许一个商品可以多次下单，此种方式会有问题，待以后解决
		if (springRedisClient.setnx(CACHE_KEY + subscriptionId,Constants.REDIS_NAME_SPACE,preOrder.getPrmtActId() + COLON + preOrder.getVelModelId()) == 1) {
			springRedisClient.setex((CACHE_KEY + subscriptionId),Constants.REDIS_NAME_SPACE , ORDER_INTERVAL, preOrder.getPrmtActId() + COLON + preOrder.getVelModelId());
			log.info("报名号成功放入redis>>" + (CACHE_KEY + subscriptionId));
			try {
				orderCode = preOrderCreateService.createPreOrder(preOrder);
				log.info("调用服务 preOrderCreateService.createPreOrder预生成订单号: ", orderCode);
				if (orderCode != null) {
					//key = ms:order:interval:subscriptionId
					//value = promotionId:velModelId
					springRedisClient.setex(CACHE_KEY + orderCode,Constants.REDIS_NAME_SPACE, ORDER_INTERVAL, (CACHE_KEY + subscriptionId));
					log.info("订单号成功放入redis>>" + CACHE_KEY + orderCode);
				}
			} catch (PreOrderQuotaLackException e) {
				log.error("配额不足", e.getMessage());
				//清除redis cache
				springRedisClient.del(CACHE_KEY + subscriptionId,Constants.REDIS_NAME_SPACE);
				throw e;
			}
		} else {
			log.warn(" 报名号{}已经下过单，需要去订单中心支付或取消订单 ",subscriptionId);
			orderCode = "-1";
		}
		return orderCode;
	}

}
