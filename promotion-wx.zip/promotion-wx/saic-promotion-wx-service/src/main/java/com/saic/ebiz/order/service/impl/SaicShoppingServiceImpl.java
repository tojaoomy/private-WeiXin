/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.order.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.framework.web.freemarker.MultiDomUrl;
import com.meidusa.fastjson.JSON;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.carlib.service.client.BrandClient;
import com.saic.ebiz.carlib.service.client.VelColorClient;
import com.saic.ebiz.carlib.service.client.VelModelInfoClient;
import com.saic.ebiz.carlib.service.client.VelSeriesClient;
import com.saic.ebiz.carlib.service.entity.VelBrand;
import com.saic.ebiz.carlib.service.entity.VelColor;
import com.saic.ebiz.carlib.service.entity.VelModelColorExt;
import com.saic.ebiz.carlib.service.entity.VelSeries;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.mdm.partner.client.StoreClient;
import com.saic.ebiz.mdm.partner.entity.StoreBaseInfo;
import com.saic.ebiz.order.entity.BrandVO;
import com.saic.ebiz.order.entity.CityVO;
import com.saic.ebiz.order.entity.ColorImageVO;
import com.saic.ebiz.order.entity.PreOrderVO;
import com.saic.ebiz.order.entity.ProductVO;
import com.saic.ebiz.order.entity.PromotionStore;
import com.saic.ebiz.order.entity.ProvinceVO;
import com.saic.ebiz.order.entity.SeriesVO;
import com.saic.ebiz.order.service.SaicShoppingService;
import com.saic.ebiz.promotion.service.api.IPreOrderPromotionService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
import com.saic.ebiz.promotion.service.vo.CxgMerchandiseVO;
import com.saic.ebiz.promotion.service.vo.StoreVO;

import freemarker.template.TemplateModelException;

/**
 * @author hejian
 *
 */
@Service("saicShoppingServiceImpl")
public class SaicShoppingServiceImpl implements SaicShoppingService {

	private Logger log = LoggerFactory.getLogger(getClass());
	
	/** The multiple domain image url . */
    @Resource
    private MultiDomUrl fmImgUrl;
    
    /**
     * 经销商客户端
     */
    @Resource
    private StoreClient storeClient;
    
    /**
     * 品牌客户端
     */
    @Resource
    private BrandClient brandClient;
    
    /**
     * 车系客户端
     */
    @Resource
    private VelSeriesClient seriesClient;
    
    /**
     * 车型客户端
     */
    @Resource
    private VelModelInfoClient velModelInfoClient;
    
    /**
     * 车型颜色的图片
     */
    @Autowired
    private VelColorClient velColorClient;
    
    /** 获取新活动扩展信息 */
	@Resource
	private IPromotionExtendService iPromotionExtendService;
	
	/** 预订单查询接口 */
	@Autowired
	private IPreOrderPromotionService iPreOrderPromotionService; 
	
	@Resource
	private IPromotionQualificationService iPromotionQualificationService;
    
	/* (non-Javadoc)
	 * @see com.saic.ebiz.msweb.service.SaicShoppingService#getDealerStoreList(java.lang.Long, java.lang.Long, java.lang.Long,java.lang.Long)
	 */
	@Override
	public List<PromotionStore> getDealerStoreList(Long promotionId,
			Long vehicleModelId, Long colorId,Long cityId) {
		BigDecimal deposit = getDeposit(promotionId);
		// call interface provided by others PS:
		List<StoreVO> stores = this.iPreOrderPromotionService.getStoreListByPrmtModelColor(promotionId, vehicleModelId, colorId);
		List<PromotionStore> storeList = new ArrayList<PromotionStore>();
		
		StoreBaseInfo store = null;
		for (StoreVO entity : stores) {
			try {
				//if findStoresByStoresIds 返回空list，会报异常信息
				store = this.storeClient.findStoresByStoresIds(entity.getStoreId()).get(0);
			} catch (Exception ex) {
				ex.printStackTrace();
				this.log.info("storeClient.findStoresByStoresIds 返回空list");
				continue;
			}
			
			PromotionStore promotionStore = new PromotionStore();
			promotionStore.setAddress(store.getAddress());
			promotionStore.setLatitude(store.getLatitude());
			promotionStore.setLongitude(store.getLongitude());
			promotionStore.setStoreId(store.getStoreId());
			promotionStore.setStoreName(store.getStoreName());
			promotionStore.setDeposit(deposit);
			promotionStore.setPhoneNumber(store.getHotLine());
			promotionStore.setStock(entity.getAvailableNum());
			promotionStore.setQq(entity.getQq());
			
			long storeCityId = store.getCityId();
			//only is this city,add to list
			if (storeCityId == cityId) {
				storeList.add(promotionStore);
			}
		}
		this.log.info("车享购获取经销商列表:",JSONObject.toJSONString(storeList));
		return storeList;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.msweb.service.SaicShoppingService#getDeposit(long, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public BigDecimal getDeposit(long promotionId) {
		return iPromotionExtendService.findPromotionExtendByPromotionId(promotionId).getDeposit();
	}

	/* 
	 * 车享购二期一个活动对应一个商品，即一对一，车享购二期可以通过promotionId来查询所有的车型列表
	 * 车享购三期一个活动对应多个商品，即一对多，但是现在必须用活动+车型来定位所有的列表
	 * (non-Javadoc)
	 * @see com.saic.ebiz.msweb.service.SaicShoppingService#getVehicleModelList(Long ,Long ,Long ,Long )
	 * 
	 */
	@Override
	public List<BrandVO> getVehicleModelList(Long promotionId, Long vehicleModelId) {
		List<BrandVO> brandList = new ArrayList<BrandVO>();
		VelModelColorExt vehicle = this.findModelById(vehicleModelId);
		
		if(log.isInfoEnabled()){
			log.info(" getVehicleModelList -> promotionId : {} , vehicleModelId : {}",promotionId , vehicleModelId);
		}
		
		//构建BrandVO Object
		BrandVO brandVO = new BrandVO();
		brandVO.setValue(vehicle.getVelBrandId());
		brandVO.setText(this.findBrandById(vehicle.getVelBrandId()).getVelBrandChsName());
		List<SeriesVO> seriesList = new ArrayList<SeriesVO>();
		
		//构建SeriesVO Object
		SeriesVO seriesVO = new SeriesVO();
		seriesVO.setBrandId(vehicle.getVelBrandId());
		seriesVO.setValue(vehicle.getVelSeriesId());
		seriesVO.setText(this.findSeriesById(vehicle.getVelSeriesId()).getVelSeriesChsName());
		List<ProductVO> vehicleModelList = new ArrayList<ProductVO>();

		//构建ProductVO Object
		ProductVO productVO = new ProductVO();
		productVO.setSeriesId(vehicle.getVelSeriesId());
		productVO.setValue(vehicle.getVelModelId());
		productVO.setText(vehicle.getVelModelName());

		List<ColorImageVO> colorList = new ArrayList<ColorImageVO>(); 
		//TBD 通过promotionId和VehicleModelId获取颜色
		//返回的颜色ID不能重复，如果有需去重，经过确认接口返回不重复
		List<Long> colorIdSet = this.iPreOrderPromotionService.getColorListByPrmtModelId(promotionId, vehicleModelId);

		//if null,indicate that have not set the color for this vehicle mode
		if(colorIdSet == null || colorIdSet.isEmpty()){
            List<VelColor> list = vehicle.getVelColors();
            for (VelColor velColor : list) {
            	colorList.add(setVelColorImage(velColor));
            }
		}else{
			for(Iterator<Long> it = colorIdSet.iterator(); it.hasNext();){
				VelColor velColor = velColorClient.findColorByColorId(it.next());
				colorList.add(setVelColorImage(velColor));
			}
		}

		productVO.setChildren(colorList);
		vehicleModelList.add(productVO);
		seriesVO.setChildren(vehicleModelList);
		seriesList.add(seriesVO);
		brandVO.setChildren(seriesList);
		brandList.add(brandVO);
		log.info("车型对应颜色列表" + JSON.toJSONString(brandList));
		return brandList;
	}
	@Override
	public List<BrandVO> getListBySeriesId(Long promotionId, Long brandId, Long seriesId) {
		List<BrandVO> brandList = new ArrayList<BrandVO>();
		List<CxgMerchandiseVO> merchandiseList = iPromotionQualificationService.getVelModelColorForCxgBySeries(promotionId,brandId,seriesId);
		
		if(log.isInfoEnabled()){
			log.info(" getListBySeriesId -> promotionId : {} , vehicleModelId : {}",promotionId , seriesId);
		}
		//构建BrandVO Object
		BrandVO brandVO = new BrandVO();
		brandVO.setValue(brandId);
		brandVO.setText(this.findBrandById(brandId).getVelBrandChsName());
		List<SeriesVO> seriesList = new ArrayList<SeriesVO>();
		
		//构建SeriesVO Object
		SeriesVO seriesVO = new SeriesVO();
		seriesVO.setBrandId(brandId);
		seriesVO.setValue(seriesId);
		seriesVO.setText(this.findSeriesById(seriesId).getVelSeriesChsName());
		List<ProductVO> vehicleModelList = new ArrayList<ProductVO>();
			
		//构建ProductVO Object
		for (int i = 0; i < merchandiseList.size(); i++) {
			ProductVO productVO = new ProductVO();
			productVO.setSeriesId(seriesId);
			productVO.setValue(merchandiseList.get(i).getVelModelId());
			productVO.setText(this.findModelById(merchandiseList.get(i).getVelModelId()).getVelModelName());
			
//			List<ColorImageVO> colorList = new ArrayList<ColorImageVO>(); 
//			//TBD 通过promotionId和VehicleModelId获取颜色
//			//if null,indicate that have not set the color for this vehicle mode
//			if(merchandiseList.get(i).getColorIdList() == null || merchandiseList.get(i).getColorIdList().size() > 0){
//				for (int k = 0; k < merchandiseList.get(i).getColorIdList().size(); k++) {
//					VelColor velColor = velColorClient.findColorByColorId(merchandiseList.get(i).getColorIdList().get(k));
//					colorList.add(setVelColorImage(velColor));
//				}
//			}
//			productVO.setChildren(colorList);
			vehicleModelList.add(productVO);
		}
		seriesVO.setChildren(vehicleModelList);
		seriesList.add(seriesVO);
		brandVO.setChildren(seriesList);
		brandList.add(brandVO);
		log.info("车型对应颜色列表" + JSON.toJSONString(brandList));
		return brandList;
	}
	
	@Override
	public List<ColorImageVO> getColorListBySeriesId(Long promotionId, Long vehicleModelId){
		List<ColorImageVO> colorList = new ArrayList<ColorImageVO>(); 
		VelModelColorExt vehicle = this.findModelById(vehicleModelId);
		List<Long> colorIdSet = this.iPreOrderPromotionService.getColorListByPrmtModelId(promotionId, vehicleModelId);
		if(colorIdSet == null || colorIdSet.isEmpty()){
            List<VelColor> list = vehicle.getVelColors();
            for (VelColor velColor : list) {
            	colorList.add(setVelColorImage(velColor));
            }
		}else{
			for(Iterator<Long> it = colorIdSet.iterator(); it.hasNext();){
				VelColor velColor = velColorClient.findColorByColorId(it.next());
				colorList.add(setVelColorImage(velColor));
			}
		}
		return colorList;
	}
	
	private ColorImageVO setVelColorImage(VelColor velColor){
		ColorImageVO colorImageVO = new ColorImageVO();
		colorImageVO.setColorId(velColor.getVelColorId());
		colorImageVO.setColorName(velColor.getVelColorChsName());
		colorImageVO.setImageId(velColor.getColorImgId());
		colorImageVO.setImageUrl(addPath(velColor.getVelColorImgPath()));
		return colorImageVO;
	}

	/* (non-Javadoc)
	 * @see com.saic.ebiz.msweb.service.SaicShoppingService#placeOrder(com.saic.ebiz.msweb.entity.PreOrderVO, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public String placeOrder(PreOrderVO preOrderVO, HttpServletRequest request) {
		return null;
	}

	/**
     * 本地工具类:
     * 功能描述: 设置图片路径<br>
     * @param velColorImgPath
     * @return
     * @throws TemplateModelException
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String addPath(String velColorImgPath){
        List<String> args = new ArrayList<String>();
        args.add("/26x12"+velColorImgPath);
        String result = "";
        try {
            result = String.valueOf(fmImgUrl.exec(args));
        } catch (TemplateModelException e) {
           log.error("图片路径设置失败");
        }
        return result;
    }

	@Override
	public VelBrand findBrandById(Long brandId) {
		return this.brandClient.findBrandById(brandId);
	}

	@Override
	public VelSeries findSeriesById(Long seriesId) {
		return this.seriesClient.findSeriesById(seriesId);
	}

	@Override
	public VelModelColorExt findModelById(Long vehicleModelId) {
		return this.velModelInfoClient.findModelWithColorById(vehicleModelId);
	}

	/**
	 * 
	 * @param promotionId
	 * @param showProvince 该属性，TRUE显示省份和城市列表 ,FALSE在预订单页只显示城市
	 * @return
	 */
	@Override
	public List<ProvinceVO> getProvinceVOByPromotionId(Long promotionId,Long vehicleModelId,boolean showProvince,Long colorId) {
		Map<Long,List<Long>> provinceCityMap = iPromotionQualificationService.getCityMapByPromotionIdVelModelId(promotionId,vehicleModelId,colorId);
		if(showProvince){
			return populateProvinceCityAll(provinceCityMap);
		} else{
			//useless
			return populateProvinceCityOnly(provinceCityMap); 
		}
	}

	/**
	 * TBD 暂时未处理，该功能还不需实现
	 * @param provinceCityMap
	 * @return
	 */
	private List<ProvinceVO> populateProvinceCityAll(Map<Long,List<Long>> provinceCityMap){
		Set<Long> keys = provinceCityMap.keySet();
		Iterator<Long> it = keys.iterator();
		List<ProvinceVO> provinceVOList = new ArrayList<ProvinceVO>();
		while(it.hasNext()){
			Long provinceId = it.next();
			//获取省份信息
			DataItemBean dataItemBean = ConstantCodeService.getRegionInfo(String.valueOf(provinceId));
			if(dataItemBean != null){
				ProvinceVO provinceVO = new ProvinceVO();
				provinceVO.setText(dataItemBean.getName());
				provinceVO.setValue(Long.valueOf(dataItemBean.getCode()));
				//遍历城市列表
				List<Long> cityIdList = provinceCityMap.get(provinceId);
				List<CityVO> cities = new ArrayList<CityVO>();
				for(Long cityId : cityIdList){
					dataItemBean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
					if (dataItemBean != null) {
						CityVO cityVO = new CityVO();
						cityVO.setText(dataItemBean.getName());
						cityVO.setValue(Long.valueOf(dataItemBean.getCode()));
						cityVO.setPvalue(Long.valueOf(dataItemBean.getParentCode()));
						cities.add(cityVO);
					}
				}
				provinceVO.setChildren(cities);
				provinceVOList.add(provinceVO);
			}
		}
		return provinceVOList;
	}
	
	private List<ProvinceVO> populateProvinceCityOnly(Map<Long,List<Long>> provinceCityMap){
		Collection<List<Long>> values = provinceCityMap.values();
		//存放所有的城市ID
		List<Long> cityIdList = new ArrayList<Long>();
		Iterator<List<Long>> it = values.iterator();
		while(it.hasNext()){
			cityIdList.addAll(it.next());
		}
		//根据城市ID排序，以防出现乱序的情形
		Collections.sort(cityIdList);
		
		List<ProvinceVO> results = new ArrayList<ProvinceVO>();
		ProvinceVO provinceVO = new ProvinceVO();
		//因为province对应前台来说没什么用，所以传值-1和“”，表明是显示全部的信息
		provinceVO.setValue(-1L);
		provinceVO.setText("");
		/////////////////////////////////////////////
		
		List<CityVO> cities = new ArrayList<CityVO>();
		for(Long cityId : cityIdList){
			DataItemBean dataItemBean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
			if (dataItemBean != null) {
				CityVO cityVO = new CityVO();
				cityVO.setText(dataItemBean.getName());
				cityVO.setValue(Long.valueOf(dataItemBean.getCode()));
				//设置省份为-1和上面同步
				cityVO.setPvalue(-1L);
				cities.add(cityVO);
			}
		}
		provinceVO.setChildren(cities);
		results.add(provinceVO);
		return results;
	}
	
	@Override
	public List<CityVO> getCityOnly(Long promotionId,Long vehicleModelId,Long colorId){
		Map<Long,List<Long>> provinceCityMap = iPromotionQualificationService.getCityMapByPromotionIdVelModelId(promotionId, vehicleModelId,colorId);
		Collection<List<Long>> values = provinceCityMap.values();
		
		//存放所有的城市ID
		List<Long> cityIdList = new ArrayList<Long>();
		Iterator<List<Long>> it = values.iterator();
		while(it.hasNext()){
			cityIdList.addAll(it.next());
		}
		
		//根据城市ID排序，以防出现乱序的情形
		Collections.sort(cityIdList);
		
		List<CityVO> cities = new ArrayList<CityVO>();
		
		for(Long cityId : cityIdList){
			DataItemBean dataItemBean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
			if (dataItemBean != null) {
				CityVO cityVO = new CityVO();
				cityVO.setText(dataItemBean.getName());
				cityVO.setValue(Long.valueOf(dataItemBean.getCode()));
				//设置省份为-1和上面同步
				cityVO.setPvalue(-1L);
				cities.add(cityVO);
			}
		}
		return cities;
	}


}
