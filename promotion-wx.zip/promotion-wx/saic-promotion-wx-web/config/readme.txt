/**
 * Copyright (C), 2014-4-12, 上汽电商
 * 
 * @author 汤斐
 * @version 1.0
 * @date 2014-4-12
 */
 
一。 框架要求环境要求
   1. jdk版本: jdk1.7.0_45以上
   2. tomcat版本: apache-tomcat-7.0.52以上
   3. mysql版本: 5.5.31 建议
   4. maven版本: apache-maven-3.2.1 建议
   
二。框架实现功能
   1.spring4mvc (json数据传输)
   2.spring4websocket stomp (mvc服务端), stomp.js客户端
   3.spring4websocket handler 服务端,websocket-api客户端调用
   4.venus调用 (支付功能，短信功能)
   5.mybatis接入
   6.公司统一配置的接入
   7.logback日志接入
 
三. maven配置说明
         为方便在真机环境和公司的虚机环境都能使用本框架，在框架中配置了两套私服的settings
   (1)。项目组私服配置。
                 项目组 私服地址：http://192.168.22.58:8081/nexus/
                   配置说明：将框架中 /config/mvn-config/l_settings.txt中内容 拷贝到(真机上的本地私服环境)/pache-maven-3.2.1-bin/conf/settings.xml中,将其全部覆盖
                                         修改settings.xml中的本地仓库地址,如下：
                   <localRepository>D:\maven\repository</localRepository>
   (2)。公司私服配置。
                 项目组 私服地址：http://maven.dds.com/nexus/
                   配置说明：将框架中 /config/mvn-config/v_settings.txt中内容 拷贝到(虚机上的本地私服环境)/pache-maven-3.2.1-bin/conf/settings.xml中,将其全部覆盖
                                         修改settings.xml中的本地仓库地址,如下：
                   <localRepository>D:\maven\repository</localRepository>
                   
   (3).如需在框架中新增jar包，在pom.xml增加依赖，需通知项目组私服管理员，在项目组私服上添加相应的jar包。    
   (4).如非特殊情况，真机的maven的setting不能直接配置v_sttings.xml的内容。      
                   
四。代码管理
        在提交代码时，无需提交框架下/target目录和.classpath文件。
 
五。框架中测试说明
   1.TestCityController  
                 测试功能点:springmvc,radis缓存服务器
   2.TestPaymentController 
                 测试功能点:venus的支付功能
   3.TestPinController 
                 测试功能点:venus的短信功能
   4.TestGrape
                测试功能点:资源文件内容获取
   5.test_handler.html
                测试功能点: spring4websocket handler测试
   6.test_stomp1.html
                测试功能点: spring4websocket stomp订阅发布测试   
              
                 
六。统一配置说明
     1.在/conf/applicationContext.xml的 propertyPlaceholderConfigurer节点中做统一配置
     2.application.properties中配置统一配置服务器地址
     3.propertyPlaceholderConfigurer节点可以配置读本地资源文件和统一配置服务器的切换
       <!-- 统一配置 -->
	   <bean id="propertyPlaceholderConfigurer" class="com.saic.grape.utils.CustomizedPropertyPlaceholderConfigurer">
			<property name="ignoreUnresolvablePlaceholders" value="true" />
			<property name="locations">
				<list>
				    <!-- 接统一配置   -->
				    <value>classpath:application.properties</value>
				    <!--  
				    <value>classpath:jdbc.properties</value>
				    <value>classpath:redis.properties</value>
				    -->
					<value>classpath:grape_conf.properties</value>
					<value>classpath:constant.properties</value>
				</list>
			</property>
			<property name="fileEncoding" value="utf-8" />
	  </bean>
	 
	 
       
    
  