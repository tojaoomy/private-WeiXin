package com.saic.ebiz.baba.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.ibm.framework.web.gson.GsonView;

/**
 * baba 埋点
 * @author v_hexiang
 *
 */
@Controller
@RequestMapping("/babaMD")
public class BaBaJieMaiDianController {
	
	/** The Constant logger. */
	private final static Logger logger = LoggerFactory
			.getLogger(BaBaJieMaiDianController.class);
	
//	/** 缓存接口. */
//	@Resource(name = "springRedisClient")
//	private IRedisClient redisClient;
	
	/**
	 * 用户行为跟踪logger.
	 */
	private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");
	
	
	/**
	 * 叭叭主会场wx规则页
	 * @param keyId 规则页key
	 * @v_hexiang
	 */
	@RequestMapping("/getrule")
	public GsonView getBaBaJieRule(HttpServletRequest request,String userId,String keyId){
		GsonView gv = new GsonView();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Cookie[] cookies = request.getCookies();
		String userTraceCookie = "";
		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if ("user_trace_cookie".equals(name)) {
				userTraceCookie = cookie.getValue();
				break;
			}
		}
		if(!StringUtils.isEmpty(keyId) && keyId.equals("rule001")){
			usertraceLogger.info("\t zj \t"+userTraceCookie + "\t" + userId + "\t"
			 + format.format(new Date())+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_"+keyId+"\t" 
			 + "中奖查询活动规则微信端"+"\t " + request.getHeader("user-agent") 
			 + "\t" + 3 + "\t" + 13);
		}else if(keyId.equals("rule002")){
			usertraceLogger.info("\t hy \t"+userTraceCookie + "\t" + userId + "\t"
			 + format.format(new Date())+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_"+keyId+"\t" 
			 + "开始抽奖活动规则微信端"+"\t " + request.getHeader("user-agent") 
			 + "\t" + 3 + "\t" + 13);	
		}else{
			usertraceLogger.info("\t bf \t"+userTraceCookie + "\t" + userId + "\t"
			 + format.format(new Date())+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_"+keyId+"\t" 
			 + "不服来比活动规则微信端"+"\t " + request.getHeader("user-agent") 
			 + "\t" + 3 + "\t" + 13);
		}
			
		return gv;
	}
	
	
	/**
	 * 获取客户端ip
	 * 
	 * @param request
	 * @return
	 */
	public String getIp(HttpServletRequest request) {
		logger.info("获取客户端ip地址");
		String ip = null;
		try {
			ip = request.getHeader("x-forwarded-for");
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
			logger.info("客户端ip地址为：" + ip);
			return ip;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("发生异常ip地址获取失败");
			return null;
		}

	}

}
