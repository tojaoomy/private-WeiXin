package com.saic.ebiz.baba.controller;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.saic.framework.redis.client.IRedisClient;
import com.ibm.framework.web.gson.GsonView;
import com.meidusa.fastjson.JSONObject;
import com.meidusa.toolkit.common.bean.config.ConfigUtil;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.util.payment.SignUtil;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.util.ControllerUtil;
import com.saic.ebiz.market.util.DesUtil;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.ebiz.promotion.service.api.IBeepReservedService;
import com.saic.ebiz.promotion.service.api.IGiftManagerService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionPreheatingPageService;
import com.saic.ebiz.promotion.service.api.IQAWarehouseService;
import com.saic.ebiz.promotion.service.api.IVenueService;
import com.saic.ebiz.promotion.service.commons.constants.RedisConstants;
import com.saic.ebiz.promotion.service.commons.enums.BusinessType;
import com.saic.ebiz.promotion.service.entity.CampaignSigninDetailEntity;
import com.saic.ebiz.promotion.service.entity.GiftQuotaEntity;
import com.saic.ebiz.promotion.service.vo.CampaignSigninVo;
import com.saic.ebiz.promotion.service.vo.OrderInfoVo;
import com.saic.ebiz.promotion.service.vo.PromotionResult;
import com.saic.ebiz.promotion.service.vo.QAWarehouseVo;
import com.saic.ebiz.promotion.service.vo.ReservedParamsVo;
import com.saic.ebiz.promotion.service.vo.ReturnMsgVo;
import com.saic.ebiz.promotion.service.vo.UserInfo;
import com.saic.ebiz.promotion.service.vo.VenueRemind;
import com.saic.ebiz.web.entity.BaBaJie3FModel;
import com.saic.sso.client.SSOClient;

@Controller
@RequestMapping("/babajie")
@SuppressWarnings("all")
public class BaBaJiePreheatController {

	
	/**
	 * SSO服务
	 */
	@Autowired
	private SSOClient ssoClient;
	@Autowired
	private IMemberService memberService;
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
	/** 注册验证码过期时间，秒 */
	private static final int VALIDCODE_EXPIRE = 60;
	
	/** 验证重复提交key */
	private static final String TOKEN_KEY = "yanzhengchongfutijiao";
	
	 /**
	  * callback域名
	  */
//	private @Value("${ebiz.wap.web.domainCallback:}") String domainCallback;
	    
	  /**
	   * 订单二级域名
	   */
	private @Value("${ebiz.wap.web.domain:}") String domain;


	/** 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");
	/**
	 * 日志
	 */
	private final Logger logger = LoggerFactory
			.getLogger(BaBaJiePreheatController.class);

	/**
	 * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	@Autowired
	private JsSDKSign jsSDKSign;

	@Autowired
	private IVenueService iVenueService;
	
	
	 /**
	  * 签到信息
	  */
	@Autowired
	private IQAWarehouseService iqAWarehouseService;
	
	/** 缓存接口. */
	@Resource(name = "springRedisClient")
	private IRedisClient redisClient;
	
	/** 验证码key */
	public static final String VALIDATECODE_REDIS_KEY = "mini:promotion:authCode:validateCode:";
	  
	/**
	 * 1F调用4个礼包接口
	 */
	@Autowired
	private IPromotionPreheatingPageService ipromotionPreheatingPageService;
	
	@Autowired
	private IGiftManagerService iGiftManagerService;
	/**
	 * 提交订单
	 */
	@Autowired
	private IBeepReservedService beepReservedService;

	/**
	 * 支付渠道
	 */
	private static int CHANNELTYPE = 1;

	/**
	 * 支付者编号, 固定值
	 */
	private static final String PAY_CODE = "201406170000000004";
	/**
	 * 绑定服务
	 */
	@Resource
	private BoundingService boundingService;
	/**
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	/** 3F页面所需内容静态块 */
	private static List<BaBaJie3FModel> List_3f = new ArrayList<BaBaJie3FModel>();
	static {
		init3_lsit();
	}
	/**
	 * 2F加载所需静态块
	 * 
	 * @param userId
	 * @param request
	 * @return
	 */
	static List<String> codeList = new ArrayList<String>();
	static {
		codeList.add("baba_polo");
		codeList.add("baba_pst");
		codeList.add("baba_mr");
		codeList.add("baba_xr");
		codeList.add("baba_yl");
		codeList.add("baba_jw");
		codeList.add("baba_ck");
		codeList.add("baba_clz");
		codeList.add("baba_kdlc");
		codeList.add("baba_rx");
		codeList.add("baba_mg3");
		codeList.add("baba_rw550");
		codeList.add("baba_rw350");
		codeList.add("baba_bj330");
		codeList.add("baba_bj560");
		codeList.add("baba_hg");
		codeList.add("baba_hgv");
		codeList.add("baba_g10");
		codeList.add("baba_mrb");
	}

	@RequestMapping("/main")
	public ModelAndView main(
			@RequestParam(value = "userId", required = false) Long userId,
			HttpServletRequest request) {
		ModelAndView mv = null;
		String uId = request.getParameter(RequestConstants.USER_ID);
		UserInfo user = null;
		//if (Integer.valueOf(uId) > 0) {
			if (!StringUtils.isEmpty(uId) &&  !"-1".equals(uId)) {
			user = memberService.findMembCentInfo(Integer.valueOf(uId));
			//check用户是否已经关注
			userConcernCheck(mv,user);
		}
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		logger.info("request parameters userId = {}, openId = {} ", uId, openId);
		if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
			String autorizationUrl = "redirect:"
					+ authorizationService.buildAuthorizationLink(appId,
							(redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE",
					Authorization.babajie.name());
			logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
			logger.debug("授权url : {} ######", autorizationUrl);
			mv = new ModelAndView(autorizationUrl);
		} else {
			boolean timeLater = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-08-08 00:00:00"); 
			if(timeLater){
				mv = new ModelAndView("forward:/babamain/index.htm");
				return mv;
			}else{
				mv = new ModelAndView("/babajie/index.ftl");
			
			}
			mv.addObject(RequestConstants.USER_ID, uId).addObject(
					RequestConstants.OPEN_ID, openId);
		
		}

	// 微信分享JSSDK分享
		Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
        mv.addObject("jssdk", map);
        mv.addObject("user", user);
        mv.addObject("userId", userId);
        mv.addObject("openId",openId);
        mv.addObject("isMobileAuth", this.isMobileAuth(request,userId));
        //加载三楼信息
        loadData3F(mv);
        loadData2F(mv,user);
        loadData1F(mv,userId);
		return mv;
	}
	
	/**
	 * 加载1f信息
	 */
	private void loadData1F(ModelAndView mav,Long userId) {
		// 加载一楼信息
		boolean cantsignin = true;
		QAWarehouseVo queryQAWarehouseById = iqAWarehouseService.queryQAWarehouseById(1000001L);
		if(queryQAWarehouseById!=null){
			if("a".equals(queryQAWarehouseById.getQaAttribute())||"A".equals(queryQAWarehouseById.getQaAttribute())){
				cantsignin = false;
			}
		}
		mav.addObject("CANTSIGNIN", cantsignin);

		CampaignSigninVo campaignSigninVo = iqAWarehouseService.queryCampaignSigninByUserId("A-1588", userId);
		  	if (campaignSigninVo != null) {
				// 截取礼包“+”
				String string = campaignSigninVo.getPresentName();
				if(string!=null&&string!=""){
					if(string.startsWith("+")){
						String substring = string.substring(1,string.length());
						campaignSigninVo.setPresentName(substring);
					}
				}
				mav.addObject("signNum", campaignSigninVo.getSigninNum());
			}
		  	
			mav.addObject("campaignSigninVo", campaignSigninVo);
	  }
	
	/**
	 * 加载2f信息
	 */
	private void loadData2F(ModelAndView mav, UserInfo user) {
		// 加载2f
		List<GiftQuotaEntity> queryGifts = iGiftManagerService.queryGifts(6);
		Map<String, GiftQuotaEntity> map = new HashMap<String, GiftQuotaEntity>();
		Map<String, ReservedParamsVo> orderStatus = new HashMap<String, ReservedParamsVo>();
		List<ReservedParamsVo> reservedParamsVos = new ArrayList<ReservedParamsVo>();
		for (GiftQuotaEntity giftQuotaEntity : queryGifts) {

			for (String code : codeList) {
				ReservedParamsVo re = new ReservedParamsVo();
				if (giftQuotaEntity.getGiftCode().equals(code)) {
					re.setMdseCode(code);
					map.put(code, giftQuotaEntity);
					re.setMdseId(Long.parseLong(giftQuotaEntity.getGiftName()));
					re.setBatchId(giftQuotaEntity.getTotalNum());
					if (user != null) {
						re.setMemberId(user.getUserId());
					} else {
						re.setMemberId(-1L);
					}
					reservedParamsVos.add(re);
					continue;
				}

			}

		}

		// 调用接口返回list
		reservedParamsVos = beepReservedService
				.queryOrderStatus(reservedParamsVos);
		// 查询支付状态

		for (ReservedParamsVo reservedParamsVo : reservedParamsVos) {
			for (String code : codeList) {
				if (reservedParamsVo.getMdseCode().equals(code)) {
					orderStatus.put(code, reservedParamsVo);
					continue;
				}
			}
		}
		mav.addObject("orderStatus", orderStatus);
		mav.addObject("queryGifts", map);
		mav.addObject("date", daysBetween());
	}

	// 2f检查领取状态
	@RequestMapping("/checkStatus")
	public GsonView checkStatus(HttpServletRequest request, long mdseId,
			long batchId, String cityId,Long userId) {
		logger.info("订单按钮被点击，准备生成订单，参数mdseId" + mdseId + "batchId" + batchId);
		
		GsonView gv = new GsonView();
		ReservedParamsVo paramsVo = new ReservedParamsVo();
		paramsVo.setMdseId(mdseId);
		paramsVo.setBatchId(batchId);
		paramsVo.setChannelType(CHANNELTYPE);
		paramsVo.setCityId(cityId);
		Date dateTime = null;
		Date date = new Date();
		Long time = date.getTime() + (60 * 60 * 1000);
		dateTime = new Date(time);
		paramsVo.setDeadlineTime(dateTime);
		String linename = "";
		String brandName = request.getParameter("brandName");
		if (brandName != null || !"".equals(brandName)) {
			brandName = "半价车预约";
		}
		paramsVo.setBrandName(brandName);
		paramsVo.setTotalAmt(1);
		UserInfo user = null;
//		Long userId = 60222L;
		if (logger.isDebugEnabled()) {
			logger.debug("获取到的用户的ID为：" + userId);
		}
		if (userId!=null && userId > 0) {
			user = memberService.findMembCentInfo(userId);
			if (user != null) {
				paramsVo.setMemberId(userId);
				paramsVo.setMobile(user.getMobile());
				if (user.getName() != null && !"".equals(user.getName())) {
					paramsVo.setMemberName(user.getName());
				} else {
					paramsVo.setMemberName(user.getMobile());
				}
				// 价格
				paramsVo.setCashPrice(new BigDecimal(88));
				logger.info("获取到的用户的手机信息：" + user.getMobile() + "用户的手机是否绑"
						+ user.getMobileAuthFlag());
				Cookie[] cookies = request.getCookies();
				String userTraceCookie = "";
				for (Cookie cookie : cookies) {
					String name = cookie.getName();
					if ("user_trace_cookie".equals(name)) {
						userTraceCookie = cookie.getValue();
						break;
					}
				}
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				usertraceLogger.info("\t"+userTraceCookie + "\t" + userId + "\t"
						 + format.format(new Date())+"\t "+this.getIp(request)+" \t"+"88_wx_preheat_yxzc_order_"+mdseId +"\t" 
						 + "八八节创建订单"+"\t " + request.getHeader("user-agent") 
						 + "\t" + 3 + "\t" + 13);
			
			} else {
				logger.info("获取到的用户信息失败：userId = " + userId);
			}
		}
		ReturnMsgVo msgVo = new ReturnMsgVo();
		msgVo = beepReservedService.createAndCheckReservation(paramsVo);
		logger.info("订单创建完毕，创建状态：msgVo" + msgVo);
		gv.addStaticAttribute("result", msgVo);
		return gv;
	}

	/**
	 * @Title: activitiesRemind
	 * @Description: 三楼预约(功能描述)
	 * @param @param request
	 * @param @param modelName
	 * @param @param code
	 * @param @param mobile
	 * @param @param userId
	 * @param @return 设定文件
	 * @return GsonView 返回类型
	 * @throws
	 */
	@RequestMapping("/activitiesRemind")
	public GsonView activitiesRemind(HttpServletRequest request,
			@RequestParam String modelName, @RequestParam String code,
			@RequestParam String mobile, @RequestParam String userId,@RequestParam String keyId) {
		GsonView gv = new GsonView();
		if (StringUtils.isEmpty(modelName) || StringUtils.isEmpty(code)
				|| StringUtils.isEmpty(mobile) || StringUtils.isEmpty(userId)) {
			gv.addStaticAttribute("resultMsg", "非法参数,请重新登录并关注!");
			gv.addStaticAttribute("resultCode", "1");
			return gv;
		}
		boolean isRemind = iVenueService.isVenueRemind(code,
				Long.valueOf(userId));
		if (isRemind) {
			gv.addStaticAttribute("resultMsg", "您已关注，感谢你的参与！");
			gv.addStaticAttribute("resultCode", "1");
			return gv;
		}
		VenueRemind venueRemind = new VenueRemind();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date RemindTime;
		try {
			RemindTime = format.parse("2015-08-08 10:00:00");
		} catch (ParseException e) {
			gv.addStaticAttribute("resultMsg", "关注时间错误!");
			gv.addStaticAttribute("resultCode", "1");
			e.printStackTrace();
			return gv;
		}
		venueRemind.setAppId("ma");
		venueRemind.setMsgCode("068");
		venueRemind.setMobile(mobile);
		venueRemind.setVenueCode(code);
		venueRemind.setRemindTime(RemindTime);
		venueRemind.setHdId(Long.valueOf(28));
		venueRemind.setWeekDate(modelName);
		venueRemind.setUserId(Long.parseLong(userId));
		venueRemind.setBusinessType(BusinessType.ACTIVITY.code());
		try {
			boolean addVenueRemind = iVenueService.addVenueRemind(venueRemind);
			if (addVenueRemind) {
				Cookie[] cookies = request.getCookies();
				String userTraceCookie = "";
				for (Cookie cookie : cookies) {
					String name = cookie.getName();
					if ("user_trace_cookie".equals(name)) {
						userTraceCookie = cookie.getValue();
						break;
					}
				}
				usertraceLogger.info("\t bf \t"+userTraceCookie + "\t" + userId + "\t"
						 + format.format(new Date())+"\t "+this.getIp(request)+" \t"+keyId +"\t" 
						 + "八八节半价活动关注成功"+"\t " + request.getHeader("user-agent") 
						 + "\t" + 3 + "\t" + 13);
				gv.addStaticAttribute("resultCode", "0");
				gv.addStaticAttribute("resultMsg",
						"关注成功，活动当天我们将以短信的形式通知您，期待您的参与！");
				return gv;
			} else {
				gv.addStaticAttribute("resultMsg", "关注失败，请稍后重试！");
				gv.addStaticAttribute("resultCode", "1");
				return gv;
			}
		} catch (Exception e) {
			gv.addStaticAttribute("resultMsg", "关注失败,请稍后重试!");
			gv.addStaticAttribute("resultCode", "1");
			e.printStackTrace();
			return gv;
		}
	}

	// 加载三楼信息
	private void loadData3F(ModelAndView mav) {
		// 获取登录的UCM配置
		mav.addObject("accountQuickBase",
				ConfigUtil.getProperties().get("ebiz.ms.web.accountQuickBase"));
		for (BaBaJie3FModel baBaJie3FModel : List_3f) {
			long count = iVenueService.findVenueRemindByCode(baBaJie3FModel.getCode());
			count = count*17;
			baBaJie3FModel.setCount(count+32/3);
			baBaJie3FModel.setCount(count);
		}
		mav.addObject("promotionlist", List_3f);
	}
	//检查用户是否以关注
	private void userConcernCheck(ModelAndView mav, UserInfo user) {
		// TODO Auto-generated method stub
		Boolean isConcern = null;
		for (BaBaJie3FModel baBaJie3FModel : List_3f) {
			isConcern = iVenueService.isVenueRemind(baBaJie3FModel.getCode(),
					user.getUserId());
			baBaJie3FModel.setIsConcern(isConcern);
		}
	}
	// 3F数据初始化
	private static void init3_lsit() {
		BaBaJie3FModel model01 = new BaBaJie3FModel("荣威550",
				"2014款 550S 1.8L 自动智选版", "c_baba_3f_lw550.png", "146.331",
				"11?,?00", "c_baba_3f_01");

		BaBaJie3FModel model02 = new BaBaJie3FModel("MG GS",
				"2015款 1.5TGI TST精英版", "c_baba_3f_mg.png", "157,201",
				"13?,?00", "c_baba_3f_02");

		BaBaJie3FModel model03 = new BaBaJie3FModel("新途观",
				"2015款 1.8TSI 自动两驱舒适版", "c_baba_3f_xtg.png", "264.983",
				"2??,?00", "c_baba_3f_03");

		BaBaJie3FModel model04 = new BaBaJie3FModel("新朗逸",
				"2013款 改款 1.6L 自动舒适版", "c_baba_3f_xly.png", "155.252",
				"11?,?00", "c_baba_3f_04");

		BaBaJie3FModel model05 = new BaBaJie3FModel("新帕萨特",
				"2014款 1.8TSI DSG尊雅版", "c_baba_3f_xpst.png", "227.789",
				"1??,?00", "c_baba_3f_05");

		BaBaJie3FModel model06 = new BaBaJie3FModel("明锐", "2015款1.6L 自动逸俊版",
				"c_baba_3f_mr.png", "170.570", "1??,?00", "c_baba_3f_06");

		BaBaJie3FModel model07 = new BaBaJie3FModel("全新英朗", "2015款 15N 自动豪华型",
				"c_baba_3f_yl.png", "153.874", "12?,?00", "c_baba_3f_07");

		BaBaJie3FModel model08 = new BaBaJie3FModel("昂科威", "2014款 28T 四驱精英型",
				"c_baba_3f_kw.jpg", "301.624", "26?,?00", "c_baba_3f_08");

		BaBaJie3FModel model09 = new BaBaJie3FModel("君威", "2015款 1.6T 领先技术型",
				"c_baba_3f_jw.png", "211.921", "1??,?00", "c_baba_3f_09");

		BaBaJie3FModel model10 = new BaBaJie3FModel("迈锐宝", "2014款 2.0L 自动豪华版",
				"c_baba_3f_wrb.png", "209.215", "1??,?00", "c_baba_3f_10");

		BaBaJie3FModel model11 = new BaBaJie3FModel("科鲁兹", "2015款 1.5L 自动豪华版",
				"c_baba_3f_klz.jpg", "155.252", "11?,?00", "c_baba_3f_11");

		BaBaJie3FModel model12 = new BaBaJie3FModel("宝骏730",
				"2014款 1.5L手动舒适ESP版 7座", "c_baba_3f_bj730.jpg", "86.954",
				"7?,?00", "c_baba_3f_12");

		BaBaJie3FModel model13 = new BaBaJie3FModel("2015款G10", " 2.0T自动纪念版",
				"c_baba_3f_g10.png", "181.890", "1??,?00", "c_baba_3f_13");

		BaBaJie3FModel model14 = new BaBaJie3FModel("凯迪拉克ATS-L ",
				"2014款 25T 舒适型 ", "c_baba_3f_ATS-L.jpg", "321.704", "25?,?00",
				"c_baba_3f_14");

		BaBaJie3FModel model15 = new BaBaJie3FModel("森林人", "2015款 2.5i 特装纪念版",
				"c_baba_3f_slr.jpg", "283.953", "24?,?00", "c_baba_3f_15");

		BaBaJie3FModel model16 = new BaBaJie3FModel("尚酷 ", "2015款 1.4TSI 风尚版",
				"c_baba_3f_slb.jpg", "248.668", "1??,?00", "c_baba_3f_16");
		List_3f.add(model01);
		List_3f.add(model02);
		List_3f.add(model03);
		List_3f.add(model04);
		List_3f.add(model05);
		List_3f.add(model06);
		List_3f.add(model07);
		List_3f.add(model08);
		List_3f.add(model09);
		List_3f.add(model10);
		List_3f.add(model11);
		List_3f.add(model12);
		List_3f.add(model13);
		List_3f.add(model14);
		List_3f.add(model15);
		List_3f.add(model16);
	}

	/**
	 * 计算两个日期之间相差的天数
	 * 
	 * @param smdate
	 *            较小的时间
	 * @param bdate
	 *            较大的时间
	 * @return 相差天数
	 * @throws ParseException
	 */
	public int daysBetween() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date smdate = new Date();
		Date bdate = null;
		try {
			bdate = sdf.parse("2015-8-8");
			smdate = sdf.parse(sdf.format(smdate));
			bdate = sdf.parse(sdf.format(bdate));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(smdate);
		long time1 = cal.getTimeInMillis();
		cal.setTime(bdate);
		long time2 = cal.getTimeInMillis();
		long between_days = (time2 - time1) / (1000 * 3600 * 24);
		if (between_days < 0) {
			between_days = 0;
		}

		return Integer.parseInt(String.valueOf(between_days));
	}

	/**
	 * 商品支付
	 * 
	 * @return
	 */
	@RequestMapping("/xiading")
	public ModelAndView xiading(String openId,String orderId, HttpServletRequest req) {
		// String orderId = req.getParameter(RequestConstants.ORDER_ID);
		// if(StringUtils.isEmpty(orderId)){
		// orderId = (String) modelMap.get(RequestConstants.ORDER_ID);
		// }

		String url = "/pay/payment.ftl";
		OrderInfoVo order = null;
		logger.info("PayController => prepayment ###### 订单号 : " + orderId);
		// 根据订单ID获取订单相关信息
		if (StringUtils.isBlank(orderId)) {
			throw new BaseException("订单号不能为空!!!");
		} else {
			order = beepReservedService.queryOrderInfoByOrderCode(orderId);
		}

		logger.info("调用iActOrderQueryService.getActOrderById(" + orderId
				+ ") 返回 : " + JSONObject.toJSONString(order));

		ModelAndView model = null;
		if (order != null) {
			Long userId = order.getMemberId();
			logger.debug("询价单 userId : " + userId);
			if (userId == null) {
				throw new BaseException("没找到userId");
			}
			// 授权回调会传入openId
//			String openId = "o9987sykPLLLD8htxU8yBMbOzI4I";
			// 如果不是授权的回调，则通过userId从数据库中query
			if (StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)) {
				openId = this.boundingService.getOpenIdByUserId(userId);
				logger.debug("询价单 openId : " + openId);
				// 如果查询不到，则走授权获取
				if (StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)) {
					String autorizationUrl = "redirect:"
							+ authorizationService.buildAuthorizationLink(
									appId, (redirectHost
											+ "/oauth.htm?orderId=" + orderId),
									Scope.snsapi_base);
					autorizationUrl = autorizationUrl.replace("STATE",
							Authorization.payment.name());
					logger.debug("未知的用户，使用授权获取openId######");
					logger.debug("授权url : {} ######", autorizationUrl);
					model = new ModelAndView(autorizationUrl);
					return model;
					// throw new BaseException("没找到openId");
				}
			}

			// 活动订单状态为11 且 如果订单支付状态为1--未支付 或 3--支付失败
			// if
			// (ActOrderStatus.COMMIT.code().equals(order.getActOrderStatus())
			// && (PayStatus.PAY_FAILURE.code().equals(order.getPayStatus()) ||
			// PayStatus.UNPAY.code().equals(order.getPayStatus()))) {
			url = "/pay/payment.ftl"; // 订单支付信息页
			Map<String, String> map = this.buildRequestPara(order, openId);
			model = new ModelAndView(url);
			model.addObject("requestPara", map);
			logger.debug("跳转到支付页面,参数map:" + JSONObject.toJSON(map));
		} else {
			// 1 已支付 4 已退款
			// 跳到我的询价中心
			// url = "redirect:" + domain + "/inquiry/enquiryList/-1/1.htm";
			model = new ModelAndView(url);
		}
		// }else{
		// logger.error("orderService.getOrderById(" + orderId + ")返回null");
		// throw new BaseException("订单号(" + orderId + ")不存在!!!");
		// }
		model.addObject("order", order);
		return model;
	}

	/**
	 * 
	 * 功能描述: 创建支付请求签名参数<br>
	 * 〈功能详细描述〉
	 *
	 * @param orderId
	 *            订单编号
	 * @param productDesc
	 *            订单名称
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public Map<String, String> buildRequestPara(OrderInfoVo order, String openId) {
		Map<String, String> tempParams = new HashMap<String, String>();
		// 支付者编号 固定值
		tempParams.put("partner", Constants.PARTNER_CODE);
		// 订单 编号 长度不超过18位
		tempParams.put("orderId", order.getOrderCode());
		// 商品名称 TBD
		tempParams.put("mdseName", Constants.MERCHANDISE_NAME);
		// 商品描述 TBD
		tempParams.put("body", Constants.MERCHANDISE_DESC);
		// 店铺id
		// tempParams.put("storeId", String.valueOf(order.getStoreId()));
		// 终端类型
		// tempParams.put("terminalType", Constants.TERMINALTYPE);
		// 交易类型
		// tempParams.put("txnType", Constants.TRADE_TYPE_PAYMENT);
		// 异步通知URL 支付系统会执行job来update订单状态
		tempParams.put("notifyUrl",domain+"/babajie/asyncCallBack.htm");
		//tempParams.put("notifyUrl","192.168.22.200/babajie/asyncCallBack.htm");
		// 同步通知URL 支付完成后，打开一个页面，支付成功还是失败
		tempParams.put("returnUrl", domain + "/babajie/syncCallBack.htm");
		//tempParams.put("returnUrl", "192.168.22.200/babajie/syncCallBack.htm");
		// 支付金额
		tempParams.put("txnAmount", String.valueOf(order.getCashPrice()));
		// 交易关闭时间，以分钟为单位 TBD 全局变量
		tempParams.put("timeout", Constants.ORDER_TIME_OUT);
		// GlobalRule gr = this.iGlobalRuleService.findGlobalRule();
		// tempParams.put("timeout", String.valueOf(gr.getPreorderExpireTime() *
		// 60));
		// service PC端的支付值为WEB_PAY 微信端的值WEIXIN_PAY
		tempParams.put("service", "WEIXIN_PAY");
		// 交易完成返回地址,一般为订单中心地址
		// tempParams.put("finishUrl", domain+"/member/myInquiry.htm");
		// TBD
		tempParams.put("openId", openId);
		// tempParams.put("openId", "o9987szKf2fn2SsGJgrF6EU3-2Ds");
		Map<String, String> values = SignUtil.buildRequestPara(tempParams,
				Constants.PRIVATE_KEY);
		return values;
	}

	private static class Constants {
		/** 订单超时时间 */
		public static final String ORDER_TIME_OUT = "60";

		/** 支付成功 */
		public static final String SUCCESS = "success";

		/** 支付失败 */
		public static final String FAIL = "fail";

		/** 支付者合作伙伴编号 */
		public static final String PARTNER_CODE = "000003";

		/** 支付状态 ：1 未支付,2 支付成功,3 支付失败 */
		public static final Integer PAY_STATUS_SUCCESS = 2;

		/** 退款状态 ：2 退款成功 */
		public static final Integer REFUND_STATUS_SUCCESS = 2;

		/** 支付 */
		public static final String PAYMENT = "payment";

		/** 退款 */
		public static final String REFUND = "refund";

		/** 交易类型(1-支付，2-退款) */
		// public static String TRADE_TYPE_PAYMENT = "1";

		/** 终端类型(1-主站，2-手机App，3-手机网站) */
		// public static String TERMINAL_TYPE = "1";

		/** 支付渠道(默认为1-支付宝) */
		// public static String PAYMENT_CHANNEL = "1";

		/** 支付状态(支付失败) */
		// public static String PAYSTATUS_PAY_FAIL = "3";

		/** 支付状态(未支付) */
		// public static String PAYSTATUS_NOT_PAY = "1";

		/** 常规车微信私有密钥 */
		public static final String PRIVATE_KEY = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBANyWvzVkGwFB7UjJexKy1Ewx8FnlVEkLxYvz8zTYT64oUQjhm+bsikcbqtymU07b/CwjW9+6eLYhLdjn6A5SEZvtvm0+d/pWG6uHEwovxFYYw5pzdRyIZyjzu5IUAptS9K/sAUSa958MMp1MJt8eGR+8ZqV2RHw6NoJHvic2X2rpAgMBAAECgYEAy1GPEDEiyvfvM+WxsLxv/YMSHGnKVEGrZaIHCzBN0SKL/nmkbyabFYuk4xfTNZ6CQlSc/Awt8wGF9qVaOMjgPHiwqBAg1q/4g0ASK6SbFn/Q0KwRXTBS6nB/p+Bf6ge8Dp1JQ2zJEMYbxdToj/tFUB20nPZM5y4Otp83BUTeXNkCQQDyWVWUZx5bU/bCFD42RlBbfB1Qe6AmY3B7XnfdbYtk/s6RSKNL1WKKH7YkmiBbgjvzniHieXj0uUeg9gbwyzzrAkEA6QOh53qefc4gMQyugBRJ0rWdeiqzV6o4ME8ZNoHCvYLrSn+rJBuKzeF0T4D+YatpqHhAiXPw9ZHSpsqvCqnyewJBAOPQ9LD/yrqhkHpbGyxcJtgJMWlh/Wd43NksMdOWUY5MNZS/SrpTykD7lHaN6FL9dywI/+NsuzaaIWp/PIEJHKcCQDh/8/sf5VxV5cJe89UEll3sQbIEtpXUJWm5VEC+OA0huJHI4SORNhfzyfMZMRVXrff2qJdrsIqrACwHS2hHiw8CQQCOqAdMVtenb8WVtbn6VX7f/tZ6JeyfpmmxtT2koJUx5B/DrzXZpz9/LMoX1MgqQH2USg95pevvllhzqrt/i3/f";

		/** 共有密钥 */
		public static final String PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC1j5RFCiw5bKY72+m9eUjnyVFccniN6GDItUiv1adwauEYygi44JWIxNYfbGB8VspIEjMCQKi6Oww94h0tSTqqarjqATF1jybSvNtqAddcrXWd3W13crQ6i2L5b9HS1jfds1oL94zxi1qcIm/AnH54BYHVv7Y8p3ltDhk3P9QD6QIDAQAB";

		/** 支付商品名称 */
		public static final String MERCHANDISE_NAME = "半价车购买预约";

		/** 支付商品描述 */
		public static final String MERCHANDISE_DESC = "半价车购买预约";
	}

	/**
	 * . 功能描述: 支付同步回调反馈支付状态(支付完成之后，open一个页面说明支付成功或者失败)<br>
	 * 
	 */
	@RequestMapping("/syncCallBack")
	@ResponseBody
	public ModelAndView getSyncCallBack(HttpServletRequest req,
			HttpServletResponse rep) {
		String ip = req.getRemoteAddr();
		logger.info("syncCallBack ip:" + ip);
		String url = "";
		Map<String, String> params = this.getRequestParams(req);
		logger.debug("PayController => syncCallBack ###### params : "
				+ JSONObject.toJSONString(params));
		String orderId = params.get(RequestConstants.ORDER_ID);
		String status = params.get("status");
		logger.debug("orderId : " + orderId + "###### payStatus : " + status);
		String sign = params.get("sign");
		logger.debug("orderId : " + orderId + "###### payStatus : " + status
				+ " ###### sign : " + sign);
		boolean verify = SignUtil
				.verifySign(params, Constants.PUBLIC_KEY, sign);
		logger.debug("订单号 orderId : " + orderId + " 校验签名 : "
				+ (verify ? " 成功" : " 失败"));

		OrderInfoVo order = null;
		// 根据订单ID获取订单相关信息
		if (StringUtils.isBlank(orderId)) {
			throw new BaseException("订单号不能为空!!!");
		} else {
			order = beepReservedService.queryOrderInfoByOrderCode(orderId);
		}
		logger.info("调用iActOrderQueryService.getActOrderById(" + orderId
				+ ") 返回 : " + JSONObject.toJSONString(order));
		Long userId = null;
		if (order != null) {
			userId = order.getMemberId();
		} else {
			throw new BaseException("未找到订单 ：" + orderId);
		}
		if (verify && status.equals(Constants.SUCCESS)) {
			url = "/babajie/pay_success.ftl";
		} else {
			url = "/pay/pay_error.ftl";
		}
		return new ModelAndView(url).addObject(RequestConstants.ORDER_ID,
				orderId).addObject(RequestConstants.USER_ID, userId);
	}

	/**
	 * . 功能描述: 支付异步回调更改订单的状态<br>
	 * 
	 */
	@RequestMapping("/asyncCallBack")
	@ResponseBody
	public String asyncCallBack(HttpServletRequest req, HttpServletResponse rep) {
		logger.info("异步回调 asyncCallBack 开始");
		String ip = req.getRemoteAddr();
		String orderId = ""; // 订单编号
		String notifyType = ""; // 通知类型payment
		String status = ""; // 支付状态
		String txnDate = ""; // 付款时间
		String paymentId = "";// 支付流水号
		PrintWriter out = null;
		Map<String, String> params = null;
		String sign = ""; // 签名
		boolean verify = false;

		try {
			out = rep.getWriter();
			params = this.getRequestParams(req);
			logger.info("PayController => asyncCallBack ###### params "
					+ JSONObject.toJSONString(params));
			orderId = params.get("orderId");
			status = params.get("status");
			notifyType = params.get("notifyType");
			txnDate = params.get("txnDate");
			paymentId = params.get("paymentId");
			logger.info(
					"ip : {} , 订单号 : {} , 支付状态 : {} , 支付类型 : {} , 付款时间 : {} ",
					ip, orderId, status, notifyType, txnDate);
			sign = params.get("sign");
			logger.info(
					"ip : {} , 订单号 : {} , 支付状态 : {} , 支付类型 : {} , 付款时间 : {} , 签名 : {} ",
					ip, orderId, status, notifyType, txnDate, sign);
			verify = SignUtil.verifySign(params, Constants.PUBLIC_KEY, sign);
			logger.info("订单号 orderId : " + orderId + "校验签名 : "
					+ (verify ? " 成功" : " 失败"));

			try {
				if (verify && status.equals(Constants.SUCCESS)
						&& notifyType.equals(Constants.PAYMENT)) { // 支付通知逻辑
					// 支付
					logger.info("orderId : " + orderId
							+ " payment asyncCallBack start !!!");
					// iActOrderUpdateService.payActOrderComplete(orderId,
					// Constants.PAY_STATUS_SUCCESS);
					ReservedParamsVo res = new ReservedParamsVo();
					res.setOrderCode(orderId);
					res.setCashPaymentNo(paymentId);
					OrderInfoVo order = beepReservedService
							.queryOrderInfoByOrderCode(orderId);
					res.setMemberId(order.getMemberId());
					beepReservedService.updateReservedOrderStatus(res);
					logger.info("orderId : " + orderId
							+ " payment asyncCallBack end !!!");
					out.print(Constants.SUCCESS);// 输出success
				} else if (verify && status.equals(Constants.SUCCESS)
						&& notifyType.equals(Constants.REFUND)) { // 如果需要退款成功通知逻辑
					// 退款
					logger.debug("orderId : " + orderId
							+ " refund asyncCallBack start !!!");
					// iActOrderUpdateService.dealRefundResult(orderId,
					// Constants.REFUND_STATUS_SUCCESS);
					// LOGGER.debug("orderId : " + orderId +
					// " refund asyncCallBack end !!!");
					out.print(Constants.SUCCESS);// 输出success
				} else {
					out.println(Constants.FAIL);
				}
			} catch (Exception e) {
				logger.error("订单 : " + orderId + " 支付回调状态异步更改接口异常"
						+ e.getMessage());
				if (out != null) {
					out.println(Constants.FAIL);
				}
			}
		} catch (Exception e) {
			logger.error("订单 : " + orderId + " 异步回调签名校验异常" + e.getMessage());
			if (out != null) {
				out.println(Constants.FAIL);
			}
		}

	        return null;
	    }
	    /**
	     * 
	     * 功能描述: 获取回调请求参数<br>
	     * 
	     */
	    private Map<String,String> getRequestParams(HttpServletRequest req){
	        Map<String,String> params = new HashMap<String,String>();
	        Map<?,?> requestParams = req.getParameterMap();
	        
	        for (Iterator<?> iter = requestParams.keySet().iterator(); iter.hasNext();) {
	            String name = (String) iter.next();
	            String[] values = (String[]) requestParams.get(name);
	            StringBuffer buffer = new StringBuffer("");
	            String valueStr = "";
	            for (int i = 0; i < values.length; i++) {
	            	buffer.append(values[i] + ",");
	            }
	            valueStr = buffer.toString();
	            valueStr = valueStr.substring(0, valueStr.length() - 1);
	            params.put(name, valueStr);
	        }
	        return params;
	    }
	    
	    
	    /**
		 * 检查用户登录状态及调用接口
		 * 
		 * @param userid
		 * @param request
		 * @return
		 */
		@RequestMapping("/checksign")
		public GsonView checkOrder(@RequestParam Long userid,
				HttpServletRequest request) {
			GsonView gv = new GsonView();
			CampaignSigninVo campaignSigninVo = iqAWarehouseService
					.queryCampaignSigninByUserId("A-1588", userid);
			if(campaignSigninVo!=null){
				gv.addStaticAttribute("signnum", campaignSigninVo.getSigninNum());
			}
			return gv;

		}
		
		@RequestMapping("/LVCode")
		public GsonView logoValidateCode(HttpServletRequest request,HttpServletResponse response,Long userId,HttpSession session) {
			GsonView gv = new GsonView();

			QAWarehouseVo blNum = iqAWarehouseService.queryQAWarehouseById(1000000l);
			int qaNumber = Integer.parseInt(blNum.getQaQuestionImage());
			String blABC = blNum.getQaQuestion();
			if("A".equals(blABC) || "C".equals(blABC)){
				QAWarehouseVo qavo = null;
				String cate = "";//定义的时间
				List listRd1 = new ArrayList();// 随机出4个数
				List listRd2 = new ArrayList();// 随机出2个数
				boolean bRd1 = true;
				boolean bRd2 = true;
				Random r = new Random();
				//gv.addStaticAttribute("textNumber", qaNumber);
				
				while (bRd1) {
					int num;
					num = r.nextInt(qaNumber);
					if (!listRd1.contains(num)) {
						listRd1.add(num);
					}
					if (listRd1.size() == 4) {
						bRd1 = false;
					}
				}

				/** 取出随机数的值 */
				List<QAWarehouseVo> qAWarehouseVoList = new ArrayList<QAWarehouseVo>();
				
				List listQavoN = new ArrayList();
				List listQavoI = new ArrayList();
				List listQavoNtext = new ArrayList();
				for (int i = 0; i < 4; i++) {
					try {
						int listRd1key = (Integer) listRd1.get(i);
						qavo = iqAWarehouseService.queryQAWarehouseById(((long) listRd1key+1));
						if(qavo==null){
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

					if (qavo != null) {
						// qAWarehouseVoList.add(qavo);
						try {
							cate = DesUtil.encrypt(qavo.getQaQuestion(), "chexiang88");
							listQavoN.add(cate);
							listQavoI.add(qavo.getQaQuestionImage());
							qAWarehouseVoList.add(qavo);
						} catch (Exception e) {
							e.printStackTrace();
						}

					}
				}
				gv.addStaticAttribute("resultN", listQavoN);
				gv.addStaticAttribute("resultI", listQavoI);

				List<QAWarehouseVo> list = new ArrayList<QAWarehouseVo>();
				/** 第一个随机数 */
				while (bRd2) {
					int num;
					num = r.nextInt(4);
					if (!listRd2.contains(num)) {
						listRd2.add(num);
					}
					if (listRd2.size() == 2) {
						bRd2 = false;
					}
				}
				boolean bl = true;
				for (int i = 0; i < 4; i++) {
					if ((Integer) listRd2.get(0) != i) {
						int listDd2key = (Integer) listRd2.get(0);
						if (qAWarehouseVoList.get(listDd2key).getQaQuestion()
								.equals(qAWarehouseVoList.get(i).getQaQuestion())
								|| qAWarehouseVoList.get(listDd2key).getQaQuestion() == qAWarehouseVoList
										.get(i).getQaQuestion()) {
							list.add(qAWarehouseVoList.get(listDd2key));
							bl = false;
						}
					}
				}
				/** 存值到前端页面 */
				String result1 = null;
				if (bl) {
					list.add(qAWarehouseVoList.get((Integer) listRd2.get(0)));
					for (int i = 0; i < 4; i++) {
						if ((Integer) listRd2.get(1) != i) {
							int listDd2key = (Integer) listRd2.get(1);
							if (qAWarehouseVoList.get(listDd2key).getQaQuestion()
									.equals(qAWarehouseVoList.get(i).getQaQuestion())
									|| qAWarehouseVoList.get(listDd2key)
											.getQaQuestion() == qAWarehouseVoList
											.get(i).getQaQuestion()) {
								list.add(qAWarehouseVoList.get(listDd2key));
							}
						}
					}
					if (qAWarehouseVoList.get((Integer) listRd2.get(1)) == null
							|| qAWarehouseVoList.get((Integer) listRd2.get(1)).equals(null)) {

					} else {
						list.add(qAWarehouseVoList.get((Integer) listRd2.get(1)));
					}
					result1 = qAWarehouseVoList.get((Integer) listRd2.get(0))
							.getQaQuestion()
							+ " 和  "
							+ qAWarehouseVoList.get((Integer) listRd2.get(1))
									.getQaQuestion();
				} else {
					list.add(qAWarehouseVoList.get((Integer) listRd2.get(0)));
					result1 = qAWarehouseVoList.get((Integer) listRd2.get(0))
							.getQaQuestion() + "";
				}

				gv.addStaticAttribute("result1", result1);
				gv.addStaticAttribute("blABC", blNum.getQaQuestion());
				//Date d1 = new Date(); //第间
				/** session */
				//HttpSession session = request.getSession();
				//session.setAttribute("list", list);
				String imgNameURL  = StringUtils.EMPTY;
				for (QAWarehouseVo qaWarehouseVo : list) {
						imgNameURL+=qaWarehouseVo.getQaQuestion()+",";
				}
				//session.setAttribute("blABC", blNum.getQaQuestion());
				redisClient.set("blABC",com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,blABC,RedisConstants.EXPIRE_TIME_ONE_MINUTE);
				redisClient.set("list",com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,imgNameURL,RedisConstants.EXPIRE_TIME_ONE_MINUTE);
				//session.setAttribute("d1", d1);//传时间
				
			}else if("B".equals(blABC)){
				
				gv.addStaticAttribute("blABC", "B");
				gv.addStaticAttribute("null123", "null123");
				//Date d1 = new Date(); //第间
				//HttpSession session = request.getSession();
				//session.setAttribute("blABC", "B");
				redisClient.set("blABC",com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,blABC,RedisConstants.EXPIRE_TIME_TEN_MINUTE);
				//session.setAttribute("d1", d1);
				//System.out.println("dl:"+d1);
			}else{
				logger.error("没找到A、B、C三套方案数据库的定义!!");
			}
			return gv;
		}
			
			
		@SuppressWarnings({ "unused", "unchecked" })
		@RequestMapping("/goLVCode")
		public GsonView goLogoValidateCode(HttpServletRequest request, HttpServletResponse response , String promotionId,Long brandId,Long userId,HttpSession session) {
			GsonView gv = new GsonView();

			String blABC =  redisClient.get("blABC",com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,null);
			redisClient.del("blABC",com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE);
			if(StringUtils.isBlank(blABC)){
				blABC = iqAWarehouseService.queryQAWarehouseById(1000000l).getQaQuestion();
			}
		//	String blABC = (String) session.getAttribute("blABC");
//			List<QAWarehouseVo> listSession = (List<QAWarehouseVo>) session.getAttribute("list");
//			if(listSession==null || listSession.size() ==0){
//				listSession=(List<QAWarehouseVo>) request.getSession().getAttribute("list");
//			}
			String imgUrllist = redisClient.get("list",com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,null);
			redisClient.del("list",com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE);
			String[] split = imgUrllist.split(",");
			
			//System.out.println("dl:"+session.getAttribute("d1"));
			//Date d1 = (Date) session.getAttribute("d1");
			//Date d2 = new Date(); //第二间
			//System.out.println("dl:"+d1);
			//SimpleDateFormat f = new SimpleDateFormat("hhmmss"); //格式化 hhmmss
			//int d1Number = Integer.parseInt(f.format(d1).toString()); //第间格式化转int
			//int d2Number = Integer.parseInt(f.format(d2).toString()); //第二间格式化转int
			//int date1 = d2Number-d1Number;
			
			//Long d1Number = d1.getTime();
			//Long d2Number = d2.getTime();
			//int date1 = (int) (d2Number-d1Number);
			
			int ifs = 0; // 判断验证码；0,图片错误,1,验证码错误,2,正确
			int message = -1 ;

			//判断验证码方案
				if("A".equals(blABC)){
					String inputValidCode = request.getParameter("inputValidCode");
					if(inputValidCode==null||inputValidCode.equals("")){
						String card = "";
						int numi = 0;
						// 接收ftl的数据
						String obj = request.getParameter("obj");

						// 接收ftl的选择图片
						String[] str = obj.split(",");
						for (int i = 0; i < str.length; i++) {
							try {
								card = DesUtil.decrypt(str[i], "chexiang88");
								str[i] = card;
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
//						List str2 = new ArrayList();
//						for (QAWarehouseVo qaWarehouseVo : listSession) {
//							str2.add(qaWarehouseVo.getQaQuestion());
//							numi++;
//						}

						if (split.length == str.length) {

							if (str.length >= 2) {
								// 判断商标
								for (int i = 0; i < str.length; i++) {
									if (str.length == 2) {
										if (str[i].equals(split[0])|| str[i].equals(split[1])) {
											ifs = 2;
										} else {
											ifs = 0;
											break;
										} 
									} else if (str.length == 3) {
										if (str[i].equals(split[0])|| str[i].equals(split[1])|| str[i].equals(split[2])) {
											ifs = 2;
										} else {
											ifs = 0;
											break;
										}
									} else if (str.length == 4) {
										if (str[i].equals(split[0])|| str[i].equals(split[1])|| str[i].equals(split[2])|| str[i].equals(split[3])) {
											ifs = 2;
										} else {
											ifs = 0;
											break;
										}
									}
								}
								if (ifs == 2) {
									/** 判断验证码 */
									//Long userId = ssoClient.getLoginStatus(request);
									if (userId == null || userId <= 0) {
										ifs = 3;
									} else {
										
										ifs = 2;
										Long flag = redisClient.setnx("nx"+userId,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE, "成功");
										redisClient.expire("nx"+userId,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE, RedisConstants.EXPIRE_TIME_ONE_MINUTE);
										if (flag == 0) {
											gv.addStaticAttribute("test", "ss");
											gv.addStaticAttribute("result", 4);
											return gv;
										}
										CampaignSigninVo campaignSigninVo = iqAWarehouseService
												.queryCampaignSigninByUserId("A-1588",
														userId);
										
										// 截取礼包“+”
										PromotionResult pr= getAllByUserId(request,
												userId, brandId);
										if(campaignSigninVo!=null){
											String string = campaignSigninVo.getPresentName();
											if(string!=null&&string!=""){
												if(string.startsWith("+")){
													String substring = string.substring(1,string.length());
													campaignSigninVo.setPresentName(substring);
												}
											}
										}
										gv.addStaticAttribute("SigninVo", campaignSigninVo);
										gv.addStaticAttribute("result", ifs);
										if (pr.getResultCode() == 0) {
											gv.addStaticAttribute("SerialCode",pr.getSerialCode());
											gv.addStaticAttribute("SerialCodeUrl",pr.getUrl());
											//用户预约成功，将key存入session
											//this.makeKey("A-1588", userId);
										}
//										else if (pr.getResultCode() == 1) {
//											boolean b = campaignSigninVo.getPresentName()
//													.contains("油卡");
//											gv.addStaticAttribute("oilcard", b);
//										}  
										message = pr.getResultCode();
									}
								}
							} else {
								ifs = 1;
							}
						}else{
							ifs = 0;
						}
						
					}else{
						ifs = 1;
						logger.info("A方案被非法访问!!");
					}
					
				}else if("B".equals(blABC)){
					/**判断验证码*/
					//Long userId = ssoClient.getLoginStatus(request);
					
					if (userId == null || userId <= 0) {
						ifs=3;
					}else{
						/**获取验服务器验证码*/
						String key = VALIDATECODE_REDIS_KEY + "checkCodeWap" + userId;
						String validCode = StringUtils.EMPTY;
						if (redisClient.exists(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE)) {
							/**获取redis缓存的Value,赋值给validCode*/
							validCode = redisClient.get(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,null);
							logger.debug("redis中获取到的验证码：key={}, value={}", key, redisClient.get(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,null));
							/**删除redis缓存验证码*/
							redisClient.del(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE);
						}
						String inputValidCode = request.getParameter("inputValidCode");	
						if(StringUtils.isNotBlank(validCode) && inputValidCode.equalsIgnoreCase(validCode)) {
							ifs = 2;
							Long flag = redisClient.setnx("nx"+userId,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE, "成功");
							redisClient.expire("nx"+userId,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE, 60);
							if (flag == 0) {
								gv.addStaticAttribute("test", "ss");
								gv.addStaticAttribute("result", 4);
								return gv;
							}
							CampaignSigninVo campaignSigninVo = iqAWarehouseService.queryCampaignSigninByUserId("A-1588", userId);
							PromotionResult pr = getAllByUserId(request, userId,brandId);
							// 截取礼包“+”
							if(campaignSigninVo!=null){
								String string = campaignSigninVo.getPresentName();
								if(string!=null&&string!=""){
									if(string.startsWith("+")){
										String substring = string.substring(1,string.length());
										campaignSigninVo.setPresentName(substring);
									}
								}
							
							}
							gv.addStaticAttribute("SigninVo", campaignSigninVo);
							gv.addStaticAttribute("result", ifs);
							if (pr.getResultCode() == 0) {
								gv.addStaticAttribute("SerialCode", pr.getSerialCode());
								gv.addStaticAttribute("SerialCodeUrl",pr.getUrl());
								//用户预约成功，将key存入session
								//this.makeKey("A-1588", userId);
							}
//							else if (pr.getResultCode() == 1) {
//								boolean b = campaignSigninVo.getPresentName().contains("油卡");
//								gv.addStaticAttribute("oilcard", b);
//							} 
							message = pr.getResultCode();
						
						} else {
							ifs = 1;
						}
					}
				}else if("C".equals(blABC)){
					
					String card = "";
					int numi = 0;
					// 接收ftl的数据
					String obj = request.getParameter("obj");

					// 接收ftl的选择图片
					String[] str = obj.split(",");
					for (int i = 0; i < str.length; i++) {
						try {
							card = DesUtil.decrypt(str[i], "chexiang88");
							str[i] = card;
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					
					if (split.length == str.length) {

						if (str.length >= 2) {
							// 判断商标
							for (int i = 0; i < str.length; i++) {
								if (str.length == 2) {
									if (str[i].equals(split[0])|| str[i].equals(split[1])) {
										ifs = 2;
									} else {
										ifs = 0;
										break;
									} 
								} else if (str.length == 3) {
									if (str[i].equals(split[0])|| str[i].equals(split[1])|| str[i].equals(split[2])) {
										ifs = 2;
									} else {
										ifs = 0;
										break;
									}
								} else if (str.length == 4) {
									if (str[i].equals(split[0])|| str[i].equals(split[1])|| str[i].equals(split[2])|| str[i].equals(split[3])) {
										ifs = 2;
									} else {
										ifs = 0;
										break;
									}
								}
							}
							if (ifs == 2) {
								/**判断验证码*/
								//Long userId = ssoClient.getLoginStatus(request);
								
								if (userId == null || userId <= 0) {
									ifs=3;
								}else{
									/**获取验服务器验证码*/
									String key = VALIDATECODE_REDIS_KEY + "checkCodeWap" + userId;
									String validCode = StringUtils.EMPTY;
									if (redisClient.exists(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE)) {
										/**获取redis缓存的Value,赋值给validCode*/
										validCode = redisClient.get(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,null);
										logger.debug("redis中获取到的验证码：key={}, value={}", key, redisClient.get(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE,null));
										/**删除redis缓存验证码*/
										redisClient.del(key,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE);
									}
									String inputValidCode = request.getParameter("inputValidCode");	
									if(StringUtils.isNotBlank(validCode) && inputValidCode.equalsIgnoreCase(validCode)) {
										ifs = 2;
										Long flag = redisClient.setnx("nx"+userId,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE, "成功");
										redisClient.expire("nx"+userId,com.saic.ebiz.market.common.constant.Constants.REDIS_NAME_SPACE, RedisConstants.EXPIRE_TIME_ONE_MINUTE);
										if (flag == 0) {
											gv.addStaticAttribute("test", "ss");
											gv.addStaticAttribute("result", 4);
											
											return gv;
										}
										CampaignSigninVo campaignSigninVo = iqAWarehouseService.queryCampaignSigninByUserId("A-1588", userId);
										PromotionResult pr = getAllByUserId(request, userId,brandId);
										// 截取礼包“+”
										if(campaignSigninVo!=null){
											String string = campaignSigninVo.getPresentName();
											if(string!=null&&string!=""){
												if(string.startsWith("+")){
													String substring = string.substring(1,string.length());
													campaignSigninVo.setPresentName(substring);
												}
											}
										
										}
										gv.addStaticAttribute("SigninVo", campaignSigninVo);
										gv.addStaticAttribute("result", ifs);
										if (pr.getResultCode() == 0) {
											gv.addStaticAttribute("SerialCode", pr.getSerialCode());
											gv.addStaticAttribute("SerialCodeUrl",pr.getUrl());
											//用户预约成功，将key存入session
											//this.makeKey("A-1588", userId);
										}
//										else if (pr.getResultCode() == 1) {
//											boolean b = campaignSigninVo.getPresentName().contains("油卡");
//											gv.addStaticAttribute("oilcard", b);
//										} 
										message = pr.getResultCode();
									
									} else {
										ifs = 1;
									}
								}
							}
						} else {
							ifs = 1;
						}
					} else{
						ifs = 0;
					}
				}
			
			
			gv.addStaticAttribute("result", ifs);
			gv.addStaticAttribute("message", message);
			return gv;
		}


		
		
	    /**
		 * 根据用户id查询签到状态跳转不同接口
		 * 
		 * @param userid
		 * @return
		 */
		public PromotionResult getAllByUserId(HttpServletRequest request,
				Long userid, Long brandId) {
			PromotionResult pr = new PromotionResult();
			Cookie[] cookies = request.getCookies();
			String userTraceCookie = "";
			for (Cookie cookie : cookies) {
				String name = cookie.getName();
				if ("user_trace_cookie".equals(name)) {
					userTraceCookie = cookie.getValue();
					break;
				}
			}
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			usertraceLogger.info("\t qd \t"+userTraceCookie + "\t" + userid + "\t"
					 + format.format(new Date())+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_sign" + "\t" 
					 + "八八节一楼签到活动" +"\t "+ request.getHeader("user-agent") 
					 + "\t" + 3 + "\t" + 13);
			
			// 收集用户登录信息
			CampaignSigninVo campaignSigninVo = iqAWarehouseService
					.queryCampaignSigninByUserId("A-1588", userid);
			if (campaignSigninVo != null) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				// 获取当前时间与最后签到时间
				Date date =new Date();
				Date signdate = campaignSigninVo.getSigninTime();
				String now = sdf.format(date);
			    String signtime = sdf.format(signdate);
				// 当天已经登录

				long time = System.currentTimeMillis() - signdate.getTime();
				if(now.equals(signtime)){
				 pr.setResultCode(1);
//				if (time <= 120000) {
//					pr.setResultCode(1);
				} else {
					// 当天未登录 且第一次登录调用88积分
					if (campaignSigninVo.getSigninNum() == null) {
						pr = getScore(request, userid, brandId);
					} else if (campaignSigninVo.getSigninNum() == 2) {
						// 已签到2天调用租车券
						pr = getRentCar(request, userid, brandId);
					} else if (campaignSigninVo.getSigninNum() == 4) {
						// 已签到4天(第五天)购油卡
						pr = getDrawOilCard(request, userid, brandId);
					} else if (campaignSigninVo.getSigninNum() == 7) {
						// 已签到7天(第八天)588购车券
						pr = getGouCheCoupon(request, userid, brandId);
					} else {
						pr = getNoGifts(request, userid, brandId);
					}
				}
			} else {
				// 第一次登录调用88积分
				pr = getScore(request, userid, brandId);
			}

			return pr;
		}

		/**
		 * 调用88积分
		 * 
		 * @param userid
		 * @return
		 */
		public PromotionResult getScore(HttpServletRequest request, Long userid,
				Long brandId) {
			UserInfo userInfo = memberService.findMembCentInfo(userid);
			CampaignSigninDetailEntity csde = new CampaignSigninDetailEntity();
			String ip = this.getIp(request);
			if (ip.indexOf(",") > 0) {
				ip = ip.split(",")[0];
			}
			csde.setIpAddress(ip);
			csde.setCampaignFlag("A-1588");
			csde.setUserId(userid);
			csde.setPromotionCode("C88_1F_SIGNIN01");
			csde.setBrandId(brandId);
			if (userInfo != null) {
				csde.setMobile(userInfo.getMobile() != null ? userInfo.getMobile(): "");
				csde.setUserName(userInfo.getName() != null ? userInfo.getName(): "");
			}
			// 积分接口
			PromotionResult message = ipromotionPreheatingPageService
					.signServiceForCredit(csde);
			return message;
		}

		/**
		 * 无礼包调用
		 * 
		 * @param userid
		 * @return
		 */
		public PromotionResult getNoGifts(HttpServletRequest request, Long userid,
				Long brandId) {
			UserInfo userInfo = memberService.findMembCentInfo(userid);
			CampaignSigninDetailEntity csde = new CampaignSigninDetailEntity();
			String ip = this.getIp(request);
			if (ip.indexOf(",") > 0) {
				ip = ip.split(",")[0];
			}
			csde.setIpAddress(ip);
			csde.setCampaignFlag("A-1588");
			csde.setUserId(userid);
			csde.setBrandId(brandId);
			if (userInfo != null) {
				csde.setMobile(userInfo.getMobile() != null ? userInfo.getMobile(): "");
				csde.setUserName(userInfo.getName() != null ? userInfo.getName(): "");
			}
			// 积分接口
			PromotionResult message = ipromotionPreheatingPageService
					.signServiceForNoGifts(csde);
			return message;
		}

		/**
		 * 获取客户端ip
		 * 
		 * @param request
		 * @return
		 */
		public String getIp(HttpServletRequest request) {
			logger.info("获取客户端ip地址");
			String ip = null;
			try {
				ip = request.getHeader("x-forwarded-for");
				if (ip == null || ip.length() == 0
						|| "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("Proxy-Client-IP");
				}
				if (ip == null || ip.length() == 0
						|| "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("WL-Proxy-Client-IP");
				}
				if (ip == null || ip.length() == 0
						|| "unknown".equalsIgnoreCase(ip)) {
					ip = request.getRemoteAddr();
				}
				logger.info("客户端ip地址为：" + ip);
				return ip;
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("发生异常ip地址获取失败");
				return null;
			}

		}

		/**
		 * 获取租车券
		 * 
		 * @param request
		 * @param userid
		 * @param brandId
		 * @return
		 */
		public PromotionResult getRentCar(HttpServletRequest request, Long userid,
				Long brandId) {
			UserInfo userInfo = memberService.findMembCentInfo(userid);
			CampaignSigninDetailEntity csde = new CampaignSigninDetailEntity();
			String ip = this.getIp(request);
			if (ip.indexOf(",") > 0) {
				ip = ip.split(",")[0];
			}
			csde.setIpAddress(ip);
			csde.setCampaignFlag("A-1588");
			csde.setUserId(userid);
			csde.setPromotionCode("C88_1F_SIGNIN02");
			csde.setBrandId(brandId);
			if (userInfo != null) {
				csde.setMobile(userInfo.getMobile() != null ? userInfo.getMobile(): "");
				csde.setUserName(userInfo.getName() != null ? userInfo.getName(): "");
			}
			PromotionResult pr = ipromotionPreheatingPageService
					.signServiceForluckDrawRentCoupon(csde);
			return pr;
		}

		/**
		 * 获取购油卡
		 * 
		 * @param request
		 * @param userid
		 * @param brandId
		 * @return
		 */
		public PromotionResult getDrawOilCard(HttpServletRequest request,
				Long userid, Long brandId) {
			UserInfo userInfo = memberService.findMembCentInfo(userid);
			CampaignSigninDetailEntity csde = new CampaignSigninDetailEntity();
			String ip = this.getIp(request);
			if (ip.indexOf(",") > 0) {
				ip = ip.split(",")[0];
			}
			csde.setIpAddress(ip);
			csde.setCampaignFlag("A-1588");
			csde.setUserId(userid);
			csde.setPromotionCode("C88_1F_SIGNIN03");
			csde.setBrandId(brandId);
			if (userInfo != null) {
				csde.setMobile(userInfo.getMobile() != null ? userInfo.getMobile(): "");
				csde.setUserName(userInfo.getName() != null ? userInfo.getName(): "");
			}
			PromotionResult pr = ipromotionPreheatingPageService
					.signServiceForluckDrawOilCard(csde);
			return pr;
		}

		/**
		 * 获取购车券
		 * 
		 * @param request
		 * @param userid
		 * @param brandId
		 * @return
		 */
		public PromotionResult getGouCheCoupon(HttpServletRequest request,
				Long userid, Long brandId) {
			UserInfo userInfo = memberService.findMembCentInfo(userid);
			CampaignSigninDetailEntity csde = new CampaignSigninDetailEntity();
			String ip = this.getIp(request);
			if (ip.indexOf(",") > 0) {
				ip = ip.split(",")[0];
			}
			csde.setIpAddress(ip);
			csde.setCampaignFlag("A-1588");
			csde.setUserId(userid);
			csde.setPromotionCode("C88_1F_SIGNIN04");
			csde.setBrandId(brandId);
			if (userInfo != null) {
				csde.setMobile(userInfo.getMobile() != null ? userInfo.getMobile(): "");
				csde.setUserName(userInfo.getName() != null ? userInfo.getName(): "");
			}

			PromotionResult pr = ipromotionPreheatingPageService
					.signServiceForGouCheCoupon(csde);
			return pr;
		}
		
		private Integer isMobileAuth(HttpServletRequest request,Long userId) {
			UserInfo user = null;
			Integer isAuth = 0;
			if (userId > 0) {
				 user = memberService.findMembCentInfo(userId);
				if (user.getMobileAuthFlag() == 1) {
					isAuth = 1;
				}
			}
			return isAuth;
		}
		
}
