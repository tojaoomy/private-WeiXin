package com.saic.ebiz.baba.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.ibm.framework.web.gson.GsonView;
import com.saic.ebiz.carmall.service.api.ISolrService;
import com.saic.ebiz.carmall.service.api.IWhiteListService;
import com.saic.ebiz.carmall.service.vo.SpuQueryCriterial;
import com.saic.ebiz.carmall.service.vo.SpuSimpleVO;
import com.saic.ebiz.carmall.service.vo.WhiteList;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.util.ControllerUtil;
import com.saic.ebiz.promotion.service.api.ICampaignWinService;
import com.saic.ebiz.promotion.service.api.IGiftManagerService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionBaBaHomePageService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.api.IQAWarehouseService;
import com.saic.ebiz.promotion.service.api.IpAddressService;
import com.saic.ebiz.promotion.service.commons.CommonConst;
import com.saic.ebiz.promotion.service.commons.constants.RedisConstants;
import com.saic.ebiz.promotion.service.entity.CampaignWinEntity;
import com.saic.ebiz.promotion.service.entity.GiftQuotaEntity;
import com.saic.ebiz.promotion.service.entity.IpAdderssEntity;
import com.saic.ebiz.promotion.service.entity.PromotionDispIndexEntity;
import com.saic.ebiz.promotion.service.util.DateUtils;
import com.saic.ebiz.promotion.service.vo.BaBaHomeLotteryResultVo;
import com.saic.ebiz.promotion.service.vo.BaBaLotteryResultVo;
import com.saic.ebiz.promotion.service.vo.CampaignSigninVo;
import com.saic.ebiz.promotion.service.vo.QAWarehouseVo;
import com.saic.ebiz.promotion.service.vo.UserInfo;
import com.saic.ebiz.web.entity.BaBaOneInfo;
import com.saic.framework.redis.client.IRedisClient;

/**
 * baba节主会场wx controller
 * @author 
 *
 */
@Controller
@RequestMapping("/babamain")
public class BaBaJiePreheatMainController {
	
	/**
	 * 日志
	 */
	private final Logger logger = LoggerFactory.getLogger(BaBaJiePreheatMainController.class);
	
	
	/** 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");
	
	
	/**
	 * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	@Autowired
	private JsSDKSign jsSDKSign;
	
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
	/**
	 * 会员服务接口
	 */
	@Autowired
	private IMemberService memberService;
	
	/**
	 * 签到信息
	 */
	@Autowired
	private IQAWarehouseService iqAWarehouseService;
	
	@Autowired
	private IGiftManagerService iGiftManagerService;
	
	/**
	 *  商城UCM
	 */
	private  @Value("${ebiz.mcar.web.mcarBase}") String mcarBase;
	/**
	 *  车享拍URL
	 */
	private  @Value("${ebiz.pai.web.paiBase}") String paiBase;
	
	/**
	 *  洗车
	 */
	private  @Value("${ebiz.recruit.web.cxBase}") String recruitCxBase;
	/**
	 * 查询3楼价钱
	 */
	@Autowired
	private ISolrService solrService;
   /**
    * 活动扩展
    */
    @Autowired
    private IPromotionExtendService remotePromotionExtendService;
    /**
	 * IP查询
	 */
	@Autowired
	private IpAddressService ipAddressService;

	/**
	 * 中奖用户服务.
	 */
	@Autowired
	private ICampaignWinService iCampaignWinService;
	/**
	 * 中奖信息
	 */
	@Autowired
	private IWhiteListService iWhiteListService;
	/**
	 * 活动服务
	 */
	@Autowired
	private IPromotionService iPromotionService;
	
	@Autowired
	private IPromotionBaBaHomePageService iPromotionBaBaHomePageService;
	/** 缓存接口. */
    @Resource(name = "springRedisClient")
	private IRedisClient redisClient;
	/**
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	/**主会场4F品牌List*/
	private static final String BABA_MAIN_FOUR_CARLIST = "/babajie/main/five_brandlist.ftl";
	/** 主会场3F城市List */
	private static final String BABA_MAIN_THREE_CARLIST = "/babajie/main/four_citylist.ftl";
	/**4F初始化品牌ID*/
	private static final Long BRANDID = 1L;
	/**1F 活动ID*/
	private static final String OEN_PROMOTIONCODE = "C88_MAIN_1F_001";
	/**1F半价车信息*/
	private static Map<String,BaBaOneInfo> oneMap = new HashMap<String,BaBaOneInfo>();
	/** 3F不服来买 **/
	private static Map<String,SpuSimpleVO> threeMap = new HashMap<String,SpuSimpleVO>();
	/**
	 * 2F抽奖返回结果
	 */
	private static final int BABA_RESULT_2F_ONE = 1;
	private static final int BABA_RESULT_2F_TWO = 2;
	private static final int BABA_RESULT_2F_THREE = 3;
	private static final int BABA_RESULT_2F_FOUR = 4;
	private static final int BABA_RESULT_2F_FIVE = 5;
	private static final int BABA_RESULT_2F_SIX = 6;
	private static final int BABA_RESULT_2F_SEVEN = 7;
	private static final int BABA_RESULT_2F_EIGHT = 8;
	private static final int BABA_RESULT_2F_NINE = 9;
	
	/**
	 * 绑定服务
	 */
	@Resource
	private BoundingService boundingService;

	
	static{
		loadoneMap();
		initthreeMap();
	}
	private static void loadoneMap() {
		oneMap.put("6020004", new BaBaOneInfo("荣威550,","2014款550S 1.8L自动智选版","142,294","71,147","2f_rw550.png"));
		oneMap.put("6010009", new BaBaOneInfo("荣威350,","2014款350 1.5L 自动讯悦版 +inkanet","109,531","54,766","2f_rw350.png"));
		oneMap.put("7105006", new BaBaOneInfo("MG 锐行","1.5T自动 豪华版+inkanet","127,116","63,558","2f_MGrx.png"));
		oneMap.put("7070014", new BaBaOneInfo("MG MG3","1.5L 自动精英版","92,164 元","46,082","2f_MGmg3.png"));
		oneMap.put("3105006", new BaBaOneInfo("别克全新英朗","2015款 15N 自动豪华型","149,911","74,955","2f_bkyl.png"));
		oneMap.put("300350047", new BaBaOneInfo("别克君威 ","2015款 1.6T 精英技术型","229,150","114,575","2f_bkjw.png"));
		oneMap.put("4710002", new BaBaOneInfo("雪佛兰创酷 ","1.4T 自动两驱舒适型","133,629","66,814","2f_xflck.png"));
		oneMap.put("4460012", new BaBaOneInfo("雪佛兰迈锐宝","2.0L豪华版","204,274","102,137","2f_xflmrb.png"));
		oneMap.put("1001020498", new BaBaOneInfo("雪佛兰新科鲁兹","1.5L 自动豪华版","150,996","75,498","2f_xflklz.png"));
		oneMap.put("5970001", new BaBaOneInfo("凯迪拉克 ATS-L","25T 舒适型","315,154","157,577","2f_kdlkATS-L.png"));
		oneMap.put("114009", new BaBaOneInfo("上海大众 New Polo","1.4L 手动风尚版","83,697","41,849","2f_shdzpolo.png"));
		oneMap.put("1120019", new BaBaOneInfo("上海大众 新帕萨特","1.8TSI DSG尊荣版","238,901","119,450","2f_pst.png"));
		oneMap.put("2720016", new BaBaOneInfo("斯柯达 全新明锐","1.6L手自动一体逸俊版","166,193","83,096","2f_mr.png"));
		oneMap.put("2260020", new BaBaOneInfo("斯柯达 昕锐","1.6L 自动智选版","116,261","58,131","2f_tr.png"));
		oneMap.put("9670002", new BaBaOneInfo("五菱宏光S","舒适型1.5L","73,277","36,638","2f_wlhg.png"));
		oneMap.put("9103006", new BaBaOneInfo("五菱宏光V","标准型 1.5L","58,080","29,040","2f_wlhgv.png"));
		oneMap.put("99999999998", new BaBaOneInfo("宝骏330","即将上市","敬请期待","敬请期待","2f_bj330.png"));
		oneMap.put("99999999999", new BaBaOneInfo("宝骏560", "2015款 1.8L 手动精英型", "96,362",
				"46,181", "2f_bj560.png"));
		oneMap.put("1000690033", new BaBaOneInfo("大通G10","2.0T自动纪念版","179,350","89,675","2f_dtG10.png"));
	}	
	
	/**
	 * 主会场入口
	 * @param userId
	 * @param request
	 * @return
	 */
	@RequestMapping("/index")
	public ModelAndView Main(@RequestParam(value = "userId", required = false) Long userId,
			HttpServletRequest request){
		ModelAndView mv = null;
		boolean isEnd = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-09-08 23:59:59"); 
		
		//如果活动已结束
		if(isEnd){
			  mv = new ModelAndView("redirect:http://m.chexiang.com");
			  return mv;
		} 
			String uId = request.getParameter(RequestConstants.USER_ID);
			UserInfo user = null;
			if (!StringUtils.isEmpty(uId) &&  !"-1".equals(uId)) {
				user = memberService.findMembCentInfo(Integer.valueOf(uId));
			}
			String openId = request.getParameter(RequestConstants.OPEN_ID);
			logger.info("request parameters userId = {}, openId = {} ", uId, openId);
			if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
				String autorizationUrl = "redirect:"
						+ authorizationService.buildAuthorizationLink(appId,
								(redirectHost + "/oauth.htm"), Scope.snsapi_base);
				autorizationUrl = autorizationUrl.replace("STATE",
						Authorization.babajieMain.name());
				logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
				logger.debug("授权url : {} ######", autorizationUrl);
				mv = new ModelAndView(autorizationUrl);
			} else {
				mv = new ModelAndView("/babajie/main/index.ftl");
				mv.addObject(RequestConstants.USER_ID, uId).addObject(
						RequestConstants.OPEN_ID, openId);
			}

			// 微信分享JSSDK分享
			Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
	        mv.addObject("jssdk", map);
	        mv.addObject("user", user);
	        mv.addObject("userId", userId);
	        mv.addObject("openId",openId);
	        mv.addObject("isMobileAuth", this.isMobileAuth(request,userId));
	      //加载一楼信息
	  		loadFirstFloor(mv,user);
	  		//三楼
	  	// 加载三楼信息
	  			List<SpuSimpleVO> spuList = initThreeFloor(7);
	  			mv.addObject("spuList", spuList);
	  	// 2楼
	  			// 获取当前时间判断是否是特殊节日
	  			String dateNow = DateUtils.format(new Date(), "dd");
	  			int showZhuanpan = 0;
	  			String promotionCode;
	  			if (dateNow.indexOf("8") > 0) {
	  				showZhuanpan = 1;
	  				promotionCode = "C_1588_2F_02";
	  			} else {
	  				showZhuanpan = 0;
	  				promotionCode = "C_1588_2F_01";
	  			}
	  			// 获取积分
	  			if (user != null) {
	  				BigDecimal integral = iPromotionBaBaHomePageService
	  						.queryUserIntegral(user.getUserId());
	  				//mav.addObject("integral", integral);
	  				if (integral.intValue() < 88) {
	  					mv.addObject("integralNotNull", true);
	  				}
	  				mv.addObject("winOut", initSeFloorStatus(promotionCode, user));
	  			}
	  			mv.addObject("showZhuanpan", showZhuanpan);
	  			String ip = this.getIp(request);
	  			if(ip.indexOf(",")>0) {
	  	    	   ip = ip.split(",")[0];
	  	        }
	  			IpAdderssEntity ipInfo = ipAddressService.getIPInfo(ip);
	  			boolean ISSHIP = true;
	  			if(null == ipInfo){
	  				logger.info("获取到的用户IP为:"+ip);
	  				ISSHIP = false;
	  			}else{
	  				logger.info("获取到的用户IP为:"+ip+"---地址为:"+ipInfo.getCountry()+"--"+ipInfo.getLocal());
	  			}
	  			mv.addObject("ISSHIP", ISSHIP);

	  		//加载四楼信息
	  			
			mv.addObject("mcarBase", mcarBase);
	  		List<PromotionDispIndexEntity> PromotionDispIndexEntity = iPromotionService.getPromotionImagByBrandId(BRANDID);
	  		mv.addObject("brandId", BRANDID);
	  		mv.addObject("paiBase", paiBase);
	  		mv.addObject("recruitCxBase",recruitCxBase);
	  		mv.addObject("promotionlist",PromotionDispIndexEntity);
	  		mv.addObject("nowTime",new Date().getTime());
	        //加载签到信息
	        loadDataSignin(mv,userId);
			return mv;
		
	}
	//加载一楼信息
	private void loadFirstFloor(ModelAndView mav,UserInfo user) {
		//判断用户是否中奖/是否参与了本次活动
		boolean isWin = false;
		boolean isWinCar = false;
		boolean closedWinCar = false;
		Integer surplusNum = null;
		String modelId = null;
		boolean  IsLottery = true;
		
		boolean xiche = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-08-08 00:00:00"); 
		boolean chewu = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-08-19 10:00:00"); 
		boolean jiayou = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-08-29 00:00:00"); 
		if(xiche && chewu && jiayou){
			 xiche = false;
			 chewu = false;
			 jiayou = true;
		}else if(xiche && chewu){
			 xiche = false;
			 chewu = true;
			 jiayou = false;
		}else if(xiche){
			 xiche = true;
			 chewu = false;
			 jiayou = false;
		}
		mav.addObject("xiche", xiche);
		mav.addObject("chewu", chewu);
		mav.addObject("jiayou", jiayou);
		
		QAWarehouseVo QAWarehouseVo = iqAWarehouseService.queryQAWarehouseById(1000004L);
		
		if(null != QAWarehouseVo && StringUtils.isBlank(QAWarehouseVo.getQaQuestion()) && StringUtils.isBlank(QAWarehouseVo.getQaQuestionImage())){
			QAWarehouseVo.setQaQuestion("A");
			IsLottery = false;
		}
		//是否在8/8/10:00
		boolean istimeLater = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss",QAWarehouseVo.getQaQuestionImage());
		if(!istimeLater){
			IsLottery = false;
		}
		
		mav.addObject("IsLottery", IsLottery);
		
		//是否A/B方案
		mav.addObject("ISAORB", QAWarehouseVo.getQaQuestion());
		if(user == null || user.getUserId() < 0){
			return;
		}
		List<WhiteList> whiteList = iWhiteListService.findExistWhiteList(null, user.getUserId(), 1l);
		if(whiteList !=null && whiteList.size() > 0){
			mav.addObject("supId", whiteList.get(0).getSpuId());
		}
		
		long promotionId = iPromotionService.getPromotionIdByCode(OEN_PROMOTIONCODE);
		BaBaHomeLotteryResultVo BaBaHomeLotteryResultVo = iPromotionBaBaHomePageService.queryPromotionSubscription(promotionId,user.getUserId(), user.getMobile());
		//中半价车
		if(null != BaBaHomeLotteryResultVo && BaBaHomeLotteryResultVo.getWinOrderList() != null && BaBaHomeLotteryResultVo.getWinOrderList().size() > 0){
			boolean timeLater = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-08-11 00:00:00");
			if(timeLater){
				closedWinCar = true;
			}
			isWinCar = true;
			modelId = BaBaHomeLotteryResultVo.getWinOrderList().get(0).getCarModelId();
			BaBaOneInfo baBaOneInfo = oneMap.get(modelId);
			mav.addObject("modelId", modelId);
			mav.addObject("baBaOneInfo", baBaOneInfo);
			
		}
		//没有参加过抽奖的用户设置为0
		if(null == BaBaHomeLotteryResultVo.getHasLotteryNum() || BaBaHomeLotteryResultVo.getHasLotteryNum() < 0){
			BaBaHomeLotteryResultVo.setHasLotteryNum(0);
		}
		//0 ---->参加了本次活动
		if(BaBaHomeLotteryResultVo.getResultCode() == 0){
			isWin = true;
		}
		
		
		mav.addObject("isWin", isWin);
		mav.addObject("isWinCar", isWinCar);
		mav.addObject("modelId", modelId);
		mav.addObject("surplusNum", surplusNum);
		mav.addObject("closedWinCar", closedWinCar);
		mav.addObject("BaBaHomeLotteryResultVo", BaBaHomeLotteryResultVo);
	}
	/**
	 * @Title: BaBaJieMain 
	 * @Description: 2F转盘抽奖(功能描述) 
	 * @param @param request
	 * @param @return    ModelAndView
	 * @return ModelAndView    返回类型 
	 * @throws
	 */
	@RequestMapping("turnplate")
	public GsonView turnplate(HttpServletRequest request,@RequestParam Long userId
			,@RequestParam String mobile){
		GsonView gv = new GsonView();
		Long flag = redisClient.setnx("nx-c88-main-2f" + userId,Constants.REDIS_NAME_SPACE, "成功");
		redisClient.expire("nx-c88-main-2f" + userId,Constants.REDIS_NAME_SPACE, 4);
		if(flag == 0){
			gv.addStaticAttribute("result", 5);
			return gv;
		}
		Cookie[] cookies = request.getCookies();
		String userTraceCookie = "";
		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if ("user_trace_cookie".equals(name)) {
				userTraceCookie = cookie.getValue();
				break;
			}
		}
		usertraceLogger.info("\t zj \t"+userTraceCookie + "\t" + userId + "\t"
				 + DateUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_query" + "\t" 
				 + "中奖查询-转盘" +"\t "+ request.getHeader("user-agent") 
				 + "\t" + 3 + "\t" + 13);
		
		BaBaLotteryResultVo baBaLotteryResultVo = null;
		long promotionId = iPromotionService.getPromotionIdByCode(OEN_PROMOTIONCODE);
		baBaLotteryResultVo = iPromotionBaBaHomePageService.luckDrawFirstFloor(promotionId, userId, mobile);
		if(StringUtils.isBlank(baBaLotteryResultVo.getContent()) || baBaLotteryResultVo.getResultCode() != 0){
			gv.addStaticAttribute("result", 4);
			logger.info("未知错误,服务端未返回抽奖结果:userId = "+userId +" mobile="+mobile);
			return gv;
		}
		if(baBaLotteryResultVo.getContent().equals("888")){
			gv.addStaticAttribute("result", 0);
			logger.info("八八节主会场2F抽奖 userID = "+userId +" mobile="+mobile +" 抽中888购车卷");
		}else if(baBaLotteryResultVo.getContent().equals("1088")){
			gv.addStaticAttribute("result", 1);
			logger.info("八八节主会场2F抽奖 userID = "+userId +" mobile="+mobile +" 抽中1888购车卷");
		}else if(baBaLotteryResultVo.getContent().equals("8888")){
			gv.addStaticAttribute("result", 2);
			logger.info("八八节主会场2F抽奖 userID = "+userId +" mobile="+mobile +" 抽中8888购车卷");
		}else if(baBaLotteryResultVo.getContent().equals("5888")){
			gv.addStaticAttribute("result", 3);
			logger.info("八八节主会场2F抽奖 userID = "+userId +" mobile="+mobile +" 抽中5888购车卷");
		}
		return gv;
	}
	
	/**
	 * @Title: BaBaJieMain
	 * @param @param request
	 * @param @return ModelAndView
	 * @return ModelAndView 返回类型
	 * @throws
	 */
	@RequestMapping("loadfourlist")
	public ModelAndView loadFourFloor(HttpServletRequest request,
			@RequestParam Long brandId) {
		
		if (null == brandId || brandId < 0) {
			logger.info("主会场4F品牌切换错误----->brandId = " + brandId);
			return null;
		}
		ModelAndView mav = new ModelAndView(BABA_MAIN_FOUR_CARLIST);
		List<PromotionDispIndexEntity> PromotionDispIndexEntity = iPromotionService
				.getPromotionImagByBrandId(brandId);
		if(null != PromotionDispIndexEntity){
			logger.info("根据品牌获取到的活动数量--->" + PromotionDispIndexEntity.size());
		}
		mav.addObject("brandId", brandId);
		mav.addObject("promotionlist", PromotionDispIndexEntity);
		return mav;
	}

	/**
	 * @Title: BaBaJieMain
	 * @param @param request
	 * @param @return ModelAndView
	 * @return ModelAndView 返回类型
	 * @throws
	 */
	@RequestMapping("updateWinNum")
	public GsonView updateWinNum(HttpServletRequest request,
			@RequestParam String userId, @RequestParam String modelId,
			@RequestParam String mobile) {
		Cookie[] cookies = request.getCookies();
		String userTraceCookie = "";
		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if ("user_trace_cookie".equals(name)) {
				userTraceCookie = cookie.getValue();
				break;
			}
		}
		usertraceLogger.info("\t zj \t"+userTraceCookie + "\t" + userId + "\t"
				 + DateUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_query" + "\t" 
				 + "中奖查询-去支付" +"\t "+ request.getHeader("user-agent") 
				 + "\t" + 3 + "\t" + 13);
		GsonView gv = new GsonView();
		CampaignWinEntity entity = new CampaignWinEntity();
		entity.setUserId(userId);
		entity.setMobile(mobile);
		entity.setCarModelId(modelId);
		int update = iCampaignWinService.update(entity);
		gv.addStaticAttribute("update", update);
		return gv;
	}	
	
	/**
	 * 加载签到信息
	 */
	private void loadDataSignin(ModelAndView mav,Long userId) {
		// 加载签到信息
		boolean cantsignin = true;
		QAWarehouseVo queryQAWarehouseById = iqAWarehouseService.queryQAWarehouseById(1000001L);
		if(queryQAWarehouseById!=null){
			if("a".equals(queryQAWarehouseById.getQaAttribute())||"A".equals(queryQAWarehouseById.getQaAttribute())){
				cantsignin = false;
			}
		}
		mav.addObject("CANTSIGNIN", cantsignin);

		CampaignSigninVo campaignSigninVo = iqAWarehouseService.queryCampaignSigninByUserId("A-1588", userId);
		  	if (campaignSigninVo != null) {
				// 截取礼包“+”
				String string = campaignSigninVo.getPresentName();
				if(org.apache.commons.lang.StringUtils.isNotEmpty(string)){
					if(string.startsWith("+")){
						String substring = string.substring(1,string.length());
						campaignSigninVo.setPresentName(substring);
					}
				}
				mav.addObject("signNum", campaignSigninVo.getSigninNum());
			}
		  	
			mav.addObject("campaignSigninVo", campaignSigninVo);
	  }
	
	
	/**
	 * 手机是否绑定
	 * @param request
	 * @param userId
	 * @return
	 */
	private Integer isMobileAuth(HttpServletRequest request,Long userId) {
		UserInfo user = null;
		Integer isAuth = 0;
		if (userId > 0) {
			 user = memberService.findMembCentInfo(userId);
			if (user.getMobileAuthFlag() == 1) {
				isAuth = 1;
			}
		}
		return isAuth;
	}
	
	/**
	 * @Title: BaBaJieMain
	 * @param @param request
	 * @param @return 设定文件
	 * @return ModelAndView 返回类型
	 * @author v_guojingtao
	 * @throws
	 */
	public List<SpuSimpleVO> initThreeFloor(@RequestParam int cityId) {
		SpuQueryCriterial spuQueryCriterial = new SpuQueryCriterial();
		List<String> spuIdList = new ArrayList<String>();
		spuQueryCriterial.setSpuIds(spuIdList);
		Pagination page = new Pagination();
		List<SpuSimpleVO> spuSimpleVOList = DataUtils.FOURTH_FLOOR_BU_FU_LAI_BI_MAP.get(cityId);
		try {
			if(null == spuSimpleVOList || spuSimpleVOList.size() == CommonConst.DIGIT_ZERO) {
				// 查询出所在城市的商品spuId
				List<GiftQuotaEntity> queryGiftList = iGiftManagerService
						.queryGifts(cityId);
				
				// 将商品id付给spuId
				if(null == queryGiftList || queryGiftList.size() == CommonConst.DIGIT_ZERO) {
					logger.info("BabajieMainController initThreeFloor queryGifts is null.");
					return null;
				}
				
				for (int i = 0, len = queryGiftList.size(); i < len; i++) {
					
					GiftQuotaEntity entity = queryGiftList.get(i);
					
					if(null == entity) {
						continue;
					}
					spuIdList.add(entity.getGiftName());
				}
				// 查询出所在城市所有的商品
				PaginationResult<List<SpuSimpleVO>> pa = solrService
						.searchByCriterial(spuQueryCriterial, page);
				spuSimpleVOList = pa.getR();
				
				if (null == spuSimpleVOList || spuSimpleVOList.size() == CommonConst.DIGIT_ZERO) {
					logger.info("BabajieMainController initThreeFloor spuSimpleVOList is null.");
					return null;
				}
				for (GiftQuotaEntity gift : queryGiftList) {
					for (String spuCode : threeMap.keySet()) {
						SpuSimpleVO spuSimpleVO = threeMap.get(spuCode);
						if (gift.getGiftCode().equals(spuCode)) {
							spuSimpleVO.setSpuId(gift.getGiftName());
							break;
						}
					}
					
				}
				
				for (SpuSimpleVO spuSimpleVO1 : spuSimpleVOList) {
					for (String spuCode : threeMap.keySet()) {
					SpuSimpleVO spuSimpleVO = threeMap.get(spuCode);
						if ((spuSimpleVO1.getSpuId()).equals(spuSimpleVO.getSpuId())) {
							spuSimpleVO1.setTitle(spuSimpleVO.getTitle());
							spuSimpleVO1.setSubTitle(spuSimpleVO.getSubTitle());
							spuSimpleVO1.setCoverImgUrl(spuSimpleVO.getCoverImgUrl());
							break;
						}
					}
				}
				DataUtils.FOURTH_FLOOR_BU_FU_LAI_BI_MAP.put(cityId, spuSimpleVOList);
			}
			
			return spuSimpleVOList;
		} catch (Exception e) {
			logger.error("solrService.searchByCriterial(spuQueryCriterial, page)调用异常",e.getMessage());
			return spuSimpleVOList;
		}
	}
	/**
	 * 三楼切换城市改变价格
	 * @param cityId
	 * @return
	 * @author v_guojingtao
	 */
	@RequestMapping("/changeCity")
	public ModelAndView changeCity(@RequestParam int cityId) {
		ModelAndView mav = new ModelAndView(BABA_MAIN_THREE_CARLIST);
		List<SpuSimpleVO> spuList = initThreeFloor(cityId);
		mav.addObject("spuList", spuList);
		mav.addObject("mcarBase", mcarBase);
		return mav;
	}
	/**
	 * @return baBaLotteryResultVo 抽奖结果
	 * @author v_guojingtao code 平日 C_1588_2F_01 逢8 C_1588_2F_02
	 */
	@RequestMapping("/initWinEntity")
	public GsonView initWinEntity(HttpServletRequest request,
			@RequestParam Long userId, @RequestParam String promotionCode) {
		GsonView gv = new GsonView();
		BaBaLotteryResultVo baBaLotteryResultVo = null;
		UserInfo user = null;

		try {
			// 用户名为空
			if (userId == null || userId <= 0) {
				gv.addStaticAttribute("result", BABA_RESULT_2F_ONE);
				return gv;
			}
			user = memberService.findMembCentInfo(userId);
			// 用户名不合法
			if (user == null) {
				gv.addStaticAttribute("result", BABA_RESULT_2F_ONE);
				return gv;
			}
			// 验证重复提交
			Long flag = redisClient.setnx(promotionCode + userId,Constants.REDIS_NAME_SPACE, "成功");
			redisClient.expire(promotionCode + userId,Constants.REDIS_NAME_SPACE, RedisConstants.EXPIRE_TIME_FIVE_SECOND);
			if (flag == 0) {
				// 频率过高
				gv.addStaticAttribute("result", BABA_RESULT_2F_TWO);
				return gv;
			} 
			

			if (promotionCode == null || "".equals(promotionCode)) {
				gv.addStaticAttribute("result", BABA_RESULT_2F_THREE);
				return gv;
			}
			if (initSeFloorStatus(promotionCode,user) == true) {
				gv.addStaticAttribute("result", BABA_RESULT_2F_NINE);
				return gv;
			}
			Long promotionId = iPromotionService
					.getPromotionIdByCode(promotionCode);

			// 埋点
			Cookie[] cookies = request.getCookies();
			String userTraceCookie = "";
			for (Cookie cookie : cookies) {
				String name = cookie.getName();
				if ("user_trace_cookie".equals(name)) {
					userTraceCookie = cookie.getValue();
					break;
				}
			}

			usertraceLogger.info("\t hy \t"+userTraceCookie + "\t" + userId + "\t"
					 + DateUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_lottery" + "\t" 
					 + "抽奖" +"\t "+ request.getHeader("user-agent") 
					 + "\t" + 3 + "\t" + 13);

			baBaLotteryResultVo = iPromotionBaBaHomePageService
					.luckDrawSecondFloor(promotionId, userId, user.getMobile());
			// 判断抽奖结果
			winResult(gv, baBaLotteryResultVo);

		} catch (Exception e) {
			logger.error("抽奖接口调用异常", e.getMessage());
		}
		return gv;
	}

	/**
	 * 判断中奖结果
	 * 
	 * @param gv
	 * @author v_guojingtao
	 */
	public GsonView winResult(GsonView gv,
			BaBaLotteryResultVo baBaLotteryResultVo) {
		if (baBaLotteryResultVo == null) {
			// 接口返回结果为空
			gv.addStaticAttribute("result", BABA_RESULT_2F_FOUR);
			return gv;
		}
		if (baBaLotteryResultVo.getResultCode() == 0) {
			// 中奖
			if (baBaLotteryResultVo.getWinStatus() == 1) {
				if (baBaLotteryResultVo.getContent().indexOf("888") != -1) {
					baBaLotteryResultVo.setResultCode(5);
					baBaLotteryResultVo.setContent("恭喜您获得价值888元车享购车券");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("积分") != -1) {
					baBaLotteryResultVo.setResultCode(2);
					baBaLotteryResultVo.setContent("恭喜您获得了188积分");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("iPhone") != -1) {
					baBaLotteryResultVo.setResultCode(0);
					baBaLotteryResultVo.setContent("恭喜您获得iPhone 6 一部");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("半价车") != -1) {
					baBaLotteryResultVo.setResultCode(2);
					baBaLotteryResultVo.setContent("恭喜您获得了半价车购买权");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("10") != -1) {
					baBaLotteryResultVo.setResultCode(4);
					baBaLotteryResultVo.setContent("恭喜您获得华住酒店10元电子优惠券");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("20") != -1) {
					baBaLotteryResultVo.setResultCode(4);
					baBaLotteryResultVo.setContent("恭喜您获得华住酒店20元电子优惠券");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("30") != -1) {
					baBaLotteryResultVo.setResultCode(4);
					baBaLotteryResultVo.setContent("恭喜您获得华住酒店30元电子优惠券");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("50") != -1) {
					baBaLotteryResultVo.setContent("恭喜您获得华住酒店50元电子优惠券");
					baBaLotteryResultVo.setResultCode(4);
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				} else if (baBaLotteryResultVo.getContent().indexOf("谢谢参与") != -1) {
					baBaLotteryResultVo.setResultCode(1);
					baBaLotteryResultVo.setContent("谢谢参与");
					gv.addStaticAttribute("baBaLotteryResultVo",
							baBaLotteryResultVo);
					return gv;
				}
			} else {
				// 未中奖
				gv.addStaticAttribute("result", BABA_RESULT_2F_EIGHT);
				return gv;
			}
		} else if (baBaLotteryResultVo.getResultCode() == 5) {
			// 取劵失败
			gv.addStaticAttribute("result", BABA_RESULT_2F_FIVE);
			return gv;
		} else if (baBaLotteryResultVo.getResultCode() == 6) {
			// 查询积分异常
			gv.addStaticAttribute("result", BABA_RESULT_2F_SIX);
			return gv;
		} else {
			// 积分不足
			gv.addStaticAttribute("result", BABA_RESULT_2F_SEVEN);
			return gv;
		}
		return gv;
	}

	/**
	 * 
	 * @param mav
	 *            验证一天只能签到一次
	 * @param promotionCode
	 * @param user
	 * @author v_guojingtao
	 */
	public boolean initSeFloorStatus( String promotionCode,
			UserInfo user) {
		boolean flag = false;
		try {
			Long promotionId = iPromotionService
					.getPromotionIdByCode(promotionCode);
			Date date = iPromotionBaBaHomePageService
					.queryLastSecondFloorLuckDraw(promotionId,user.getUserId(), user.getMobile());

			QAWarehouseVo qAWarehouseVo = iqAWarehouseService.queryQAWarehouseById(1000003L);
			if (qAWarehouseVo == null) {
				//抽奖时间为一天
				 String dateNow = DateUtils.format(new Date(), "yyyy-MM-dd");
				 //最后签到日期
				 String dateLast = DateUtils.format(date, "yyyy-MM-dd");
				 if (dateNow.equals(dateLast)) {
					 flag = true;
				 }
				 return flag;
			}
			String code = qAWarehouseVo.getQaQuestion();
			//抽奖时间为5分钟
			if ("B".equalsIgnoreCase(code)) {
				if (date==null) {
					return false;
				}
				long time = System.currentTimeMillis() - date.getTime();
				if (time <= 300000) {
					flag = true;
				}
			} else {
				//抽奖时间为一天
				 String dateNow = DateUtils.format(new Date(), "yyyy-MM-dd");
				 //最后签到日期
				 String dateLast = DateUtils.format(date, "yyyy-MM-dd");
				 if (dateNow.equals(dateLast)) {
					 flag = true;
				 }
			}
			return flag;
		} catch (Exception e) {
			logger.error(
					"solrService.searchByCriterial(spuQueryCriterial, page)调用异常",
					e.getMessage());
			return flag;
		}
	}
	
	private static void initthreeMap() {
		SpuSimpleVO spuVo = new SpuSimpleVO();
		spuVo.setTitle("荣威550");
		spuVo.setSubTitle("2014款 550S 1.8L 自动智选版");
		spuVo.setCoverImgUrl("c_baba_3f_lw550.png");
		threeMap.put("baba_3f_rw550",spuVo);
		
		SpuSimpleVO spuVo1 = new SpuSimpleVO();
		spuVo1.setTitle("MG GS");
		spuVo1.setSubTitle("2015款 1.5TGI TST精英版");
		spuVo1.setCoverImgUrl("c_baba_3f_mg.png");
		threeMap.put("baba_3f_mggs",spuVo1);
		
		SpuSimpleVO spuVo2 = new SpuSimpleVO();
		spuVo2.setTitle("新途观");
		spuVo2.setSubTitle("2015款 1.8TSI自动两驱舒适版");
		spuVo2.setCoverImgUrl("c_baba_3f_xtg.png");
		threeMap.put("baba_3f_tg",spuVo2);
		
		SpuSimpleVO spuVo3 = new SpuSimpleVO();
		spuVo3.setTitle("新朗逸");
		spuVo3.setSubTitle("2013款 改款 1.6L 自动舒适版");
		spuVo3.setCoverImgUrl("c_baba_3f_xly.png");
		threeMap.put("baba_3f_ly",spuVo3);
		
		SpuSimpleVO spuVo4 = new SpuSimpleVO();
		spuVo4.setTitle("新帕萨特");
		spuVo4.setSubTitle("2014款 1.8TSI DSG尊荣版");
		spuVo4.setCoverImgUrl("c_baba_3f_xpst.png");
		threeMap.put("baba_3f_pst",spuVo4);
		
		SpuSimpleVO spuVo5 = new SpuSimpleVO();
		spuVo5.setTitle("明锐");
		spuVo5.setSubTitle("2015款1.6L 自动逸俊版");
		spuVo5.setCoverImgUrl("c_baba_3f_mr.png");
		threeMap.put("baba_3f_mr",spuVo5);
		
		SpuSimpleVO spuVo6 = new SpuSimpleVO();
		spuVo6.setTitle("全新英朗");
		spuVo6.setSubTitle("2015款 15N 自动豪华型");
		spuVo6.setCoverImgUrl("c_baba_3f_yl.png");
		threeMap.put("baba_3f_yl",spuVo6);
		
		SpuSimpleVO spuVo7 = new SpuSimpleVO();
		spuVo7.setTitle("昂科威");
		spuVo7.setSubTitle("2014款 28T 四驱精英型");
		spuVo7.setCoverImgUrl("c_baba_3f_kw.jpg");
		threeMap.put("baba_3f_akw",spuVo7);
		
		SpuSimpleVO spuVo8 = new SpuSimpleVO();
		spuVo8.setTitle("君威");
		spuVo8.setSubTitle("2015款 1.6T 领先技术型");
		spuVo8.setCoverImgUrl("c_baba_3f_jw.png");
		threeMap.put("baba_3f_jw",spuVo8);
		
		SpuSimpleVO spuVo9 = new SpuSimpleVO();
		spuVo9.setTitle("迈锐宝");
		spuVo9.setSubTitle("2014款 2.0L 自动豪华版");
		spuVo9.setCoverImgUrl("c_baba_3f_wrb.png");
		threeMap.put("baba_3f_mrb",spuVo9);
		
		SpuSimpleVO spuVo10 = new SpuSimpleVO();
		spuVo10.setTitle("科鲁兹");
		spuVo10.setSubTitle("2015款 1.5L 自动豪华版");
		spuVo10.setCoverImgUrl("c_baba_3f_klz.jpg");
		threeMap.put("baba_3f_klz",spuVo10);
		
		SpuSimpleVO spuVo11 = new SpuSimpleVO();
		spuVo11.setTitle("宝骏730");
		spuVo11.setSubTitle("2014款1.5L手动舒适ESP版7座");
		spuVo11.setCoverImgUrl("c_baba_3f_bj730.jpg");
		threeMap.put("baba_3f_bj730",spuVo11);
		
		SpuSimpleVO spuVo12 = new SpuSimpleVO();
		spuVo12.setTitle("2015款G10");
		spuVo12.setSubTitle("2.0T自动时尚版");
		spuVo12.setCoverImgUrl("c_baba_3f_g10.png");
		threeMap.put("baba_3f_g10",spuVo12);
		
		SpuSimpleVO spuVo13 = new SpuSimpleVO();
		spuVo13.setTitle("凯迪拉克ATS-L");
		spuVo13.setSubTitle("2014款 25T 舒适型");
		spuVo13.setCoverImgUrl("c_baba_3f_ATS-L.jpg");
		threeMap.put("baba_3f_kdlk",spuVo13);
		
		SpuSimpleVO spuVo14 = new SpuSimpleVO();
		spuVo14.setTitle("森林人");
		spuVo14.setSubTitle("2015款 2.5i 特装纪念版");
		spuVo14.setCoverImgUrl("c_baba_3f_slr.jpg");
		threeMap.put("baba_3f_slr",spuVo14);
		
		SpuSimpleVO spuVo15 = new SpuSimpleVO();
		spuVo15.setTitle("尚酷");
		spuVo15.setSubTitle("2015款 1.4TSI 风尚版");
		spuVo15.setCoverImgUrl("c_baba_3f_slb.jpg");
		threeMap.put("baba_3f_sk",spuVo15);
	}

	
	/**
	 * 获取客户端ip
	 * 
	 * @param request
	 * @return
	 */
	public String getIp(HttpServletRequest request) {
		logger.info("获取客户端ip地址");
		String ip = null;
		try {
			ip = request.getHeader("x-forwarded-for");
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
			logger.info("客户端ip地址为：" + ip);
			return ip;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("发生异常ip地址获取失败");
			return null;
		}

	}
	
	/**
	 * 不服来比按钮埋点（下订单）
	 * @param request
	 * @param userId 用户id
	 * @param promotionid 活动id
	 * @return
	 */
	@RequestMapping("/recordBFLB")
	public GsonView recordBFLB(HttpServletRequest request,@RequestParam String userId,@RequestParam String spuId){
		GsonView gv = new GsonView();
			Cookie[] cookies = request.getCookies();
			String userTraceCookie = "";
			for (Cookie cookie : cookies) {
				String name = cookie.getName();
				if ("user_trace_cookie".equals(name)) {
					userTraceCookie = cookie.getValue();
					break;
				}
			}
				usertraceLogger.info("\t bf \t"+userTraceCookie + "\t" + userId + "\t"
				 + DateUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_order_"+spuId+"\t" 
				 + "不服来比"+"\t " + request.getHeader("user-agent") 
				 + "\t" + 3 + "\t" + 13);
		
		
		return gv;
	}
	
	@RequestMapping("/skipTest")
	public ModelAndView skipTest(){
		ModelAndView mav = new ModelAndView("/babajie/main/index.ftl");
		return mav;
	}

}
