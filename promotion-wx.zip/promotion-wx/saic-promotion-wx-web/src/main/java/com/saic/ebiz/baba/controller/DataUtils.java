package com.saic.ebiz.baba.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.saic.ebiz.carmall.service.vo.SpuSimpleVO;

/**
 * Data Utils
 * 
 * @author zhangxiaohui
 * @since 2015-08-03 22:29
 */
public class DataUtils {

	public static Map<Integer,List<SpuSimpleVO>> FOURTH_FLOOR_BU_FU_LAI_BI_MAP = new HashMap<Integer,List<SpuSimpleVO>>();

}
