package com.saic.ebiz.baba.controller;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ibm.framework.web.gson.GsonView;

@Controller
@RequestMapping("/testData")
@SuppressWarnings("all")
public class TestData {
    
    @RequestMapping("/executedeletecitymapJob")
    public GsonView deleteMapJob(HttpServletRequest req) {
    	GsonView gv = new GsonView();
    	DataUtils.FOURTH_FLOOR_BU_FU_LAI_BI_MAP.clear();
    	gv.addStaticAttribute("result", "map清除成功");
        return gv;
    }
    
}
