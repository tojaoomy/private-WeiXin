package com.saic.ebiz.baba.controller;

/**
 * 〈一句话功能简述〉<br>
 * 判别用户端设备类型工具类
 * 
 * @author meizhiqing
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public final class UserDeviceUtil {
    private UserDeviceUtil() {

    }

    /**
     * 功能描述: <br>
     * 判别用户端设备类型
     * 
     * @param userAgent
     * @return 1.pc; 2。移动设备
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static int getDeviceType(String userAgent) {
        int type = 2;
        if (userAgent.contains("Windows")) {
            type = 1;
        }
        return type;
    }

}
