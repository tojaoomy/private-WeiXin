package com.saic.ebiz.bc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.gson.GsonView;
import com.meidusa.fastjson.JSON;
import com.saic.ebiz.bc.utils.UrlUtil;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.util.PropertiesUtil;
import com.saic.ebiz.market.util.CookieUtil;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.promotion.service.api.IGiftManagerService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.client.PromotionClient;
import com.saic.ebiz.promotion.service.entity.GiftQuotaEntity;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionExtend;
import com.saic.ebiz.promotion.service.vo.PromotionResult;
import com.saic.sso.client.SSOClient;

/**
 * 
 * @author v_fanjinzhou BC类售 车Controller类
 */
@Controller
@RequestMapping("/bcsales")
public class BCSalesController {

    /** The Constant logger. */
    private final static Logger logger = LoggerFactory.getLogger(BCSalesController.class);

    // 活动服务
    @Autowired
    private IPromotionService remotePromotionService;

    // 活动扩展
    @Autowired
    private IPromotionExtendService remotePromotionExtendService;

    @Autowired
    private PromotionClient promotionClient;

    @Autowired
    private IPromotionService promotionService;
    /**
     * SSO服务
     */
    @Autowired
    private SSOClient ssoClient;

    @Autowired
    private IMemberService remoteMemberService;

    @Autowired
    private IGiftManagerService iGiftManagerService;

    @Autowired
    private UserService userService;

    @Autowired
    private JsSDKSign jsSDKSign;

    /**
     * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
     * 
     */
    @Value("${ebiz.wap.web.appId:}")
    private String appId;

    /** 用户行为跟踪logger. */
    private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");

    /**
     * 报用户行为跟踪logger.source来源业务渠道 1：电商主站2：车享宝3：营销子站
     */
    public static final int source_YXZZ = 3;

    /**
     * 报用户行为跟踪logger.type订单类型 13.促销活动-------即营销子站，即cxzz来源的销售线索，比如大转盘，
     */
    public static final int type_YXZZ = 13;

    /**
     * 1：电商主站； 2：车享宝； 3：营销子站； 4：保养管家； 5：第三方联合登陆； 6：别克联合登陆； 7：微信服务号； 8：微信订阅号；
     * 9：微信红包 11：呼叫中心； 12：平安保险（PC）； 13：订单系统； 14：车畅销； 20：车知道（内部账号）； 21：别克微信商城；
     * 22：荣威俱乐部； 23：crm； 24：运营平台； 29：车享购微信服务号； 31：平安微信； 35：新浪微博PC； 36：新浪微博移动；
     * 60：Other
     */
    private static final String TRACE_SOURCE = "7";

    /**
     * 线索类型 10.促销车订购 11.预约试乘试驾 12.在线询价 13.促销活动 14.常规车预定 15.来电咨询 16.在线留言咨询
     * 17.贷款购车 18.拉手电话 20.其他
     */
    private static final String TRACE_TYPE = "20";

    public static List<String> promotionBCodes = new ArrayList<String>();

    public static List<String> promotionCCodes = new ArrayList<String>();
    static {
        promotionBCodes.add("Xiuqiu328_b01_001");
        promotionBCodes.add("Xiuqiu328_b01_002");
        promotionBCodes.add("Xiuqiu328_b01_003");
        promotionBCodes.add("Xiuqiu328_b01_004");
        promotionBCodes.add("Xiuqiu328_b01_005");
        promotionBCodes.add("Xiuqiu328_b01_006");
        promotionBCodes.add("Xiuqiu328_b01_007");
        promotionBCodes.add("Xiuqiu328_b01_008");
        promotionBCodes.add("Xiuqiu328_b01_009");
        promotionBCodes.add("Xiuqiu328_b01_010");
        promotionBCodes.add("Xiuqiu328_b01_011");
        promotionBCodes.add("Xiuqiu328_b01_012");
        promotionBCodes.add("Xiuqiu328_b01_013");
        promotionBCodes.add("Xiuqiu328_b01_014");
        promotionBCodes.add("Xiuqiu328_b01_015");
        promotionBCodes.add("Xiuqiu328_b01_016");
        promotionBCodes.add("Xiuqiu328_b01_017");
        promotionBCodes.add("Xiuqiu328_b01_018");
        promotionBCodes.add("Xiuqiu328_b01_019");
        promotionBCodes.add("Xiuqiu328_b01_020");

        promotionCCodes.add("Xiuqiu328_c01_001");
        promotionCCodes.add("Xiuqiu328_c01_002");
        promotionCCodes.add("Xiuqiu328_c01_003");
        promotionCCodes.add("Xiuqiu328_c01_004");
        promotionCCodes.add("Xiuqiu328_c01_005");
        promotionCCodes.add("Xiuqiu328_c01_006");
        promotionCCodes.add("Xiuqiu328_oem_mggs");
        promotionCCodes.add("Xiuqiu328_c01_008");
        promotionCCodes.add("Xiuqiu328_c01_009");
        promotionCCodes.add("Xiuqiu328_c01_010");
        promotionCCodes.add("Xiuqiu328_c01_011");
        promotionCCodes.add("Xiuqiu328_c01_012");
        promotionCCodes.add("Xiuqiu328_c01_013");
        promotionCCodes.add("Xiuqiu328_c01_014");
        promotionCCodes.add("Xiuqiu328_c01_015");
        promotionCCodes.add("Xiuqiu328_c01_016");
        promotionCCodes.add("Xiuqiu328_c01_017");
        promotionCCodes.add("Xiuqiu328_c01_018");
        promotionCCodes.add("Xiuqiu328_c01_019");
        promotionCCodes.add("Xiuqiu328_c01_020");
        promotionCCodes.add("Xiuqiu328_c01_021");
        promotionCCodes.add("Xiuqiu328_c01_022");
        promotionCCodes.add("Xiuqiu328_c01_023");
        promotionCCodes.add("Xiuqiu328_c01_024");
        promotionCCodes.add("Xiuqiu328_c01_025");
        promotionCCodes.add("Xiuqiu328_c01_026");
        promotionCCodes.add("Xiuqiu328_c01_027");
        promotionCCodes.add("Xiuqiu328_c01_028");
        promotionCCodes.add("Xiuqiu328_c01_029");
        promotionCCodes.add("Xiuqiu328_c01_030");
        // promotionCCodes.add("Xiuqiu328_c01_031");
    }

    @RequestMapping("/bsales")
    public ModelAndView bc(HttpServletRequest request, @RequestParam("userId") Long userId, @RequestParam("openId") String openId) {
        ModelAndView mav = new ModelAndView("/xiuqiu_328/BC/c328M-list.ftl");
        Map<String, Promotion> xiuqiuByCodes = promotionService.getXiuqiuByCodes(promotionBCodes);
        List<GiftQuotaEntity> giftQuotaEntities = iGiftManagerService.queryGifts(1);
        Map<String, GiftQuotaEntity> giftMap = new HashMap<String, GiftQuotaEntity>();
        for (int i = 1; i < 5; i++) {
            giftMap.put("G" + i, giftQuotaEntities.get(i - 1));
        }
        mav.getModelMap().put("giftMap", giftMap);
        mav.getModelMap().put("userId", userId);
        mav.getModelMap().put("openId", openId);
        mav.getModelMap().put("xiuqiuByCodes", xiuqiuByCodes);
        // 微信分享JSSDK分享
        Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
        mav.addObject("jssdk", map);
        return mav;
    }

    @RequestMapping("/bcPageGoto")
    public ModelAndView bcPageGoto(HttpServletRequest request, String pageName, Long userId, String openId) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("/xiuqiu_328/BC/" + pageName);
        Map<String, Promotion> xiuqiuByCodes = promotionService.getXiuqiuByCodes(promotionBCodes);
        // int num = xiuqiuByCodes.size();
        // int proStatus =
        // xiuqiuByCodes.get("Xiuqiu328_b01_020").getPromotionStatus();
        // 若页面名称包含“more”或者“2nd”则为c类车
        if (pageName.contains("More") || pageName.contains("2nd")) {
            xiuqiuByCodes = promotionService.getXiuqiuByCodes(promotionCCodes);
        }
        List<GiftQuotaEntity> giftQuotaEntities = iGiftManagerService.queryGifts(1);
        Map<String, GiftQuotaEntity> giftMap = new HashMap<String, GiftQuotaEntity>();
        for (int i = 1; i < 5; i++) {
            giftMap.put("G" + i, giftQuotaEntities.get(i - 1));
        }
        mav.getModelMap().put("giftMap", giftMap);
        mav.getModelMap().put("xiuqiuByCodes", xiuqiuByCodes);
        mav.getModelMap().put("userId", userId);
        mav.getModelMap().put("openId", openId);
        // 微信分享JSSDK分享
        Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
        mav.addObject("jssdk", map);
        return mav;
    }

    @ResponseBody
    @RequestMapping("/qiangGou")
    public GsonView qiangGou(String promotionCode, String keyId, Long userId, Long giftId, HttpServletRequest request, HttpServletResponse response) {
        usertraceLogger.info("微信端BC类车\t" + getCookieByName(request) + "\t" + userId + "\t" + "成功" + "\t" + "keyId = " + keyId + "\t" + TRACE_SOURCE + "\t" + TRACE_TYPE);
        GsonView gv = new GsonView();
        try {

            // UserLoginVO userLoginVO = checkLoginStatus(request, gv);
            // if (!userLoginVO.getIsLoginSuccess()) {
            // return gv;
            // }
            UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(userId);
            String mobile = userBaseInfoVO.getMobile();
            long promotionId = promotionService.getPromotionIdByCode(promotionCode);

            List<String> promotionCodes = new ArrayList<String>();
            promotionCodes.add(promotionCode);
            Map<String, Promotion> promotionMap = promotionService.getXiuqiuByCodes(promotionCodes);
            Promotion promotion = promotionMap.get(promotionCode);
            // String mobile = "13641754374";
            long customerId = remotePromotionService.getCustomerId(userId, mobile);

            PromotionResult subscribeResult = null;
            boolean isAvailable = false;
            String url = "";

            subscribeResult = remotePromotionService.newSubscribe(promotionId, mobile, userId);
            logger.debug("subscribe：接口返回结果:" + JSON.toJSONString(subscribeResult) + "--调用参数:promotionId:" + promotionId + "--mobile:" + mobile + "--userId:" + userId + "--customerId:" + customerId);

            if (subscribeResult != null) {

                Cookie[] cookies = request.getCookies();
                String userTraceCookie = "";
                for (Cookie cookie : cookies) {
                    String name = cookie.getName();
                    if ("user_trace_cookie".equals(name)) {
                        userTraceCookie = cookie.getValue();
                        break;
                    }
                }
                usertraceLogger.info(userTraceCookie + "\t" + userId + "\t" + promotionId + "\t" + PropertiesUtil.getValue(String.valueOf(subscribeResult.getResultCode())) + "\t" + mobile + "\t" + source_YXZZ + "\t" + type_YXZZ + "\t" + keyId);

                if (subscribeResult.getResultCode() == 0) {
                    long velBrandId = promotion.getVelBrandId();
                    long velSeriesId = promotion.getVelSeriesId();

                    Long velModelId = promotion.getVelModelId() == null ? -1L : promotion.getVelModelId();
                    url = UrlUtil.getCheXiangGouOrderUrl(promotionId, subscribeResult.getSubscriptionId(), -1L, velBrandId, velSeriesId, velModelId, checkMobile(request), giftId, userId);
                    logger.debug("拼接后的URL为:" + url);
                }

                if (subscribeResult.getSubscription() != null) {
                    isAvailable = subscribeResult.getSubscription().isAvailable();
                }
            }

            PromotionExtend promotionExtend = remotePromotionExtendService.findPromotionExtendByPromotionId(promotionId);
            if (promotionExtend != null) {
                gv.addStaticAttribute("userPrmtLimit", promotionExtend.getUserPrmtLimit());
            }
            gv.addStaticAttribute("isAvailable", isAvailable);
            gv.addStaticAttribute("subscribeResult", subscribeResult);
            gv.addStaticAttribute("url", url);
            if (promotion != null) {
                gv.addStaticAttribute("members", promotion.getTotalMembers());
            }
        } catch (Exception e) {
            logger.error("车享购抢购错误,错误信息:{}", e.getMessage());
        }
        return gv;
    }

    @ResponseBody
    @RequestMapping("/checkValideCode")
    private boolean checkVaildCode(HttpSession session, String userCode) {
        boolean flag = false;
        String validCode = (String) session.getAttribute("RANDOMVALIDATECODEKEY");
        if (userCode.toLowerCase().equals(validCode.toLowerCase())) {
            flag = true;
        }
        return flag;
    }

    /**
     * 校验请求来源是否来自手机 <br>
     * 〈功能详细描述〉
     * 
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static boolean checkMobile(HttpServletRequest request) {
        String regexMatch = "nokia|iphone|ipod|iuc|android|motorola|^mot\\-|softbank|foma|docomo|kddi|up\\.browser|up\\.link|";
        regexMatch += "htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|";
        regexMatch += "blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|";
        regexMatch += "symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\\-|longcos|pantech|gionee|^sie\\-|portalmmm|";
        regexMatch += "jig\\s browser|hiptop|ucweb|^ucweb|^benq|haier|^lct|opera\\s*mobi|opera\\*mini|320x320|240x320|176x220";

        String userAgent = request.getHeader("user-agent").toLowerCase();
        if (StringUtils.isBlank(userAgent)) {
            return true;
        } else {
            Pattern p = Pattern.compile(regexMatch);
            Matcher m = p.matcher(userAgent);
            if (m.find()) {
                return true;
            }
        }
        return false;
    }

    private String getCookieByName(HttpServletRequest request) {
        Cookie cookie = CookieUtil.getCookieByName(request, "user_trace_cookie");
        String cookieName = null;
        if (cookie != null) {
            cookieName = cookie.getValue();
        }
        return cookieName;
    }

    @ResponseBody
    @RequestMapping("/checkMobile")
    private boolean isBindMobile(Long userId) {
        boolean flag = false;
        try {
            UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(userId);
            String mobile = userBaseInfoVO.getMobile();
            if (mobile != null && !"".equals(mobile)) {
                flag = true;
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }
}