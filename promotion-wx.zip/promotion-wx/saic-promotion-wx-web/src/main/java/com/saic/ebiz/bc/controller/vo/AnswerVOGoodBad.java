/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.bc.controller.vo;


/**
 * @author hejian
 *
 */
public class AnswerVOGoodBad{

	/**
	 * 
	 */
	private Long answerId;
	
	private boolean isOnGood;
	
	private boolean isOnBad;

	/**
	 * @return the answerId
	 */
	public Long getAnswerId() {
		return answerId;
	}

	/**
	 * @param answerId the answerId to set
	 */
	public void setAnswerId(Long answerId) {
		this.answerId = answerId;
	}

	/**
	 * @return the isOnGood
	 */
	public boolean isOnGood() {
		return isOnGood;
	}

	/**
	 * @return the isOnBad
	 */
	public boolean isOnBad() {
		return isOnBad;
	}

	/**
	 * @param isOnGood the isOnGood to set
	 */
	public void setOnGood(boolean isOnGood) {
		this.isOnGood = isOnGood;
	}

	/**
	 * @param isOnBad the isOnBad to set
	 */
	public void setOnBad(boolean isOnBad) {
		this.isOnBad = isOnBad;
	}

}
