package com.saic.ebiz.bc.controller.vo;
/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author qiuyunming
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class UserLoginVO {
    
    private long userId;
    
    private String userName;
    
    private int mobileAuthFlag;
    
    private Long mobileId;
    
    private String mobile;
    
    //用户登入和手机绑定都为true才为true
    private boolean isLoginSuccess;
    
    //用户是否登入
    private boolean isLogin;
    
    //用户是否手机绑定了
    private boolean isCellPhoneBinding;

   public long getUserId() {
       return userId;
   }

   public void setUserId(long userId) {
       this.userId = userId;
   }

   public String getUserName() {
       return userName;
   }

   public void setUserName(String userName) {
       this.userName = userName;
   }

   public int getMobileAuthFlag() {
       return mobileAuthFlag;
   }

   public void setMobileAuthFlag(int mobileAuthFlag) {
       this.mobileAuthFlag = mobileAuthFlag;
   }

   public Long getMobileId() {
       return mobileId;
   }

   public void setMobileId(Long mobileId) {
       this.mobileId = mobileId;
   }

   public String getMobile() {
       return mobile;
   }

   public void setMobile(String mobile) {
       this.mobile = mobile;
   }

   public boolean getIsLoginSuccess() {
       return isLoginSuccess;
   }

   public void setIsLoginSuccess(boolean isLoginSuccess) {
       this.isLoginSuccess = isLoginSuccess;
   }

   public boolean getIsLogin() {
       return isLogin;
   }

   public void setIsLogin(boolean isLogin) {
       this.isLogin = isLogin;
   }

   public boolean getIsCellPhoneBinding() {
       return isCellPhoneBinding;
   }

   public void setIsCellPhoneBinding(boolean isCellPhoneBinding) {
       this.isCellPhoneBinding = isCellPhoneBinding;
   }


}
