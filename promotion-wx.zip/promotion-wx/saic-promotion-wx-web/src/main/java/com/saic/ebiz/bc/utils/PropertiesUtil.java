package com.saic.ebiz.bc.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.meidusa.toolkit.common.bean.config.ConfigUtil;

/**
 * 〈一句话功能简述〉<br>
 * 读取属性配置文件工具类
 * 
 * @author v_fanjx
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public final class PropertiesUtil {
    /**
     * 隐藏工具类的构造方法
     */
    private PropertiesUtil() {

    }

    /**
     * 本地属性对象
     */
    public static final Properties URLPROPS = new Properties();
    /**
     * 远程服务器属性对象
     */
    public static final Properties REMOTEPROPS = ConfigUtil.getProperties();

    /**
     * 日志
     */
    private static final Logger logger = LoggerFactory.getLogger(PropertiesUtil.class);

    static {
        InputStream is = PropertiesUtil.class.getResourceAsStream("/conf/main_setting.properties");
        try {
            URLPROPS.load(is);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
    }

    public static String getValue(String key) {
        return URLPROPS.getProperty(key);
    }

    public static String getRemoteValue(String key) {
        return REMOTEPROPS.getProperty(key);
    }
}
