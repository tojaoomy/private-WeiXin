package com.saic.ebiz.bc.utils;

import java.net.URLEncoder;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.saic.framework.url.encrypt.SecurityHelper;

/**
 * 〈一句话功能简述〉<br>
 * 拼接跳到主站的URL
 * 
 * @author v_fanjx
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public final class UrlUtil {

    /** The Constant logger. */
    private final static Logger logger = LoggerFactory.getLogger(UrlUtil.class);

    /**
     * 功能描述: <br>
     * 拼接车享购订单URL
     * 
     * @param promotionId
     * @param subscriptionId
     * @param cityId
     * @param isMobile
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String getCheXiangGouOrderUrl(Long promotionId, Long subscriptionId, Long cityId, Long velBrandId, Long velSeriesId, Long velModelId, boolean isMobile, Long giftId, Long userId) {
        String url = null;
        try {

            String parUrl = "promotionId=" + promotionId + "&brandId=" + velBrandId + "&seriesId=" + velSeriesId + "&vehicleModelId=" + velModelId + "&subscriptionId=" + subscriptionId + "&cityId=" + cityId+ "&userId="+userId;
            if (giftId != null ) {
                parUrl += "&giftId=" + giftId;
            }
           
//            String enToken = new String(Base64.encodeBase64(SecurityHelper.verifyWithMD5(parUrl).getBytes("UTF-8")), "UTF-8");
            String token = "&token=" + URLEncoder.encode(
                    new String(Base64.encodeBase64(SecurityHelper
                            .verifyWithMD5(parUrl).getBytes())), "utf-8");
            // String mainSiteUrl = (isMobile) ?
            // PropertiesUtil.getRemoteValue("saicMobileOrderUrl") :
            // PropertiesUtil
            // .getRemoteValue("saicOrderUrl");
            // String mainSiteUrl = (isMobile) ?
            // PropertiesUtil.getRemoteValue("mobileOrderUrl") :
            // PropertiesUtil.getRemoteValue("orderUrl");
            // mainSiteUrl = mainSiteUrl.replaceAll("buildorder", "saicOrder");
            url = "saicOrder.htm" + "?" + parUrl + token;

        } catch (Exception e) {
            logger.debug("error:" + e.toString());
        }
        return url;
    }
    
    /**
     * 功能描述: <br>
     * 拼接订单URL
     * 
     * @param userId
     * @param mobile
     * @param promotionId
     * @param subscriptionId
     * @param benefit
     * @param isMobile
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String getOrderUrl(Long promotionId, Long subscriptionId, boolean isMobile) {
        String url = null;
        try {
            String parUrl = "promotionId=" + promotionId + "&subscriptionId=" + subscriptionId;
            String enToken = new String(Base64.encodeBase64(SecurityHelper.verifyWithMD5(parUrl).getBytes("UTF-8")),
                    "UTF-8");
            String token = "&token=" + URLEncoder.encode(enToken, "utf-8");
//            String mainSiteUrl = (isMobile) ? PropertiesUtil.getRemoteValue("mobileOrderUrl") : PropertiesUtil
//                    .getRemoteValue("orderUrl");
            String mainSiteUrl = PropertiesUtil.getRemoteValue("orderUrl");
            url = mainSiteUrl + "?" + parUrl + token;
        } catch (Exception e) {
        	e.getStackTrace();
        }
        return url;
    }
}
