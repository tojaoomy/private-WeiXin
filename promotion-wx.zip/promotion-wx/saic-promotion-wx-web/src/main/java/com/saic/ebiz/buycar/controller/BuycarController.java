package com.saic.ebiz.buycar.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.gson.GsonView;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.oem.controller.RwSouthController;
import com.saic.ebiz.promotion.service.api.IFocusMediaService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.vo.PromotionResult;
import com.saic.ebiz.promotion.service.vo.UserInfo;

@Controller
@RequestMapping("/buycar")
public class BuycarController {
	
	
	/**
	 * 日志
	 */
	private final Logger logger = LoggerFactory
			.getLogger(RwSouthController.class);
	
	/**
	 * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx38a0b3a7cc7761f9
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/** 活动服务 */
	@Autowired
	private IFocusMediaService iFocusMediaService;
	
	
	@Autowired
	private JsSDKSign jsSDKSign;
	
	/**
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;

	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;	
	
	
	@Autowired
	private IMemberService memberService;
	
	/** 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");
	
	static List<String> codeListMG = new ArrayList<String>();
	static {
		codeListMG.add("MGALL_EAST_MG3");
		codeListMG.add("MGALL_EAST_MG5");
		codeListMG.add("MGALL_EAST_MG6");
		codeListMG.add("MGALL_EAST_MGGS");
		codeListMG.add("MGALL_EAST_MGGT");
	}
	
	
	
	@RequestMapping("/index")
	public ModelAndView main(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request) {
		ModelAndView mv = null;
		String uId = request.getParameter(RequestConstants.USER_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		logger.info("request parameters userId = {}, openId = {} ", uId, openId);
		if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
			String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.buycar.name());
			logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
			logger.debug("授权url : {} ######", autorizationUrl);
			mv = new ModelAndView(autorizationUrl);
		} else {
			mv = new ModelAndView("/buycar/index.ftl");
			mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
		}
		
		// 微信分享JSSDK分享
        Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
        mv.addObject("jssdk", map);
		return mv;
	}
	
	
	
	@RequestMapping("/use")
	public GsonView use(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request) {
		GsonView gv = new GsonView();
		String uId = request.getParameter(RequestConstants.USER_ID);
		UserInfo user = memberService.findMembCentInfo(Integer.valueOf(uId));
		String mobile = user.getMobile();
		if(StringUtils.isEmpty(mobile)){
			gv.addStaticAttribute("result", 6);
		}else{
	        PromotionResult result = iFocusMediaService.getGouCheCoupon(Long.parseLong(uId), mobile);
	        gv.addStaticAttribute("result", result.getResultCode());
		}
		
		//记录用户日志
		Cookie[] cookies = request.getCookies();
		String userTraceCookie = "";
		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if ("user_trace_cookie".equals(name)) {
				userTraceCookie = cookie.getValue();
				break;
			}
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		usertraceLogger.info("\t"+userTraceCookie + "\t" + userId + "\t"
					 + "yzsgc_wx_promotion_yxzc_faquan" + "\t" + format.format(new Date())+"\t "+this.getIp(request)+" \t"
					+ request.getHeader("user-agent") 
					+ "一站式购车588元购车抵用券活动" + "\t" + 3 + "\t" + 13);
		return gv;
	}
	
	public String getIp(HttpServletRequest request) {
		logger.info("获取客户端ip地址");
		String ip = null;
		try{
			ip = request.getHeader("x-forwarded-for");  
	       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	           ip = request.getHeader("Proxy-Client-IP");  
	       }  
	       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	           ip = request.getHeader("WL-Proxy-Client-IP");  
	       }  
	       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	           ip = request.getRemoteAddr();  
	       }  
	       if(ip.indexOf(",")>0) {
	    	   ip = ip.split(",")[0];
	       }
	       logger.info("客户端ip地址为：" + ip);
	       return ip;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("发生异常ip地址获取失败");
			return null;
		}
		
	}
}
