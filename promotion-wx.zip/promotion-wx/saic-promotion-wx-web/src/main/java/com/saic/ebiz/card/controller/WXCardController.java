package com.saic.ebiz.card.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.promotion.service.api.IWeiXinCardService;
import com.saic.ebiz.promotion.service.entity.WeixinCardCompanyEntity;
import com.saic.ebiz.promotion.service.entity.WeixinCardEntity;

/**
 * 微信名片
 */
@Controller
@RequestMapping(value="/wxcard")
public class WXCardController {
	/*日志*/
	private final Logger logger = LoggerFactory.getLogger(WXCardController.class);
	
	/*微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx38a0b3a7cc7761f9*/
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	//微信JSAPI授权
	@Autowired
	private JsSDKSign jsSDKSign;

	/**
	 * 授权服务
	 */
	@Resource 
	private AuthorizationService authorizationService;	
	
	
	/** 微信名片服务 */
	@Autowired
	private IWeiXinCardService iWeiXinCardService;
	
	/**
	 * 验证是否为微信浏览器打开
	 * @param requset 当前请求
	 * @return boolean true 微信打开   false 非微信打开
	 */
	private boolean isOpenInWX(HttpServletRequest request) {
		boolean result = true;
		String userAgent = request.getHeader("User-Agent");
        if(!StringUtils.isEmpty(userAgent) && !userAgent.toLowerCase().contains("micromessenger")){
        	result = false;
        }
		return result;
	}
	/**
	 * 名片展示入口
	 */
	@RequestMapping("/show")
	public ModelAndView cardShow(HttpServletRequest request){
		
		ModelAndView mv = null;
		String userId = request.getParameter(RequestConstants.USER_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		String tzhuserId = request.getParameter("tzhUserId");	//淘智汇userid
		logger.info("请求的用户ID userId ： {}, openId = {}, tzhuserId = {}", userId, openId,tzhuserId);
		//mv = new ModelAndView("/wxCard/wx-card.ftl");
		mv = new ModelAndView("/wxCard/wx-card-new.ftl");
		String isOpenInWX = "0";
		//判断是否微信端打开
        if(isOpenInWX(request)){ //微信浏览器打开
        	if (StringUtils.isEmpty(userId) || "-1".equals(userId)) {
    			String autorizationUrl = "redirect:" + authorizationService.
    					buildAuthorizationLink(appId, (redirectHost + "oauthNoLogin.htm?tzhUserId="+tzhuserId), Scope.snsapi_base);
    			autorizationUrl = autorizationUrl.replace("STATE", Authorization.wxCard.name());
    			logger.info("授权url : {} ", autorizationUrl);
    			mv = new ModelAndView(autorizationUrl);
    			return mv;
    		}
        	// 微信分享JSSDK分享
		    Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + 
		    		"?" + request.getQueryString());
		    mv.addObject("jssdk", map).addObject("isOpenInWX","1");
		    isOpenInWX = "1";
        }
        try {
        	//获取当前用户的名片信息
    		int userIdint = Integer.parseInt(tzhuserId);	//确认userId是否使用int类型 进行异常处理
    		WeixinCardEntity wxCardInfo = iWeiXinCardService.getWeixinCard(userIdint);
    		logger.info("名片信息 : {} ", JSONObject.fromObject(wxCardInfo));
    		if(wxCardInfo==null){//审核未通过 
    			return new ModelAndView("/wxCard/wx-Nocard.ftl").addObject("isOpenInWX",isOpenInWX).addObject("isDelete","0");
    		}else if(wxCardInfo.getAuditedUserDetail()==null || wxCardInfo.getAuditStatus() == 4){
    			String isDelete = "0";
    			if(wxCardInfo.getRowStatus() == 2 || wxCardInfo.getAuditStatus() == 4){
    				//已删除
    				isDelete = "1";
    			}
    			return new ModelAndView("/wxCard/wx-Nocard.ftl").addObject("isOpenInWX",isOpenInWX).addObject("isDelete",isDelete); 
    		}
    		JSONObject detailInfo = JSONObject.fromObject(wxCardInfo.getAuditedUserDetail());
    		wxCardInfo = (WeixinCardEntity) JSONObject.toBean(detailInfo, WeixinCardEntity.class);
    		mv.addObject("wxCardInfo", wxCardInfo);
    		mv.addObject("tzhuserId", tzhuserId);
    		//根据公司ID获取公司信息
    		WeixinCardCompanyEntity wxCardCompanyEntity = iWeiXinCardService.findWeixinCardCompanyById(wxCardInfo.getCompanyId());
    		mv.addObject("company", wxCardCompanyEntity.getCompanyName());
    		mv.addObject("companyAddress", wxCardCompanyEntity.getAddress());
    		mv.addObject("areaCode", wxCardCompanyEntity.getAreaCode());
		} catch (Exception e) {
			logger.info("sli--|-- 显示名片信息出错 ="
					+ e.getLocalizedMessage());
		}
		return mv;
	}
	
	/**
	 * 名片地图展示
	 */
	@RequestMapping("/cardMap")
	public ModelAndView cardMap(HttpServletRequest request){
		ModelAndView mv = null;
		String userId = request.getParameter(RequestConstants.USER_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		String tzhuserId = request.getParameter("tzhUserId");	//淘智汇userid
		logger.info("请求的用户ID userId ： {}, openId = {}, tzhUserId : {} ", userId, openId,tzhuserId);
		if (StringUtils.isEmpty(userId) || "-1".equals(userId)) {
			String autorizationUrl = "redirect:" + authorizationService.
					buildAuthorizationLink(appId, (redirectHost + "oauthNoLogin.htm?tzhUserId="+tzhuserId), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.wxCardMap.name());
			logger.info("授权url : {} ", autorizationUrl);
			mv = new ModelAndView(autorizationUrl);
		}
		else{
			mv = new ModelAndView("/wxCard/wx-cardMap.ftl");
			//获取当前用户的名片信息
			int userIdint = Integer.parseInt(tzhuserId);	//确认userId是否使用int类型 进行异常处理
			WeixinCardEntity wxCardInfo = iWeiXinCardService.getWeixinCard(userIdint);
			logger.info("名片信息 : {} ", JSONObject.fromObject(wxCardInfo));
			mv.addObject("wxCardInfo", wxCardInfo).addObject(RequestConstants.OPEN_ID, openId).addObject("nowTime", new Date().getTime());
			// 微信分享JSSDK分享
		    Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + 
		    		"?" + request.getQueryString());
		    mv.addObject("jssdk", map);
		}
		return mv;
	}
	
	/**
	 * 名片编辑页
	 */
	@RequestMapping("/cardEdit")
	public ModelAndView cardEdit(HttpServletRequest request){
		ModelAndView mv = new ModelAndView("/wxCard/wx-cardEdit.ftl");
		String tzhuserId = request.getParameter("tzhUserId");	//淘智汇userid
		try {
			int userIdint = Integer.parseInt(tzhuserId);	//确认userId是否使用int类型 进行异常处理
			//查询是否已创建名片-带出历史名片信息
			WeixinCardEntity wxCardInfo = iWeiXinCardService.getWeixinCard(userIdint);
			logger.info("名片信息 : {} ", JSONObject.fromObject(wxCardInfo));
			//查询公司信息
			List<String> companyNames = iWeiXinCardService.getWeixinCardCompanyNames();
			logger.info("公司信息 : {} ", companyNames);
			if(companyNames !=null && companyNames.size()>0){
				List<WeixinCardCompanyEntity> wxCardCompanyEntity = null;
				if(wxCardInfo!=null){
					WeixinCardCompanyEntity companyEntity = iWeiXinCardService.findWeixinCardCompanyById(wxCardInfo.getCompanyId());
					mv.addObject("companyEntity", companyEntity); //公司信息
					wxCardCompanyEntity = iWeiXinCardService.findWeixinCardCompanyByName(companyEntity.getCompanyName());
				}else{
					wxCardCompanyEntity = iWeiXinCardService.findWeixinCardCompanyByName(companyNames.get(0));
				}
				logger.info("根据公司姓名查询具体信息 {} ",JSONArray.fromObject(wxCardCompanyEntity));
				mv.addObject("companys", wxCardCompanyEntity); //公司信息
				
			}
			mv.addObject("tzhUserId", userIdint);	//保存淘智汇userId
			mv.addObject("wxCardInfo", wxCardInfo); //名片信息ftl中判断信息是否存在
			mv.addObject("companyNames", companyNames); //公司信息
		} catch (Exception e) {
			logger.info("sli--|-- 查询基础信息(名片信息,公司,地址信息)出错 ="
					+ e.getLocalizedMessage());
		}
		
		return mv;
	}
	
	/**
	 * @Title: cardInfoSave
	 * @Description: 名片信息保存 
	 * @param: userId - 淘智汇用户Id(必填)
	 * @param: cardPhoto - 头像地址(必填)
	 * @param: cardName - 姓名(必填)
	 * @param: cardPhone - 手机号(必填)
	 * @param: cardCompanyId - 公司ID(必填)
	 * @param: cardPosition - 职位(必填)
	 * @param: cscLoginName - 公司录入人(必填)
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/cardInfoSave")
	public boolean cardInfoSave(HttpServletRequest request) {
		boolean result = true;
		//获取必要参数
		String tzhuserId = request.getParameter(RequestConstants.USER_ID);	//淘智汇userid
		String cardPhoto = request.getParameter("cardPhoto");				//头像地址
		String cardName = request.getParameter("cardName");					//姓名
		String cardPhone = request.getParameter("cardPhone");				//手机号
		String cardCompanyId = request.getParameter("cardCompanyId");		//weixincompanyentity的ID  公司Id
		String cardPosition = request.getParameter("cardPosition");			//职位
		String cscLoginName = request.getParameter("cscLoginName");			//录入来源
		String cardEmail = request.getParameter("cardEmail");		
		
		try {
			int userIdint = Integer.parseInt(tzhuserId);	//确认userId是否使用int类型 进行异常处理
			int cardCompanyIdint = Integer.parseInt(cardCompanyId);	
			//查询是否已创建名片-带出历史名片信息
			WeixinCardEntity wxCardInfo = iWeiXinCardService.getWeixinCard(userIdint);
			boolean updateInfo = false;
			if(wxCardInfo!=null){
				updateInfo = true;
			}else{
				wxCardInfo = new WeixinCardEntity();
			}
			wxCardInfo.setUserId(userIdint);
			wxCardInfo.setUserHeadImg(cardPhoto);
			wxCardInfo.setUserName(cardName);
			wxCardInfo.setMobileNum(cardPhone);
			wxCardInfo.setPositionName(cardPosition);
			wxCardInfo.setCompanyId(cardCompanyIdint);					//companyId字段存储weixincompanyentity的id
			wxCardInfo.setCscLoginName(cscLoginName);		
			wxCardInfo.setEmail(cardEmail);
			if(updateInfo){
				wxCardInfo.setAuditStatus(1);
				wxCardInfo = iWeiXinCardService.updateWeixinCard(wxCardInfo);
			}else{
				wxCardInfo = iWeiXinCardService.addWeixinCard(wxCardInfo);
			}
			
			logger.info("保存微信名片后的信息 {} ",JSONObject.fromObject(wxCardInfo));
			if(wxCardInfo==null){
				result = false;
			}
			
		} catch (Exception e) {
			result = false;
			logger.info("sli--|-- 保存名片信息出错 ="
					+ e.getLocalizedMessage());
		}
		return result;
	}
	
	/**
	 * @Title: getAddressBycomName
	 * @Description: 根据公司名获取地址等相关信息 
	 * @param: comName - 公司名(必)
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getAddressBycomName")
	public JSONArray getAddressBycomName(HttpServletRequest request) {
		String comName = request.getParameter("comName");			//公司名
		List<WeixinCardCompanyEntity> wxCardCompanyEntity = iWeiXinCardService.findWeixinCardCompanyByName(comName);
		logger.info("根据公司姓名查询具体信息 {} ",JSONArray.fromObject(wxCardCompanyEntity));
		JSONArray companyList = new JSONArray();
		if(wxCardCompanyEntity!=null & wxCardCompanyEntity.size()>0){
			companyList = JSONArray.fromObject(wxCardCompanyEntity);
		}
		return companyList;
	}
	
	
	/**
	 *  页面跳转
	 */
	@RequestMapping("/pageChange")
	public ModelAndView cardPageChange(HttpServletRequest request){
		ModelAndView mv = null;
		String pageName = request.getParameter("pageName");
		logger.info("需要跳转的页面名 pageName = " + pageName);
		mv = new ModelAndView("/wxCard/"+pageName+".ftl");
		//判断是否微信端打开
        if(isOpenInWX(request)){ //微信浏览器打开
		    mv.addObject("isOpenInWX","1");
        }
		return mv;
	}
}
