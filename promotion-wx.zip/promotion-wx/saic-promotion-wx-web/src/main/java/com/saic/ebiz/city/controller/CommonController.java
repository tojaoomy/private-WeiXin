/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.city.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ibm.framework.web.gson.GsonView;
import com.saic.ebiz.market.entity.ProvinceVO;
import com.saic.ebiz.market.service.AreaService;

/**
 * 公共控制器.<br> 
 * @author v_xuxuewen01
 */
@Controller
@RequestMapping("/common")
public class CommonController {
    
    /** The area service : get all provineces and citys. */
    @Resource(name = "areaService")
    private AreaService areaService;
    
    /**
     * 功能描述: 得到省和城市<br>
     * .
     * @return the area gson
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/getArea")
    public GsonView getAreaGson() {
        GsonView gv = new GsonView();
        List<ProvinceVO> result = areaService.getAllProvinces();
        gv.addStaticAttribute("result", result);
        return gv;
    }
    
    /**
     *  通过城市id获取省份信息
     *  
     * @param cityId
     * 
     * @return
     */
    @RequestMapping("/province/city/{cityId}")
    @ResponseBody
    public GsonView getProvinceByCityId(@PathVariable("cityId") Long cityId){
    	GsonView gv = new GsonView();
    	ProvinceVO result = areaService.getProvinceByCityId(cityId);
    	gv.addStaticAttribute("result", result);
        return gv;
    }
    
    /**
     *  通过城市id获取省份信息
     *  
     * @param cityId
     * 
     * @return
     */
    @RequestMapping("/checkAccessCondition")
    @ResponseBody
    public GsonView getProvinceByCityId2(@RequestParam("cityId") Long cityId){
    	GsonView gv = new GsonView();
    	ProvinceVO result = areaService.getProvinceByCityId(cityId);
    	gv.addStaticAttribute("result", result);
    	return gv;
    }
}
