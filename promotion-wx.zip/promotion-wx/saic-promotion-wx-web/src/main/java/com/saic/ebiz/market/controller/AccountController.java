package com.saic.ebiz.market.controller;
/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */


import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.meidusa.fastjson.JSON;
import com.meidusa.fastjson.JSONObject;
import com.meidusa.toolkit.common.bean.config.ConfigUtil;
import com.saic.ebiz.component.wx.job.TicketJob;
import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.entity.user.UserBean;
import com.saic.ebiz.market.common.util.MyOpenIdTokenUtil;
import com.saic.ebiz.market.common.util.RegexUtil;
import com.saic.ebiz.market.common.util.SendMessageUtil;
import com.saic.ebiz.market.common.util.login.RandomValidateCode;
import com.saic.ebiz.market.event.RedirectHandler;
import com.saic.ebiz.market.service.AccountService;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.service.FindPassWordService;
import com.saic.ebiz.market.service.ValidateService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.api.WebAccountService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.sso.client.entity.LoginInfo;

/**
 * 账户管理控制器<br>wx
 * 
 */
@Controller
@RequestMapping("/account")
public class AccountController {
    /** The Constant logger. */
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountController.class);

	private static final Logger weiXinLoger = LoggerFactory.getLogger("weixin-trace");
    /** 用户名存在. */
    private static final int LOGIN_RET_CODEEXISTS = 100;
    
    /** The Constant loginRtnCodeError. */
    private static final int LOGIN_RET_CODEERROR = 101;
    
    /** The Constant loginRtnCodeLimit. */
    private static final int LOGIN_RET_CODELIMIT = 102;

    /** 保存密码打勾key值. */
    private static final String SAVEPASS_OK_KEY = "isSavePass";
    
    /** 保存密码打勾. */
    private static final String SAVEPASS_OK_VALUE = "1";
    
    /**  应用ID,注册来源的应用ID号，1：电商主站应用. */
    private static final int APPID = 1;

    /**  认证类型-->1:用户名，2:手机， 3:邮箱. */
    private static final int ALIAS_TYPE = 1;
    
    /**  创建类型. */
    private static final int CREATE_TYPE = 1;
    
    /**  密码安全级别. */
    private static final int SECURITY_TYPE = 2;
    
    /** 用户错误信息键. */
    private static final String NAME_MESSAGE_KEY = "nameMessage";
    
    /** 用户验证码错误信息键. */
    private static final String VALID_MESSAGE_KEY = "message";
    /** 用户验错误信息键. */
    private static final String ERMSG = "errormessage";
    /** 用户名最小长度. */
    private static final int USERNAME_LENTH_MIN = 6;
    
    /** 用户名最大长度. */
    private static final int USERNAME_LENTH_MAX = 20;
    
    /**  登录模板路径. */
    private static final String FTL_LOGIN = "/account/wap-login.ftl";
    
    /**  登录模板路径. */
    private static final String WXFTL_LOGIN = "/account/wxwap-login.ftl";
    
    /**  登录模板路径. */
    private static final String USER_LOGIN = "/account/user_login.ftl";
    /**  找回密码登陆页面. */
    
    private static final String FTL_FDPWD = "/account/find-password.ftl";
    /** 找回密码. */
    @Resource
    private FindPassWordService findPassWordService;
    /**  营销子站首页. */
    @Value("${ebiz.wap.web.minisite:}")
    private String minisiteIndex;
    /** 实现类. */
    @Resource(name = "validateServiceImpl")
    private ValidateService validateService;
    
    /** The account service. */
    @Resource(name = "accountServiceImpl")
    private AccountService accountService;
    
    @Autowired
    private TicketJob ticketJob;
    
    /** MDM用户操作服务 */
    @Autowired
    private UserService userService;
    
    /** 通过该工具实现redis缓存的交换. */
    @Autowired
    private MyOpenIdTokenUtil idTokenUtil;
    
    /** 微信服务可以通过此服务实现用户登录绑定和取消绑定 */
    @Autowired
    private WebAccountService webAccountService;
    
    @Autowired
    private IUserService iUserService;
    
    @Resource
    private RedirectHandler redirectHandler;
    
    /** 用户行为跟踪logger. */
   	private Logger newuserRegisterLogger = LoggerFactory.getLogger("NEW-USER-REGISTER");
    
    /**  注入gson. */
    @Resource
    private Gson gson;

    /**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 bdf9bedfd1e36dc2797cddc02847cb88
	 * 测试账号        04a4ea410735b9a134d41ed29ce64699
	 * 
	 */
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
    
	@Autowired
	private BoundingService boundingService;
    /**
     * 功能描述: 转向会员登陆<br>
     * .
     * 
     * @param userBean the user bean
     * @param result the result
     * @param request the request
     * @return the model and view
     * @see  
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/login")
    public ModelAndView login(@ModelAttribute UserBean userBean, BindingResult result,
            HttpServletRequest request) {
        String backUrl =request.getParameter("backUrl");
        String fromType=request.getParameter("fromType");
        String token=request.getParameter("token");
        String openid=request.getParameter(RequestConstants.OPEN_ID);
        String errcode=request.getParameter("errcode");
     if(StringUtils.isNotBlank(openid)){
    	  return new ModelAndView(FTL_LOGIN)
	        		.addObject("fromType", fromType).addObject(RequestConstants.OPEN_ID, openid)
	        		.addObject("backUrl", backUrl);
		}
		if (StringUtils.isNotBlank(fromType) && StringUtils.isNotEmpty(fromType) && "1".equals(fromType.trim())) {
			try {
				openid=idTokenUtil.getOpenIdToken(token);
    			LOGGER.info("获取openid : " + openid);
				if (!StringUtils.isBlank(openid) && !"null".equals(openid)) {
					LOGGER.info("获取openid" + (openid == null ? "null" : openid));
					LOGGER.info("进入opendi为有的状态");
					return new ModelAndView(FTL_LOGIN).addObject(SAVEPASS_OK_KEY, SAVEPASS_OK_VALUE)
							.addObject("fromType", fromType)
							.addObject(RequestConstants.OPEN_ID, openid)
							.addObject("backUrl", backUrl)
							.addObject("token", token)
							.addObject("message", (errcode == null ? null : (Integer.parseInt(errcode) == 0 ? 
									"未知异常": (Integer.parseInt(errcode) == 1) ? "token授权失败": (Integer.parseInt(errcode) == 2 ? "绑定失败" : ""))));
				} else {
					LOGGER.info("进入opendi为空的状态");
					return new ModelAndView("/account/errortip.ftl");
				}

			} catch (Exception e) {
				LOGGER.error("exchangeOpenId Error", e);
				return new ModelAndView("/account/errortip.ftl");
			}
		} else {
			return new ModelAndView(FTL_LOGIN)
					.addObject(SAVEPASS_OK_KEY, SAVEPASS_OK_VALUE)
					.addObject("backUrl", backUrl)
					.addObject("message",
							(errcode == null ? null : (Integer
									.parseInt(errcode) == 0 ? "未知异常" : (Integer
									.parseInt(errcode) == 1) ? "token授权失败"
									: (Integer.parseInt(errcode) == 2 ? "绑定失败"
											: ""))));
		}
    }
    
    /**
     * 
     * 针对车享购微信服务号
     * 
     * 功能描述: 微信登陆绑定<br>
     * .
     * 
     * @param userBean the user bean
     * @param result the result
     * @param request the request
     * @return the model and view
     * @see AccountController#userLogin(HttpServletRequest, HttpServletResponse, HttpSession, UserBean, BindingResult)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/wxlogin")
    public ModelAndView wxlogin(@ModelAttribute UserBean userBean, BindingResult result,
    		HttpServletRequest request) {
   
    	weiXinLoger.info("wxlogin==>|begin");
    	writeLog(request);
    	String backUrl =request.getParameter("backUrl");
    	//来源
    	String fromType=request.getParameter("fromType");
    	String token=request.getParameter("token");
    	//token是由uuid--openid组成
    	String openid=request.getParameter(RequestConstants.OPEN_ID);
    	String errcode=request.getParameter("errcode");
    	
    	LOGGER.debug("backUrl : {} , fromType : {} , token : {} , openid : {} , errcode : {}", backUrl, fromType, token, openid, errcode);
    	
    	if(StringUtils.isNotBlank(openid)){
    		return new ModelAndView(WXFTL_LOGIN)
    		.addObject("fromType", fromType).addObject("openid", openid)
    		.addObject("backUrl", backUrl)
    		.addObject("backUrl", backUrl)
    		.addObject("keyid",request.getParameter("keyid"));
    	}
    	//目前车享购来源是29
    	if(StringUtils.isNotBlank(fromType) && StringUtils.isNotEmpty(fromType) && Constants.MDM_USER_SAIC_SOURCE.equals(fromType.trim())){
    		try {
//    			openid = idTokenUtil.getOpenIdToken(token);
    			LOGGER.info(" wxlogin 获取openid : " + openid);
    			if(!StringUtils.isBlank(openid)&& !"null".equals(openid)){
    				LOGGER.info("获取openid" + (openid==null ? "null" : openid));
    				LOGGER.info("进入opendi为有的状态");
    				WebAccountVO webAccountVO = new WebAccountVO();
    				webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE);
    				webAccountVO.setNumber(openid);
    				//车享购微信来源
    				webAccountVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));
    				//
					List<WebAccountVO> accountByCondition = this.webAccountService.findWebAccountByCondition(webAccountVO);
					boolean isBounding = false;
					if (null != accountByCondition && accountByCondition.size() > 0) {
						isBounding = true;
					}
					//如果绑定，则跳到成功绑定的页面
					if (isBounding){
						return new ModelAndView("/account/wxbindingSuccess.ftl").addObject("operateType", "4");
					}
    				
    				return new ModelAndView(WXFTL_LOGIN).addObject(SAVEPASS_OK_KEY, SAVEPASS_OK_VALUE)
    						.addObject("fromType", fromType).addObject("openid", openid)
    						.addObject("backUrl", backUrl)
    						.addObject("token", token)
    						.addObject("message", (errcode==null?null:(Integer.parseInt(errcode)==0?"未知异常":(Integer.parseInt(errcode)==1)?"token授权失败":(Integer.parseInt(errcode)==2?"绑定失败":""))));
    			}else{
    				LOGGER.error("进入opendi为空的状态");
    				return new ModelAndView("/account/errortip.ftl");
    			}
    			
    		} catch (Exception e) {
    			LOGGER.error("exchangeOpenId Error",e.getMessage());
    			return new ModelAndView("/account/errortip.ftl");
    		}
    	}else{
    		return new ModelAndView(WXFTL_LOGIN).addObject(SAVEPASS_OK_KEY, SAVEPASS_OK_VALUE)
    				.addObject("backUrl", backUrl)
    				.addObject("message", (errcode==null?null:(Integer.parseInt(errcode)==0?"未知异常":(Integer.parseInt(errcode)==1)?"token授权失败":(Integer.parseInt(errcode)==2?"绑定失败":""))));
    	}
    }
    /**
     * 功能描述: 用户注销.<br>
     *
     * @param request the request
     * @param response the response
     * @return 注销页面
     * @throws UnsupportedEncodingException the unsupported encoding exception
     */
    @RequestMapping("/logout")
    public ModelAndView logout(HttpServletRequest request, HttpServletResponse response)
            throws UnsupportedEncodingException {
    
        // userLogout的第一个参数服务中未用
        accountService.userLogout(NumberUtils.LONG_ZERO, request, response);
        
        // 修改为直接转至子站活动首页
        return new ModelAndView("redirect:" + minisiteIndex);
    }
    
    @RequestMapping("/findpassword")
    public ModelAndView findPassword(HttpServletRequest request, HttpServletResponse response)
            throws UnsupportedEncodingException {
    	Long userid=Long.MIN_VALUE;
//    	String phone =StringUtils.EMPTY;
    	String isExist =StringUtils.EMPTY;
        String fromType= request.getParameter("fromType");
        String openid=request.getParameter("openid");
        weiXinLoger.info("@action:findpassword in parmes：【userid="+userid
        		+",isExist="+isExist+",fromType="+fromType+",openid="+openid+"】");
        return new ModelAndView("/account/find-password.ftl").addObject("fromType", fromType).addObject("openid", openid).addObject("random", Math.random());
    }
    
    @RequestMapping("/identityauthor")
    public ModelAndView identityauthor(HttpServletRequest request, HttpServletResponse response, HttpSession session){
       String phoneNum=StringUtils.EMPTY;
       String aliasName=request.getParameter("account")+"";
       String CheckCode=request.getParameter("CheckCode");
       String openid=request.getParameter("openid");
       String fromType=request.getParameter("fromType");
       weiXinLoger.info("@action:identityauthor in parmes：【phoneNum="+phoneNum
       		+",aliasName="+aliasName+",CheckCode="+CheckCode
       		+",fromType="+fromType+",openid="+openid+"】");
       ResponseVO aliasNameResponse =null;
       long userid=0l;
       String  accounttype="1";
       Pattern pattern =  Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");
       Matcher matcher = pattern.matcher(aliasName);
       if (matcher.matches()){
    	   accounttype="3";
       }
       pattern = Pattern.compile("^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$");     
         matcher = pattern.matcher(aliasName);
       if (matcher.matches()){
    	   accounttype="2";
       }
       if(StringUtils.isBlank(aliasName)){
    	   return new ModelAndView("/account/find-password.ftl").addObject("userid", userid)
    	   .addObject(ERMSG, "用户名必须填写")
        		   .addObject("openid", openid)
        		   .addObject("fromType", fromType);
       }
       String validCode = (String) session.getAttribute(RandomValidateCode.RANDOMCODEKEY);
       LOGGER.debug("session中获取验证码：key={}, value={}", RandomValidateCode.RANDOMCODEKEY, validCode);
       session.removeAttribute(RandomValidateCode.RANDOMCODEKEY);
       if (StringUtils.isBlank(validCode)) {
           return new ModelAndView(FTL_FDPWD).addObject(ERMSG, "验证码已失效！").addObject("userid", userid).addObject("random", Math.random())
        		   .addObject("aliasName", aliasName)
        		   .addObject("openid", openid)
        		   .addObject("fromType", fromType);
       }   
       // 验证验证码
       if (!CheckCode.equalsIgnoreCase(validCode)) {
           return new ModelAndView(FTL_FDPWD).addObject(ERMSG, "验证码输入有误！").addObject("userid", userid).addObject("random", Math.random())
        		   .addObject("aliasName", aliasName)
        		   .addObject("openid", openid)
        		   .addObject("fromType", fromType);
       }
    	if(!StringUtils.isBlank(accounttype)){
    		 
    		if(accounttype.equals("1")){
    			aliasNameResponse= accountService.aliasNameIsUsed(aliasName, 1, 1);
        	}
			if(accounttype.equals("2")){
				aliasNameResponse= accountService.aliasNameIsUsed(aliasName, 2, 1); 		
			}
			if(accounttype.equals("3")){
				aliasNameResponse= accountService.aliasNameIsUsed(aliasName, 3, 1);
			}
    	}else{
    		return new ModelAndView(FTL_FDPWD).addObject(ERMSG, "用户不存在").addObject("userid", userid).addObject("random", Math.random())
           		   .addObject("openid", openid)
           		   .addObject("fromType", fromType);
    	}
    	if(101==aliasNameResponse.getRtnCode()){
    		 return new ModelAndView(FTL_FDPWD).addObject(ERMSG, "用户不存在").addObject("userid", userid).addObject("random", Math.random())
    				 .addObject("openid", openid)
             		   .addObject("fromType", fromType);
    	}
    	userid = aliasNameResponse.getUserId();
      if(userid<=0){
    	  return new ModelAndView(FTL_FDPWD).addObject(ERMSG, "用户不存在").addObject("userid", userid)
    			  .addObject("openid", openid).addObject("random", Math.random())
          		   .addObject("fromType", fromType);
      }
	  UserBaseInfoVO uvo=  userService.findBaseInfoByUserId(userid);
		if(uvo!=null){
			phoneNum=uvo.getMobile();
		  	  LOGGER.debug("通过userid获取手机号为"+phoneNum);  
	  	}else{
	  	   return new ModelAndView(FTL_FDPWD).addObject(ERMSG, "用户不存在").addObject("userid", userid).addObject("random", Math.random())
	  			 .addObject("openid", openid)
        		   .addObject("fromType", fromType);
	  	}
		if(StringUtils.isEmpty(phoneNum)){
		  	   return new ModelAndView("/account/author-failtrue.ftl").addObject("userid", userid).addObject("random", Math.random())
		  	   .addObject("openid", openid)
			   .addObject("fromType", fromType);
		}else{
			 return new ModelAndView("/account/user-author.ftl")
       	  	 .addObject( "phoneNum",phoneNum)
       	  	 .addObject("userid", userid)
       	  	 .addObject("openid", openid).addObject("userid", userid).addObject("random", Math.random())
       		 .addObject("fromType", fromType);
		}
    }
    
    @RequestMapping("/validateCodepassword")
    public ModelAndView validateCodepassword(HttpServletRequest request, HttpServletResponse response
    		,@RequestParam("phoneNum") String phoneNum,RedirectAttributes attributes){
    		writeLog(request);
    	   String temStyle =request.getParameter("temStyle");
    	   String captcha =request.getParameter("captcha");
    	   String openid=request.getParameter("openid");
           String fromType=request.getParameter("fromType");
           ResponseVO aliasNameResponse = accountService.aliasNameIsUsed(phoneNum, 2, 1);
           long userid = aliasNameResponse.getUserId();
//           aliasNameResponse= accountService.aliasNameIsUsed(phoneNum, 2, 1); 	
           weiXinLoger.info("validateCodepassword|userId|"+userid);
    	   int returncode=1;
    	   if(StringUtils.isBlank(captcha)){
    		   return new ModelAndView("/account/user-author.ftl").addObject(ERMSG, "验证码不能为空").addObject("userid", userid).addObject("phoneNum", phoneNum)
    				   .addObject("openid", openid).addObject("phoneNum", phoneNum)
    					 .addObject("fromType", fromType);
    	   }
    	   //if(captcha.equals("999999")){
    		   //returncode=1;
    	   //}else{
    	  returncode= validateService.toAuthCheckCode(userid, 1, captcha, phoneNum.trim(), Integer.parseInt(temStyle));
    	   //}
    	   //0,验证失败，1验证成功,2验证码失效
		  if(returncode!=1){
			  return new ModelAndView("/account/user-author.ftl").addObject(ERMSG, (returncode==0?"验证失败":(returncode==2?"验证码过期":""))).addObject("userid", userid).addObject("phoneNum", phoneNum)
					  .addObject("openid", openid).addObject("random", Math.random()).addObject("phoneNum", phoneNum)
						 .addObject("fromType", fromType);
		  }
		  return new ModelAndView("/account/pwd-reset.ftl").addObject("userid", userid).addObject("openid", openid).addObject("phoneNum", phoneNum)
					 .addObject("fromType", fromType).addObject("random", Math.random());
    }
    
    @RequestMapping("/pwdreset")
    public ModelAndView pwdreset(HttpServletRequest request,
    		HttpServletResponse response ){
		String openid = request.getParameter("openid");
		String fromType = request.getParameter("fromType");
		String securityTypestr = request.getParameter("securitytype");
		String phoneNum = request.getParameter("phoneNum");
		ResponseVO aliasNameResponse = accountService.aliasNameIsUsed(phoneNum , 2, 1);
		long userid = aliasNameResponse.getUserId();
		weiXinLoger.info("@action:pwdreset in parmes：【securityTypestr="
				+ securityTypestr + ",fromType=" + fromType + ",openid="
				+ openid + "】" + ",userid=" + userid);
    	int securityType=3;
    	int passStrong=0;
		if (!StringUtils.isBlank(securityTypestr)) {
			passStrong = Integer.parseInt(securityTypestr);
			if (passStrong == 0) {
				securityType = 3;
			} else if (passStrong == 1) {
				securityType = 2;
			} else if (passStrong == 2) {
				securityType = 1;
			} else {
				LOGGER.error(">>>>没有找到对应的securityType");
			}

		}
		String duplicate = request.getParameter("duplicate");
		String original = request.getParameter("original");

		if (StringUtils.isBlank(original) || StringUtils.isBlank(duplicate)) {
			return new ModelAndView("/account/pwd-reset.ftl")
					.addObject("userid", userid).addObject(ERMSG, "密码必须填写")
					.addObject("openid", openid)
					.addObject("random", Math.random())
					.addObject("fromType", fromType);
		}
		if (!duplicate.equals(original)) {
			return new ModelAndView("/account/pwd-reset.ftl")
					.addObject("userid", userid).addObject(ERMSG, "两次密码不一致")
					.addObject("openid", openid)
					.addObject("random", Math.random())
					.addObject("fromType", fromType);
		}

		ResponseVO rvo = findPassWordService.updatePasswd(userid, original,
				securityType);
		weiXinLoger.info("@action:pwdreset--method:updatePasswd out result：【ResponseVO=" + JSONObject.toJSON(rvo) + "】");
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		
		Cookie[] cookies = request.getCookies();
		for (Cookie s : cookies) {
			s.setMaxAge(1);
		}
		
		if (rvo.getRtnCode() == 100) {
			return new ModelAndView("/account/reset-successfull.ftl")
					.addObject("openid", openid)
					.addObject("random", Math.random())
					.addObject("fromType", fromType);

		} else {
			return new ModelAndView("/account/pwd-reset.ftl")
					.addObject("userid", userid).addObject(ERMSG, "修改失败,请重试")
					.addObject("openid", openid)
					.addObject("random", Math.random())
					.addObject("fromType", fromType);
		}
		
    }
    	/**
     * 功能描述: 验证会员登陆<br>
     * .
     * 
     * @param request the request
     * @param response the response
     * @param session the session
     * @param userBean the user bean
     * @param result the result
     * @return the model and view
     * @throws UnsupportedEncodingException the unsupported encoding exception
     * @see  AccountController#wxlogin(UserBean, BindingResult, HttpServletRequest)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/userLogin")
    @ResponseBody
    public ModelAndView userLogin(HttpServletRequest request, HttpServletResponse response,
            HttpSession session, @ModelAttribute @Valid UserBean userBean, BindingResult result
            ) throws UnsupportedEncodingException {
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
     	newuserRegisterLogger.info("\t"+ sdf.format(new Date())+"\t "+this.getIp(request)+" \t"+ request.getParameter("keyid") + "_login \t" 
      			 + "微信登录"  +"\t"+  request.getHeader("user-agent") + "\t" + 3 + "\t" + 13);
    	LOGGER.info("***************测试1：/userLogin");
    	String fromType=request.getParameter("fromType");
    	String token=request.getParameter("token");
    	String openid=request.getParameter("openid");
    	//String name=request.getParameter("userName");
    	
    	LOGGER.info("fromType : {} , token : {} , openid : {} ", fromType, token, openid);
    	
        // 获取登陆参数并验证
        String isSavePass = request.getParameter(SAVEPASS_OK_KEY);
        if ("on".equals(isSavePass)) {
            isSavePass = SAVEPASS_OK_VALUE;
        }
        // 验证
        accountService.validateUserLogin(userBean, result);
        if (result.hasErrors()) {
        	LOGGER.info("***************测试1：backurl : {} ", userBean.getBackUrl());
            return new ModelAndView(WXFTL_LOGIN).addObject(SAVEPASS_OK_KEY, isSavePass).addObject("fromType", fromType).addObject("token", token).addObject("openid", openid).addObject("backUrl", userBean.getBackUrl());
        }
        
        // 调用接口 验证用户登陆
        LoginInfo loginInfo = accountService.userLogin(APPID, userBean.getUserName(), userBean.getPassword(),
                SAVEPASS_OK_VALUE.equals(isSavePass), request, response);
        LOGGER.info("登陆返回信息： {}", gson.toJson(loginInfo));
        
		String uuid = getCookieUUid(request);
		loguserinfo("user----login", uuid, (loginInfo != null ? loginInfo.getUserId() + "" : ""), "");

		if (loginInfo != null && loginInfo.getRtnCode() == LOGIN_RET_CODEERROR) {
			weiXinLoger.error("cxg_userLogin_info:\t 微信服务号登录失败\t" + loginInfo.getUserId() + "\t" + openid + "\t" + getCookieUUid(request) + "\t" + "输入的用户名或密码不正确");
            return new ModelAndView(WXFTL_LOGIN).addObject(VALID_MESSAGE_KEY, "您输入的用户名或密码不正确！").addObject(
                    SAVEPASS_OK_KEY, isSavePass).addObject("fromType", fromType).addObject("token", token).addObject("openid", openid).addObject("backUrl", userBean.getBackUrl());
		} else if (loginInfo != null && loginInfo.getRtnCode() == LOGIN_RET_CODELIMIT) {
			weiXinLoger.error("cxg_userLogin_info:\t 微信服务号登录失败\t" + loginInfo.getUserId() + "\t" + openid + "\t" + getCookieUUid(request) + "\t" + "该账户登录出错次数已达上限");
            return new ModelAndView(WXFTL_LOGIN).addObject(VALID_MESSAGE_KEY, "该账户登录出错次数已达上限，请24小时后重试！").addObject(
                    SAVEPASS_OK_KEY, isSavePass).addObject("fromType", fromType).addObject("token", token).addObject("openid", openid).addObject("backUrl", userBean.getBackUrl());
        }
        //如果是微信入口
        if(StringUtils.isNotBlank(fromType) && StringUtils.isNotEmpty(fromType)&&"29".equals(fromType.trim())){
        	if(StringUtils.isNotEmpty(openid))
        	{
        	    
        		try {
        			 //boolean bool = preBoundingCheck(loginInfo.getUserId());
        		    String boundingOpenId = boundingService.getOpenIdByUserId(loginInfo.getUserId());
             	    //该userId已经绑定过了返回
             	    if(StringUtils.isNotBlank(boundingOpenId)){
             	       LOGGER.info("已经绑定过:openid:{}", openid);
             	        if(!boundingOpenId.equals(openid)) {
                 	    	weiXinLoger.error("cxg_userLogin_info:\t 微信服务号登录失败\t" + loginInfo.getUserId() + "\t" + openid + "\t" + getCookieUUid(request) + "\t" + "该账号已经绑定其他微信号");
                 	        return new ModelAndView(WXFTL_LOGIN).addObject(VALID_MESSAGE_KEY, "该账号已经绑定其他微信号，如需绑定，请取消绑定再绑定您的微信。谢谢！！！").addObject(
                                     SAVEPASS_OK_KEY, isSavePass).addObject("fromType", fromType).addObject("token", token).addObject("openid", openid).addObject("backUrl", userBean.getBackUrl());
             	        }
             	    } else {
             	        LOGGER.info("没有绑定过:openid:{}", openid);
             	        //没有绑定过
            			WebAccountVO wv=new WebAccountVO();
            			wv.setNumber(openid);
            			wv.setSource(29);
            			wv.setType(Constants.MDM_USER_SAIC_TYPE);
            			List<WebAccountVO>  wvs= accountService.findWebAccountByCondition(wv);
            			  
            		    if(wvs==null || wvs.size()<=0){
            				 boolean isS = accountService.addWinxinOpenIDAndUserIdReleation(loginInfo.getUserId(), openid);
        		        	 if(!isS){
        		        			//注销
        		        	        accountService.userLogout(NumberUtils.LONG_ZERO, request, response);
        		        	        return new ModelAndView("redirect:/account/wxlogin.htm?"+"fromType="+fromType+"&token="+token+"&errcode=2").addObject("backUrl", userBean.getBackUrl());
        		        		}else{
        		        			LOGGER.info("绑定成功 ，userid = " + loginInfo.getUserId());
        		        			String accessToken = ticketJob.getToken();
        		        			SendMessageUtil.sendTextMessage(openid, appId, appSecret, "恭喜您已成功绑定车享账号！！！",accessToken);
        		        		}
            			 }else{
            			     String accessToken = ticketJob.getToken();
            				 SendMessageUtil.sendTextMessage(openid, appId, appSecret, "您已是车享会员",accessToken);
            			 }
        			 
             	    }
        		} catch (Exception e) {
					LOGGER.error("addWinxinOpenIDAndUserIdReleation Error", e);
					accountService.userLogout(NumberUtils.LONG_ZERO, request, response);
					return new ModelAndView("redirect:/account/wxlogin.htm?"+"fromType="+fromType+"&token="+token+"&errcode=0"+"openid"+openid).addObject("backUrl", userBean.getBackUrl());
				}
        		//3,通知微信用户绑定成功
        	}
        }
        // 用户回调用url
        if (StringUtils.isBlank(userBean.getBackUrl())) {
            LOGGER.debug("跳转至：/account/loginSuccess.ftl");
            //跳转到成功页面，然后在转到 我的订单
           // return new ModelAndView("redirect:/member/orderlist.htm");
              return new ModelAndView("/account/loginSuccess.ftl").addObject("fromType", fromType);
        } else {
        	LOGGER.debug("跳转至userBean.getBackUrl()：redirect:"+userBean.getBackUrl());
        	String backUrl = userBean.getBackUrl();
        	if(!backUrl.contains("redirect:")){
        		backUrl = "redirect:" + URLDecoder.decode(backUrl, "UTF-8");
        	}else{
        		backUrl = URLDecoder.decode(backUrl, "UTF-8");
        	}
            LOGGER.debug("跳转至：{}", backUrl);
            String redirectUrl = backUrl;
            if(backUrl.endsWith(".ftl")){
            	redirectUrl = backUrl + "?openid=" + openid + "&userid=" + loginInfo.getUserId() + "&fromType=" + fromType;
            }/*else if(backUrl.endsWith("index.htm")){
            	redirectUrl = backUrl + "?userId=" + loginInfo.getUserId();
            }else if(backUrl.endsWith("/-1/1.htm")){
            	redirectUrl = backUrl.replace("-1", String.valueOf(loginInfo.getUserId()));
            }*/
            else{
            	redirectUrl = redirectHandler.buildBackUrl(backUrl, loginInfo.getUserId());
            }
            weiXinLoger.info("cxg_userLogin_info:\t 微信服务号登录成功\t" + loginInfo.getUserId() + "\t" + openid + "\t" + getCookieUUid(request) + "\t" + redirectUrl);
            

            newuserRegisterLogger.info("\t"+loginInfo.getUserId()  +"\t"+sdf.format(new Date())+"\t "+this.getIp(request)+" \t"+ request.getParameter("keyid") + "_login \t" 
         			 + "登录成功" +"\t"+ request.getHeader("user-agent") + "\t" + 3 + "\t" + 13);
            LOGGER.debug("redirectUrl:==="+redirectUrl);
            return new ModelAndView(redirectUrl).addObject("fromType", fromType)
            		.addObject(RequestConstants.OPEN_ID, openid)
            		.addObject(RequestConstants.USER_ID, loginInfo.getUserId());
        }
    }
    
    @RequestMapping("/user/login")
    @ResponseBody
    public ModelAndView userlogin(HttpServletRequest request, HttpServletResponse response,
            HttpSession session, @ModelAttribute @Valid UserBean userBean, BindingResult result
            ) throws UnsupportedEncodingException {
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // 获取登陆参数并验证
        String isSavePass = request.getParameter(SAVEPASS_OK_KEY);
        if ("on".equals(isSavePass)) {
            isSavePass = SAVEPASS_OK_VALUE;
        }
        // 验证
        accountService.validateUserLogin(userBean, result);
        if (result.hasErrors()) {
            return new ModelAndView(USER_LOGIN).addObject(SAVEPASS_OK_KEY, isSavePass).addObject("backUrl", userBean.getBackUrl());
        }
        
        // 调用接口 验证用户登陆
        LoginInfo loginInfo = accountService.userLogin(APPID, userBean.getUserName(), userBean.getPassword(),
                SAVEPASS_OK_VALUE.equals(isSavePass), request, response);
        LOGGER.debug("登陆返回信息： {}", gson.toJson(loginInfo));
        
		String uuid = getCookieUUid(request);
		loguserinfo("user----login", uuid, (loginInfo != null ? loginInfo.getUserId() + "" : ""), "");

		if (loginInfo != null && loginInfo.getRtnCode() == LOGIN_RET_CODEERROR) {
            return new ModelAndView(USER_LOGIN).addObject(VALID_MESSAGE_KEY, "您输入的用户名或密码不正确！").addObject("backUrl", userBean.getBackUrl());
		} else if (loginInfo != null && loginInfo.getRtnCode() == LOGIN_RET_CODELIMIT) {
            return new ModelAndView(USER_LOGIN).addObject(VALID_MESSAGE_KEY, "该账户登录出错次数已达上限，请24小时后重试！")
            		.addObject(SAVEPASS_OK_KEY, isSavePass).addObject("backUrl", userBean.getBackUrl());
        }
        // 用户回调用url
        if (StringUtils.isBlank(userBean.getBackUrl())) {
            LOGGER.debug("跳转至：/account/loginSuccess.ftl");
            //跳转到成功页面，然后在转到 我的订单
              return new ModelAndView("/account/loginSuccess.ftl");
        } else {
        	LOGGER.debug("跳转至userBean.getBackUrl()：redirect:"+userBean.getBackUrl());
        	String backUrl = userBean.getBackUrl();
        	if(!backUrl.contains("redirect:")){
        		backUrl = "redirect:" + URLDecoder.decode(backUrl, "UTF-8");
        	}else{
        		backUrl = URLDecoder.decode(backUrl, "UTF-8");
        	}
            newuserRegisterLogger.info("\t"+loginInfo.getUserId()  +"\t"+sdf.format(new Date())+"\t "+this.getIp(request)+" \t"+ request.getParameter("keyid") + "_login \t" 
         			 + "登录成功" +"\t"+ request.getHeader("user-agent") + "\t" + 3 + "\t" + 13);
            LOGGER.debug("跳转至：{}" , backUrl);
            //如果是正式环境，则不需要userid
            if(request.getRequestURL().toString().contains(Constants.DOMAIN)){
       			return new ModelAndView(backUrl);
            }
            return new ModelAndView(backUrl).addObject(RequestConstants.USER_ID, loginInfo.getUserId());
        }
    }
    
    /**
     * 绑定预check，确定该userId是否绑定过其他的微信
     * 
     * 
     * 功能描述: <br>
     * 〈功能详细描述〉
     *
     * @param userId
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private boolean preBoundingCheck(Long userId){
        WebAccountVO webAccountVO = new WebAccountVO();
        webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE
               );
        webAccountVO.setUserId(userId);
        webAccountVO.setStatus(1);
        // 车享购微信来源
        webAccountVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));
        List<WebAccountVO> accountByCondition = this.webAccountService
                .findWebAccountByCondition(webAccountVO);
        LOGGER.info("AccountController =》 preBoundingCheck 根据用户 id : {}, 返回", userId,JSONObject.toJSONString(accountByCondition));
        
        //多条提示失败
        if(accountByCondition != null && accountByCondition.size() > 0){
            for(WebAccountVO accountVO : accountByCondition){
                //因彭瑶提供的接口未过滤source=29
                if(accountVO.getSource() != null && Constants.MDM_USER_SAIC_SOURCE.equals(String.valueOf(accountVO.getSource()))){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * 功能描述: 获取验证码<br>
     * .
     * 
     * @param request the request
     * @param response the response
     * @param session the session
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/validateCode")
    public void validateCode(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        System.setProperty("java.awt.headless", "true");
        
        // 设置相应类型,告诉浏览器输出的内容为图片
        response.setContentType("image/jpeg");
        // 设置响应头信息，告诉浏览器不要缓存此内容
        response.setHeader("Pragma", "No-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expire", 0);
        
        RandomValidateCode validateCode = new RandomValidateCode();
        BufferedImage image = validateCode.getValidateImage();
        
        // 将生成的code放入redis, 并设置VALIDCODE_EXPIRE秒过期
        session.setAttribute(RandomValidateCode.RANDOMCODEKEY, validateCode.getCodeString());
        LOGGER.debug("session中设置验证码：key={}, value={}", RandomValidateCode.RANDOMCODEKEY, validateCode.getCodeString());

        try {
            ImageIO.write(image, "JPEG", response.getOutputStream());
            System.setProperty("java.awt.headless", "true");
        } catch (IOException e) {
            LOGGER.error("validateCode image transmission was error !", e);
        }
    }

    /**
     * 功能描述: 用户注册<br>
     * .
     *
     * @param userBean the user bean
     * @param result the result
     * @param request the request
     * @return the model and view
     * @throws UnsupportedEncodingException the unsupported encoding exception
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/register")
    public ModelAndView register(HttpServletResponse response,HttpServletRequest request,Model model) throws UnsupportedEncodingException {
		String token = request.getParameter("token");
		String fromType = request.getParameter("fromType");
		String openid = request.getParameter("openid");
	    if(StringUtils.isNotBlank(fromType) && StringUtils.isNotEmpty(fromType) && Constants.MDM_USER_SAIC_SOURCE.equals(fromType.trim())){
			try {
				if (StringUtils.isBlank(openid) || "null".equals(openid)) {
					openid = idTokenUtil.getOpenIdToken(token);
				}
				LOGGER.info("获取openid" + openid);
				if (!StringUtils.isBlank(openid) && !"null".equals(openid)) {
					LOGGER.info("进入openid为有的状态");
					model.addAttribute("openid", openid);
					model.addAttribute("token", token);
					model.addAttribute("fromType", fromType);
					return new ModelAndView("/account/mobile-regist.ftl");

				} else {
					LOGGER.info("进入openid为无的状态");
					return new ModelAndView("/account/errortip.ftl");
				}

			} catch (Exception e) {
				LOGGER.error("exchangeOpenId Error", e);
				return new ModelAndView("/account/errortip.ftl");
			}
		} else {
			return new ModelAndView("/account/mobile-regist.ftl");
		}
    }
    
    /**
     * 功能描述: 微信用户注册<br>
     * .
     *
     * @param userBean the user bean
     * @param result the result
     * @param request the request
     * @return the model and view
     * @throws UnsupportedEncodingException the unsupported encoding exception
     * @see  	ValidatePhoneController#wxToCheckPhoneAndCodeRegister(com.saic.ebiz.market.common.entity.user.BasicPersonalInfoBean, BindingResult, HttpServletRequest, HttpServletResponse, Model, RedirectAttributes)
     * 			参考 {@link AccountController#wxlogin(UserBean, BindingResult, HttpServletRequest)}
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/wxregister")
    public ModelAndView wxregister(HttpServletResponse response,HttpServletRequest request,Model model) throws UnsupportedEncodingException {
		
   
    	String token = request.getParameter("token");
		String fromType = request.getParameter("fromType");
		String backUrl = request.getParameter("backUrl");
		String openid = request.getParameter("openid");
		weiXinLoger.info("wxregister==>|begin");
    	writeLog(request);
    	LOGGER.debug("backUrl : {} , fromType : {} , token : {} , openid : {}", backUrl, fromType, token, openid);
		try {
			if (!com.mysql.jdbc.StringUtils.isEmptyOrWhitespaceOnly(token)) {
				String	openId = idTokenUtil.getOpenIdToken(token);
				if(com.mysql.jdbc.StringUtils.isNullOrEmpty(openId)||"null".equalsIgnoreCase(openId)){
					return new ModelAndView("/account/errortip.ftl");
				}
			}
		} catch (Exception e1) {
		}
		if (com.mysql.jdbc.StringUtils.isEmptyOrWhitespaceOnly(openid)&&!com.mysql.jdbc.StringUtils.isEmptyOrWhitespaceOnly(token)){
			try {
				openid = idTokenUtil.getOpenIdToken(token);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
    	if(StringUtils.isNotBlank(fromType)&&StringUtils.isNotEmpty(fromType)&& Constants.MDM_USER_SAIC_SOURCE.equals(fromType.trim())){
    		try {
    			LOGGER.info("获取openid");
    			if(StringUtils.isBlank(openid)||"null".equals(openid)){
    				openid = this.idTokenUtil.getOpenIdToken(token);
    			}
    			LOGGER.info("获取openid"+openid);
    			
    			if(!StringUtils.isBlank(openid)&& !"null".equals(openid)){
    				LOGGER.info("进入openid为有的状态");
    				model.addAttribute("openid", openid);
    				model.addAttribute("token", token);
    				model.addAttribute("fromType", fromType);
    			
    				WebAccountVO webAccountVO = new WebAccountVO();
    				webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE);
    				webAccountVO.setNumber(openid);
					List<WebAccountVO> accountByCondition = this.webAccountService.findWebAccountByCondition(webAccountVO);
					boolean isBounding = false;
					if (null != accountByCondition && accountByCondition.size() > 0) {
						isBounding = true;
					}
					if (isBounding){
						return new ModelAndView("/account/wxbindingSuccess.ftl").addObject("operateType", "4");
					}
    				
    			return new ModelAndView("/account/wxmobile-regist.ftl").addObject("backUrl", backUrl).addObject("openid",openid).addObject("keyid",request.getParameter("keyid"));
    				
    			}else{
    				LOGGER.info("进入openid为无的状态");
    				return new ModelAndView("/account/errortip.ftl");
    			}
    			
    		} catch (Exception e) {
    			LOGGER.error("exchangeOpenId Error",  e);
    			return new ModelAndView("/account/errortip.ftl");
    		}
    	}else{
    		return new ModelAndView("/account/wxmobile-regist.ftl").addObject("backUrl", backUrl).addObject("openid",openid);
    	}
    }

    /**
     * 功能描述: 验证用户注册<br>
     * .
     * 
     * @param userBean the user beanO
     * @param result the result
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the model and view
     * @throws UnsupportedEncodingException the unsupported encoding exception
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/userRegister")
    public ModelAndView userRegister(@ModelAttribute @Valid UserBean userBean, BindingResult result,
            HttpServletRequest request, HttpServletResponse response, HttpSession session)
            throws UnsupportedEncodingException {
        //String openid=request.getParameter("openid");
        String registUrl = "/account/wap-register.ftl";
        
        // 验证
        accountService.validateUserRegister(userBean, result);
        if (result.hasErrors()) {
            return new ModelAndView(registUrl);
        }
        
        // 注册用户名长度6-20
        if (userBean.getUserName().trim().length() < USERNAME_LENTH_MIN
                || userBean.getUserName().trim().length() > USERNAME_LENTH_MAX) {
            return new ModelAndView(registUrl).addObject(NAME_MESSAGE_KEY, "用户名为6-20位字符,为英文或英数混合");
        }
        
        // 注册用户名不能为全数字
        if (RegexUtil.check(RegexUtil.REGEX_NUM, userBean.getUserName().trim())) {
            return new ModelAndView(registUrl).addObject(NAME_MESSAGE_KEY, "用户名不能全为数字");
        }
        
        // 注册用户名只能为英文或数字
        if (!RegexUtil.check(RegexUtil.REGEX_EN_NUM, userBean.getUserName().trim())) {
            return new ModelAndView(registUrl).addObject(NAME_MESSAGE_KEY, "用户名为英文或英数混合");
        }
        
        // 获取验证码
        String validCode = (String) session.getAttribute(RandomValidateCode.RANDOMCODEKEY);
        LOGGER.debug("session中获取验证码：key={}, value={}", RandomValidateCode.RANDOMCODEKEY, validCode);
        session.removeAttribute(RandomValidateCode.RANDOMCODEKEY);
        if (StringUtils.isBlank(validCode)) {
            return new ModelAndView(registUrl).addObject("codeMessage", "验证码已失效！");
        }
        
        // 验证验证码
        if (!userBean.getCheckCode().equalsIgnoreCase(validCode)) {
            return new ModelAndView(registUrl).addObject("codeMessage", "验证码错误！");
        }

        // release
        ResponseVO aliasNameResponse = accountService.aliasNameIsUsed(userBean.getUserName(), ALIAS_TYPE, APPID);
        if (null == aliasNameResponse || aliasNameResponse.getRtnCode() == LOGIN_RET_CODEEXISTS) {
            return new ModelAndView(registUrl).addObject(NAME_MESSAGE_KEY, "用户名已存在！");
        }

        ResponseVO registerResponse = accountService.userRegister(
                userBean.getUserName(), userBean.getPassword(), ALIAS_TYPE, APPID, CREATE_TYPE, SECURITY_TYPE);

        if (null == registerResponse || registerResponse.getRtnCode() == LOGIN_RET_CODEERROR) {
            return new ModelAndView(registUrl).addObject(NAME_MESSAGE_KEY, "注册失败！");
        }
        
        // 注册后用户直接登陆
        LoginInfo loginInfo = accountService.userLogin(APPID, userBean.getUserName(), userBean.getPassword(),
                false, request, response);
        LOGGER.debug("登陆返回信息： {}", gson.toJson(loginInfo));
        
        
        String url = StringUtils.EMPTY;
        if (StringUtils.isBlank(userBean.getBackUrl())) {
            url = "redirect:/account/validPhone.htm";
        } else {
            userBean.setBackUrl(URLEncoder.encode(userBean.getBackUrl(), StandardCharsets.UTF_8.toString()));
            url = "redirect:/account/validPhone.htm?backUrl=" + userBean.getBackUrl();
        }
        
        return new ModelAndView(url);
    }
    
    private void loguserinfo(String prefix,String cookie_uuid,String userId,String userType){
    	try{
    		newuserRegisterLogger.info(prefix+":"+"\t"+cookie_uuid+"\t"+(userId==null?"":userId)+"\t"+(userType==null?"":userType));
    	}catch(Exception e){
    		LOGGER.error("write-newuserRegisterLogger-error", e);
    	}
    }
    private String getCookieUUid(HttpServletRequest request){
    	Cookie[] cookies = request.getCookies();
        String userTraceCookie = "";
        for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if ("user_trace_cookie".equals(name)) {
				userTraceCookie = cookie.getValue();
				break;
			}
		}
        return userTraceCookie;
    }
    
    private  void  writeLog(HttpServletRequest request){
    	@SuppressWarnings("unchecked")
		Enumeration<String> parameterNames = request.getParameterNames();
    	while (parameterNames.hasMoreElements()) {
    		String pa=parameterNames.nextElement();
			weiXinLoger.info("parameterNames==>|" + pa + "|==>"
					+ request.getParameter(pa));
		}
    }
    
	/*********
	 * 跳转网络测试URL
	 * 
	 * @param token
	 * @return
	 */
	@RequestMapping("/network")
	public ModelAndView toNetWork(String token) { 
		 
		String exandsUrl =ConfigUtil.getProperties().getProperty("exandsUrl");
		weiXinLoger.info("network|token|" + token+"|exandsUrl|"+exandsUrl);
		WebAccountVO arg0 = new WebAccountVO();
		Object type = "0";
		String openId="openId";
		String mobile="";
		try {
			openId = idTokenUtil.getOpenIdToken(token);
		} catch (Exception e) {
			e.printStackTrace();
			openId="openId";
		}
		arg0.setNumber(openId==null?"openId":openId);
		arg0.setType(Constants.MDM_USER_SAIC_TYPE);
		List<WebAccountVO> accountByCondition = webAccountService.findWebAccountByCondition(arg0);
		if (accountByCondition != null && accountByCondition.size() > 0) {
			WebAccountVO webAccountVO = accountByCondition.get(0);
			Long userId = webAccountVO.getUserId();
			weiXinLoger.info("network|userId|" + userId);
			UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(userId);
			weiXinLoger.info("network|userBaseInfoVO|" + JSON.toJSONString(userBaseInfoVO));
			if (userBaseInfoVO!=null&&11 == userBaseInfoVO.getType()) {
				type = "1";
				mobile=userBaseInfoVO.getMobile();
			}else {
				type="3";
			}
		}else{
			type="2";
		}

		return new ModelAndView("/account/wap-network.ftl").addObject("type", type).addObject("openId", openId).addObject("mobile", mobile).addObject("token", token).addObject("exandsUrl", exandsUrl);
	}
	
	
	/********
	 * 
	 * @return
	 */
	@RequestMapping("/networkSuccess")
	public ModelAndView networkSuccess(HttpServletRequest request){
		
		String token = request.getParameter("token");
		String openId="openId";
		try {
			openId = idTokenUtil.getOpenIdToken(token);
		} catch (Exception e) {
			e.printStackTrace();
			openId="openId";
		}
		 
		BufferedReader in = null;
		String result="";
		StringBuffer buffer = new StringBuffer();
		try {
			URL url = new URL("http://exands.com:38000/u/?AN="+openId);
			URLConnection conn = url.openConnection();
			conn.connect();
 
			in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				buffer.append(line);
			} 
			result = buffer.toString();
			weiXinLoger.info("networkSuccess|openId|"+openId+"|result|"+result);
		} catch (Exception e) {
			weiXinLoger.info("networkSuccess|openId|"+openId+"|Exception|"+e.getLocalizedMessage());
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		String status="-1";
		try {
			if (!com.mysql.jdbc.StringUtils.isEmptyOrWhitespaceOnly(result)){
				JSONObject parseObject = JSON.parseObject(result);
				if (parseObject!=null){
					status   = parseObject.getString("status");
				}
			}
			
		} catch (Exception e) {
//			e.printStackTrace();
		}
		weiXinLoger.info("networkSuccess|openId|"+openId+"|status|"+status);
		return new ModelAndView("/account/wap-networkSuccess.ftl").addObject("status", status);
	}
	/********
	 * 
	 * @return
	 */
	@RequestMapping("/networkStatus")
	public ModelAndView network(HttpServletRequest request){
		String status = request.getParameter("status");
		status=com.mysql.jdbc.StringUtils.isEmptyOrWhitespaceOnly(status)?"-1":status;
		weiXinLoger.info("networkSuccess|status|"+status);
		return new ModelAndView("/account/wap-networkSuccess.ftl").addObject("status", status);
	}
	
	/**
	 * 获取客户端ip
	 * 
	 * @param request
	 * @return
	 */
	public String getIp(HttpServletRequest request) {
		weiXinLoger.info("获取客户端ip地址");
		String ip = null;
		try {
			ip = request.getHeader("x-forwarded-for");
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
			weiXinLoger.info("客户端ip地址为：" + ip);
			return ip;
		} catch (Exception e) {
			e.printStackTrace();
			weiXinLoger.info("发生异常ip地址获取失败");
			return null;
		}

	}
}
