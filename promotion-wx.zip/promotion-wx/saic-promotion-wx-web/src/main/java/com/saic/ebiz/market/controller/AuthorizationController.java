/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.meidusa.fastjson.JSONObject;
import com.meidusa.venus.validate.util.URLUtil;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.entity.authentication.Oauth2Token;
import com.saic.ebiz.market.common.entity.authentication.SNSUserInfo;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.util.SHA1Util;
import com.saic.ebiz.market.event.AuthorizationHandler;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.mdm.entity.WebAccountVO;

/**
 * @author hejian
 * 
 */
@RestController
public class AuthorizationController {

	private static final String INDEX = "/index.htm";

	protected static final String INDEX_FTL = "/index.ftl";

	/** 登录模板路径. */
	static final String WXFTL_LOGIN = "/account/wxwap-login.ftl";
	
	private static final String WXLOGIN = "redirect:/account/wxlogin.htm";
	
	private static final String GAME_URL = "redirect:http://cx.sinotio2.com/mauthcallback?";

	private Logger log = LoggerFactory.getLogger(getClass());

	@Resource
	private AuthorizationService authorizationService;

	@Resource
	private BoundingService boundingService;
	
	@Resource
	private AuthorizationHandler authorizationHandler;

	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.domain:}")
	private String domain;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
	
	/**
	 * 微信授权的回调地址
	 * @param request
	 * @return
	 */
	@RequestMapping("/oauth")
	public ModelAndView oauth(HttpServletRequest request) {
		ModelAndView model = new ModelAndView("");
		log.info("返回的参数 : " + JSONObject.toJSONString(request.getParameterMap()));
		String code = request.getParameter("code");
		String state = request.getParameter("state");
		String backUrl = INDEX;
		
		if(StringUtils.isBlank(state)){
			throw new BaseException("微信未返回state参数。。。");
		}
		
		log.info("授权返回代码 code : {}, state : {} ", code, state);
		Oauth2Token oauth2Token = authorizationService.getOauth2Token(appId, appSecret, code);
		log.info("返回Oauth2Token : " + JSONObject.toJSONString(oauth2Token));
		String openId = oauth2Token.getOpenId();
		
		log.info("AuthorizationController => openId : " + openId);
		//如果state是等号结尾，说明需要跳转到支付页面
		String redirectUri="";
		if(state.endsWith("==")){
			try {
				//和支付约定base64加密后加==，现在这里需要去除==
				redirectUri = state.substring(0, state.length() - 2);
				redirectUri = new String(Base64.decodeBase64(redirectUri),"UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new BaseException(e);
			}
			if(redirectUri.contains("?")){
				redirectUri = "redirect:" + redirectUri + "&from=mgo.chexiang.com_oauth&openId=" + openId;
			}else{
				redirectUri = "redirect:" + redirectUri + "?from=mgo.chexiang.com_oauth&openId=" + openId;
			}
			model = new ModelAndView(redirectUri);
			log.info("支付跳转URL ====>>>>> " + redirectUri);
			return model;
		}
		
		if(StringUtils.isNotBlank(state)){
			backUrl = authorizationHandler.buildBackUrl(request);
		}
		
		List<WebAccountVO> accounts = boundingService.checkBounding(openId);
		boolean isBounding = (accounts != null && accounts.size() > 0);
		// 未绑定则跳到登录页，进行绑定
		if (!isBounding) {
			log.info("openId {" + openId + "} is not bounded... 跳转登录页面");
			model = new ModelAndView(WXLOGIN + "?"+"fromType=" + Constants.MDM_USER_SAIC_SOURCE + "&openid=" + openId + "&backUrl=" + backUrl);
			return model;
		}else{
			Long userId = accounts.get(0).getUserId();
			model = authorizationHandler.buildView(request,backUrl,openId,userId);
			log.info("对应关系  openId {} <----> userId {}", openId, userId);
		}
		log.info("授权返回页面" + model.getViewName());
		return model;
	}
	
	/**
	 * 微信授权的回调地址
	 * @param request
	 * @return
	 */
	@RequestMapping("/oauthNoLogin")
	public ModelAndView oauthNoLogin(HttpServletRequest request) {
		ModelAndView model = new ModelAndView("");
		log.info("AuthorizationController--oauthNoLogin--返回的参数 : " + JSONObject.toJSONString(request.getParameterMap()));
		String code = request.getParameter("code");
		String state = request.getParameter("state");
		String backUrl = INDEX;
		
		if(StringUtils.isBlank(state)){
			throw new BaseException("AuthorizationController--oauthNoLogin--微信未返回state参数。。。");
		}
		
		if(StringUtils.isNotBlank(state)){
			backUrl = authorizationHandler.buildBackUrl(request);
		}
		
		log.info("AuthorizationController--oauthNoLogin--授权返回代码 code : {}, state : {} ", code, state);
		Oauth2Token oauth2Token = authorizationService.getOauth2Token(appId, appSecret, code);
		log.info("AuthorizationController--oauthNoLogin--返回Oauth2Token : " + JSONObject.toJSONString(oauth2Token));
		String openId = oauth2Token.getOpenId();

		log.info("AuthorizationController--oauthNoLogin--AuthorizationController => openId : " + openId);
		List<WebAccountVO> accounts = boundingService.checkBounding(openId);
		Long userId =0l;
		if(null!=accounts && accounts.size() > 0){
			userId = accounts.get(0).getUserId();
		}
		model = authorizationHandler.buildView(request,backUrl,openId,userId);
		log.info("AuthorizationController--oauthNoLogin--对应关系  openId {} <----> userId {}", openId, userId);
		
		log.info("AuthorizationController--oauthNoLogin--授权返回页面" + model.getViewName());
		return model;
	}
	
	@RequestMapping("/oauth/sns")
	public ModelAndView oauthSns(HttpServletRequest request) {
		ModelAndView model = new ModelAndView("");
		log.info("返回的参数 : " + JSONObject.toJSONString(request.getParameterMap()));
		String code = request.getParameter("code");
		String state = request.getParameter("state");
		String backUrl = INDEX;
		
		if(StringUtils.isBlank(state)){
			throw new BaseException("微信未返回state参数。。。");
		}
		
		if(StringUtils.isNotBlank(state)){
			backUrl = authorizationHandler.buildBackUrl(request);
		}
		
		log.info("授权返回代码 code : {}, state : {} ", code, state);
		Oauth2Token oauth2Token = authorizationService.getOauth2Token(appId, appSecret, code);
		log.info("返回Oauth2Token : " + JSONObject.toJSONString(oauth2Token));
		String openId = oauth2Token.getOpenId();
		log.info("AuthorizationController => openId : " + openId);
		SNSUserInfo snsUserInfo = this.authorizationService.getUserInfo(oauth2Token.getAccessToken(), oauth2Token.getOpenId());
		log.info("微信User Info授权 SNSUserInfo : " + JSONObject.toJSONString(snsUserInfo));
		List<WebAccountVO> accounts = boundingService.checkBounding(openId);
		//2015绣球328授权转发
		if(state.startsWith(Authorization.moucheng_.name())){
			String userNickName = snsUserInfo.getNickname();
			String userHeadImg = snsUserInfo.getHeadimgurl();
			long time = new Date().getTime();
			StringBuilder builder = new StringBuilder("openId=");
			builder.append(openId).append("&userNickName=")
			.append(Base64.encodeBase64String(userNickName.getBytes())).append("&userHeadImg=")
			.append(userHeadImg).append("&state=")
			.append(state).append("&time=")
			.append(time);
			String sign = new SHA1Util().getDigestOfString(builder.toString().getBytes());
			builder.append("&sign=").append(sign);
			String url = GAME_URL + builder.toString();
			log.info("游戏授权回调URL ： " + url);
			return new ModelAndView(url);
		}
		//
		boolean isBounding = (accounts != null && accounts.size() > 0);
		// 未绑定则跳到登录页，进行绑定
		if (!isBounding) {
			log.info("openId {" + openId + "} is not bounded... 跳转登录页面");
			model = new ModelAndView(WXLOGIN + "?"+"fromType=" + Constants.MDM_USER_SAIC_SOURCE + "&openid=" + openId + "&backUrl=" + backUrl);
			return model;
		}else{
			Long userId = accounts.get(0).getUserId();
			model = authorizationHandler.buildView(request,backUrl,openId,userId);
			log.info("对应关系  openId {} <----> userId {}", openId, userId);
		}
		log.info("授权返回页面" + model.getViewName());
		return model;
	}
	
	@RequestMapping("/oauth/sns/redirect")
	public ModelAndView oauthSnsRedirect(HttpServletRequest request) {
		ModelAndView model = new ModelAndView("/error/errorMsg.ftl");
		log.info("返回的参数  : " + JSONObject.toJSONString(request.getParameterMap()));
		String code = request.getParameter("code");
		String state = request.getParameter("state");
		if(!StringUtils.isBlank(state)){
			String url = "";
			//防止state参数明文传递，base64加密方式传递
			try {
				url = new String(Base64.decodeBase64(state),"UTF-8");
			} catch (UnsupportedEncodingException e) {
				url = new String(Base64.decodeBase64(state));
			}
			//判断是不是有效的URL
			if(URLUtil.verifyUrl(url)){
				log.info("授权返回代码 code : {}, state : {} ", code, state);
				Oauth2Token oauth2Token = authorizationService.getOauth2Token(appId, appSecret, code);
				log.info("返回Oauth2Token : " + JSONObject.toJSONString(oauth2Token));
				String openId = oauth2Token.getOpenId();
				log.info("AuthorizationController => openId : " + openId);
				SNSUserInfo snsUserInfo = this.authorizationService.getUserInfo(oauth2Token.getAccessToken(), oauth2Token.getOpenId());
				log.info("微信User Info授权 SNSUserInfo : " + JSONObject.toJSONString(snsUserInfo));
				String userNickName = snsUserInfo.getNickname();
				String userHeadImg = snsUserInfo.getHeadimgurl();
				long time = new Date().getTime();
				StringBuilder builder = new StringBuilder("openId=");
				builder.append(Base64.encodeBase64String(openId.getBytes())).append("&userNickName=")
				.append(Base64.encodeBase64String(userNickName.getBytes())).append("&userHeadImg=")
				.append(userHeadImg).append("&state=").append(state).append("&time=").append(time);
				String sign = new SHA1Util().getDigestOfString(builder.toString().getBytes());
				builder.append("&sign=").append(sign);
				if(url != null && url.contains("?")){
					url = "redirect:" + url + "&" + builder.toString();
				}else{
					url = "redirect:" + url + "?" + builder.toString();
				}
				log.info("回调URL ： " + url);
				return new ModelAndView(url);
			}
		}	
		
		model.addObject("modelName", "哎呀，你访问的页面走丢了...");
		model.addObject("errorMessage", "");
		log.info("授权返回页面" + model.getViewName());
		return model;
	}
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		String encodeString = URLEncoder.encode("何剑","UTF-8");
		System.out.println("encode : " + encodeString);
		System.out.println("decode : " + URLDecoder.decode(encodeString, "UTF-8"));
		encodeString = Base64.encodeBase64String("何剑".getBytes());
		System.out.println(encodeString);
		System.out.println(new String(Base64.decodeBase64(encodeString),"UTF-8"));
		
		String str = "aHR0cDovL3BtZi5jaGV4aWFuZy5jb20vdGVzdC9hdXRoLmh0bQ====";
		str = str.substring(0, str.length() - 2);
		System.out.println(new String(Base64.decodeBase64(str),"UTF-8"));
		
		System.out.println(URLUtil.verifyUrl("http://www.baidu.com"));
	}
}
