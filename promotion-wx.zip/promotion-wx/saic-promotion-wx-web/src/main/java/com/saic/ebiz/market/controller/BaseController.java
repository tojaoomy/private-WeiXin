package com.saic.ebiz.market.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.util.CommonUtil;

public class BaseController {

    /** 红包活动code */
    protected static final String PRAIS_ACTIVE_CODE = "PRAISE_20160808";
    
	/* 日志 */
	private final Logger logger = LoggerFactory.getLogger(BaseController.class);

	/**
	 * sit mgo.sit.chexiang.com pre mgo.pre.chexiang.com pro mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.domain:}")
	protected String domain;
	
	@Value("${ebiz.mcar.web.mcarBase:}")
	protected String mcarBase;

	/**
	 * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	protected String appId;

	@Value("${ebiz.wap.web.appSecret:}")
	protected String appSecret;

	/**
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	protected String redirectHost;

	// 微信JSAPI授权
	@Autowired
	protected JsSDKSign jsSDKSign;
	
	   // TODO : 带定义完善 静态非微信打开友好页
    protected static final String WX_STATIC_URL = "resources/baba/two-dimension-code.html";

	@RequestMapping(value = "wxconfig", method = RequestMethod.POST)
	@ResponseBody
	public JSONObject getWxUrlSign(
			HttpServletRequest request,
			@RequestParam(value = "absolute_url", required = true) String absolute_url) {
		if (absolute_url != null) {
			String url = domain + CommonUtil.decodeURL(absolute_url);
			logger.info("base>>wx_config_url="+url);
			// *. 微信分享JSSDK分享
			Map<String, String> jssdk = jsSDKSign.sign(appId, url);
			String strjson = JSONObject.toJSONString(jssdk);
			return JSONObject.parseObject(strjson);

		} else {
			return null;
		}
	}

}
