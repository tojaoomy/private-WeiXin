/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.web.gson.GsonView;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.entity.BrandVO;
import com.saic.ebiz.market.entity.RoutineCarVO;
import com.saic.ebiz.market.entity.SeriesVO;
import com.saic.ebiz.market.service.BrandService;
import com.saic.ebiz.market.service.RoutineCarService;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;

/**
 * @author hejian
 *
 */
@RestController
public class BrandSeriesController {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private static final String BRAND_FTL = "/wxsales/car_brands.ftl";
	
	private static final String SERIES_FTL = "/wxsales/car_series.ftl";
	
	private static final String SERIES_MODEL_FTL = "/wxsales/car_series_model.ftl";

	private static final int PAGE_SIZE = 10;
	
	@Resource
	private BrandService brandService;
	
	@Resource
	private RoutineCarService routineCarService;
	
	/**
	 * 根据城市id，获取当前活动下的品牌
	 * 如果未传入cityId，默认上海(310100)
	 * @param cityId 城市id
	 * @return jsonView
	 */
	@RequestMapping(value="/brand",method=RequestMethod.GET)
	public GsonView getAvailableBrandsByMarketType(@RequestParam(value="cityId",defaultValue="310100") Long cityId){
		logger.info("BrandSeriesController => getAvailableBrandsByMarketType ###### cityId : " + cityId);
		GsonView gson = new GsonView();
		List<BrandVO> brands = brandService.getBrandsByMarketType(MarketType.ROUTINE.code(), cityId);
		logger.info("调用 brandService.getAvailableBrandsByMarketType返回 ： " + JSONObject.toJSONString(brands));
		gson.addStaticAttribute("brands", brands);
		return gson;
	}
	
	/**
	 * 根据城市id，获取当前活动下的品牌
	 * 如果未传入cityId，默认上海(310100)
	 * @param cityId 城市id
	 * @return jsonView
	 */
	@RequestMapping(value="/brand/{cityId}",method=RequestMethod.GET)
	public ModelAndView getAllBrandsByMarketType(@PathVariable(value="cityId") Long cityId){
		logger.info("BrandSeriesController => getAllBrandsByMarketType ###### cityId : " + cityId);
		ModelAndView model = new ModelAndView(BRAND_FTL);
		List<BrandVO> brands = brandService.getBrandsByMarketType(MarketType.ROUTINE.code(), cityId);
		logger.info("调用 brandService.getAllBrandsByMarketType返回 ： " + JSONObject.toJSONString(brands));
		model.addObject("brands", brands);
		return model;
	}
	
	/**
	 * 根据城市和品牌刷选车系
	 * @param cityId 城市id
	 * @param brandId 品牌id
	 * @return
	 */
	@RequestMapping(value="/series",method=RequestMethod.GET)
	public GsonView getAvailableSeriesByMarketType(@RequestParam(value="cityId",required=true) Long cityId,
			@RequestParam(value="brandId",required=true) Long brandId){
		logger.info("BrandSeriesController => getAvailableSeriesByMarketType ###### cityId : {},brandId : {} ", cityId, brandId);
		GsonView gson = new GsonView();
		List<SeriesVO> series = brandService.getSeriesByMarketType(MarketType.ROUTINE.code(), cityId, brandId);
		logger.info("调用 brandService.getAvailableSeriesByMarketType返回 ： " + JSONObject.toJSONString(series));
		gson.addStaticAttribute("series", series);
		return gson;
	}
	
	/**
	 * 根据城市和品牌刷选车系
	 * @param cityId 城市id
	 * @param brandId 品牌id
	 * @return
	 */
	@RequestMapping(value="/series/{cityId}/{brandId}",method=RequestMethod.GET)
	public ModelAndView getAllSeriesByMarketType(@PathVariable(value="cityId") Long cityId,
			@PathVariable(value="brandId") Long brandId){
		logger.info("BrandSeriesController => getAvailableSeriesByMarketType ###### cityId : {},brandId : {} ", cityId, brandId);
		ModelAndView model = new ModelAndView(SERIES_FTL);
		List<SeriesVO> series = brandService.getSeriesByMarketType(MarketType.ROUTINE.code(), cityId, brandId);
		logger.info("调用 brandService.getAvailableSeriesByMarketType返回 ： " + JSONObject.toJSONString(series));
		model.addObject("series", series);
		return model;
	}
	
	/**
	 * 根据城市和品牌+车系筛选常规车车型
	 * @param brandId
	 * @param cityId
	 * @param seriesId
	 * @param totalDisplayLength 前台已显示的常规车数量
	 * @return
	 */
	@RequestMapping(value="/model",method=RequestMethod.GET)
	public ModelAndView getAllModelBySeriesId(@RequestParam(value="brandId",required=true) Long brandId,
			@RequestParam(value="cityId",required=true) Long cityId,
			@RequestParam(value="seriesId",required=true) Long seriesId,
			@RequestParam(value="totalDisplayLength",required=true) Integer totalDisplayLength){
		logger.info("BrandSeriesController => getAllModelBySeriesId ###### brandId : {} , cityId : {} , seriesId : {} , totalDisplayLength : {}",
				brandId , cityId, seriesId, totalDisplayLength);
		Pagination pagination = new Pagination(PAGE_SIZE, totalDisplayLength/PAGE_SIZE + 1);
		List<RoutineCarVO> routineCars = routineCarService.findConventionalVehicleByPromotionIdSeriesIdColorId(MarketType.ROUTINE.code(), cityId, brandId, seriesId, true, pagination);
		logger.info("routineCarService.findConventionalVehicleByPromotionIdSeriesIdColorId ###### 返回数据 : " + JSONObject.toJSONString(routineCars));
		ModelAndView model = new ModelAndView(SERIES_MODEL_FTL);
		model.addObject("routineCars", routineCars).addObject("TotalNum", pagination.getTotalRows());
		return model;
	}
}
