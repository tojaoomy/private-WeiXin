package com.saic.ebiz.market.controller;
/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */


import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.saic.framework.redis.client.IRedisClient;
import com.saic.ebiz.comment.service.api.IUserCommentService;
import com.saic.ebiz.comment.service.entity.Evaluation;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.util.ImageUtil;
import com.saic.ebiz.market.common.util.login.RandomValidateCode;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.order.service.api.PreOrderCancelService;
import com.saic.ebiz.promotion.service.api.IActOrderQueryService;
import com.saic.ebiz.promotion.service.api.IActOrderUpdateService;
import com.saic.ebiz.promotion.service.api.IClaimService;
import com.saic.ebiz.promotion.service.api.routine.IGlobalRuleService;
import com.saic.ebiz.promotion.service.api.routine.IRoutineCarService;
import com.saic.ebiz.promotion.service.commons.constants.RedisConstants;
import com.saic.ebiz.promotion.service.commons.enums.ActOrderStatus;
import com.saic.ebiz.promotion.service.entity.routine.ClaimEntity;
import com.saic.ebiz.promotion.service.vo.RoutineCarOrder;
import com.saic.ebiz.promotion.service.vo.RoutineCarSelection;
import com.saic.ebiz.promotion.service.vo.routine.GlobalRule;
import com.saic.ebiz.promotion.service.vo.routine.RoutineCar;

/**
 * 我的询价单<br>wx
 * 
 */
@Controller
@RequestMapping("/inquiry")
public class EnquiryListController {
	
	/** The Constant logger. */
    private static final Logger LOGGER = LoggerFactory.getLogger(EnquiryListController.class);

	
	/**  我的询价单路径. */
    private static final String FTL_ENQUIRYLIST = "/wxsales/enquiryList.ftl";
    /**  我的询价单路径. */
    private static final String FTL_AJAXENQUIRY = "/wxsales/ajaxEnquiry.ftl";
    /**  支付路径. */
    private static final String FTL_PAY = "/wxsales/myEnquiryPay.ftl";
    /**  已到店路径. */
    private static final String FTL_SHOP = "/wxsales/myEnquiryShop.ftl";
    /**  已报价路径. */
    private static final String FTL_QUOTE = "/wxsales/myEnquiryQuote.ftl";
    /**  发表评论路径. */
    private static final String FTL_EVALUATE = "/wxsales/evaluate.ftl";
    /**  申请赔付路径. */
    private static final String FTL_COMPENSATE = "/wxsales/compensate.ftl";
    /**  错误信息路径. */
    private static final String ERROR_FTL = "error/error-404.ftl";
    
    @Resource
	private IActOrderQueryService iActOrderQueryService;
    
    @Resource
    private IActOrderUpdateService iActOrderUpdateService;
    
    @Resource
    private IClaimService iClaimService;
    
    @Resource
    private IRoutineCarService iRoutineCarService;
    
    @Resource
    private IUserCommentService iUserCommentService;
    
    @Resource
    private PreOrderCancelService preOrderCancelService;
    
    @Resource
    private IGlobalRuleService iGlobalRuleService;
    
    /**缓存接口.*/
    @Resource(name="springRedisClient")
    private IRedisClient redisClient;
    
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
    
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
    /**
	 * 分页参数
	 */
	private static int CURRENTPAGE = 1;
	
	private static int PAGESIZE = 5;
	
	/**
	 * redis 过期时间
	 */
	private static int EXPIRETIME = 120;
	
	private static final int MUNUAL_CANNEL_BY_CUSTOMER = 2;
    
	/**
	 * 我的询价单列表（分页）
	 * @param userId
	 * @param currentPage
	 * @param request
	 * @return
	 */
    @RequestMapping(value="/enquiryList/{userId}/{currentPage}",method={RequestMethod.GET})
    public ModelAndView getMyActOrderList(@PathVariable("userId")Long userId,@PathVariable("currentPage")Integer currentPage,HttpServletRequest request){
    	LOGGER.info(getClass() + " => getMyActOrderList ####### userId : {}, currentPage : {}", userId, currentPage);
    	if(userId == -1){
    		//如果userId=-1，跳转到授权页面去 ，同时需要在AccountController的userLogin和userRegister跳转到对应的url
    		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
    		autorizationUrl = autorizationUrl.replace("STATE", Authorization.inquiry.name());
    		LOGGER.debug("未知的用户，使用授权获取openId来查询对应userId######");
    		LOGGER.debug("授权url : {} ######", autorizationUrl);
    		return new ModelAndView(autorizationUrl);
    	}
    	
        /**
		 * 分页条件
		 */
		Pagination page = new Pagination();
		if(null != currentPage){
			page.setCurrentPage(currentPage);
		}else{
			page.setCurrentPage(CURRENTPAGE);
		}
		ModelAndView mv = new ModelAndView(FTL_ENQUIRYLIST);
		if(page.getCurrentPage() > 1){
			mv = new ModelAndView(FTL_AJAXENQUIRY);
		}
		page.setPagesize(PAGESIZE);
    	PaginationResult<List<RoutineCarOrder>> list = null;
    	GlobalRule globalRule = null;
    	try {
    		list = iActOrderQueryService.queryMyActOrder(userId, page, 1);
    		globalRule = iGlobalRuleService.findGlobalRule();
		} catch (Exception e) {
			LOGGER.error("调用iActOrderQueryService接口查询我的询价单异常：{}",e.getMessage());
			e.printStackTrace();
		}
    	if(null != list){
			List<RoutineCarOrder> rcoList = list.getR();
			if(null != rcoList && rcoList.size() > 0){
				for (int i = 0; i < rcoList.size(); i++) {
					if(rcoList.get(i).getActOrderStatus().equals(ActOrderStatus.PAYMENT.code()) || rcoList.get(i).getActOrderStatus().equals(ActOrderStatus.HAS_QUOTA.code()) || 
							rcoList.get(i).getActOrderStatus().equals(ActOrderStatus.CHOOSE_DEALER.code())){
						Long times = rcoList.get(i).getPayTime().getTime()+globalRule.getQuoteTimeLimit()*60*1000;
						if(new Date().getTime()-times < 0){
							rcoList.get(i).setCountDownStr(String.valueOf(times));
		    			}
					}
				}
				mv.addObject("routineCarOrderList", rcoList);
				mv.addObject("userId", userId);
			}
			Pagination pagination = list.getPagination();
			int currentPage2 = pagination.getCurrentPage();
			mv.addObject("currentPage", currentPage2);
		}
		return mv;
	}
    
    /**
     * 询价单详情
     * @param actOrderId
     * @param request
     * @return
     */
	@RequestMapping("/actorder/{userId}/{actOrderId}")
    public ModelAndView getRoutineCarOrderByActOrder(@PathVariable(value="userId") Long userId,@PathVariable String actOrderId,HttpServletRequest request){
        ModelAndView mv = new ModelAndView();
        RoutineCarOrder routineCarOrder = null;
        String provincename = null;
    	try {
    		routineCarOrder = iActOrderQueryService.queryActOrderDetail(actOrderId);
    		List<RoutineCarSelection> list = routineCarOrder.getSelections();
    		for (int i = 0; i < list.size(); i++) {
				list.get(i).setImgurl(ImageUtil.getStaticImageUrl(ImageUtil.DEFAULT_RESOLUTION, list.get(i).getImgurl()));
			}
    		provincename = ConstantCodeService.getRegionNameByCode(routineCarOrder.getLicenseProvinceId().toString());
    		Long times = 0l;
    		if(routineCarOrder.getActOrderStatus().equals(ActOrderStatus.PAYMENT.code()) || routineCarOrder.getActOrderStatus().equals(ActOrderStatus.HAS_QUOTA.code()) ||
    				routineCarOrder.getActOrderStatus().equals(ActOrderStatus.CHOOSE_DEALER.code())){
    			times = routineCarOrder.getPayTime().getTime()+iGlobalRuleService.findGlobalRule().getQuoteTimeLimit()*60*1000;
    		}
    		if(routineCarOrder.getActOrderStatus() == 11 || routineCarOrder.getActOrderStatus() == 12 || routineCarOrder.getActOrderStatus() == 13){
    			if(times - new Date().getTime() > 0){
    				routineCarOrder.setCountDownStr(String.valueOf(times));
    			}
    			mv.setViewName(FTL_PAY);
			}else if(routineCarOrder.getActOrderStatus() == 20 || routineCarOrder.getActOrderStatus() == 21){
				if(times - new Date().getTime() > 0){
    				routineCarOrder.setCountDownStr(String.valueOf(times));
    			}
				mv.setViewName(FTL_QUOTE);
			}else{
				mv.setViewName(FTL_SHOP);
			}
			mv.addObject("routineCarOrder", routineCarOrder);
			String codeId = userToken(request);     //根据ip、port、timestamp 生成
			mv.addObject("codeId", codeId);
    		mv.addObject("provincename", provincename);
    		mv.addObject("userId", userId);
		} catch (Exception e) {
			LOGGER.error("调用iActOrderQueryService接口查询询价单详情异常：{}",e.getMessage());
			e.printStackTrace();
			mv.setViewName(ERROR_FTL);
			return mv;
		}
		return mv;
	}
    
    /**
     * 发表评论
     * @param actOrderId
     * @param request
     * @return
     */
    @RequestMapping("/evaluate/{userId}/{actOrderId}")
    public ModelAndView evaluate(@PathVariable(value="userId") Long userId,@PathVariable String actOrderId,HttpServletRequest request){
    	ModelAndView mv = new ModelAndView();
    	RoutineCarOrder routineCarOrder = null;
    	try {
        	routineCarOrder = iActOrderQueryService.queryActOrderDetail(actOrderId);
		} catch (Exception e) {
			LOGGER.error("调用iActOrderQueryService接口查询我的询价单异常：{}",e.getMessage());
			e.printStackTrace();
			mv.setViewName(ERROR_FTL);
			return mv;
		}
		mv.setViewName(FTL_EVALUATE);
		mv.addObject("routineCarOrder", routineCarOrder);
		mv.addObject("userId", userId);
    	return mv;
    }
    
    /**
     * 发表评论
     * @param actOrderId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/evaluateToDo/{userId}/{actOrderId}")
    public String evaluateToDo(@PathVariable(value="userId") Long userId,@PathVariable String actOrderId,
    		@RequestParam(value="claimComment",required=true) String content,@RequestParam(value="score",required=true) int score,
    		@RequestParam(value="routineCarId",required=true) Long routineCarId,HttpServletRequest request){
    	String istrue = "0";
		try {
			//功能代码
			RoutineCar routineCar = iRoutineCarService.findRoutineCarById(routineCarId);
			RoutineCarOrder routineCarOrder = iActOrderQueryService.queryActOrderDetail(actOrderId);
			Evaluation eval = new Evaluation();
			eval.setContent(content);
			eval.setUserId(userId);
			eval.setScore(score);
			eval.setVelBrandId(routineCar.getVelBrandId());
			eval.setVelModelId(routineCar.getVelModelId());
			eval.setVelSeriesId(routineCar.getVelSeriesId());
        	eval.setObjectId(actOrderId);
        	eval.setCommentSource(1);
        	eval.setCloseFlag(0);
        	eval.setUserName(routineCarOrder.getUserName());
        	eval.setMobile(routineCarOrder.getMobileNo());
			if(this.iUserCommentService.addEvaluation(eval)){
				istrue = "1";
			}
		} catch (Exception e) {
			LOGGER.error("调用iUserCommentService接口发表评论异常：{}",e.getMessage());
		}
    	return istrue;
    }
    
    /**
     * 申请赔付
     * @param actOrderId
     * @param request
     * @return
     */
    @RequestMapping("/compensate/{userId}/{actOrderId}")
    public ModelAndView compensate(@PathVariable String actOrderId,
    		@PathVariable(value="userId") Long userId,HttpServletRequest request){
    	ModelAndView mv = new ModelAndView(FTL_COMPENSATE);
    	RoutineCarOrder routineCarOrder = null;
    	try {
        	routineCarOrder = iActOrderQueryService.queryActOrderDetail(actOrderId);
		} catch (Exception e) {
			LOGGER.error("调用iActOrderQueryService接口查询我的询价单异常：{}",e.getMessage());
			e.printStackTrace();
			mv.setViewName(ERROR_FTL);
			return mv;
		}
    	mv.addObject("routineCarOrder", routineCarOrder);
    	mv.addObject("userId", userId);
    	return mv;
    }
    
    /**
     * 申请赔付
     * @param actOrderId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/compensateToDo/{userId}/{actOrderId}")
    public String compensateToDo(
    		@PathVariable(value="userId") Long userId,
    		@PathVariable(value="actOrderId") String actOrderId,
    		@RequestParam(value="routineId",required=true) Long routineId,
    		@RequestParam(value="promotionId",required=true) Long promotionId,
    		@RequestParam(value="claimComment",required=true) String claimComment){
    	String istrue = "0";
		try{
    		//功能代码
			ClaimEntity claimEntity = new ClaimEntity();
			claimEntity.setClaimComment(claimComment);
			claimEntity.setActOrderId(actOrderId);
			claimEntity.setRoutineId(routineId);
			claimEntity.setPromotionId(promotionId);
			claimEntity.setUserId(userId);
			claimEntity.setClaimStatus(1);
	    	if(iClaimService.createClaim(claimEntity)){
				istrue = "1";
			}
    	} catch (Exception e) {
			LOGGER.error("调用iClaimServicr接口申请赔付异常：{}",e.getMessage());
			e.printStackTrace();
		}
		return istrue;
    }
    
    
    /**
     * 功能描述: 获取验证码<br>
     * .
     * 
     * @param request the request
     * @param response the response
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/validateCode/{codeId}")
    public void validateCode(@PathVariable String codeId,HttpServletRequest request, HttpServletResponse response) {
    	try {
	    	System.setProperty("java.awt.headless", "true");
	        response.setContentType("image/jpeg");// 设置相应类型,告诉浏览器输出的内容为图片
	        response.setHeader("Pragma", "No-cache");// 设置响应头信息，告诉浏览器不要缓存此内容
	        response.setHeader("Cache-Control", "no-cache");
	        response.setDateHeader("Expire", 0);
	        RandomValidateCode validateCode = new RandomValidateCode();
	        BufferedImage image = validateCode.getValidateImage();
	        redisClient.set(codeId,Constants.REDIS_NAME_SPACE,validateCode.getCodeString(),RedisConstants.EXPIRE_TIME_ONE_HOUR);
	        redisClient.expire(codeId,Constants.REDIS_NAME_SPACE, EXPIRETIME);
            ImageIO.write(image, "JPEG", response.getOutputStream());
            System.setProperty("java.awt.headless", "true");
        } catch (IOException e) {
            LOGGER.error("validateCode image transmission was error !", e);
        }
    }
    
    
    /**
     * 选择经销商
     * @param storeId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/store/{userId}/{actOrderId}")
    public String updateMerchandiseStore(@PathVariable(value="userId") Long userId,@PathVariable String actOrderId,
    		@RequestParam("routineCarId")Long routineCarId,
    		@RequestParam("storeId")Long storeId,
    		@RequestParam(value="code",required=true)String code,
    		@RequestParam(value="codeId",required=true)String codeId,
    		HttpServletRequest request, HttpServletResponse response){
    	String istrue = "0";
    	try{
    		String validateCode = redisClient.get(codeId,Constants.REDIS_NAME_SPACE,null);
    		//验证  验证码失效
    		if (StringUtils.isBlank(validateCode)) {
    			istrue = "1";
    			return istrue;
	        }   
			// 验证验证码
			if (!code.equalsIgnoreCase(validateCode)) {
				istrue = "0";
				return istrue;
			}
	    	//修改选择的经销商
	    	if(iActOrderQueryService.selectStore(actOrderId, routineCarId, storeId)){
	    		istrue = "2";
	    	}else{
    			istrue = "3";
    		}
    	} catch (Exception e) {
			LOGGER.error("调用iActOrderQueryService接口选择经销商异常：{}",e.getMessage());
			e.printStackTrace();
		}
    	return istrue;
    }
    
    /**
     * 取消询价单
     * @param actOrderId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/deactorder/{userId}/{actOrderId}")
    public String deleteActOrder(@PathVariable(value="userId") Long userId,@PathVariable String actOrderId,HttpServletRequest request, HttpServletResponse response){
    	String istrue = "0";
    	try{
	    	//取消询价单
    		RoutineCarOrder routineCarOrder = iActOrderQueryService.queryActOrderDetail(actOrderId);
	    	if(routineCarOrder.getActOrderStatus().equals(ActOrderStatus.ARRIVED.code()) || routineCarOrder.getActOrderStatus().equals(ActOrderStatus.HAS_CAR.code())){
	    		preOrderCancelService.cancelPreOrder(routineCarOrder.getOrderId(), routineCarOrder.getUserId(), "");
	    		istrue = "1";
	    	}else{
	    		if(iActOrderUpdateService.cancelActOrder(actOrderId,MUNUAL_CANNEL_BY_CUSTOMER)){
	    			istrue = "1";
	    		}
	    	}
    	} catch (Exception e) {
			LOGGER.error("调用iActOrderUpdateService接口取消询价单异常：{}",e.getMessage());
			e.printStackTrace();
			return istrue;
		}
    	return istrue;
    }

    
    public static String userToken(HttpServletRequest request){
    	String token = "";
    	String ip = request.getHeader("x-forwarded-for"); 
        if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("Proxy-Client-IP"); 
        } 
        if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("WL-Proxy-Client-IP"); 
        } 
        if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getRemoteAddr(); 
        }
        int port =request.getRemotePort();
        int random = (int)(Math.random()*900)+100;
        if(ip != null){
        	ip = ip.replace(".", "");
        }else{
        	ip = "";
        }
    	token = ip+port+new Date().getTime()+random;
        return token;
    }
    
}
