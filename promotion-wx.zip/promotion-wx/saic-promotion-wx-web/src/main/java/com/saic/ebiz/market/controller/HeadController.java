package com.saic.ebiz.market.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.iam.service.entity.AcctAliasVO;
import com.saic.ebiz.iam.service.entity.AuthInfoVO;
import com.saic.ebiz.market.common.util.ChineseUtil;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.sso.client.SSOClient;


/**
 * The Class PageHeadController.
 */
@Controller
@RequestMapping("/common")
public class HeadController {
    
    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(HeadController.class);
    
    /** 页面footer显示用户名英文长度. */
    private static final int PAGEFOOTER_NAME_LENGTH = 7;
    
    /** 页面footer显示用户名中文长度. */
    private static final int PAGEFOOTER_NAME_CHINESE = 5;
    
    /** The member center service. */
    @Resource
    private UserService userService;
    
    
    @Resource
    private IUserService iUserService;
    /** The ssoclient. */
    @Resource
    private SSOClient ssoclient;
    
    /**
     * 功能描述: page head<br>
     * .
     * 
     * @param request the request
     * @param response the response
     * @return the map
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/head")
    @ResponseBody
    public Map<String, Object> showDefaultPageHead(HttpServletRequest request,HttpServletResponse response){
        Long userId = ssoclient.getLoginStatus(request);
        LOGGER.debug("获取userId：{}", userId);
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("status", userId);
        // 用户未登陆则返回
        if (NumberUtils.LONG_ZERO.equals(userId)) {
            return map;
        // 已登陆用户userId置为1
        } else {
            map.put("status", NumberUtils.LONG_ONE);
        }
        // 获取个人主要信息
        String realName = StringUtils.EMPTY;
        UserBaseInfoVO mciVO =null;
        mciVO= userService.findBaseInfoByUserId(userId);
       
        LOGGER.debug("调用memberCenterService.findMembCentInfo({})：{}", userId, JSONObject.toJSONString(mciVO));
         //用户昵称
        if (mciVO != null) {
            if (StringUtils.isNotBlank(mciVO.getNickName())) {
                realName = mciVO.getNickName();
            } 
//            else if(StringUtils.isNotBlank(mciVO.getName())) {
//                realName = mciVO.getName();
//            }
            else {
            	try {
           		 AuthInfoVO authInfoVO	=iUserService.getAuthInfo("", userId, 1);
           		 if (authInfoVO != null) {
                        for (AcctAliasVO acctAliasVO : authInfoVO.getAuthList()) {
                        // 2:手机， 3:邮箱
                           if (acctAliasVO.getAliasType() == 1) {
                           	//用户名
                           	realName=acctAliasVO.getAliasName();
                        }
                        // 个人密保问题状态
                    }
           		 }
				} catch (Exception e) {
					e.printStackTrace();
				}
           }
        }
        if (null == realName) {
            realName = StringUtils.EMPTY;
        }
        // 过长名称截断
        if (realName.length() > PAGEFOOTER_NAME_LENGTH) {
            // 中文名称超长截断
            if (ChineseUtil.countChinese(realName) > PAGEFOOTER_NAME_CHINESE) {
                realName = realName.substring(NumberUtils.INTEGER_ZERO, PAGEFOOTER_NAME_CHINESE).concat("…");
            } else {
                realName = realName.substring(NumberUtils.INTEGER_ZERO, PAGEFOOTER_NAME_LENGTH).concat("…");
            }
        }
        LOGGER.debug("flag001"+realName);
        map.put("realName", realName);
        return map;
    }
}
