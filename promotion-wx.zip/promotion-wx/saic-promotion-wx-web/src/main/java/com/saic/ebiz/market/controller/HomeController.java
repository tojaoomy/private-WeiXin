package com.saic.ebiz.market.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.entity.BrandVO;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.service.BrandService;
import com.saic.ebiz.market.service.ShoppingCartService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.promotion.service.api.routine.IGlobalRuleService;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	private static final String INDEX_FTL = "/index.ftl";
	
	private static final String INSTRODUCTION_FTL = "/introduction.ftl";
	
	private static final String ERROR_FTL = "error/error-404.ftl";
	
	private static final String DEFAULT_CITY_ID = "370200";
	
	/**
	 * 判断微信用户是否绑定车享账号的服务
	 */
	@Resource
	private BoundingService boundingService;
	
	/**
	 * 品牌服务
	 */
	@Resource
	private BrandService brandService;
	
	/**
	 * 常规车全局服务
	 */
	@Resource
	private IGlobalRuleService iGlobalRuleService;
	
	/**
	 * 购物车服务
	 */
	@Resource
	private ShoppingCartService shoppingCartService;
	
	/**
	 * MDM服务接口
	 */
	@Resource(name = "userService")
	private UserService userService;
	
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	/**
	 * 如果userid为空的话，是否应该跳转到404页面？
	 * 
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView home(Locale locale,
			HttpServletRequest request,HttpServletResponse response) {
		ModelAndView model = new ModelAndView(INDEX_FTL);
		
		String openId = request.getParameter(RequestConstants.OPEN_ID);

		String userId = request.getParameter(RequestConstants.USER_ID);
		
		String cityId = request.getParameter(RequestConstants.CITY_ID);
		
		String switchFlag = request.getParameter(RequestConstants.SWITCH);
		
		logger.info("HomeController => home openId : {}, userId : {}, cityId : {}, switchFlag : {}", openId, userId, cityId, switchFlag);
		//先判断userId是否存在，存在则继续流程
		//否则跳转到授权页面
//		String tmpUserId = "";
//		if(openId != null && openId.length() > 0){
//			tmpUserId = boundingService.getBoundingUserId(openId);
//			//返回为""，则表明未绑定
//			if("".equals(tmpUserId)){
//				//TBD 跳到登录页面
//				logger.info("openid 为 {} 未绑定账号，跳到登录页面。", openId);
//			}
//		}
		
		//TBD 如果userid和查询的不一致
		if(userId != null && userId.length() > 0){
			if(userService.findBaseInfoByUserId(Long.valueOf(userId)) == null){
				logger.error("系统未找到userId : {}, 请联系管理员。", userId);
				throw new BaseException("未找到用户" + userId);
			}
		}else{
//			userId="10257";
			//跳转到授权页面去 ，同时需要在AccountController的userLogin和userRegister跳转到对应的url
			String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.index.name());
			logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
			logger.debug("授权url : {} ######", autorizationUrl);
			model = new ModelAndView(autorizationUrl);
			return model;
		}
		
		//如果是城市切换，这清空该用户的购物车。
		//. 切换之后，常规车在该城市下可能不存在，所以需要清空
		if(StringUtils.isNotEmpty(switchFlag) && RequestConstants.SWITCH.equals(switchFlag)){
			this.shoppingCartService.empty(userId);
		}
		
		if(cityId == null || cityId.length() == 0){
			//默认青岛
			cityId = DEFAULT_CITY_ID;
		}
		
		List<BrandVO> brands = brandService.getBrandsByMarketType(MarketType.ROUTINE.code(), Long.valueOf(cityId));
		logger.info("调用 brandService.getAvailableBrandsByMarketType返回 ： " + JSONObject.toJSONString(brands));
		DataItemBean bean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
		if(bean == null){
			throw new BaseException("该城市未找到，请稍后再试。。。");
		}
		model.addObject(RequestConstants.USER_ID,userId)
			.addObject(RequestConstants.OPEN_ID, openId)
			.addObject(RequestConstants.CITY_ID, cityId)
			.addObject(RequestConstants.CITY_NAME, bean.getName().replaceAll("市", ""))
			.addObject("brands", brands)
			.addObject("otherBrands", getOtherBrand(brands))
			.addObject("maxNumOfCar", iGlobalRuleService.findGlobalRule().getMaxCarNum());
		return model;
	}
	
	/**
	 * 因前台页面只显示配置的品牌，其他品牌显示，但是遮拦
	 * @param brands
	 * @return
	 */
	private Map<Long,String> getOtherBrand(List<BrandVO> brands){
		Map<Long,String> allBrands = new HashMap<Long,String>();
		allBrands.put(1L, "大众");
		allBrands.put(2L, "斯柯达");
		allBrands.put(3L, "别克");
		allBrands.put(4L, "雪佛兰");
		allBrands.put(5L, "凯迪拉克");
		allBrands.put(6L, "荣威");
		allBrands.put(7L, "MG");
		allBrands.put(8L, "宝骏");
		allBrands.put(9L, "五菱");
		allBrands.put(10L, "上汽大通");
		for(BrandVO brand : brands){
			if(allBrands.containsKey(brand.getId())){
				allBrands.remove(brand.getId());
			}
		}
		return allBrands;
	}
	
	/**
	 * 关注车享购时发送的news页
	 * @param locale
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/introduction", method = RequestMethod.GET)
	public ModelAndView introduction(Locale locale, Model model,
			HttpServletRequest request) {
		return new ModelAndView(INSTRODUCTION_FTL);
	}
	
	@RequestMapping(value = "/errorPage404")
	public ModelAndView error() {
		return new ModelAndView(ERROR_FTL);
	}
	
	@RequestMapping("idx/test")
	public ModelAndView test() {
		return new ModelAndView("/index.bak.ftl");
	}
	
	@RequestMapping("test/produt")
	public ModelAndView getProduct(){
		ModelAndView model = new ModelAndView("/wxsales/car_series_product.ftl");
		return model;
	}
}
