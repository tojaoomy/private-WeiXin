/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.IntegerConverter;
import org.apache.commons.beanutils.converters.LongConverter;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.entity.ColorImageVO;
import com.saic.ebiz.market.entity.ColorVO;
import com.saic.ebiz.market.entity.InquiryOrderVO;
import com.saic.ebiz.market.entity.RoutineCarVO;
import com.saic.ebiz.market.entity.ShoppingCart;
import com.saic.ebiz.market.service.RoutineCarService;
import com.saic.ebiz.market.service.ShoppingCartService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.promotion.service.api.IActOrderCreateService;
import com.saic.ebiz.promotion.service.api.IActOrderUpdateService;
import com.saic.ebiz.promotion.service.api.routine.IGlobalRuleService;
import com.saic.ebiz.promotion.service.commons.exception.IllegalActOrderUserException;
import com.saic.ebiz.promotion.service.vo.RoutineCarOrder;
import com.saic.ebiz.promotion.service.vo.routine.GlobalRule;

/**
 * @author hejian
 * 
 */
@RestController
@RequestMapping("/inquiry")
public class InquiryController implements ApplicationContextAware{
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	/** 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("weixin-trace");
	
	 /**  登录模板路径. */
	private static final String FTL_INQUIRY = "/wxsales/car_inquiry.ftl";
	
    static final String FTL_INQUIRY_OLD = "/wxsales/inquiry.ftl";
    
    private static final String FTL_INQUIRY_OK =  "/wxsales/enquiry-ok.ftl";
    
    /** 支付页面  */
    private static final String PAYMENT_FTL = "forward:/pay/prepayment";
    
    /** 支付定金0元 */
    private static final BigDecimal ZERO_DEPOSIT = new BigDecimal(0.00);
    
	@Resource
	private IGlobalRuleService iGlobalRuleService;
	
	@Resource
	private RoutineCarService routineCarService;
	
	@Resource
	private ShoppingCartService shoppingCartService;
	
	/** 创建活动订单接口 */
	@Resource
	private IActOrderCreateService iActOrderCreateService;
	
	/**
     * 活动订单更新
     */
    @Resource
    private IActOrderUpdateService iActOrderUpdateService;
	
	@Resource(name = "userService")
	private UserService userService;
	
	/**
	 *  1：电商主站；
	 *	2：车享宝；
	 *	3：营销子站；
	 *	4：保养管家；
	 *	5：第三方联合登陆；
	 *	6：别克联合登陆；
	 *	7：微信服务号；
	 *	8：微信订阅号；
	 *	9：微信红包 
	 *	11：呼叫中心；
	 *	12：平安保险（PC）；
	 *	13：订单系统；
	 *	14：车畅销；
	 *	20：车知道（内部账号）；
	 *	21：别克微信商城；
	 *	22：荣威俱乐部；
	 *	23：crm；
	 *	24：运营平台；
	 *	29：车享购微信服务号；
	 *	31：平安微信；
	 *	35：新浪微博PC；
	 *	36：新浪微博移动；
	 *	60：Other
	 */
	private static final String TRACE_SOURCE = "7";
	
	/**
	 * 线索类型
	 *	10.促销车订购
	 *	11.预约试乘试驾
	 *	12在线询价
	 *	13.促销活动
	 *	14.常规车预定
	 *	15.来电咨询
	 *	16在线留言咨询
	 *	17.贷款购车
	 *	18.拉手电话
	 *	20.其他
	 */
	private static final String TRACE_TYPE = "14";

	/**
	 * 根据用户的id和城市从redis中获取常规车信息
	 * 
	 * @param userId 	用户id
	 * @param cityId	城市id
	 * @return
	 */
    @RequestMapping(value="/{userId}/{cityId}",method={RequestMethod.GET})
	public ModelAndView inquire(@PathVariable("userId")Long userId,@PathVariable("cityId")Long cityId) {
    	logger.info("inquire => userId : {},cityId : {}", userId,cityId);
    	//根据userId获取购物车
    	List<ShoppingCart> shoppingCart = shoppingCartService.loadByUserId(userId,cityId);
    	logger.info("shoppingCartService.loadByUserId(userId,cityId) => " + JSONObject.toJSONString(shoppingCart));
    	List<Long> routineCarIds = new ArrayList<Long>();
    	for(ShoppingCart cart : shoppingCart){
    		routineCarIds.add(cart.getRoutineCarId());
    	}
    	List<RoutineCarVO> vos = routineCarService.findRoutineCar(routineCarIds);
    	logger.info("routineCarService.findRoutineCar(" + JSONObject.toJSONString(routineCarIds) + ") => " + JSONObject.toJSONString(vos));
    	GlobalRule gr = this.iGlobalRuleService.findGlobalRule();
    	logger.info("iGlobalRuleService.findGlobalRule() => " + JSONObject.toJSONString(gr));
    	UserBaseInfoVO userInfo = this.userService.findBaseInfoByUserId(userId);
    	if(userInfo == null){
    		throw new BaseException("用户 " + userId + "未找到！！！");
    	}
    	logger.info("userService.findBaseInfoByUserId => " + JSONObject.toJSONString(userInfo));
		ModelAndView model = new ModelAndView(FTL_INQUIRY);
		model.addObject("RoutineCarVOList", vos);
		model.addObject("GlobalRule", gr);
		model.addObject("userInfo", userInfo);
		model.addObject(RequestConstants.USER_ID, userId);
		//根据用户会员中心的所设置的城市和省份设置下询价单页的上牌省市
		if(userInfo.getCity() != null && !NumberUtils.INTEGER_ZERO.equals(userInfo.getCity())){
			model.addObject(RequestConstants.CITY_ID, userInfo.getCity());
			model.addObject(RequestConstants.PROVINCE_ID, ConstantCodeService.getRegionInfo(String.valueOf(userInfo.getCity())).getParentCode());
		}else{
			model.addObject(RequestConstants.CITY_ID, cityId);
			model.addObject(RequestConstants.PROVINCE_ID, ConstantCodeService.getRegionInfo(String.valueOf(cityId)).getParentCode());
		}
		model.addObject("currentCityId", cityId);
		if(vos != null && vos.size() > 0){
			model.addObject("brandId", vos.get(0).getBrandId());
			String models = String.valueOf(vos.get(0).getVehicleModelId());
			//前台页面隐藏域 xx=yy为了查询配置参数方便
			if(vos.size() == 2){
				models = (models + "=" + vos.get(1).getVehicleModelId());
			}
			model.addObject("models", models);
		}
		return model;
	}
    
    /**
     * 询价单优化，用户点击常规车即走询价单页，
     * 不再添加到购物车中
     * @param userId	用户id
     * @param cityId	城市id
     * @param routineCarId	常规车id
     * @return
     */
    @RequestMapping(value="/{userId}/{cityId}/{routineCarId}",method={RequestMethod.GET})
    public ModelAndView inquireOptimization(@PathVariable("userId")Long userId,@PathVariable("cityId")Long cityId,
    		@PathVariable("routineCarId")Long routineCarId) {
    	logger.info("inquire => userId : {}, cityId : {}, routineCarId", userId,cityId,routineCarId);
    	List<Long> routineCarIds = new ArrayList<Long>();
    	routineCarIds.add(routineCarId);
    	List<RoutineCarVO> vos = routineCarService.findRoutineCar(routineCarIds);
    	logger.info("routineCarService.findRoutineCar(" + JSONObject.toJSONString(routineCarIds) + ") => " + JSONObject.toJSONString(vos));
    	GlobalRule gr = this.iGlobalRuleService.findGlobalRule();
    	logger.info("iGlobalRuleService.findGlobalRule() => " + JSONObject.toJSONString(gr));
    	UserBaseInfoVO userInfo = this.userService.findBaseInfoByUserId(userId);
    	if(userInfo == null){
    		throw new BaseException("用户 " + userId + "未找到！！！");
    	}
    	logger.info("userService.findBaseInfoByUserId => " + JSONObject.toJSONString(userInfo));
    	ModelAndView model = new ModelAndView(FTL_INQUIRY);
    	model.addObject("RoutineCarVOList", vos);
    	model.addObject("GlobalRule", gr);
    	model.addObject("userInfo", userInfo);
    	model.addObject(RequestConstants.USER_ID, userId);
    	//根据用户会员中心的所设置的城市和省份设置下询价单页的上牌省市
    	if(userInfo.getCity() != null && !NumberUtils.INTEGER_ZERO.equals(userInfo.getCity())){
    		model.addObject(RequestConstants.CITY_ID, userInfo.getCity());
    		model.addObject(RequestConstants.PROVINCE_ID, ConstantCodeService.getRegionInfo(String.valueOf(userInfo.getCity())).getParentCode());
    	}else{
    		model.addObject(RequestConstants.CITY_ID, cityId);
    		model.addObject(RequestConstants.PROVINCE_ID, ConstantCodeService.getRegionInfo(String.valueOf(cityId)).getParentCode());
    	}
    	model.addObject("currentCityId", cityId);
    	if(vos != null && vos.size() > 0){
    		model.addObject("brandId", vos.get(0).getBrandId());
    		String models = String.valueOf(vos.get(0).getVehicleModelId());
    		//前台页面隐藏域 xx=yy为了查询配置参数方便
    		if(vos.size() == 2){
    			models = (models + "=" + vos.get(1).getVehicleModelId());
    		}
    		model.addObject("models", models);
    	}
    	return model;
    }
    
    @RequestMapping(method={RequestMethod.POST})
    public ModelAndView inquire(InquiryOrderVO inquiryOrderVO,HttpServletRequest request) {
		logger.info("InquiryOrderVO : " + JSONObject.toJSONString(inquiryOrderVO));
		ModelAndView view = null;
		RoutineCarOrder routineCarOrder = new RoutineCarOrder();
		String userTraceCookie = "";
		Long userId = null;
		try {
			ConvertUtils.register(new DateConverter(null), java.util.Date.class);
			ConvertUtils.register(new LongConverter(null), Long.class);
			ConvertUtils.register(new IntegerConverter(null), Integer.class);
			BeanUtils.copyProperties(routineCarOrder, inquiryOrderVO);
			//1pc 2微信
			routineCarOrder.setOrderSource(2);
			routineCarOrder.setAmount(inquiryOrderVO.getSelections().size());
			routineCarOrder.setCreateId(inquiryOrderVO.getUserId());
			routineCarOrder.setCreateName(inquiryOrderVO.getUserName());
			
			userId = routineCarOrder.getUserId();
			
			//设置客户所在省份
			if(inquiryOrderVO.getCustProvinceId() == null){
				routineCarOrder.setCustProvinceId(Long.valueOf(ConstantCodeService.getRegionInfo(inquiryOrderVO.getCustCityId().toString()).getParentCode()));
			}
			//设置客户所在城市
			if(inquiryOrderVO.getCustCityId() == null){
				routineCarOrder.setCustCityId(inquiryOrderVO.getCustCityId());
			}
			logger.info("订单 参数 RoutineCarOrder : " + JSONObject.toJSONString(routineCarOrder));
			Cookie[] cookies = request.getCookies();
			for (Cookie cookie : cookies) {
				String name = cookie.getName();
				if ("user_trace_cookie".equals(name)) {
					userTraceCookie = cookie.getValue();
					break; 
				}
			}
			view = dispatchHandlerProcess(routineCarOrder,userTraceCookie);
			//生成订单成功后清空购物车
			shoppingCartService.empty(String.valueOf(userId));
			logger.info("清空购物车完成！！！");
		} catch (Exception e) {
			logger.error("发成异常 " + e.getMessage());
			usertraceLogger.info("微信端常规车询价单\t" + userTraceCookie + "\t"
					+ userId + "\t" + "创建失败" + "\t" + "-1" +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
		} 
		return view;
	 }
    
    /**
     * 用来做特殊分发的逻辑处理。
     * 	1. 如果预付定金为0，生成一张已支付的询价单。
     *  2. 不为0，则跳转支付系统
     * @return 跳转的视图展示页面
     * @throws IllegalActOrderUserException 
     */
	private ModelAndView dispatchHandlerProcess(RoutineCarOrder routineCarOrder,String userTraceCookie) throws IllegalActOrderUserException {
		String orderId = "";
		//如果询价单预定金为0元，生成一张已支付的询价单
		if (iGlobalRuleService.findGlobalRule().getDeposit().doubleValue() == ZERO_DEPOSIT.doubleValue()) {
			orderId = iActOrderCreateService.createRoutineCarOrderWithoutPayment(routineCarOrder);
			usertraceLogger.info("微信端常规车询价单\t" + userTraceCookie + "\t"
					+ routineCarOrder.getUserId() + "\t" + "创建成功" + "\t" + orderId +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
			logger.info("生成订单成功 orderId : " + orderId + "并开始清空购物车");
			logger.info("清空购物车完成！！！");
			return new ModelAndView("/pay/inquiry_success.ftl").addObject(RequestConstants.ORDER_ID, orderId).addObject(RequestConstants.USER_ID, routineCarOrder.getUserId());
		}else{
			orderId = this.iActOrderCreateService.createRoutineCarOrder(routineCarOrder);
			usertraceLogger.info("微信端常规车询价单\t" + userTraceCookie + "\t"
					+ routineCarOrder.getUserId() + "\t" + "创建成功" + "\t" + orderId +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
			logger.info("生成订单成功 orderId : " + orderId + "并开始清空购物车");
			//跳转支付系统
			return new ModelAndView(PAYMENT_FTL + "?orderId=" + orderId);
		}
	}
    
    /**
     * 返回对应常规车的颜色列表
     * 
     * 与前端商议返回json数据
     * 
     * @param routineCarId
     * @return
     */
    @RequestMapping("/color/{routineCarId}")
    public List<ColorVO> inquireColorList(@PathVariable(value="routineCarId") Long routineCarId){
    	logger.info("inquireColorList =>: " + JSONObject.toJSONString(routineCarId));
    	List<ColorVO> colorVOList = new ArrayList<ColorVO>();
    	List<Long> routineCarIds = new ArrayList<Long>();
    	routineCarIds.add(routineCarId);
    	List<RoutineCarVO> vos = routineCarService.findRoutineCar(routineCarIds);
    	logger.info("routineCarService.findRoutineCar(" + routineCarId + ") : " + JSONObject.toJSONString(vos));
    	if(vos == null || vos.size() == 0){
    		return null;
    	}else{
    		for(ColorImageVO civ : vos.get(0).getColors()){
    			ColorVO colorVO = new ColorVO();
    			colorVO.setColorId(civ.getId());
    			colorVO.setName(civ.getName());
    			colorVO.setUrl(civ.getImageUrl());
    			colorVOList.add(colorVO);
    		}
    	}
    	String data = JSONObject.toJSONString(colorVOList);
    	logger.info("inquireColorList 返回 " + data);
    	return colorVOList;
    }
    
	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
	}
	
	@RequestMapping("/finish")
	public ModelAndView inquiryOKPage(){
		ModelAndView mv = new ModelAndView(FTL_INQUIRY_OK);
		return mv;
	}

}
