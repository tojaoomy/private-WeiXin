package com.saic.ebiz.market.controller;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.saic.ebiz.cms.service.api.IRTFExtService;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.promotion.service.api.IGroupBuyService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
import com.saic.ebiz.promotion.service.api.IPromotionSubscriptionService;
import com.saic.ebiz.promotion.service.commons.enums.PromotionStatus;
import com.saic.ebiz.promotion.service.vo.GroupBuyExt;
import com.saic.ebiz.promotion.service.vo.GroupBuyVO;
import com.saic.ebiz.promotion.service.vo.PromotionSubscription;
import com.saic.ebiz.promotion.service.vo.UserInfo;

/**
 * 手机端阶梯团购<br> 
 * @author zhanghui
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/mobileJieTiBuy")
public class JieTiGouController {
	/**
	 * 日子文件
	 */
	Logger LOGGER = LoggerFactory.getLogger(JieTiGouController.class);
	
	/**  团购活动页面. */
    private static final String FTL_MBINDEX = "/jieti/index.ftl";
	
    /**  支付信息页面. */
    private static final String FTL_MBPAY = "/jieti/pay.ftl";
    
    /**  错误信息路径. */
    private static final String ERROR_FTL = "error/error-404.ftl";
    
    
    
    @Autowired
    private IMemberService iMemberService;    
    
    /**
	 * 活动服务
	 */
	@Autowired
	private IGroupBuyService iGroupBuyService;
	
	/**
     * 活动服务
     */
    @Autowired
    private IPromotionQualificationService iPromotionQualificationService;
    
    
    
    
    @Autowired
    private IRTFExtService rtfExtService;
	
	/**
     * 促销活动报名服务
     */
    @Autowired
    private IPromotionSubscriptionService promotionSubscriptionService;
    
    /**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
    
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	
	@Value("${ebiz.ms.web.orderBase:}")
	private String mUrl;
	
    /**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
    
    
    @RequestMapping("/mbjieti/{userId}/{promotionId}")
    public ModelAndView getJieTiGouMsg(@PathVariable("userId") Long userId,@PathVariable("promotionId") Long promotionId,HttpServletRequest request){
    	// 1.校验请求来源是否来自手机，并跳转到不同页面
    	ModelAndView mv = new ModelAndView(FTL_MBINDEX);
		try {
			if (userId == -1) {
        		//如果userId=-1，跳转到授权页面去 ，同时需要在AccountController的userLogin和userRegister跳转到对应的url
				String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm?orderId="+promotionId), Scope.snsapi_base);
	    		autorizationUrl = autorizationUrl.replace("STATE", Authorization.promotion.name());
	    		LOGGER.debug("未知的用户，使用授权获取openId来查询对应userId######");
	    		LOGGER.debug("授权url : {} ######", autorizationUrl);
	    		return new ModelAndView(autorizationUrl);
            }
            // 获取用户信息
            UserInfo user = iMemberService.findMembCentInfo(userId);
            GroupBuyExt groupBuy = iGroupBuyService.getGroupBuyExtByPromotionId(promotionId);
            // 获取用户是否已付保证金
            int hasPay = 0;
            // 用户是否报名成功
            PromotionSubscription result = null;
            if (user != null) {
                result = promotionSubscriptionService.getPromotionSubscriptionStatus(promotionId, user.getMobile());
                if (result != null) {
                	hasPay = result.getSubscriptionStatus();
                	mv.addObject("subscriptionId", result.getSubscriptionId());
                }
            }
            mv.addObject("hasPay", hasPay);
            checkStatus(groupBuy);
            // 如果活动状态不是5,6,7(5 已发布, 6进行中, 7 已结束)，则活动不予显示
            if (!(PromotionStatus.PUBLISHED.code().equals(groupBuy.getPromotionStatus())
                    || PromotionStatus.ONGOING.code().equals(groupBuy.getPromotionStatus())
                    || PromotionStatus.FINSHED.code().equals(groupBuy.getPromotionStatus()))) {
                mv.setViewName(ERROR_FTL);
    			return mv;
            }
            //获得团购的规则
            if(groupBuy.getContentId()!=null){
            	mv.addObject("ruleContent", rtfExtService.readRTF(groupBuy.getContentId()));
            }
            //获得团购的状态
            GroupBuyVO groupBuyVO = iGroupBuyService.getGroupBuyVO(promotionId);
            mv.addObject("groupBuyStatus", groupBuyVO.getGbStatus());
            mv.addObject("groupBuy", groupBuy);
            mv.addObject("userId", userId);
            // 用于页面倒计时
            mv.addObject("nowTime", System.currentTimeMillis());
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            mv.setViewName(ERROR_FTL);
			return mv;
        }
        return mv;
    }
    
    @RequestMapping("/mbadd/{userId}/{promotionId}")
    public ModelAndView addJieTiGou(@PathVariable("userId") Long userId,@PathVariable("promotionId") Long promotionId,HttpServletRequest request){
    	ModelAndView mv = new ModelAndView(FTL_MBPAY);
    	try {
            // 获取用户是否登陆
            if (userId == -1) {
        		//如果userId=-1，跳转到授权页面去 ，同时需要在AccountController的userLogin和userRegister跳转到对应的url
        		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm?orderId="+promotionId), Scope.snsapi_base);
        		autorizationUrl = autorizationUrl.replace("STATE", Authorization.promotion.name());
        		LOGGER.debug("未知的用户，使用授权获取openId来查询对应userId######");
        		LOGGER.debug("授权url : {} ######", autorizationUrl);
        		return new ModelAndView(autorizationUrl);
            }
            GroupBuyExt groupBuy = iGroupBuyService.getGroupBuyExtByPromotionId(promotionId);
            mv.addObject("deposit", groupBuy.getPromotionExtend().getDeposit());
            mv.addObject("promotionId", promotionId);
    	}catch(Exception e){
    		LOGGER.error(e.getMessage(), e);
    		mv.setViewName(ERROR_FTL);
			return mv;
    	}
    	return mv;
    }
    
	 /**
     * 功能描述: 根据时间来判断状态,而不是直接使用状态<br>
     * 
     * @param GroupBuyExt groupBuy
     */
    private void checkStatus(GroupBuyExt groupBuy) {
        if (groupBuy != null) {
            Date now = new Date();
            if (now.before(groupBuy.getStartTime())) {
            	groupBuy.setPromotionStatus(5);
            } else if (now.after(groupBuy.getEndTime())) {
            	groupBuy.setPromotionStatus(7);
            } else if(now.after(groupBuy.getStartTime()) && now.before(groupBuy.getEndTime())){
            	groupBuy.setPromotionStatus(6);
            }
        }
    }
    
}
