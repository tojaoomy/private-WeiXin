package com.saic.ebiz.market.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.component.wx.job.TicketJob;
import com.saic.ebiz.market.common.entity.authentication.Token;
import com.saic.ebiz.market.common.entity.menu.manager.SaicMenuManager;
import com.saic.ebiz.market.common.util.CommonUtil;
import com.saic.ebiz.market.common.util.MenuUtil;

@RestController
@RequestMapping("/menu")
public class MenuController {
    
    @Autowired
    private TicketJob ticketJob;
	
	@ResponseBody
	@RequestMapping("/create/{sit}/{appid}/{appsecret}")
	public ModelAndView createMenu(@PathVariable("sit")String sit,
    		@PathVariable("appid")String appid, @PathVariable("appsecret")String appsecret, HttpServletRequest request){
		ModelAndView mv = new ModelAndView("/ftlib/menu.ftl");
		
		String token = ticketJob.getToken();
		//Token token = CommonUtil.getAccessToken(appid,appsecret);
        if (token != null) {
        	if(sit.equals("prd")){
        		sit="";
        	}
            int result = MenuUtil.createMenu(SaicMenuManager.getMenuNew("."+sit), token);
            mv.addObject("result", result);
            if (result == 0) {
            	mv.addObject("msg", "菜单生成成功！");
            } else {
            	mv.addObject("msg", "菜单生成失败！");
            }
        }
        return mv;
	}
}
