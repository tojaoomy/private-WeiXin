/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.service.BoundingService;

/**
 * @author hejian
 *
 */
@RestController
public class MockController {
	
	private static Logger logger = LoggerFactory.getLogger(MockController.class);
	
	@Resource
	private BoundingService boundingService;
	
	static{
		System.setProperty("app.development.mock", "false");
		System.setProperty("system.development.mock", "true");
		System.setProperty("system.show.alert", "true");
	}
	
	/**
	 * 显示弹框
	 * @return
	 */
	@RequestMapping("/showAlert")
	public synchronized String showAlert(){
		System.setProperty("system.show.alert", "true");
		return System.getProperty("system.show.alert");
	}
	
	/**
	 * 隐藏弹框
	 * @return
	 */
	@RequestMapping("/hideAlert")
	public synchronized String hideAlert(){
		System.setProperty("system.show.alert", "false");
		return System.getProperty("system.show.alert");
	}
	
	/**
	 * 开发时是否mock数据
	 * @param mode
	 * @return
	 */
	@RequestMapping("/dev/{mode}")
	public synchronized String devMode(@PathVariable("mode") boolean mode){
		System.setProperty("system.development.mock", String.valueOf(mode));
		String devMode = System.getProperty("system.development.mock");
		String appMode = System.getProperty("app.development.mock");
		logger.info("MockController => System.getProperty('system.development.mock') : " + devMode);
		StringBuilder builder = new StringBuilder();
		builder.append("system.development.mock : ").append(devMode).append("\t\n")
		.append("app.development.mock : ").append(appMode);
		return builder.toString();
	}
	
	/**
	 * 程序系统是否mock数据
	 * @param mode
	 * @return
	 */
	@RequestMapping("/app/{mode}")
	public synchronized String appMode(@PathVariable("mode") boolean mode){
		System.setProperty("app.development.mock", String.valueOf(mode));
		String devMode = System.getProperty("system.development.mock");
		String appMode = System.getProperty("app.development.mock");
		logger.info("MockController => System.getProperty('app.development.mock') : " + appMode);
		
		StringBuilder builder = new StringBuilder();
		builder.append("system.development.mock : ").append(devMode).append("\t\n")
		.append("app.development.mock : ").append(appMode);
		return builder.toString();
	}
	
	@RequestMapping("/mock")
	public synchronized String mock(){
		System.setProperty("system.development.mock", "true");
		System.setProperty("app.development.mock", "true");
		String devMode = System.getProperty("system.development.mock");
		String appMode = System.getProperty("app.development.mock");
		
		StringBuilder builder = new StringBuilder();
		builder.append("system.development.mock : ").append(devMode).append("\t\n")
		.append("app.development.mock : ").append(appMode);
		return builder.toString();
	}
	
	@RequestMapping("/mockPay")
	public ModelAndView mockPay(){
		String url = "/pay/pay_success.ftl";
//		url = "/pay/pay_error.ftl";
		return new ModelAndView(url).addObject(RequestConstants.ORDER_ID, "201405935930495").addObject(RequestConstants.USER_ID, "559592");
	}
	
	@RequestMapping("/inactive/{userId}/{token}")
	public String inactiveUserByUserId(@PathVariable("userId") Long userId,@PathVariable("token") String token){
		if("chexiang".equalsIgnoreCase(token)){
			Boolean bool = boundingService.deleteWebAccountByUserId(userId);
			if(bool){
				return "删除用户" + userId + "成功";
			}
			return "删除用户" + userId + "失败";
		}else{
			return "token不正确";
		}
	}
}
