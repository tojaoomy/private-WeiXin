package com.saic.ebiz.market.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.saic.ebiz.comment.service.api.IUserCommentService;
import com.saic.ebiz.comment.service.entity.Evaluation;
import com.saic.ebiz.comment.service.vo.EvaluationVO;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.constant.JsonMapDto;
import com.saic.ebiz.market.constant.MmsConstants;
import com.saic.ebiz.market.constant.PreOrderQueryBean;
import com.saic.ebiz.market.constant.ShowPreOrderVo;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.service.MemberOrderService;
import com.saic.ebiz.mdm.partner.client.StoreClient;
import com.saic.ebiz.mediastorage.exception.MediaStorageFailException;
import com.saic.ebiz.order.service.api.PreOrderCancelService;
import com.saic.ebiz.order.service.entity.dto.PreOrderQueryCustResultDTO;
import com.saic.ebiz.promotion.service.api.IActOrderQueryService;
import com.saic.ebiz.promotion.service.api.IClaimService;
import com.saic.ebiz.promotion.service.api.routine.IRoutineCarService;
import com.saic.ebiz.promotion.service.entity.routine.ClaimEntity;
import com.saic.ebiz.promotion.service.vo.RoutineCarOrder;
import com.saic.ebiz.promotion.service.vo.routine.RoutineCar;
import com.saic.framework.redis.client.IRedisClient;
import com.saike.filestorage.client.DefaultFileStrorageClient;
import com.saike.filestorage.domain.FileType;
import com.saike.filestorage.exception.FileSizeExceedException;
import com.saike.filestorage.exception.FileStorageFailException;


/**
 * 我的订单<br>wx
 * 
 */
@Controller
@RequestMapping("/myorder")
public class MyOrderController {

	/** The Constant logger. */
    private static final Logger LOGGER = LoggerFactory.getLogger(MyOrderController.class);

    
	/**  我的订单路径. */
    private static final String FTL_ORDERLIST = "/wxorder/orderList.ftl";
    /**  我的订单路径. */
    private static final String FTL_AJAXEORDER = "/wxorder/ajaxOrder.ftl";
    /**  订单详情路径. */
    private static final String FTL_DETAIL = "/wxorder/orderDetail.ftl";
    /**  发表评论路径. */
    private static final String FTL_EVALUATE = "/wxorder/evaluate.ftl";
    /**  申请赔付路径. */
    private static final String FTL_COMPENSATE = "/wxorder/compensate.ftl";
    /**  申请赔付路径. */
    private static final String FTL_APPLYCANCLE = "/wxorder/applyCancle.ftl";
    /**  错误信息路径. */
    private static final String ERROR_FTL = "error/error-404.ftl";
    
    @Resource
	private IActOrderQueryService iActOrderQueryService;
    
    @Resource
	private MemberOrderService memberOrderService;
    /** * 常规车客户端. */
    @Resource
    private IRoutineCarService iRoutineCarService;
    /** 店铺客户端. */
    @Autowired
    private StoreClient storeClient;
    
    @Resource
    private IClaimService iClaimService;
    
    @Resource
    private IUserCommentService iUserCommentService;
    
    @Resource
    private PreOrderCancelService preOrderCancelService;
    
    /** 文件存储服务*/
    @Autowired
    private DefaultFileStrorageClient fileStrorageClient;
    
//    /** The fm img url. */
//    @Resource
//    private MultiDomUrl fmImgUrl;
    
    /**缓存接口.*/
    @Resource(name="springRedisClient")
    private IRedisClient redisClient;
    
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
    
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * 分布式存储文件读取地址
	 */
	@Value("${filestorage.url}")
	private String filestorageUrl;
    /**
	 * 分页参数
	 */
	private static int PAGESIZE = 5;
	
    
	/**
	 * 我的订单列表（分页）
	 * @param userId
	 * @param currentPage
	 * @param request
	 * @return
	 */
    @RequestMapping(value="/orderList/{userId}/{currentPage}",method={RequestMethod.GET})
    public ModelAndView searchOrderList(@PathVariable("userId")Long userId,
    		@PathVariable("currentPage")Integer currentPage,
    		@RequestParam(value="countPage",required=false) Integer countPage,
    		HttpServletRequest request){
    	LOGGER.info(getClass() + " => getMyActOrderList ####### userId : {}, currentPage : {}", userId, currentPage);
    	if(userId == -1){
    		//如果userId=-1，跳转到授权页面去 ，同时需要在AccountController的userLogin和userRegister跳转到对应的url
    		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
    		autorizationUrl = autorizationUrl.replace("STATE", Authorization.order.name());
    		LOGGER.debug("未知的用户，使用授权获取openId来查询对应userId######");
    		LOGGER.debug("授权url : {} ######", autorizationUrl);
    		return new ModelAndView(autorizationUrl);
    	}
    	
        /**
		 * 分页条件
		 */
    	ModelAndView mv = new ModelAndView(FTL_ORDERLIST);
		Pagination page = new Pagination();
		if(null != currentPage && currentPage == 1){
			page.setCurrentPage(currentPage);
		}else if(null != currentPage && currentPage > 1){
			page.setCurrentPage(currentPage);
			mv = new ModelAndView(FTL_AJAXEORDER);
		}
		if(countPage != null){
			page.setCurrentPage(1);
			page.setPagesize(PAGESIZE*countPage);
			mv = new ModelAndView(FTL_AJAXEORDER);
		}else{
			page.setPagesize(PAGESIZE);
		}
		
    	// 用于页面显示数据格式
        PaginationResult<List<PreOrderQueryBean>> listPro = null;
    	try {
    		listPro = memberOrderService.queryAllOrderByParmes(userId, page);
    		Pagination pagination = listPro.getPagination();
    		int currentPage2 = pagination.getCurrentPage();
    		mv.addObject("currentPage", currentPage2);
    		mv.addObject("preOrderList", listPro.getR());
		} catch (Exception e) {
			LOGGER.error("调用memberOrderService接口查询我的订单异常：{}",e.getMessage());
			e.printStackTrace();
		}
		return mv;
	}
    
    
    /**
     * 获取订单是否已发表评论
     * @param userId
     * @param orderIds
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/showStatus/{userId}")
    public JsonMapDto isEvaluate (@PathVariable(value="userId") Long userId,@RequestParam String orderIds,HttpServletRequest request){
    	JsonMapDto jsonMapDto = JsonMapDto.getFaile();
    	Map<String, Object> resultMap = Maps.newHashMap();
    	try {
    		String[] orders = orderIds.split(",");
    		List<ShowPreOrderVo> orderIdList = new ArrayList<ShowPreOrderVo>();
    		List<String> evaluateOrderId = iUserCommentService.getIfEvalueateList(userId, 8);
    		List<Long> claimOrderId = iClaimService.queryApplyedActOrdersByUserId(userId);
    		ShowPreOrderVo mapDto = null;
    		PreOrderQueryBean preOrderQueryBean = null;
    		ClaimEntity claimEntity = null;
    		for (int i = 0; i < orders.length; i++) {
				mapDto = new ShowPreOrderVo();
				mapDto.setPreOrderId(orders[i]);
    			if(orders[i] != null && orders[i].length() > 0 && evaluateOrderId.contains(orders[i])){
    				mapDto.setIsEvaluate(1);
				}
    			preOrderQueryBean = memberOrderService.queryOrderDetailByParmes(orders[i], userId.intValue());
				mapDto.setMayCompensate(doisCompensate(preOrderQueryBean.getInquiryOrderId()));
				if(mapDto.getMayCompensate() == 1 && orders[i] != null && orders[i].length() > 0 && claimOrderId.contains(Long.valueOf(preOrderQueryBean.getInquiryOrderId()))){
					claimEntity = iClaimService.findClaimDetailByActOrderId(preOrderQueryBean.getInquiryOrderId());
					mapDto.setIsCompensate(1);
					mapDto.setCliemStatus(claimEntity.getClaimStatus());
				}
				orderIdList.add(mapDto);
			}
    		resultMap.put("lst", orderIdList);
    		jsonMapDto = JsonMapDto.getSuccess();
        	jsonMapDto.setResult(resultMap);
		} catch (Exception e) {
			LOGGER.error("调用iUserCommentService接口查询订单评论信息异常：{}",e.getMessage());
			return jsonMapDto;
		}
		return jsonMapDto;
	}
    
    /**
     * 订单详情
     * @param orderId
     * @param request
     * @return
     */
	@RequestMapping("/order/{userId}/{orderId}")
    public ModelAndView orderDetail (@PathVariable(value="userId") Long userId,@PathVariable String orderId,HttpServletRequest request){
        ModelAndView mv = new ModelAndView(FTL_DETAIL);
    	try {
    		// 调用接口查询订单明细详情
            PreOrderQueryBean  proBean = memberOrderService.queryOrderDetailByParmes(orderId, userId.intValue());
            if (proBean == null) {
            	mv.setViewName(ERROR_FTL);
                return mv;
            }
            mv.addObject("proBean", proBean);
		} catch (Exception e) {
			LOGGER.error("调用memberOrderService接口查询订单详情异常：{}",e.getMessage());
			e.printStackTrace();
			mv.setViewName(ERROR_FTL);
			return mv;
		}
		return mv;
	}
    
    /**
     * 发表评论
     * @param order
     * @param request
     * @return
     */
    @RequestMapping("/evaluate/{userId}/{orderId}")
    public ModelAndView evaluate(@PathVariable(value="userId") Long userId,@PathVariable String orderId,HttpServletRequest request){
    	ModelAndView mv = new ModelAndView(FTL_EVALUATE);
    	//根据orderId查询是否发表评论过
    	List<EvaluationVO> evaluations = null;
    	try {
			evaluations = iUserCommentService.findEvaluationByObjectId(orderId, userId);
		} catch (Exception e) {
			LOGGER.error("调用iUserCommentService接口查询订单的评论信息异常：{}",e.getMessage());
		}
    	if(evaluations != null && evaluations.size() > 0){
    		mv.addObject("star", evaluations.get(0).getScore());
    		mv.addObject("claimComment", evaluations.get(0).getContent());
    	}else{
    		mv.addObject("orderId", orderId);
    		mv.addObject("userId", userId);
    	}
    	return mv;
    }
    
    /**
     * 发表评论
     * @param order
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/evaluateToDo/{userId}")
    public String evaluateToDo(@PathVariable(value="userId") Long userId,@RequestParam String orderId,
    		@RequestParam(value="claimComment",required=true) String content,@RequestParam(value="score",required=true) int score,
    		HttpServletRequest request){
    	String istrue = "0";
		try {
			//功能代码
			PreOrderQueryBean proBean = memberOrderService.queryOrderDetailByParmes(orderId, userId.intValue());
			Evaluation eval = new Evaluation();
			eval.setContent(content);
			eval.setUserId(userId);
			eval.setScore(score);
			eval.setVelBrandId(proBean.getBrandId());
			eval.setVelModelId(proBean.getVelModelId());
			eval.setVelSeriesId(proBean.getVelSeriesId());
        	eval.setObjectId(orderId);
        	eval.setCommentSource(1);
        	eval.setCloseFlag(0);
        	eval.setUserName(proBean.getUserName());
        	eval.setMobile(proBean.getMobileNo());
			if(this.iUserCommentService.addEvaluation(eval)){
				istrue = "1";
			}
		} catch (Exception e) {
			LOGGER.error("调用iUserCommentService接口发表评论异常：{}",e.getMessage());
		}
    	return istrue;
    }
    
    /**
     * 申请赔付
     * @param orderId
     * @param request
     * @return
     */
    @RequestMapping("/compensate/{userId}/{orderId}")
    public ModelAndView compensate(@PathVariable(value="userId") Long userId,
    		@PathVariable String orderId, HttpServletRequest request){
    	ModelAndView mv = new ModelAndView(FTL_COMPENSATE);
    	PreOrderQueryBean preOrderQueryBean = memberOrderService.queryOrderDetailByParmes(orderId, userId.intValue());
    	ClaimEntity claimEntity = iClaimService.findClaimDetailByActOrderId(preOrderQueryBean.getInquiryOrderId());
		if(claimEntity != null && claimEntity.getClaimComment() != null){
			mv.addObject("imgurl", claimEntity.getVoucherImgUrl());
	    	mv.addObject("content", claimEntity.getClaimComment());
		}else{
			mv.addObject("orderId", orderId);
	    	mv.addObject("userId", userId);
		}
    	return mv;
    }
    
    
    /**
     * 获取图片扩展名
     * @param file
     * @return
     * @throws MediaStorageFailException
     */
	private String getFileTypeExtension(byte[] inputStream) {
		String filetype = "";
		try {
			byte[] b = new byte[3];
            for (int i = 0; i < b.length; i++) {
                b[i] = inputStream[i];
            }
            // 获取上传文件的文件头判断是否是jpg格式的图片
            String imgHead = bytesToHexString(b);
            if (MmsConstants.IMAGE_JPEG_JPG.equalsIgnoreCase(imgHead)) {
                filetype = "jpg";
            } else if (MmsConstants.IMAGE_PNG.equalsIgnoreCase(imgHead)) {
                filetype = "png";
            } else if (MmsConstants.IMAGE_GIF.equalsIgnoreCase(imgHead)) {
                filetype = "gif";
            }
		} catch (Exception e) {
            LOGGER.info("img to bytes error",e.getMessage());
        }
		return filetype;
    }
    /**
     * 得到上传文件的文件头
     * @param src 字节数组
     * @return 数据信息
     */
    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder();
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }
    
    /**
     * 申请赔付
     * @param orderId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/compensateToDo/{userId}")
    public String compensateToDo(@PathVariable(value="userId") Long userId,
    		@RequestParam(value="orderId") String orderId,
    		@RequestParam(value="uploadfile",required=true) String basefile,
    		@RequestParam(value="claimComment",required=true) String claimComment){
    	String istrue = "0";
		try{
			//功能代码
			String img = basefile.substring(basefile.indexOf("base64")+7);
			Base64 base64 = new Base64();
			LOGGER.info("********compensateToDo--baseFile:"+basefile+",img:"+img+",base64.decode(img):"+base64.decode(img));
			ByteArrayInputStream in = new ByteArrayInputStream(base64.decode(img));
			String imgSrc = null;
			String fileType = getFileTypeExtension(base64.decode(img));
			// 保存文件到fileStrorage
			 if(!"".equals(fileType) && "JPG".equalsIgnoreCase(fileType)){//图片JPG
					imgSrc = fileStrorageClient.storePublicFile(in,FileType.JPG);
				}else if(!"".equals(fileType) && "GIF".equalsIgnoreCase(fileType)){//图片GIF
					imgSrc = fileStrorageClient.storePublicFile(in,FileType.GIF);
				}else if(!"".equals(fileType) && "PNG".equalsIgnoreCase(fileType)){//图片PNG
					imgSrc = fileStrorageClient.storePublicFile(in,FileType.PNG);
				}
			  LOGGER.info("********compensateToDo--imgSrc:"+imgSrc);
			PreOrderQueryBean preOrderQueryBean = memberOrderService.queryOrderDetailByParmes(orderId, userId.intValue());
			RoutineCarOrder routineCarOrder = iActOrderQueryService.queryActOrderDetail(preOrderQueryBean.getInquiryOrderId());
			ClaimEntity claimEntity = new ClaimEntity();
			claimEntity.setClaimComment(claimComment);
			claimEntity.setActOrderId(routineCarOrder.getActOrderId());
			claimEntity.setRoutineId(routineCarOrder.getRoutineCarId());
			claimEntity.setPromotionId(routineCarOrder.getPrmtActId().longValue());
			claimEntity.setUserId(userId);
			claimEntity.setClaimStatus(1);
			claimEntity.setVoucherImgUrl(filestorageUrl+imgSrc);
	    	if(iClaimService.createClaim(claimEntity)){
				istrue = "1";
			}
    	} catch (Exception e) {
			LOGGER.error("调用iClaimServicr接口申请赔付异常：{}",e.getMessage());
			e.printStackTrace();
		}
		return istrue;
    }
    
//    /**
//     * 本地工具类:
//     * 功能描述: 设置图片路径<br>
//     * @param velColorImgPath
//     * @return
//     * @throws TemplateModelException
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    public String addPath(String velColorImgPath){
//        List<String> args = new ArrayList<String>();
//        args.add(velColorImgPath);
//        String result = "";
//        try {
//            result = String.valueOf(fmImgUrl.exec(args)).replace("images", "img2");
//        } catch (TemplateModelException e) {
//           LOGGER.error("图片路径设置失败");
//        }
//        return result;
//    }
    
    /**
     * 判断订单是否逾期
     * @param pre
     * @return
     */
    @SuppressWarnings("unused")
	private Integer isOverdue(PreOrderQueryBean pre) {
    	Calendar calendar = Calendar.getInstance();   
    	calendar.setTime(pre.getPayTime()); 
//    	calendar.set(Calendar.DAY_OF_MONTH,calendar.get(Calendar.DAY_OF_MONTH)+90);//让日期加1
    	calendar.set(Calendar.MINUTE,calendar.get(Calendar.MINUTE)+60);//让日期加1
    	Calendar now = Calendar.getInstance(); 
    	now.setTime(new Date());
    	int result = calendar.compareTo(now);
    	if(result < 0){
    		return 1;
    	}else{
    		return 0;
    	}
    }
    
    /**
     * 是否承诺差价，是否过期
     * @param actOrderId
     * @return
     */
    private int doisCompensate(String actOrderId) {
    	int isCompensate = 0;
    	try {
			//获得常规车对象，判断是否承诺差价，是否在期限内
			RoutineCarOrder routineCarOrder = iActOrderQueryService.queryActOrderDetail(actOrderId);
			RoutineCar routineCar = iRoutineCarService.findRoutineCarById(routineCarOrder.getRoutineCarId());
			if(routineCar != null && routineCar.getIsPriceDiffCommit() ==1){
				isCompensate = 1;
			}
		} catch (Exception e) {
			LOGGER.error("判断是否可以申请赔付出错！", e);
			return isCompensate;
		}
    	return isCompensate;
    }
    
    /**
     * 取消订单
     * @param orderId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/cancelOrder/{userId}")
    public String cancelOrder(@PathVariable(value="userId") Long userId,@RequestParam String orderId,HttpServletRequest request, HttpServletResponse response){
    	String istrue = "0";
    	try{
	    	//取消订单
    		PreOrderQueryCustResultDTO proBean = memberOrderService.queryOrderDetailByParmes(orderId, userId.intValue());
            if(proBean!=null && !proBean.getStatusCode().equals("42")){
            	preOrderCancelService.cancelPreOrder(orderId, userId, "");
        		istrue = "1";
        		String redisKey = redisClient.get("ms:order:interval:" + orderId,Constants.REDIS_NAME_SPACE,null);
                if (StringUtils.isNotBlank(redisKey)) {
                	LOGGER.info("redis中报名号 " + redisKey);
                    /** 删除redis中的报名号 */
                	redisClient.del(redisKey,Constants.REDIS_NAME_SPACE);
                }
                /** 删除redis中订单号 */
                LOGGER.info("redis中订单号 " + "ms:order:interval:" + orderId);
                redisClient.del("ms:order:interval:" + orderId,Constants.REDIS_NAME_SPACE);
            }
    	} catch (Exception e) {
			LOGGER.error("调用preOrderCancelService接口取消订单异常：{}",e.getMessage());
			e.printStackTrace();
			return istrue;
		}
    	return istrue;
    }

    /**
     * 申请退订的页面
     * @param userId
     * @param orderId
     * @param request
     * @return
     */
    @RequestMapping("/applyCancel/{userId}/{orderId}")
    public ModelAndView applyCancel(@PathVariable(value="userId") Long userId,@PathVariable String orderId,HttpServletRequest request){
    	ModelAndView mv = new ModelAndView(FTL_APPLYCANCLE);
    	mv.addObject("orderId", orderId);
		mv.addObject("userId", userId);
    	return mv;
    }
    
    /**
     * 申请退订的方法
     * @param userId
     * @param orderId
     * @param bankName
     * @param userName
     * @param bankNo
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/applyCancelToDo/{userId}")
    public String applyCancelToDo(@PathVariable(value="userId") Long userId,@RequestParam String orderId,
    		@RequestParam(value="bankName",required=true) String bankName,@RequestParam(value="userName",required=true) String userName,
    		@RequestParam(value="bankNo",required=true) Long bankNo,HttpServletRequest request){
    	String result = "0";
    	System.out.println("用户id:"+userId);
    	System.out.println("订单id："+orderId);
    	System.out.println("持卡人姓名："+userName);
    	System.out.println("开户行："+bankName);
    	System.out.println("银行卡号："+bankNo);
    	return result;
    }

    @RequestMapping("/uploadMoveImage")
	public String uploadMoveImage(HttpServletRequest request,@RequestParam CommonsMultipartFile file){
		String savePath="";
		try {
			savePath=fileStrorageClient.storePublicFile(file.getFileItem().getInputStream(),FileType.JPEG);
		} catch (FileSizeExceedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileStorageFailException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("*****************"+filestorageUrl+savePath);
		LOGGER.error("图片路径：{}",filestorageUrl+savePath);
		return savePath;
	}

    @RequestMapping("/uptest")
	public ModelAndView uptest(){

    	return new ModelAndView("/wxorder/uploadTest.ftl");
	}
}

