package com.saic.ebiz.market.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.util.RegexUtil;
import com.saic.ebiz.market.controller.vo.AuctionVo;
import com.saic.ebiz.market.controller.vo.PromotionVO;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.promotion.service.api.ICustomerInfoTraceService;
import com.saic.ebiz.promotion.service.api.IFollowOrderService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.api.IPromotionSubscriptionService;
import com.saic.ebiz.promotion.service.api.IQuotaFacadeService;
import com.saic.ebiz.promotion.service.api.ISubscriptionDetailService;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;
import com.saic.ebiz.promotion.service.vo.Auction;
import com.saic.ebiz.promotion.service.vo.LotteryResult;
import com.saic.ebiz.promotion.service.vo.UserSubscriptionOrderInfoResult;
import com.saic.framework.url.encrypt.SecurityHelper;
import com.saic.sso.client.SSOClient;


/**
 * 我的活动<br>wx
 * 
 */
@Controller
@RequestMapping("/mypromotion")
public class MyPromotionController {

	/** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(MyPromotionController.class);
    /**
     * 促销活动报名服务
     */
    @Autowired
    private IPromotionSubscriptionService promotionSubscriptionService;

    /**
     * SSO服务
     */
    @Autowired
    private SSOClient ssoClient;

    /**
     * 会员信息服务
     */
    @Autowired
    private IMemberService memberService;

    /**
     * 活动服务
     */
    @Autowired
    private IPromotionService promotionService;

    @Value("${ebiz.ms.web.orderBase:}")
    private String orderBase;
    
    /** 分页数值. */
    private static final int CURRENT_PAGE = 1;
 
    /** 每页显示的条数. */
    private static final int PAGESIZE_SERIES = 5;
    
    private static int MARKETTYPE = 50;
    
    @Autowired
    private IPromotionExtendService iPromotionExtendService;
    
    @Autowired
    private IQuotaFacadeService quotaFacadeService;
    
    /**
     * 活动详情服务
     */
    @Autowired
    private ISubscriptionDetailService subscriptionDetailService;
    
    @Autowired
    private IFollowOrderService followOrderService;
    
    @Autowired
    private ICustomerInfoTraceService customerInfoTraceService;
    
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
    
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
     * 分页查找我的活动WAP
     * @param currentPage
     * @param request
     * @return
     */
    @RequestMapping(value="/promotionlist/{userId}/{marketType}/{currentPage}",method={RequestMethod.GET})
    public ModelAndView getPaginationForWap(@PathVariable(value = "userId")Long userId,@PathVariable(value = "marketType")String marketType,@PathVariable(value = "currentPage") String currentPage,HttpServletRequest request) {
    	logger.info(getClass() + " => getPaginationForWap ####### userId : {}, currentPage : {}", userId, currentPage);
    	if(userId == -1){
    		//如果userId=-1，跳转到授权页面去 ，同时需要在AccountController的userLogin和userRegister跳转到对应的url
    		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
    		autorizationUrl = autorizationUrl.replace("STATE", Authorization.promotionList.name());
    		logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
    		logger.debug("授权url : {} ######", autorizationUrl);
    		return new ModelAndView(autorizationUrl);
    	}
    	 
    	ModelAndView mv = new ModelAndView("/jieti/promotionInfo.ftl");
		 if (currentPage == null) {
			 currentPage = String.valueOf(CURRENT_PAGE);
		 } else {
			 currentPage = String.valueOf(getCountNum(request));
		 } 
		 Integer marketTypeInt = MARKETTYPE;
		//根据活动类型查询
		 if(StringUtils.isNotEmpty(marketType)){
			 marketTypeInt = Integer.parseInt(marketType);
		 	 logger.info("marketType:{}",marketType);
		 }else{
			 marketTypeInt = MarketType.GROUP_BUY_GRADATION_PRICE.code();
		 }
		initPromotion(mv, userId, currentPage,marketTypeInt);
		mv.addObject("serverTime",System.currentTimeMillis());
		mv.addObject("marketType", marketTypeInt);
		mv.addObject("currentPage", currentPage);
		return mv;
    }
    
    /**
     * 分页查找我的活动WAP
     * @param currentPage
     * @param request
     * @return
     */
    @RequestMapping("/promotionlistdetail")
    public ModelAndView getPaginationDetailForWap(@RequestParam(value = "userId", required = false) Long userId,@RequestParam(value = "currentPage", required = false) String currentPage,
    		@RequestParam(value = "marketType", required = false)String marketType,HttpServletRequest request) {
    	logger.info(getClass() + " => getPaginationForWap ####### userId : {}, currentPage : {}", userId, currentPage);
    	if(userId == -1){
    		//如果userId=-1，跳转到授权页面去 ，同时需要在AccountController的userLogin和userRegister跳转到对应的url
    		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
    		autorizationUrl = autorizationUrl.replace("STATE", Authorization.promotionList.name());
    		logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
    		logger.debug("授权url : {} ######", autorizationUrl);
    		return new ModelAndView(autorizationUrl);
    	} 
    	ModelAndView mv = new ModelAndView("/jieti/promotionList.ftl");
		 if (currentPage == null) {
			 currentPage = String.valueOf(CURRENT_PAGE);
		 } else {
			 currentPage = String.valueOf(getCountNum(request));
		 } 
		 Integer marketTypeInt = MARKETTYPE;
		//根据活动类型查询
		 if(StringUtils.isNotEmpty(marketType)){
			 marketTypeInt = Integer.parseInt(marketType);
		 	 logger.info("marketType:{}",marketType);
		 }else{
			 marketTypeInt = MarketType.GROUP_BUY_GRADATION_PRICE.code();
		 }
		initPromotion(mv, userId, currentPage,marketTypeInt);
		mv.addObject("currentPage", currentPage);
		return mv;
    }
	
    
    /**
     * 获取页码. <br>
     * @param request HttpServletRequest
     * @return Integer 页码
     */
    private Integer getCountNum(HttpServletRequest request) {
        
        String paraCount = request.getParameter("currentPage");
        String countNum = String.valueOf(CURRENT_PAGE);
        
        if (null != paraCount
                && RegexUtil.check(RegexUtil.REGEX_MEM, paraCount)) {
            countNum = paraCount;
        }

        return Integer.parseInt(countNum);
    }
    
    /**
     * 初始化活动
     * @param mv
     * @param userId
     * @param currentPageNo
     */
    private void initPromotion(ModelAndView mv,Long userId,String currentPageNo,Integer marketType){
    	
    	 List<PromotionVO> infoList = new ArrayList<PromotionVO>();
    	 
    	 Pagination pagination = new Pagination();
    	 pagination.setCurrentPage(Integer.parseInt(currentPageNo));
    	 pagination.setPagesize(PAGESIZE_SERIES);
         PaginationResult<List<UserSubscriptionOrderInfoResult>> result = null;
		try {
			result = subscriptionDetailService.querySubscriptionOrderInfoByUserId(userId,marketType,pagination);
		} catch (Exception e) {
			logger.error("PaginationResult:{}",e.getMessage());
			e.printStackTrace();
		}
         if(null != result){
        	 logger.info("service返回list的size:"+result.getR().size());
         	List<UserSubscriptionOrderInfoResult> orderInfoList = result.getR();
         	
         	if(null != orderInfoList && orderInfoList.size() > 0){
         		for (UserSubscriptionOrderInfoResult orderInfo : orderInfoList) {
	         			PromotionVO promotionVO = new PromotionVO();
	         			BeanUtils.copyProperties(orderInfo, promotionVO);
	         			if(orderInfo.getMarketType().equals(MarketType.CHEXIANG_BUY.code())
	         					|| orderInfo.getMarketType().equals(MarketType.CHEXIANG_BUY_SECOND.code())
	         					|| orderInfo.getMarketType().equals(MarketType.TIGUAN_PROMOTION.code())){
	         				//车享购  , 车享购二期 , 朗逸定制车
	         				checkStatus(promotionVO);
	         			}else if(orderInfo.getMarketType().equals(MarketType.AUCTION.code())){
	         				//拍卖
	         				setAuctionInfo(promotionVO);
	         			}else if(orderInfo.getMarketType().equals(MarketType.SECKILL.code())){
	         				//秒杀
	         				setSeckillInfo(promotionVO);
	         			}else if(orderInfo.getMarketType().equals(MarketType.GROUP_BUY_GRADATION_PRICE.code())){
	         				//阶梯价团购活动
	         				setGroupBuyGradationInfo(promotionVO);
	         			}
	         			infoList.add(promotionVO);
	         	}
         		
         		//分页设置
         		mv.addObject("maxPageNo", result.getPagination().getPageCount());
         		mv.addObject("currentPageNo", Integer.parseInt(currentPageNo));
         	}else{
         		//分页设置
         		logger.info("我的活动列表为空"); 
            	mv.addObject("maxPageNo", 1);
          		mv.addObject("currentPageNo", 1);
         	}
         }else{
        	logger.info("我的活动列表为空"); 
        	//分页设置
        	mv.addObject("maxPageNo", 1);
      		mv.addObject("currentPageNo", 1);
         }
      	mv.addObject("orderBase", orderBase);
      	mv.addObject("marketType", marketType);
      	logger.info("controller返回页面list的size:"+infoList.size());
      	mv.addObject("infoList",infoList);
    }
    
    /**
     * 阶梯价团购活动信息设置
     * @param promotionVO
     */
    private void setGroupBuyGradationInfo(com.saic.ebiz.market.controller.vo.PromotionVO promotionVO) {
    	logger.info("阶梯价团购活动数据设置start");
    	
    	/** 开始倒计时时间设置*/
    	setStartCountdownDate(promotionVO);
    	/** 结束倒计时时间设置*/
    	setEndDateCountdown(promotionVO);
    	/** 留资倒计时时间设置*/
    	setDepositValidDate(promotionVO);
    	/**设置下单url****/
		try {
			String orderUrl;
			orderUrl = getOrderUrl(promotionVO.getPromotionId(),Long.valueOf(promotionVO.getSubscriptionId()));
			promotionVO.setOrderUrl(orderUrl);
		} catch (Exception e) {
			logger.info("设置活动下单url发生异常: " + e.getMessage());
		}
    	logger.info("阶梯价团购活动数据设置end");
	}
    
    /**
     * 拍卖活动信息设置
     */
    private void setAuctionInfo(PromotionVO auction){
    	logger.info("拍卖数据设置start");
    	Auction curAuction = auction.getAuction();
		AuctionVo tmpAuctionVo = new AuctionVo();
        
		 try {
			// 属性复制
			BeanUtils.copyProperties(curAuction, tmpAuctionVo);
		} catch (Exception e1) {
			logger.info("BeanUtils.copyProperties(curAuction, tmpAuctionVo);出错 :{}",e1.getMessage());
		}
        
		 /** 结束倒计时时间设置*/
        setEndDateCountdown(auction);
        
        logger.info("SubscriptionStatus ::" + auction.getSubscriptionStatus());
        if (auction.getSubscriptionStatus() == 4 ) {
        	/** 留资倒计时时间设置*/
        	setDepositValidDate(auction);
        	
            /** 设置下订单URL*/
            try {
                String orderUrl = getOrderUrl(auction.getPromotionId(),Long.valueOf(auction.getSubscriptionId()));
                tmpAuctionVo.setOrderUrl(orderUrl);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        auction.setAuctionVo(tmpAuctionVo);
        logger.info("拍卖数据设置end");
    }
    
    /**
     * 秒杀活动信息设置
     */
	private void setSeckillInfo(PromotionVO seckill) {
		logger.info("秒杀活动数据设置start");
		
		/** 开始倒计时时间设置*/
		setStartCountdownDate(seckill);
		/** 结束倒计时时间设置*/
		setEndDateCountdown(seckill);
		
		logger.info("SubscriptionStatus ::" + seckill.getSubscriptionStatus());
		if (seckill.getSubscriptionStatus() == 4 ) {
			/** 留资倒计时时间设置*/
			setDepositValidDate(seckill);
		}
		
		logger.info("秒杀活动数据设置end");
	}
    /**
     * 功能描述: 拼接订单URL<br>
     * 
     * @param promotionId
     * @param subscriptionId
     * @return
     * @throws Exception
     * @throws UnsupportedEncodingException
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public String getOrderUrl(Long promotionId, Long subscriptionId) throws Exception {
        String url = null;
        String parUrl = "promotionId=" + promotionId + "&subscriptionId=" + subscriptionId;
        String enToken = new String(Base64.encodeBase64(SecurityHelper.verifyWithMD5(parUrl).getBytes("UTF-8")),
                "UTF-8");
        String token = "&token=" + URLEncoder.encode(enToken, "utf-8");
        url = orderBase + "/buildorder.htm" + "?" + parUrl + token;
        return url;
    }
    
    /**
     * 车享购活动信息设置
     * @param PromotionVO promotion
     */
    private void checkStatus(PromotionVO promotion) {
        //车享购 活动状态(1 已抽奖，未购车；2 已购车未支付；3 已支付，未到店;  4 已到店，未提车; 5 已交车)
	    	// 订单 11：已提交，12：无效，13：已支付，17：待取消，18：确认取消，20：确认成交，21：成交审核不通过
	    	// 页面显示订单状态：未支付,已支付,已到店,已交车
	    	// 1:未到店  2：已到店  3：待交车 4：已交车
    	logger.info("车享购活动数据设置start");
        if (promotion != null) {
        	String orderId = promotion.getOrderId();
        	Short orderStatus = promotion.getOrderStatus();
        	String o2oStatus = promotion.getO2oStatus();
        	List<LotteryResult> lotteryResultList = promotion.getLotteryResultList();
        	for (LotteryResult lotteryResult : lotteryResultList) {
        		lotteryResult.getPrizeName();
        		
			}
        	if(StringUtils.isEmpty(orderId)){
        		//没有订单号为已抽奖,未购车
        		promotion.setPageShowStatus(1);
        	}else{
        		if(orderStatus == 15){
        			//订单号无效为已抽奖,未购车
        			promotion.setPageShowStatus(1);
        		}else if(orderStatus == 11){
        			//2 已购车未支付  
        			promotion.setPageShowStatus(2);
        			promotion.setPageOrderStatus("未支付");
        		}else if(orderStatus == 13 && o2oStatus.equals("1")){
        			//3 已支付，未到店;
        			promotion.setPageShowStatus(3);
        			promotion.setPageOrderStatus("已支付");
        		}else if(o2oStatus.equals("2")){
        			//4 已到店，未提车
        			promotion.setPageShowStatus(4);
        			promotion.setPageOrderStatus("已到店");
        		}else if(o2oStatus.equals("4")){
        			//5 已交车
        			promotion.setPageShowStatus(5);
        			promotion.setPageOrderStatus("已交车");
        		}
        	}
        	 /** 结束倒计时时间设置*/
        	setEndDateCountdown(promotion);
        }
        logger.info("车享购活动数据设置end");
    }
    
    /**
	 * 设置留资倒计时   (将有效期天数加到活动结束时间上,产生最终失效时间)
	 */
	private void setDepositValidDate(PromotionVO promotionVO){
		logger.info("计算留资倒计时begin");
		Date currentTime = new Date();//当前时间
		
		Date promEndDate = promotionVO.getEndTime();
        Calendar cal = Calendar.getInstance();
		cal.setTime(promEndDate);//结束时间
		
		if(promotionVO.getDepositValidPeriod()!=null){
			logger.info("********留资时间="+promotionVO.getDepositValidPeriod());
			cal.add(Calendar.DATE,promotionVO.getDepositValidPeriod());//在结束时间上加上留资有效时间
		}else{
			cal.add(Calendar.DATE,0);//在结束时间上加上留资有效时间
		}	
		
		/**留资最终失效时间*/
		promotionVO.setDepositValidDateLong(cal.getTime().getTime());
		
        //活动还未结束
        if(promotionVO.getPromotionStatus() != 7 || promotionVO.getPromotionStatus() != 8 ){
        	if(null != cal.getTime() && currentTime.before(cal.getTime())){
        		
        		 String timePeriod=DurationFormatUtils.formatPeriod(currentTime.getTime(), cal.getTime().getTime(), "d H");
    			 String days=timePeriod.substring(0,timePeriod.indexOf(" "));
     			 String hours=timePeriod.substring(timePeriod.indexOf(" ")+1);
     			 
     			promotionVO.setDepositValidDayLong(Long.valueOf(days));
     			promotionVO.setDepositValidHourLong(Long.valueOf(hours));
			}
        }
	}
		
	 /**
     * 结束时间倒计时设置
     * @param promotion
     */
    private void setEndDateCountdown(PromotionVO promotion){
    	Date endTime = promotion.getEndTime();
		Date currentTime = new Date();
		if(null != endTime && endTime.after(currentTime)){
			long diff = endTime.getTime() - currentTime.getTime();  //1064825846
			long day = diff/nd;//计算差少
			long hour = diff%nd/nh;//计算差少
			long min = diff%nd%nh/nm;//计算差少钟
			long sec = diff%nd%nh%nm/ns;//计算差少秒//输结
			String endRemainTime = day+"天"+hour+"时"+min+"分"+sec+"秒";
			long endRemainLong = diff/1000;
			/**
			 * 兼容线上活动
			 */
			promotion.setRemainLongTime(endRemainLong);
			promotion.setRemainTime(endRemainTime);
			
			promotion.setEndRemainLong(endRemainLong);
			promotion.setEndRemainTime(endRemainTime);
			promotion.setEndTimeLong(promotion.getEndTime().getTime());
		}
    }
	    
    /**
     * 开始时间倒计时设置
     * @param promotion
     */
    private void setStartCountdownDate(PromotionVO promotion){
    	Date startTime = promotion.getStartTime();
		Date currentTime = new Date();
		if(null != startTime && currentTime.after(startTime)){
			long diff = currentTime.getTime() - startTime.getTime();  //1064825846
			long day = diff/nd;//计算差少
			long hour = diff%nd/nh;//计算差少
			long min = diff%nd%nh/nm;//计算差少钟
			long sec = diff%nd%nh%nm/ns;//计算差少秒//输结
			String startRemainTime = day+"天"+hour+"时"+min+"分"+sec+"秒";
			long startRemainLong = diff/1000;
			
			promotion.setStartRemainLong(startRemainLong);
			promotion.setStartRemainTime(startRemainTime);
			promotion.setStartTimeLong(promotion.getStartTime().getTime());
		}
    }
    
    private static final long nd = 1000*24*60*60;//天秒数
	private static final long nh = 1000*60*60;//小时秒数
	private static final long nm = 1000*60;//钟毫秒数
	private static final long ns = 1000;//秒钟毫秒数
}
