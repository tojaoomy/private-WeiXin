/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: PreOrderController.java
 * Author:   v_xuxuewen01
 * Date:     2014年1月20日 下午12:40:02
 * Description: 预订单控制器   
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.controller;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.gson.GsonView;
import com.ibm.framework.web.validate.ReDistortFormUtil;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.service.OrderService;
import com.saic.ebiz.market.service.PreOrderInfoService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.mdm.partner.client.StoreClient;
import com.saic.ebiz.order.entity.BrandVO;
import com.saic.ebiz.order.entity.PreOrderVO;
import com.saic.ebiz.order.entity.PromotionCity;
import com.saic.ebiz.order.entity.PromotionStore;
import com.saic.ebiz.order.service.SaicOrderService;
import com.saic.ebiz.order.service.entity.PreOrder;
import com.saic.ebiz.order.service.exception.PreOrderQuotaLackException;
import com.saic.ebiz.order.utils.CookieCityUtil;
import com.saic.ebiz.promotion.service.api.IFollowOrderForMainSiteService;
import com.saic.ebiz.promotion.service.api.IGroupBuyService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.api.IQuotaFacadeService;
import com.saic.ebiz.promotion.service.entity.PromotionMerchandiseEntity;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionSubscription;
import com.saic.framework.redis.client.IRedisClient;
import com.saic.sso.client.SSOClient;

/**
 * 预订单控制器. 〈功能详细描述〉
 * 
 * @author v_xuxuewen01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/mobileorder")
public class PreOrderController {

    /** The Constant LOGGER. */
    private final Logger LOGGER = LoggerFactory.getLogger(PreOrderController.class);

    /** The channel no. 渠道 */
    private static final String CHANNEL_NO = "92";
    
    /** ftl模板order对象属性. */
    private static final String FTL_ORDER_ATTR = "preOrderVO";
    
    /** 订购数量. */
    private static final int CAR_AMOUNT = 1;
    
    /**  redis获取剩余时间错误返回值. */
    private static final int REDIS_TTL_ERROR = -1;
    
    /**  每小时分钟数. */
    private static final int MINUTE_PER_HOUR = 60;
    
    /**  redis 操作. */
    @Resource(name="springRedisClient") 
    private IRedisClient redisClient;
    
//    /** The member info service. */
    /**
	 * 新mdm服务
	 */
    @Resource(name = "userService")
    private UserService userService;
    
    @Resource
    private IUserService iUserService;
    
    @Resource
    private IPromotionService iPromotionService;
    @Resource
    private PreOrderInfoService preOrderInfoService;
    
    /** 促销子站提供的服务. */
    @Resource(name = "iFollowOrderForMainSiteService")
    private IFollowOrderForMainSiteService iFollowOrderForMainSiteService;
    
    /**
	 * 活动服务
	 */
	@Autowired
	private IGroupBuyService iGroupBuyService;
    /**
     * 服務优化接口
     */
    @Resource(name="orderService")
    private OrderService orderService;
    
    
    /** 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");
	
	
	/**The default deposit account*/
	private static final String ERROR_MSG = "0.01";
	

	/** 获取新活动扩展信息 */
	@Resource
	private IPromotionExtendService iPromotionExtendService;

	/** 获取配额新服务 */
    @Autowired
    private IQuotaFacadeService quotaFacadeService;
    
    /** 店铺客户端服务  */
    @Resource
    private StoreClient storeClient;
    
    @Resource
    private SSOClient ssoClient;
    
	/** 车享订单服务 */
	@Resource
	private SaicOrderService saicOrderService;
	
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;

	@Resource
	private BoundingService boundingService;
	
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;

	   
	/**
	 * 
	 * 功能描述: 获取(车享购活动活动)店铺的列表 包括库存和QQ<br>
	 * 〈功能详细描述〉
	 * 
	 * @param promotionId 	活动ID
	 * @param productId		车型ID
	 * @param colorId		颜色ID
	 * @param cityId		城市ID
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping("/saic/getDealerStoreList")
	public GsonView getDealerStoreList(
			@RequestParam(value = "promotionId" , required=true) Long promotionId,
			@RequestParam(value = "vehicleModelId" , required=true) Long vehicleModelId,
			@RequestParam(value = "colorId" , required=true) Long colorId,
			@RequestParam(value = "cityId" , required=true) Long cityId) {
		GsonView gson = new GsonView();
		this.LOGGER.info("-=-=-=-=活动ID : {},车型ID : {},颜色ID : {}, 城市ID : {} -=-=-=-=- ", promotionId,vehicleModelId,colorId,cityId);
		List<PromotionStore> storeList = this.orderService.getDealerStoreList(promotionId, vehicleModelId, colorId, cityId);
		Promotion promotion = this.iPromotionService.getPromotion(promotionId);
		if(promotion != null){
			Integer quotaMode = promotion.getQuotaMode();
			//全局配额模式1，车系库存限额设置到车系3或者车型7 ，在前台不显示配额
			if(quotaMode == 1 || quotaMode == 3 || quotaMode == 7){
				gson.addStaticAttribute("displayStock", false);
			}else{
				gson.addStaticAttribute("displayStock", true);
			}
		}
		gson.addStaticAttribute("storeList", storeList);
		return gson;
	}

	/**
	 * @param promotionId
	 * @param showProvince TRUE显示省份和城市列表 ,FALSE在预订单页只显示城市
	 * @return
	 */
	@RequestMapping("/province/city")
    @ResponseBody
	public GsonView getProvinceCityByPromotionId(@RequestParam(value = "promotionId" , required=true) Long promotionId,
			@RequestParam(value = "vehicleModelId" , required=true) Long vehicleModelId,
			@RequestParam(value = "colorId" , required=true) Long colorId){
		GsonView gv = new GsonView();
		List<PromotionCity> cityVO = this.orderService.getCityOnly(promotionId,vehicleModelId,colorId);
		gv.addStaticAttribute("cityVO", cityVO);
		return gv;
	}
    
    /**
     * 功能描述: 处理minisit过来的请求.<br>
     * 
     * @param request the request
     * @param session the session
     * @param userTel the user tel
     * @param promotionId the promotion id
     * @param subscriptionId the subscription id
     * @param benefit 权益描述base64转码
     * @param token 加密字符串
     * @return the model and view
     * @throws UnsupportedEncodingException the unsupported encoding exception
     */
    @RequestMapping("/buildorder" )
    public ModelAndView handleUrl(HttpServletRequest request,
            @RequestParam(value = "promotionId", required = true) Long promotionId,
            @RequestParam(value = "subscriptionId", required = true) Long subscriptionId,
            @RequestParam(value = "userId", required = true) String userId
            ) throws UnsupportedEncodingException {
    		PreOrderVO preOrderVO = new PreOrderVO();
    		preOrderVO.setUserId(userId);
    		preOrderVO.setPromotionId(promotionId);
    		preOrderVO.setSubscriptionId(subscriptionId);
    		
    		// 得到用户的信息
    		UserBaseInfoVO memberCentInfoVO = userService.findBaseInfoByUserId(Long.valueOf(userId));
    		DataItemBean dataItemBean = null;
    		if (memberCentInfoVO != null) {
    			// 设置真实名称
    			preOrderVO.setUserName(memberCentInfoVO.getName());
    			preOrderVO.setUserTel(memberCentInfoVO.getMobile());
    			dataItemBean = ConstantCodeService
    					.getRegionInfo(String.valueOf(memberCentInfoVO.getCity()));
    		}
		     // 设置用户默认城市和省
    		if (dataItemBean != null) {
		        preOrderVO.setProvinceId(dataItemBean.getParentCode());
		        preOrderVO.setProvinceName(dataItemBean.getParentName());
		        preOrderVO.setCityId(dataItemBean.getCode());
		        preOrderVO.setCityName(dataItemBean.getName());
    		}
    		PromotionSubscription subscription = iFollowOrderForMainSiteService.getPromtionSubscriptionById(preOrderVO.getSubscriptionId());
    		preOrderVO.setPrmtDesc(subscription.getPromotionBenefit());
    		Promotion promotion = iPromotionService.getPrmtMdseInfoForModel(promotionId);
    		List<BrandVO> brandVOList = orderService.getModelList(promotion,subscriptionId);
    		if(brandVOList != null && brandVOList.size() > 0){
    			preOrderVO.setBrandId(brandVOList.get(0).getValue());
    			preOrderVO.setBrandName(brandVOList.get(0).getText());
    			preOrderVO.setSeriesId(brandVOList.get(0).getChildren().get(0).getValue());
    			preOrderVO.setSeriesName(brandVOList.get(0).getChildren().get(0).getText());
    			preOrderVO.setProductId(brandVOList.get(0).getChildren().get(0).getChildren().get(0).getValue().toString());
    			preOrderVO.setProductName(brandVOList.get(0).getChildren().get(0).getChildren().get(0).getText());
    		}
            return new ModelAndView("/order/builderOrder.ftl")
                .addObject(FTL_ORDER_ATTR, preOrderVO);
    }
    
    
    /**
	 * 功能描述: 根据活动和车型，获取预订单车型信息列表.<br>
	 * 
	 * @param promotionId 活动
	 *            
	 * @param vehicleModelId 车型
	 *             
	 * @return json
	 * 
	 * 返回样式
	 * 品牌 
	 * 	车系 
	 * 	    车型	
	 * 	       颜色	
	 * -----------------------------
	 * 雪佛兰
	 * 	迈锐宝
	 * 	 2013款 2.4L AT 旗舰版
	 * 	     伯爵黑，罗紫兰
	 * 
	 * @since 从车享购三期开始，一个活动定位多个商品，但是根据需求，活动页会点击具体的商品，无需查询数据库
	 * 
	 * 
	 */
	@RequestMapping("/saic/vehicleModelList")
	public GsonView getVehicleModelList(
			@RequestParam(value = "promotionId", required = true) Long promotionId,
			@RequestParam(value = "brandId", required = false) Long brandId,
			@RequestParam(value = "seriesId", required = false) Long seriesId,
			@RequestParam(value = "subscriptionId", required = false) long subscriptionId) {
		GsonView gson = new GsonView();
		Promotion promotion = iPromotionService.getPrmtMdseInfoForModel(promotionId);
		List<BrandVO> brandVOList = orderService.getModelList(promotion,subscriptionId);
		// 配额判断
		if (brandVOList == null || brandVOList.size() == 0) {
			// 设置为“”，因为js中判断的时候data的长度
			gson.addStaticAttribute("modelList", "");
		} else {
			gson.addStaticAttribute("modelList", brandVOList);
		}
		return gson;
	}
    
    /**
     * 功能描述: 填写个人信息<br>
     * .
     * 
     * @param request the request
     * @param preOrderVO the pre order vo
     * @param result the result
     * @return the model and view
     * @throws UnsupportedEncodingException the unsupported encoding exception
     */
    @RequestMapping(value="/order/buildInfo", method=RequestMethod.POST)
    public ModelAndView buildPersonInfo(HttpServletRequest request,
            @ModelAttribute(FTL_ORDER_ATTR) PreOrderVO preOrderVO,
            BindingResult result) throws UnsupportedEncodingException {
        
        // 防篡改
        boolean isDistorToken = ReDistortFormUtil.isDistorToken(request);
        if (isDistorToken) {
            LOGGER.warn("表单被篡改");
            return new ModelAndView("/order/car-error-distort.ftl");
        }
        //得到店铺
        List<PromotionStore> storeBaseInfoList = orderService.getDealerStoreList(preOrderVO.getPromotionId(), Long.valueOf(preOrderVO.getProductId()), Long.parseLong(preOrderVO.getColorId()),Long.parseLong(preOrderVO.getCityId()));
        //获取商品的价格
        for (PromotionStore storeBaseInfo : storeBaseInfoList) {
            if (preOrderVO.getStoreId().compareTo(storeBaseInfo.getStoreId())==0) {
                BigDecimal temp = orderService.getPromotionDeposit(preOrderVO.getPromotionId());
                preOrderVO.setDeposit(String.valueOf(temp));
                break;
            }
        }
        // 得到当前城市id
        long cityId = CookieCityUtil.getCityId(request);
        LOGGER.info("从cookie中得到城市id：cityId=" + cityId);
        DataItemBean dataItemBean = ConstantCodeService.getRegionInfo(String.valueOf(cityId));
        // 设置用户默认城市和省
        if (dataItemBean != null) {
            preOrderVO.setProvinceId(dataItemBean.getParentCode());
            preOrderVO.setProvinceName(dataItemBean.getParentName());
            preOrderVO.setCityId(dataItemBean.getCode());
            preOrderVO.setCityName(dataItemBean.getName());
        }
        
        // 得到当前登陆的用户ID
        String userIds = preOrderVO.getUserId();
        // 得到用户的信息
        UserBaseInfoVO memberCentInfoVO = userService.findBaseInfoByUserId(Long.valueOf(userIds));
        if (memberCentInfoVO != null) {
            preOrderVO.setUserName(memberCentInfoVO.getName());
        }
        
        PromotionSubscription subscription = iFollowOrderForMainSiteService.getPromtionSubscriptionById(preOrderVO.getSubscriptionId());
        preOrderVO.setPrmtDesc(subscription.getPromotionBenefit());
        preOrderVO.setUserTel(subscription.getMobile());
        
        // 验证用户改subid是否已下过单, 如果存在获取剩余时间
        int remainInterval = orderRemainInterval(preOrderVO);
        
        return new ModelAndView("/order/wap-useinfo.ftl")
            .addObject(FTL_ORDER_ATTR, preOrderVO)
            .addObject("remainInterval", remainInterval);
    }

    /**
     * 功能描述: 提交订单<br>
     * .
     * 
     * @param request the request
     * @param session the session
     * @param preOrderVO the pre order vo
     * @param result the result
     * @return 调到支付页面
     * @throws UnsupportedEncodingException the unsupported encoding exception
     */
    @RequestMapping(value="/order/submit", method=RequestMethod.POST)
    public ModelAndView submitOrder(HttpServletRequest request, HttpSession session,
            @ModelAttribute(FTL_ORDER_ATTR) @Valid PreOrderVO preOrderVO,
            BindingResult result) throws UnsupportedEncodingException {
        // 得到用户的信息
        UserBaseInfoVO memberCentInfoVO = userService.findBaseInfoByUserId(Long.valueOf(preOrderVO.getUserId()));
        if (memberCentInfoVO != null) {
            preOrderVO.setEmail(memberCentInfoVO.getEmail());
        }
        ModelAndView model = null;
        //获取商品信息
        PromotionMerchandiseEntity promotionMerchandise = this.quotaFacadeService.findAvailableNumByPreOrderConditions(preOrderVO.getPromotionId(), Long.valueOf(preOrderVO.getProductId()), Long.valueOf(preOrderVO.getColorId()), preOrderVO.getStoreId());
//        if(promotionMerchandise == null){
//        	model = new ModelAndView("/order/car-lackbalance.ftl").addObject("jumpUrl", jumpUrl);
//        	return model;
//        }
        //预订单信息 存储预订单信息
        PreOrder preOrder = new PreOrder();
        Integer merchandiseId = null;
		if(promotionMerchandise.getMerchandiseId() != null){
			merchandiseId = promotionMerchandise.getMerchandiseId().intValue();
		}
        preOrder.setMerchandiseId(merchandiseId);// 商品id
        preOrder.setPrmtMdseId(Integer.valueOf(promotionMerchandise.getPrmtMdseId().toString()));// 商品信息列表ID
        preOrder.setDealerId(Integer.valueOf(preOrderVO.getStoreId().toString()));// 经销商id
        
        // 重新获取产品价格信息
        //得到店铺
//        List<PromotionStore> storeBaseInfoList = orderService.getDealerStoreList(preOrderVO.getPromotionId(), Long.valueOf(preOrderVO.getProductId()), Long.parseLong(preOrderVO.getColorId()),Long.parseLong(preOrderVO.getCityId()));
        //获取商品的价格
//        for (PromotionStore storeBaseInfo : storeBaseInfoList) {
//            if (preOrderVO.getStoreId().compareTo(storeBaseInfo.getStoreId())==0) {
                BigDecimal temp = orderService.getPromotionDeposit(preOrderVO.getPromotionId());
                preOrderVO.setDeposit(String.valueOf(temp));
//                break;
//            }
//        }
        //获取订单编号
        String orderCode  =  buildOrder(preOrderVO, preOrder,Long.valueOf(preOrderVO.getUserId()));
        // 订单生成失败, 返回
        if (orderCode == null) {
            model = new ModelAndView(ERROR_MSG).addObject("modelName", "订单生成失败").addObject("errorMessage", "订单生成失败");
        // 配额不足
        } else if (StringUtils.EMPTY.equals(orderCode)) {
            model = new ModelAndView(ERROR_MSG).addObject("modelName", "订单生成失败").addObject("errorMessage", "配额不足");
        // 订单生成成功
        } else {
            model = new ModelAndView("redirect:/myorder/orderList/" + preOrderVO.getUserId() + "/1");
        }

        return model;
    }
    
    /**
     * 功能描述: 构建订单<br>
     * .
     * 
     * @param preOrderVO 之前构建的订单信息
     * @param preOrder 需要提交的订单信息
     * @return 成功：正确的订单号， 配额不足：""， 失败：null
     * @throws UnsupportedEncodingException the unsupported encoding exception
     */
    public String buildOrder(PreOrderVO preOrderVO, PreOrder preOrder,Long userId) throws UnsupportedEncodingException {
        Promotion promotion = iPromotionService.getPrmtInfoWithOutName(preOrderVO.getPromotionId());
        String promotionCode = promotion.getPromotionCode();
        LOGGER.info("活动编码:>>"+promotionCode);
        // 渠道编号
        preOrder.setChannelNo(CHANNEL_NO);
        // 促销活动编号
        preOrder.setPrmtActId(Integer.valueOf(preOrderVO.getPromotionId().toString()));
        // 店铺id
        preOrder.setStoreId(Integer.valueOf(preOrderVO.getStoreId().toString()));
        // 品牌id
        preOrder.setBrandId(preOrderVO.getBrandId());
        // 车系id
        preOrder.setVelSeriesId(preOrderVO.getSeriesId());
        // 车型id
        preOrder.setVelModelId(Long.valueOf(preOrderVO.getProductId()));
        // 车型颜色id
        preOrder.setColorId(Long.valueOf(preOrderVO.getColorId()));
        // 预订数量
        preOrder.setAmount(CAR_AMOUNT);
        // 意向金
        preOrder.setDeposit(new BigDecimal(preOrderVO.getDeposit()));
        // Y:表示选择 N：表示为选择
        preOrder.setLoanFlag(preOrderVO.getLoanFlag().equals("Y") ? "Y" : "N");
        preOrder.setNeedInsuranceFlag(preOrderVO.getNeedInsuranceFlag().equals("Y") ? "Y" : "N");
        preOrder.setRegisterLicenceFlag(preOrderVO.getRegisterLicenceFlag().equals("Y") ? "Y" : "N");
        preOrder.setPlanArrivalTime(null);
        // 会员信息
        preOrder.setUserId(Long.valueOf(preOrderVO.getUserId()));
        preOrder.setUserName(preOrderVO.getUserName());
        preOrder.setMobileNo(preOrderVO.getUserTel());
        preOrder.setEmail(preOrderVO.getEmail());
        
        // 重新获取礼包信息
        PromotionSubscription subscription = iFollowOrderForMainSiteService.getPromtionSubscriptionById(preOrderVO.getSubscriptionId());
        preOrder.setPrmtDesc(subscription.getPromotionBenefit());
        
        String orderId = null;
        try {
            orderId = preOrderInfoService.createPreOrder(preOrder, preOrderVO.getSubscriptionId(),preOrderVO.getPromotionId());
            LOGGER.info("生成的订单号:>>"+orderId);
            usertraceLogger.info("微信端创建订单\t"  + "\t"
					+ userId + "\t" + "创建成功" + "\t" + orderId);
            //阶梯团购的已支付订单回调
			this.iFollowOrderForMainSiteService.createFollowOrderForAuction(Long.valueOf(preOrderVO.getUserId()),
						preOrderVO.getSubscriptionId(), orderId, preOrder.getPrmtMdseId().longValue());
        } catch (PreOrderQuotaLackException e) {
            // 配额不足
            orderId = StringUtils.EMPTY;
        } catch (RuntimeException e) {
            LOGGER.error("提交订单出错：", e);
            orderId = null;
        }
        return orderId;
    }
    
    
   
    /**
     * 服务优化，得到车型
     * 功能描述: 根据活动Id，获取预订单车型信息列表.<br>
     * @param promotionId the promotion id
     * @return json
     */
    @RequestMapping("/order/ajax/modelList")
    public GsonView getModelList(@RequestParam(value = "promotionId", required = true) long promotionId) {
        GsonView gson = new GsonView();
        List<BrandVO> modelList = new ArrayList<BrandVO>();
//        modelList.add(orderService.getModelList(promotionId));
        LOGGER.debug("modelList: {}", JSONObject.toJSONString(modelList));
        gson.addStaticAttribute("modelList",modelList);
        return gson;
    }

    
    /**
     * Gets the store json.
     * 
     * @param promotionId the promotion id
     * @param productId the product id
     * @param colorId the color id
     * @param request the request
     * @return the store json
     */
    @RequestMapping("/order/ajax/getStoreJson")
    @ResponseBody
    public List<PromotionCity> getStoreJson(@RequestParam(value = "promotionId", required = true) long promotionId,
            @RequestParam(value = "productId", required = true) long productId,
            @RequestParam(value = "colorId", required = true) long colorId,HttpServletRequest request) {
        //得到店铺
        List<PromotionCity> storeBaseInfoList = orderService.getCityOnly(promotionId, productId, colorId);
        return storeBaseInfoList;
    }
    
    /**
     * 功能描述: 获取同一活动同用户同手机已下订单时间<br>
     * 同用户同subscriptionId仅能提交一次订单.
     * 
     * @param preOrderVO 订单信息
     * @return 剩余时间
     */
    private int orderRemainInterval(PreOrderVO preOrderVO) {
        // 同用户同subscriptionId仅能提交一次订单
        String orderIntervalKey = new StringBuilder("ms:order:interval:")
            .append(preOrderVO.getSubscriptionId()).toString();

        // 验证redis中是否存在key, 如果存在获取剩余时间
        int remainInterval = 0;
        if (redisClient.exists(orderIntervalKey,Constants.REDIS_NAME_SPACE)) {
            remainInterval = redisClient.ttl(orderIntervalKey,Constants.REDIS_NAME_SPACE).intValue();
            // 如果没有过期, 设置为分钟
            if (remainInterval != REDIS_TTL_ERROR) {
                remainInterval = (int)Math.ceil((double)remainInterval/(double)MINUTE_PER_HOUR);
            }
        }
        return remainInterval;
    }
}
