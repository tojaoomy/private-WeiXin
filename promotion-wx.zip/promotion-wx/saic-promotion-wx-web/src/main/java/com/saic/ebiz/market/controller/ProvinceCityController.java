/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.entity.ProvinceSerialVO;
import com.saic.ebiz.market.entity.ProvinceVO;
import com.saic.ebiz.market.service.AreaService;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;

/**
 * @author hejian
 *
 */
@RestController
public class ProvinceCityController {
	
	public Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private AreaService areaService;
	
	private static final String SWITCH_CITY_FTL = "/wxsales/select-address.ftl";
	
	/**
	 * 
	 * @param request
	 * @return 获取所有的城市列表
	 */
	@RequestMapping("/common/city")
	public List<ProvinceVO> getCityList(HttpServletRequest request){
		List<ProvinceVO> list = areaService.getAllProvinces();
		return list;
	}
	
	/**
	 * 三级联动
	 * @param request
	 * @return 获取所有的城市列表
	 */
	@RequestMapping("/common/city/serial")
	public List<ProvinceSerialVO> getCitySerialList(HttpServletRequest request){
		return areaService.getAllProvinceSerials();
	}
	
	/**
	 * 
	 * @param request
	 * @return 
	 */
	@RequestMapping("/city/switch/{userId}/{cityId}")
	public ModelAndView switchCity(HttpServletRequest request,@PathVariable("userId") Long userId,@PathVariable("cityId") Long cityId){
		ModelAndView view = new ModelAndView(SWITCH_CITY_FTL);
		//userId给ftl页面跳转用，跳转完需要清空购物车
		view.addObject(RequestConstants.USER_ID, userId);
		view.addObject("pinyinCities", areaService.getPinyinCity(MarketType.ROUTINE.code()));
		return view;
	}
}
