/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.component.wx.job.TicketJob;
import com.saic.ebiz.market.common.util.CommonUtil;
import com.saic.ebiz.market.entity.qrcode.QrcodeFactory;

/**
 * @author hejian
 *
 */
@RequestMapping("/qrcode")
public class QRController {
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 bdf9bedfd1e36dc2797cddc02847cb88
	 * 测试账号        04a4ea410735b9a134d41ed29ce64699
	 * 
	 */
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
	
    @Autowired
    private TicketJob ticketJob;

	@RequestMapping("/{channelCode}")
	public ModelAndView show(@PathVariable("channelCode") String channelCode){
	    
	    String token = ticketJob.getToken();
	    
		String ticket = CommonUtil.generatePermanentQrcode(appId, appSecret, 
		        QrcodeFactory.createPermanentQrcode(channelCode,"int"), token).getString("ticket");
		return new ModelAndView("https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=" + CommonUtil.encodeURL(ticket));
	}
}
