/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.dal.pagination.Pagination;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.carlib.service.client.BrandClient;
import com.saic.ebiz.carlib.service.client.VelModelInfoClient;
import com.saic.ebiz.carlib.service.client.VelSeriesClient;
import com.saic.ebiz.carlib.service.entity.VelModel;
import com.saic.ebiz.carlib.service.entity.VelModelAttr;
import com.saic.ebiz.market.entity.RoutineCarVO;
import com.saic.ebiz.market.service.RoutineCarService;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;

/**
 * @author hejian
 *
 */
@RestController
@RequestMapping("/routine_car")
public class RoutineCarController {
	private static Logger logger = LoggerFactory.getLogger(RoutineCarController.class);
	
	private static final String ROUTINE_CAR_FTL = "/wxsales/routine_car.ftl";

	private static final String ROUTINE_CAR_CONF_FTL = "/wxsales/car_configuration.ftl";
	
	@Resource
	private RoutineCarService routineCarService;
	
	/**
	 * 车型客户端
	 */
	@Resource
	private VelModelInfoClient velModelInfoClient;
	
	@Resource
	private VelSeriesClient velSeriesClient;
	
	@Resource BrandClient brandClient;
	
	@RequestMapping("/{cityId}/{brandId}/{seriesId}")
	public ModelAndView getRoutineCar(@PathVariable("cityId") Long cityId,@PathVariable("brandId") Long brandId,@PathVariable("seriesId") Long seriesId){
		ModelAndView model = new ModelAndView(ROUTINE_CAR_FTL);
		logger.info("RoutineCarController => getRoutineCar ###### cityId : {},brandId : {},seriesId :{} ",cityId, brandId, seriesId);
		List<RoutineCarVO> routineCars = routineCarService.findConventionalVehicleByPromotionIdSeriesIdColorId(MarketType.ROUTINE.code(), cityId, brandId, seriesId, true, new Pagination());
		logger.info("RoutineCarController => getRoutineCar ###### 返回数据 : " + JSONObject.toJSONString(routineCars));
		model.addObject("routineCars", routineCars);
		return model;
	}
	
	@RequestMapping("/configurations/{models}")
	public ModelAndView getCarConfigurations(@PathVariable("models") String models){
		ModelAndView model = new ModelAndView(ROUTINE_CAR_CONF_FTL);
		logger.info("RoutineCarController => getCarConfigurations ###### models : {}", models);
		//models要么是(车型id)要么是(车型id=车型id)
		String[] modelArray = models.split("=");
		int size = modelArray.length;
		for(int i=0;i<modelArray.length;i++){
			VelModel velModel = velModelInfoClient.findVelModelById(Long.valueOf(modelArray[i]));
			model.addObject("modelName" + i, velModel.getVelModelName());
			model.addObject("seriesName" + i, this.velSeriesClient.findSeriesNameById(velModel.getVelSeriesId()));
			model.addObject("brandName" + i, this.brandClient.findBrandNameById(velModel.getVelBrandId()));
			VelModelAttr attr = velModelInfoClient.findModelWithPropById(Long.valueOf(modelArray[i]));
			System.out.println(JSONObject.toJSONString(attr.getCommonAttrMap()));
			model.addObject("commonAttr" + i, attr.getCommonAttrMap());
			System.out.println(JSONObject.toJSONString(attr.getVelAttrTypeGroupMap().get("发动机")));
			model.addObject("engineAttr" + i, attr.getVelAttrTypeGroupMap().get("发动机"));
			System.out.println(JSONObject.toJSONString(attr.getVelAttrTypeGroupMap().get("车身")));
			model.addObject("bodyAttr" + i, attr.getVelAttrTypeGroupMap().get("车身"));
		}
		model.addObject("size", size);
		return model;
	}
	
	public static void main(String[] args) {
		String[] v = "aaa=bbb".split("=");
		for(String val : v){
			System.out.println(val);
		}
	}
}
