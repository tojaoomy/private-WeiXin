package com.saic.ebiz.market.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.saic.ebiz.carlib.service.api.VelModelInfoService;
import com.saic.ebiz.carlib.service.api.VelSeriesService;
import com.saic.ebiz.carlib.service.entity.VelModel;
import com.saic.ebiz.carlib.service.entity.VelSeries;
import com.saic.ebiz.comment.service.api.IUserCommentService;
import com.saic.ebiz.comment.service.vo.EvaluationVO;
import com.saic.ebiz.comment.service.vo.EvaluatonQuery;

/**
 * 用户分享
 * @author v_liuyong
 *
 */
@RestController
@RequestMapping("/share")
public class ShareController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	/**
	 * 购车分享接口
	 */
	@Autowired
	IUserCommentService iUserCommentService;
	
	/**
	 * 车系接口
	 */
	@Autowired
	VelSeriesService velSeriesService;
	
	/**
	 * 车型接口
	 */
	@Autowired
	VelModelInfoService velModelInfoService;
	
	/**
	 * 分页参数
	 */
	private static int CURRENTPAGE = 1;
	
	private static int PAGESIZE = 10;
	
	/**
	 * 评论审核状态  2（审核通过）
	 */
	private static int SHARE_STATUS = 2;
	
	private static final String SHARE_FTL = "/wxsales/share.ftl";
	private static final String SHARE_MORE_FTL = "/wxsales/share_more.ftl";
	
	@RequestMapping("/queryBrands")
	public ModelAndView queryBrands(){
		
		ModelAndView mv = new ModelAndView(SHARE_FTL);
		return mv;
	}
	
	@RequestMapping("/shareInfo/more")
	public ModelAndView queryShareListMore(@RequestParam(value = "currentPage",required=false)Integer currentPage,
			@RequestParam(value = "brandId")Long brandId){
		logger.info("页面提交分页参数_当前页currentPage : {}, brandId : {}",currentPage,brandId);
		ModelAndView mv = new ModelAndView(SHARE_MORE_FTL);
		String flag = "1";
		/**
		 * 查询条件  审核通过
		 */
		EvaluatonQuery query = new EvaluatonQuery();
		query.setStatus(SHARE_STATUS);
		if(brandId == null){
			brandId = 1L;
		}
		query.setVelBrandId(brandId);
		
		/**
		 * 分页条件
		 */
		Pagination page = new Pagination();
		if(null != currentPage){
			page.setCurrentPage(currentPage);
		}else{
			page.setCurrentPage(CURRENTPAGE);
			currentPage = CURRENTPAGE;
		}
		page.setPagesize(PAGESIZE);
		
		
		PaginationResult<List<EvaluationVO>> result = null;
		try {
			result = iUserCommentService.queryComments(query, page);
//			result = MockShareService.getData(brandId);
		} catch (Exception e) {
			logger.info("调用userCommentService接口查询用户分享异常：{}",e.getMessage());
			e.printStackTrace();
		}
		
		if(null != result){
			List<EvaluationVO> shareList = result.getR();
			if(null != shareList && shareList.size() > 0){
				setMobileStyle(shareList);
				setVelNames(shareList);
				mv.addObject("shareList", shareList);
			}
			Pagination pagination = result.getPagination();
			int totalRows = pagination.getTotalRows();
			int total = currentPage * PAGESIZE;
			if(total > totalRows || total == totalRows){
				flag = "2";
			}
			mv.addObject("flag",flag);
			mv.addObject("currentPage", currentPage);
		}
		return mv;
	}
	
	private void setMobileStyle(List<EvaluationVO> shareList){
		for (EvaluationVO vo : shareList) {
			String mobile = vo.getMobile();
			String startTemp = mobile.substring(0,3);
			String endTemp = mobile.substring(8, mobile.length());
			mobile = startTemp+"*****"+endTemp;
			vo.setMobile(mobile);
			
		}
	}
	
	/**
     * 车型名称,车系名称
     */
    private void setVelNames(List<EvaluationVO> shareList){
    	for (EvaluationVO vo : shareList) {
    		long velSeriesId = vo.getVelSeriesId();
    		VelSeries series = velSeriesService.findSeriesById(velSeriesId);
    		//logger.info("根据车系id查询车系,车系id:{},车系:{}",velSeriesId,JSONObject.toJSONString(series));
    		if(null != series){
    			vo.setVelSeries(series.getVelSeriesChsName());
    		}
    		
    		long velModelId = vo.getVelModelId();
    		VelModel model = velModelInfoService.findVelModelById(velModelId);
    		//logger.info("根据车系id查询车型,车型id:{},车型:{}",velModelId,JSONObject.toJSONString(model));
    		if(null != model){
    			vo.setVelModel(model.getVelModelName());
    		}
		}
    }
}
