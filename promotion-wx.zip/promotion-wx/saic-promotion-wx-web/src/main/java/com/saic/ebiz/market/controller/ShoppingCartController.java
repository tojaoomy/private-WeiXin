/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.entity.ShoppingCart;
import com.saic.ebiz.market.service.ShoppingCartService;

/**
 * @author hejian
 *
 */
@RestController
public class ShoppingCartController {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private static final String CART_FTL = "/wxsales/shoppingCart.ftl";
	
	/** 购物车服务 */
	@Resource
	private ShoppingCartService shoppingCartService;
	
	/**
	 * 根据用户id拉取购物车
	 * @param userId 
	 * @return
	 */
	@RequestMapping(value="/cart/{userId}/{cityId}",method=RequestMethod.GET)
	public ModelAndView loadShoppingCartMerchandise(@PathVariable(value="userId") Long userId,@PathVariable(value="cityId") Long cityId){
		logger.info("ShoppingCartController => loadShoppingCartMerchandise ######## userId : {},cityId : {} ",userId,cityId);
		ModelAndView model = new ModelAndView(CART_FTL);
		List<ShoppingCart> shoppingCart = shoppingCartService.loadByUserId(userId,cityId);
		model.addObject("shoppingCart", shoppingCart);
		logger.info("ShoppingCartController => loadShoppingCartMerchandise ######## 返回 : {}", JSONObject.toJSONString(shoppingCart));
		return model;
	}
	
	/**
	 * 加入购物车功能，实际上加入缓存中
	 * @param userId 用户id
	 * @param routineCarId 常规车id
	 */
	@RequestMapping(value="/cart/{userId}/{routineCarId}/{cityId}",method=RequestMethod.PUT)
	public ModelAndView putIntoCart(@PathVariable(value="userId") Long userId, @PathVariable(value="routineCarId") Long routineCarId,
			 @PathVariable(value="cityId") Long cityId){
		ModelAndView model = new ModelAndView(CART_FTL);
		logger.info("ShoppingCartController => putIntoCart ######## userId : {},routineCarId : {},cityId : {} ",userId, routineCarId ,cityId);
		shoppingCartService.put(userId,cityId,routineCarId);
		logger.info("call shoppingCartService.put(userId, routineCarId) succeed ######");
		List<ShoppingCart> shoppingCart = shoppingCartService.loadByUserId(userId,cityId);
		model.addObject("shoppingCart", shoppingCart);
		logger.info("ShoppingCartController => putIntoCart ######## 返回 : {}", JSONObject.toJSONString(shoppingCart));
		return model;
	}
	
	/**
	 * 移除购物车的商品，实际上删除缓存的key
	 * @param userId 用户id
	 * @param routineCarId 常规车id
	 */
	@RequestMapping(value="/cart/{userId}/{routineCarId}/{cityId}",method=RequestMethod.DELETE)
	public ModelAndView removeFromCart(@PathVariable(value="userId") Long userId, @PathVariable(value="routineCarId") Long routineCarId,
			@PathVariable(value="cityId") Long cityId){
		ModelAndView model = new ModelAndView(CART_FTL);
		logger.info("ShoppingCartController => removeFromCart ######## userId : {},routineCarId : {},cityId : {} ",userId, routineCarId ,cityId);
		shoppingCartService.remove(userId,cityId,routineCarId);
		logger.info("call shoppingCartService.remove(userId, routineCarId) succeed ######");
		List<ShoppingCart> shoppingCart = shoppingCartService.loadByUserId(userId,cityId);
		model.addObject("shoppingCart", shoppingCart);
		logger.info("ShoppingCartController => removeFromCart ######## 返回 : {}", JSONObject.toJSONString(shoppingCart));
		return model;
	}
	
	@RequestMapping("/cart/empty/{userId}")
	public Boolean emptyCart(@PathVariable(value="userId") String userId){
		return shoppingCartService.empty(userId);
	}
}
