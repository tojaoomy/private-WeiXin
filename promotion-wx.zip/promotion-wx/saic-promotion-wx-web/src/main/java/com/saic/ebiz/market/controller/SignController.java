/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.component.wx.util.JsSDKSign;

/**
 * @author hejian
 *
 */
@RestController
@RequestMapping("/sign")
public class SignController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private JsSDKSign jsSDKSign;
	
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@RequestMapping("test")
	public void test(HttpServletRequest request,HttpServletResponse response){
		logger.info("sign : " + JSONObject.toJSONString(jsSDKSign.sign(appId, request.getRequestURL().toString())));
	}
}
