/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.market.entity.DistrictVO;
import com.saic.ebiz.market.service.StoreService;

/**
 * @author hejian
 *
 */
@Qualifier
@RestController
public class StoreController {
	private static Logger logger = LoggerFactory.getLogger(StoreController.class);
	
	private static final String CAR_STORE_FTL = "/wxsales/car_store.ftl";
	
	@Resource
	private StoreService storeService;
	
	@RequestMapping("/store/{cityId}/{promotionId}/{colorId}")
	public ModelAndView getStoreByCreterial(@PathVariable("cityId") Long cityId,@PathVariable("promotionId") Long promotionId,@PathVariable("colorId") Long colorId){
		ModelAndView model = new ModelAndView(CAR_STORE_FTL);
		logger.info("RoutineCarController => getStoreByCreterial ###### cityId : {},promotionId : {},colorId :{} ",cityId, promotionId, colorId);
		List<DistrictVO> districtVOs = storeService.getStoreByCreterial(cityId, promotionId, colorId);
		model.addObject("districtVOs", districtVOs);
		return model;
	}
	
}
