/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ibm.framework.exception.BaseException;
import com.meidusa.fastjson.JSON;
import com.saic.ebiz.component.wx.job.TicketJob;
import com.saic.ebiz.iam.service.api.IAccountService;
import com.saic.ebiz.iam.service.api.IUserService;
import com.saic.ebiz.iam.service.entity.ResponseVO;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.entity.user.BasicPersonalInfoBean;
import com.saic.ebiz.market.common.util.RegexUtil;
import com.saic.ebiz.market.common.util.SendMessageUtil;
import com.saic.ebiz.market.service.AccountService;
import com.saic.ebiz.market.service.ValidateService;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.api.WebAccountService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.mdm.entity.UserVO;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.ebiz.mdm.exception.InParamException;
import com.saic.framework.redis.client.IRedisClient;
import com.saic.sso.client.SSOClient;
import com.saic.sso.client.entity.LoginInfo;

/**
 * 手机验证/注册<br>
 * .
 * 
 * @author hejian
 */
@Controller
@RequestMapping("/account")
public class ValidatePhoneController {
	/** The Constant logger. */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ValidatePhoneController.class);
	private static final Logger weiXinLoger = LoggerFactory.getLogger("weixin-trace");

	/** 手机认证类型. */
	private static final int AUTHTYPE_MOBILE = 2;

	/** 邮箱认证类型. */
	private static final int AUTHTYPE_EMAIL = 3;
	/** 主站引用code. */
	private static final int APPID = 1;

	/** 获取验证码间隔时间(秒). */
	private static final int VALIDCODE_INTERVAL = 120;

	/** 当验证码达到最大获取次数重新获取的时间间隔(秒). */
	private static final int VALIDCODE_INTERVAL_MAX = 24 * 3600;

	/** 验证码达到最大次数重新获取的时间(秒). */
	private static final int VALIDCODE_COUNT_MAX = 10;

	/** 手机验证码key. */
	private static final String MOBILE_VALIDATECODE_REDIS_KEY = "ms:wap:account:validateMobile:";

	/** 手机验证码提示信息key. */
	private static final String MOBILE_VALIDATECODE_MSG_KEY = "Num";

	/** ftl中用户信息引用的属性名. */
	private static final String PERSON_INFO_BEAN_ATTR = "bpib";

	/** 实现类. */
	@Resource(name = "validateServiceImpl")
	private ValidateService validateService;

	@Resource(name = "accountServiceImpl")
	private AccountService accountService;
	
    @Autowired
    private TicketJob ticketJob;
	
	 /** 认证访问管理系统. */
    @Resource
    private IAccountService iAccountService;

	/** SSO单点登陆接口. */
	@Autowired
	private SSOClient ssoClient;
	

	/** 缓存接口. */
	@Resource(name = "springRedisClient")
	private IRedisClient redisClient;
	
	  @Autowired
	private WebAccountService webAccountService;
	
//	@Autowired
//	private IAccountService iaccountService;

	@Autowired
	private UserService userService;
	/** 认证访问管理系统. */
	@Resource
	private IUserService iUserService;
	
	 /** 用户行为跟踪logger. */
   	private Logger newuserRegisterLogger = LoggerFactory.getLogger("NEW-USER-REGISTER");
   	
   	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 bdf9bedfd1e36dc2797cddc02847cb88
	 * 测试账号        04a4ea410735b9a134d41ed29ce64699
	 * 
	 */
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;

	/**
	 * 功能描述: 验证手机.<br>
	 * 
	 * @param bpib
	 *            用户
	 * @param result
	 *            错误实体
	 * @param request
	 *            请求
	 * @param response
	 *            返回
	 * @return String 返回值类型
	 * @throws UnsupportedEncodingException
	 *             the unsupported encoding exception
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping("/validPhone")
	public ModelAndView validPhone(
			@ModelAttribute(PERSON_INFO_BEAN_ATTR) BasicPersonalInfoBean bpib,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {

		Long userId = ssoClient.getLoginStatus(request);
		if (userId.equals(NumberUtils.LONG_ZERO)) {
			LOGGER.debug("注册后自动登录失败!");
			throw new BaseException("userId不应为null");
		}

		UserBaseInfoVO memInfo = userService.findBaseInfoByUserId(userId);
		String mobile = memInfo.getMobile();
		if (StringUtils.isNotBlank(mobile)) {
			return new ModelAndView("/account/reg-yz.ftl").addObject(
					"validedMsg", "您已绑定过手机");
		}

		return new ModelAndView("/account/reg-yz.ftl");
	}

	/**
	 * 功能描述: 获取手机、邮箱验证码(第一步).<br>
	 * ajax调用，函数中判断用户是否登陆，不需要加入ssoFilter,<br>
	 * 加入防止通过刷验证码骚扰，同用户60秒只能获取一次验证码，24小时内获取5次。
	 * 
	 * @param bpib
	 *            用户实体
	 * @param result
	 *            错误实体
	 * @param request
	 *            请求
	 * @param response
	 *            返回
	 * @param model
	 *            模型
	 * @return String 返回值类型 </br> "-1":出错， "0":已发送，"1":该手机已存在, "-2":请输入手机号,
	 *         "-3":24小时内达到最大获取验证码次数, "-4":70秒内重复获取验证码</br> "-5":您已绑定过手机
	 * @throws IOException
	 *             异常
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping("/toGetPhoneCode")
	@ResponseBody
	public String toGetPhoneCode(
			@ModelAttribute(PERSON_INFO_BEAN_ATTR) @Valid BasicPersonalInfoBean bpib,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response, Model model) throws IOException {

		// userId 要在session中获取
		Long userId = ssoClient.getLoginStatus(request);
		LOGGER.debug("获取userId"+userId);
		if (userId.equals(NumberUtils.LONG_ZERO)) {
			LOGGER.debug("注册后自动登录失败!");
			return "-1";
		}

		// 验证用户是否已绑定手机
		UserBaseInfoVO memInfo = userService.findBaseInfoByUserId(userId);
		String mobile = memInfo.getMobile();
		if (StringUtils.isNotBlank(mobile)) {
			return "-5";
		}

		// 手机号码验证
		String valueNum = request.getParameter(MOBILE_VALIDATECODE_MSG_KEY);
		if (!RegexUtil.check(RegexUtil.REGEX_MOBILE, valueNum)) {
			return "-2";
		}
		// 模板id
		String temStyle = request.getParameter("temStyle");

		// 加入防止通过刷验证码骚扰，同用户60秒只能获取一次验证码，24小时内获取5次
		String key60 = MOBILE_VALIDATECODE_REDIS_KEY + "interval60:" + userId;
		String key24 = MOBILE_VALIDATECODE_REDIS_KEY + "interval24:" + userId;
		// 是否间隔60秒
		if (redisClient.exists(key60,Constants.REDIS_NAME_SPACE)) {
			LOGGER.debug("60秒内重复获取验证码：key={}, expire={}", key60,
					redisClient.ttl(key60,Constants.REDIS_NAME_SPACE));
			return "-4";
		} else {
			redisClient.setex(key60,Constants.REDIS_NAME_SPACE, VALIDCODE_INTERVAL, valueNum);
			LOGGER.debug("设置60秒内获取验证码：key={}", key60);
		}
		// 是否间隔24小时满10次
		if (redisClient.exists(key24,Constants.REDIS_NAME_SPACE)) {
			int count = Integer.parseInt(redisClient.get(key24,Constants.REDIS_NAME_SPACE,null));
			// 达到最大次数
			if (count >= VALIDCODE_COUNT_MAX) {
				LOGGER.debug("24小时内获取手机验证码达到最大次数：key={}, value={}, expire={}",
						key24, redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
				return "-3";
				// 次数+1
			} else {
				redisClient.incr(key24,Constants.REDIS_NAME_SPACE);
				LOGGER.debug("24小时内获取手机验证码当前次数：key={}, value={}, expire={}",
						key24, redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
			}
		} else {
			redisClient.setex(key24,Constants.REDIS_NAME_SPACE, VALIDCODE_INTERVAL_MAX, "1");
			LOGGER.debug("设置24小时内获取手机验证码次数：key={}, value={}, expire={}", key24,
					redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
		}

		// 调用接口返回已经认证的信息 因为是查询是否有邦定的邮箱所有传3
		String num = validateService.toGetResultNum(null, userId, APPID, "2");

		String returnArr = StringUtils.EMPTY;
		// 0没有邦定邮箱
		if (!"0".equals(num)) {
			if (num.equals(valueNum)) {
				returnArr = "2";
			} else {
				// 判断当前手机或邮箱是否已经存在 1不存在 0已经存在
				String arr = this.frontCheckPhone(request);
				LOGGER.debug("当前手机验证值1不存在实际值为"+arr);
				if ("1".equals(arr)) {
					int ret = NumberUtils.INTEGER_ZERO;

					// 根据"@"判断是否为邮箱，-1则为手机
					if (valueNum.indexOf('@') == NumberUtils.INTEGER_MINUS_ONE) {
						// 发送验证码
						ret = validateService
								.toReqCheckCode(
										userId,
										AUTHTYPE_MOBILE,
										request.getParameter(MOBILE_VALIDATECODE_MSG_KEY),
										temStyle);
					} else {
						ret = validateService
								.toReqCheckCode(
										userId,
										AUTHTYPE_EMAIL,
										request.getParameter(MOBILE_VALIDATECODE_MSG_KEY),
										temStyle);
					}

					// ret为0则调用接口失败
					if (ret == NumberUtils.INTEGER_ZERO) {
						returnArr = "-1";
					} else {
						returnArr = "0";
					}
				} else {
					returnArr = "1";
				}
			}
		} else {
			// 判断当前手机或邮箱是否已经存在 1不存在 0已经存在
			String arr = this.frontCheckPhone(request);
			if ("1".equals(arr)) {
				int ret = NumberUtils.INTEGER_ZERO;

				// 根据"@"判断是否为邮箱，-1则为手机
				if (valueNum.indexOf('@') == NumberUtils.INTEGER_MINUS_ONE) {
					// 发送验证码
					ret = validateService.toReqCheckCode(userId,
							AUTHTYPE_MOBILE,
							request.getParameter(MOBILE_VALIDATECODE_MSG_KEY),
							temStyle);
				} else {
					ret = validateService.toReqCheckCode(userId,
							AUTHTYPE_EMAIL,
							request.getParameter(MOBILE_VALIDATECODE_MSG_KEY),
							temStyle);
				}

				// ret为0则调用接口失败
				if (ret == NumberUtils.INTEGER_ZERO) {
					returnArr = "-1";
				} else {
					returnArr = "0";
				}
			} else {
				returnArr = "1";
			}
		}
		return returnArr;
	}

	/**
	 * 功能描述: 校验手机、手机验证码的有效性.<br>
	 * 
	 * @param bpib
	 *            用户实体
	 * @param result
	 *            错误实体
	 * @param request
	 *            请求
	 * @param model
	 *            模型
	 * @return ModelAndView 模型
	 */
	@RequestMapping("/toCheckPhoneAndCodeRegister")
	public @ResponseBody ModelAndView toCheckPhoneAndCode(
			@ModelAttribute(PERSON_INFO_BEAN_ATTR) @Valid BasicPersonalInfoBean bpib,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		String fromType = request.getParameter("fromType");
		String openId = request.getParameter("openid");
		String mobile = request.getParameter("mobile");
		String inputCode = request.getParameter("captcha");
		String token = request.getParameter("token");
		
		boolean flag = true;
		if (StringUtils.isEmpty(mobile) || StringUtils.isBlank(mobile)) {
			flag = false;
		}
		if (StringUtils.isEmpty(inputCode) || StringUtils.isBlank(inputCode)) {
			flag = false;
		}
		ResponseVO vo = null;
		// 调用方法截取页面上显示的数据格式
		if(flag==false){
			return new ModelAndView("/account/mobile-regist.ftl")
			.addObject("token", token)
			.addObject("fromType", fromType)
			.addObject("mobile", mobile)
			.addObject("openid", openId)
			.addObject("errorMsg", "手机号或者验证码不能为空");
		}
		try {
			LOGGER.debug("调用注册接口");
			vo = iUserService.normalRegForUMS(mobile, null, inputCode, 2, 1, 3,
					3, "");
			LOGGER.debug("调用注册接口结束注册账号为:"+vo.getUserId());
			
			if (vo.getRtnCode() == 101) {
				return new ModelAndView("/account/mobile-regist.ftl")
						.addObject("token", token)
						.addObject("fromType", fromType)
						.addObject("mobile", mobile)
						.addObject("openid", openId)
						.addObject("errorMsg", "验证码错误 ");
			} else if (vo.getRtnCode() == 102) {
				return new ModelAndView("/account/mobile-regist.ftl")
						.addObject("token", token)
						.addObject("fromType", fromType)
						.addObject("mobile", mobile)
						.addObject("openid", openId)
						.addObject("errorMsg", "验证码失效");
			}
		} catch (Exception e) {
			return new ModelAndView("/account/mobile-regist.ftl")
					.addObject("token", token).addObject("fromType", fromType)
					.addObject("mobile", mobile)
					.addObject("openid", openId)
					.addObject("errorMsg", "保存验证码异常");
		} 
		
		   if(StringUtils.isNotBlank(fromType)&&StringUtils.isNotEmpty(fromType)&&"1".equals(fromType.trim())){
	        	if(StringUtils.isNotBlank(openId)&&StringUtils.isNotEmpty(openId))
	        	{
	        		
	        		//2,openid,userid,调用MDM保存关联信息
	        		
	        		try {
//	        			LOGGER.debug("调用微信回复信息接口"+openId);
//	        			
//	        				LOGGER.debug("调用微信回复信息接口结束"+openId);
//	        				LOGGER.debug("调用微信和账户绑定接口开始"+openId+vo.getUserId());
	        		    
	        			boolean isS=accountService.addWinxinOpenIDAndUserIdReleation(vo.getUserId(), openId);
	        			//TBD
	        			String accessToken = ticketJob.getToken();
	        			SendMessageUtil.sendTextMessage(openId, appId, appSecret, "恭喜您已成功绑定车享账号！！！",accessToken);
       				LOGGER.debug("调用微信和账户绑定接口结束"+openId+vo.getUserId());
			        	 if(!isS){
			        			//注销
			        	        accountService.userLogout(NumberUtils.LONG_ZERO, request, response);
			        	        return new ModelAndView("redirect:/account/wxlogin.htm?"+"fromType="+fromType+"&token="+token+"openid"+openId);
			        		}else{
			        			LOGGER.info("保存关联关系失败");	
			        		}
	        		} catch (Exception e) {
						LOGGER.error("addWinxinOpenIDAndUserIdReleation Error",  e);
						 accountService.userLogout(NumberUtils.LONG_ZERO, request, response);
						return new ModelAndView("redirect:/account/wxlogin.htm?"+"fromType="+fromType+"&token="+token+"openid"+openId);
					}
	        		//3,通知微信用户绑定成功
	        	}
	      }

		LoginInfo loginInfo=accountService.userLogin(1, mobile, vo.getPassword(), true,
				request, response);
		String uuid=getCookieUUid(request);
		loguserinfo("user-register",uuid, (loginInfo==null?"":loginInfo.getUserId()+""), 1+"");
	
		return new ModelAndView("/account/registBindingSuccess.ftl")
				.addObject("token", token).addObject("fromType", fromType)
				.addObject("mobile", mobile)
				.addObject("openid", openId)
				.addObject("fromType", fromType);
	}

	/**
	 * 功能描述: 验证成功页面<br>
	 * .
	 * 
	 * @param request
	 *            请求
	 * @return ModelAndView
	 */
	@RequestMapping("/regsuccess")
	public ModelAndView registerValidSuccess(HttpServletRequest request) {
		return new ModelAndView("/account/loginSuccess.ftl");
	}

	/**
	 * 功能描述: 注册成功页面<br>
	 * .
	 * 
	 * @param request
	 *            请求
	 * @return ModelAndView
	 */
	@RequestMapping("/regsuccess-noyz")
	public ModelAndView registerNoValidSuccess(HttpServletRequest request) {
		return new ModelAndView("/account/yzno-success.ftl");
	}

	/**
	 * 功能描述: 前端验证手机号码、邮箱是否存在. <br>
	 * 〈功能详细描述〉返回页面 0:可用 1：不可用
	 * 
	 * @param request
	 *            请求
	 * @return String 返回值类型
	 * @throws IOException
	 *             异常
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	private String frontCheckPhone(HttpServletRequest request)
			throws IOException {
		int k = NumberUtils.INTEGER_ZERO;
		String arrStr;
		String str = "@";
		String resultNum = request.getParameter(MOBILE_VALIDATECODE_MSG_KEY);
		int n = resultNum.indexOf(str);
		// N为-1表示手机号码
		if (n == NumberUtils.INTEGER_MINUS_ONE) {
			// 调用接口方法判断当前输入的手机是否存在 1:可用 0:不可用
			LOGGER.debug("查看手机是否可用开始");
			k = validateService.toFrontCheckPhoneOrEma(
					request.getParameter(MOBILE_VALIDATECODE_MSG_KEY),
					AUTHTYPE_MOBILE, APPID);
			LOGGER.debug("查看手机是否可用1可用实际值"+k);
			if (k == NumberUtils.INTEGER_ZERO) {
				arrStr = "0";
			} else if (k == NumberUtils.INTEGER_ONE) {
				arrStr = "1";
			} else {
				arrStr = "2";
			}
		} else {
			// 调用接口方法判断当前输入的邮箱是否存在 0:可用 1:不可用
			k = validateService.toFrontCheckPhoneOrEma(
					request.getParameter(MOBILE_VALIDATECODE_MSG_KEY),
					AUTHTYPE_EMAIL, APPID);
			if (k == NumberUtils.INTEGER_ZERO) {
				arrStr = "0";
			} else if (k == NumberUtils.INTEGER_ONE) {
				arrStr = "1";
			} else {
				arrStr = "2";
			}
		}
		return arrStr;
	}

	@RequestMapping("/toGetPhoneCodeMobile")
	@ResponseBody
	public String toGetPhoneCodeMobile(
			@ModelAttribute(PERSON_INFO_BEAN_ATTR) @Valid BasicPersonalInfoBean bpib,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response, Model model, int isExist) throws Exception {
		/*
		 * 验证手机是不是注册过
		 */
		// userId 要在session中获取
		
		String valueNum = request.getParameter(MOBILE_VALIDATECODE_MSG_KEY);
		// 手机号码验证
		if (!RegexUtil.check(RegexUtil.REGEX_MOBILE, valueNum)) {
			return "-2";
		}
		// 模板id
		String temStyle = request.getParameter("temStyle");


		String returnArr = StringUtils.EMPTY;
		// // 0没有邦定邮箱
		// if (!"0".equals(num)) {
		// if (num.equals(valueNum)) {
		// returnArr = "2";
		// } else {
		// // 判断当前手机或邮箱是否已经存在 1不存在 0已经存在
		String arr = this.frontCheckPhone(request);
		// if ("1".equals(arr)) {
		// int ret = NumberUtils.INTEGER_ZERO;

		// // 判断当前手机或邮箱是否已经存在 1不存在 0已经存在
		if ("1".equals(arr)||"1".equals( isExist+"")) {
			//
			// // 根据"@"判断是否为邮箱，-1则为手机
			// if (valueNum.indexOf('@') == NumberUtils.INTEGER_MINUS_ONE) {
			// // 发送验证码
			LOGGER.debug("开始发送手机验证码|"+valueNum+"|"+isExist);
			validateService.toReqCheckCodeForUms(AUTHTYPE_MOBILE, valueNum,
					temStyle);
			LOGGER.debug("结束发送手机验证码|"+valueNum+"|"+isExist);
			// ret = validateService.toReqCheckCodeByMobile(AUTHTYPE_MOBILE,
			// valueNum,request.getParameter(MOBILE_VALIDATECODE_MSG_KEY));
			// } else {
			// ret = validateService.toReqCheckCode(userId, AUTHTYPE_EMAIL,
			// request.getParameter(MOBILE_VALIDATECODE_MSG_KEY), temStyle);
			// }
			// if (ret == 0) {
			// returnArr = "-1";
			// } else {
			returnArr = "0";
			// }
			// } else {
			// returnArr = "1";
			// }
		} else if ("0".equals(arr)) {
			returnArr = "1";
		}
		return returnArr;
	}
	
	@RequestMapping("/sendMobileCode")
	@ResponseBody
	public String sendMobileCode(HttpServletRequest request,@RequestParam("userId") Long userId,
			@RequestParam("mobile") String mobile){
		//发送成功
		String status = "0";
		// 模板id
		String temStyle = "004";
		// 验证用户是否已绑定手机
		// 手机号码验证
		if (!RegexUtil.check(RegexUtil.REGEX_MOBILE, mobile)) {
			return "-2";
		}
		
		//校验手机，是否存在
		ResponseVO rv = iUserService.aliasNameIsUsed(mobile, 2, APPID);
        if (rv != null && rv.getRtnCode() == 100) {
        	//该手机号已绑定
            return "1";
        }
		//发送校验码
		LOGGER.debug("开始发送手机验证码");
		// 加入防止通过刷验证码骚扰，同用户60秒只能获取一次验证码，24小时内获取5次
		String key60 = MOBILE_VALIDATECODE_REDIS_KEY + "interval60:" + mobile + 8
				+ 2;
		String key24 = MOBILE_VALIDATECODE_REDIS_KEY + "interval24:" + mobile + 8
				+ 2;
		// 是否间隔60秒
		if (redisClient.exists(key60,Constants.REDIS_NAME_SPACE)) {
			LOGGER.debug("60秒内重复获取验证码：key={}, expire={}", key60,
					redisClient.ttl(key60,Constants.REDIS_NAME_SPACE));
			return "-4";
		} 
		// 是否间隔24小时满10次
		if (redisClient.exists(key24,Constants.REDIS_NAME_SPACE)) {
			int count = Integer.parseInt(redisClient.get(key24,Constants.REDIS_NAME_SPACE,null));
			// 达到最大次数
			if (count >= VALIDCODE_COUNT_MAX) {
				redisClient.del(key60,Constants.REDIS_NAME_SPACE);
				LOGGER.debug("24小时内获取手机验证码达到最大次数：key={}, value={}, expire={}",
						key24, redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
				return "-3";
			} 
		} 
		try {
			ResponseVO vo = iAccountService.getAuthCode(userId, 2, mobile, temStyle);
			if(vo != null && vo.getRtnCode() == 100){
				LOGGER.info("手机号码 : {} ---- 验证码 : {}", mobile, vo.getResult());
				//发送成功验证码，放入缓存
				LOGGER.debug("设置60秒内获取验证码：key={}", key60);
				redisClient.setex(key60,Constants.REDIS_NAME_SPACE, 60, mobile);
				//如果设置过24小时,次数加1
				if(redisClient.exists(key24,Constants.REDIS_NAME_SPACE)){
					redisClient.incr(key24,Constants.REDIS_NAME_SPACE);
					LOGGER.debug("24小时内获取手机验证码当前次数：key={}, value={}, expire={}",
							key24, redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
				}else{
					//否则置1
					redisClient.setex(key24,Constants.REDIS_NAME_SPACE, VALIDCODE_INTERVAL_MAX, "1");
					LOGGER.debug("设置24小时内获取手机验证码次数：key={}, value={}, expire={}", key24,
							redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
				}
			}else{
				//系统异常
				return "-1";
			}
		} catch (Exception e) {
			LOGGER.error("发送手机验证码异常 : " + e.getMessage());
			return "-1";
		} 
		LOGGER.debug("结束发送手机验证码");
		return status;
	}
	
	@RequestMapping("/bindingMobile")
	@ResponseBody
	public String bindingMobile(HttpServletRequest request,@RequestParam("userId") Long userId,
			@RequestParam("mobile") String mobile,@RequestParam("mobileVerifyCode")String mobileVerifyCode){
		ResponseVO vo = null;
		//userId,验证类型2手机号，手机验证码，手机号，创建类型7
		String status = "100";
		try {
			vo = iAccountService.verifyAuthCodeAndBind(userId, 2, mobileVerifyCode, mobile, 7);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		} 
		if(vo == null){
			//校验失败
			status = "103";
		}else{
			// 调用接口返回值 100成功 101验证码错误 102验证码过期
			if (vo.getRtnCode() == 101) {
				status = "101";
			}else if (vo.getRtnCode() == 102) {
				status = "102";
			}else{
				status = String.valueOf(vo.getRtnCode());
			}
		}
		return status;
	}
	
	@RequestMapping("/toGetPhoneCodeMobilenew")
	@ResponseBody
	public String toGetPhoneCodeMobilenew(
			@ModelAttribute(PERSON_INFO_BEAN_ATTR) @Valid BasicPersonalInfoBean bpib,
			BindingResult result, HttpServletRequest request,
			HttpServletResponse response, Model model) throws Exception {
		/* * 验证手机是不是注册过*/
		// userId 要在session中获取
		String isBand = request.getParameter("isBand");
		String userid = request.getParameter("userid");
		if(userid==null||"".equals(userid.trim())){
			return "-1";
		}
		String valueNum = request.getParameter(MOBILE_VALIDATECODE_MSG_KEY);
		// 验证用户是否已绑定手机
		// 手机号码验证
		if (!RegexUtil.check(RegexUtil.REGEX_MOBILE, valueNum)) {
			return "-2";
		}
		// 模板id
		String temStyle = request.getParameter("temStyle");
		// 加入防止通过刷验证码骚扰，同用户60秒只能获取一次验证码，24小时内获取5次
		String key60 = MOBILE_VALIDATECODE_REDIS_KEY + "interval60:" + valueNum+8
				+ 2;
		String key24 = MOBILE_VALIDATECODE_REDIS_KEY + "interval24:" + valueNum+8
				+ 2;
		// 是否间隔60秒
		if (redisClient.exists(key60,Constants.REDIS_NAME_SPACE)) {
			LOGGER.debug("60秒内重复获取验证码：key={}, expire={}", key60,
					redisClient.ttl(key60,Constants.REDIS_NAME_SPACE));
			return "-4";
		} else {
			redisClient.setex(key60,Constants.REDIS_NAME_SPACE, VALIDCODE_INTERVAL, valueNum);
			LOGGER.debug("设置60秒内获取验证码：key={}", key60);
		}
		// 是否间隔24小时满10次
		if (redisClient.exists(key24,Constants.REDIS_NAME_SPACE)) {
			int count = Integer.parseInt(redisClient.get(key24,Constants.REDIS_NAME_SPACE,null));
			// 达到最大次数
			if (count >= VALIDCODE_COUNT_MAX) {
				LOGGER.debug("24小时内获取手机验证码达到最大次数：key={}, value={}, expire={}",
						key24, redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
				return "-3";
				// 次数+1
			} else {
				redisClient.incr(key24,Constants.REDIS_NAME_SPACE);
				LOGGER.debug("24小时内获取手机验证码当前次数：key={}, value={}, expire={}",
						key24, redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
			}
		} else {
			redisClient.setex(key24,Constants.REDIS_NAME_SPACE, VALIDCODE_INTERVAL_MAX, "1");
			LOGGER.debug("设置24小时内获取手机验证码次数：key={}, value={}, expire={}", key24,
					redisClient.get(key24,Constants.REDIS_NAME_SPACE,null), redisClient.ttl(key24,Constants.REDIS_NAME_SPACE));
		}
		String returnArr = StringUtils.EMPTY;
		//校验手机，是否存在
	
		String arr ="1";
		if(isBand!=null&&org.springframework.util.StringUtils.hasText(isBand)&&"0".equals(isBand.trim())){
			 arr = this.frontCheckPhone(request);
		}
	
		if ("1".equals(arr)) {
			// // 发送验证码
			LOGGER.debug("开始发送手机验证码|"+valueNum);
			validateService.toReqCheckCode(Long.parseLong(userid.trim()),AUTHTYPE_MOBILE, valueNum,
					temStyle);
			LOGGER.debug("结束发送手机验证码|"+valueNum);
			returnArr = "0";
	
		} else if ("0".equals(arr)) {
			returnArr = "1";
		}
		return returnArr;
	}
	@RequestMapping("/toGetPhoneCodeMobilefindpwd")
	@ResponseBody
	public String toGetPhoneCodeMobilefindpwd( HttpServletRequest request,
			HttpServletResponse response, Model model) throws Exception {
		/* * 验证手机是不是注册过*/
		// userId 要在session中获取
	
		String valueNum = request.getParameter(MOBILE_VALIDATECODE_MSG_KEY);
		// 验证用户是否已绑定手机
		// 手机号码验证
		if (!RegexUtil.check(RegexUtil.REGEX_MOBILE, valueNum)) {
			return "-2";
		}
		// 模板id
		String temStyle = request.getParameter("temStyle");
//		// 加入防止通过刷验证码骚扰，同用户60秒只能获取一次验证码，24小时内获取5次
//		String key60 = MOBILE_VALIDATECODE_REDIS_KEY + "interval60:" + valueNum+8
//				+ 2;
//		String key24 = MOBILE_VALIDATECODE_REDIS_KEY + "interval24:" + valueNum+8
//				+ 2;
//		// 是否间隔60秒
//		if (redisClient.exists(key60)) {
//			LOGGER.debug("60秒内重复获取验证码：key={}, expire={}", key60,
//					redisClient.ttl(key60));
//			return "-4";
//		} else {
//			redisClient.setex(key60, VALIDCODE_INTERVAL, valueNum);
//			LOGGER.debug("设置60秒内获取验证码：key={}", key60);
//		}
////		 是否间隔24小时满10次
//		if (redisClient.exists(key24)) {
//			int count = Integer.parseInt(redisClient.get(key24));
//			// 达到最大次数
//			if (count >= VALIDCODE_COUNT_MAX) {
//				LOGGER.debug("24小时内获取手机验证码达到最大次数：key={}, value={}, expire={}",
//						key24, redisClient.get(key24), redisClient.ttl(key24));
//				return "-3";
//				// 次数+1
//			} else {
//				redisClient.incr(key24);
//				LOGGER.debug("24小时内获取手机验证码当前次数：key={}, value={}, expire={}",
//						key24, redisClient.get(key24), redisClient.ttl(key24));
//			}
//		} else {
//			redisClient.setex(key24, VALIDCODE_INTERVAL_MAX, "1");
//			LOGGER.debug("设置24小时内获取手机验证码次数：key={}, value={}, expire={}", key24,
//					redisClient.get(key24), redisClient.ttl(key24));
//		}
//		

		
		String returnArr = StringUtils.EMPTY;
		//校验手机，是否存在
	
		String arr ="1";
	
		arr = this.frontCheckPhone(request);
		String isExist = request.getParameter("isExist");
		// 判断当前手机或邮箱是否已经存在 1不存在 0已经存在
		if ("1".equals(arr) || "1".equals(isExist + "")) {
			// // 发送验证码
			LOGGER.debug("开始发送手机验证码|"+valueNum);

			long userid = 0;
			try {
				userid = Long.parseLong(request.getParameter("userid"));
				if ("1".equals(isExist + "")){
				   ResponseVO aliasNameResponse = accountService.aliasNameIsUsed(valueNum, 2, 1);
		          userid = aliasNameResponse.getUserId();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			int reqCheckCode = validateService.toReqCheckCode(userid, 2,
					valueNum, temStyle);
			LOGGER.debug("结束发送手机验证码|" + valueNum + "|" + reqCheckCode+"|"+userid);
			returnArr = "0";
		}else{
			returnArr = "1";
		}
		return returnArr;
	}
	
	 private void loguserinfo(String prefix,String cookie_uuid,String userId,String userType){
	    	try{
	    	newuserRegisterLogger.info(prefix+":"+"\t"+cookie_uuid+"\t"+(userId==null?"":userId)+"\t"+(userType==null?"":userType));
	    	}catch(Exception e){
	    		LOGGER.error("write-newuserRegisterLogger-error", e);
	    	}
	    }
	    private String getCookieUUid(HttpServletRequest request){
	    	Cookie[] cookies = request.getCookies();
	        String userTraceCookie = "";
	        for (Cookie cookie : cookies) {
				String name = cookie.getName();
				if ("user_trace_cookie".equals(name)) {
					userTraceCookie = cookie.getValue();
					break;
				}
			}
	        return userTraceCookie;
	    }
	    
	    
	    /**
		 * 功能描述: 校验手机、手机验证码的有效性.<br>
		 * 
		 * @param bpib
		 *            用户实体
		 * @param result
		 *            错误实体
		 * @param request
		 *            请求
		 * @param model
		 *            模型
		 * @return ModelAndView 模型
		 */
		@SuppressWarnings("deprecation")
		@RequestMapping("/wxToCheckPhoneAndCodeRegister")
		public @ResponseBody ModelAndView wxToCheckPhoneAndCodeRegister(
				@ModelAttribute(PERSON_INFO_BEAN_ATTR) @Valid BasicPersonalInfoBean bpib,
				BindingResult result, HttpServletRequest request,
				HttpServletResponse response, Model model,RedirectAttributes attr) {


		  	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    	newuserRegisterLogger.info("\t"+ sdf.format(new Date())+"\t "+this.getIp(request)+" \t"+ request.getParameter("keyid") + "_register  \t" 
	      			 + "微信注册" +"\t"+ request.getHeader("user-agent") + "\t" + 3 + "\t" + 13);
	    	System.out.println("==================测试：keyid="+request.getParameter("keyid"));
		String operateType = "0"; //0:操作失败  1：注册成功  2：注册并绑定成功 3：认证成功
		String name = request.getParameter("name");
		//1:认证  0：注册
		String token= request.getParameter("token");
		String isExist= request.getParameter("isExist");
		String fromType= request.getParameter("fromType");
		String openId= request.getParameter("openid");;
		String mobile = request.getParameter("mobile");
		String inputCode = request.getParameter("captcha");
		String backUrl = request.getParameter("backUrl");
		boolean isFromRegistPage = "regist".equals(request.getParameter("fromPage"));
		String userId = "";
		ResponseVO vo = null;
		weiXinLoger.info("--------------参数：isExist="+isExist+",fromType="+fromType+",openId="+openId+",mobile="+mobile+",inputCode="+inputCode+",backUrl="+backUrl+",isFromRegistPage="+isFromRegistPage);
//			String token = request.getParameter("token");
		if (isFromRegistPage) {
			weiXinLoger.info("开始注册信息");
				   boolean  flag=true;
					if(StringUtils.isEmpty(mobile)|| StringUtils.isBlank(mobile)){
						  flag=false;
					}
					if(StringUtils.isEmpty(inputCode)|| StringUtils.isBlank(inputCode)){
						  flag=false;
					}
					// 调用方法截取页面上显示的数据格式
					if(flag==false){
						weiXinLoger.error("cxg_userRegister_info:\t 微信服务号注册失败\t" + mobile + "\t" + inputCode + "\t" + openId + "\t" + getCookieUUid(request) + "\t" + "手机号或者验证码为空");
						weiXinLoger.info("手机号或者验证码不能为空返回：wxlogininformation");
						return new ModelAndView(isFromRegistPage?"/account/wxmobile-regist.ftl":"/account/wxlogininformation.ftl")
		//				.addObject("token", token)
						.addObject("fromType", fromType)
						.addObject("mobile", mobile).addObject("name", name)
						.addObject("openid", openId)
						.addObject("backUrl",backUrl)
						.addObject("isExist", isExist)
						.addObject("errorMsg", "手机号或者验证码不能为空");
					}
					
					try {
						weiXinLoger.info("updateUser|name|:" + name);
						
						//20150325微信活动不需要用户输入用户名
						/*if(com.mysql.jdbc.StringUtils.isEmptyOrWhitespaceOnly(name)){
							weiXinLoger.info("用户名不能为空");
							return new ModelAndView(isFromRegistPage?"/account/wxmobile-regist.ftl":"/account/wxlogininformation.ftl")
			//				.addObject("token", token)
							.addObject("fromType", fromType)
							.addObject("mobile", mobile).addObject("name", name)
							.addObject("openid", openId)
							.addObject("backUrl",backUrl)
							.addObject("isExist", isExist)
							.addObject("errorMsg", "用户名不能为空");	
						}*/
						weiXinLoger.info("调用注册接口");
						//
						vo = iUserService.normalRegForUMS(mobile, null, inputCode, 2, 1, Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE),
								3, "");
						//iUserService.n
						operateType = "1";
						weiXinLoger.info("调用注册接口结束注册账号为:"+vo.getUserId());


				    	newuserRegisterLogger.info("\t"+vo.getUserId()+"\t"+ sdf.format(new Date())+"\t "+this.getIp(request)+" \t"+ request.getParameter("keyid") + "_register  \t" 
				      			 + "注册成功" +"\t"+ request.getHeader("user-agent") + "\t" + 3 + "\t" + 13);
						/*if (!com.mysql.jdbc.StringUtils.isEmptyOrWhitespaceOnly(name)) {
							try {
								UserVO userVO = new UserVO();
								userVO.setUserId(vo.getUserId());
								//更新用户注册来源为车享购29
								userVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));
								userVO.setName(name);
								userService.updateUser(userVO);
								weiXinLoger.info("updateUser|success|:" + JSON.toJSONString(userVO));
							} catch (InParamException e) {
								weiXinLoger.info("updateUser|error|:" + e.getLocalizedMessage());
							}
						}*/
						
						//					    	 .addAllObjects(velBrandModel)
						if (vo.getRtnCode() == 101) {
							weiXinLoger.error("cxg_userRegister_info:\t 微信服务号注册失败\t" + mobile + "\t" + inputCode + "\t" + openId + "\t" + getCookieUUid(request) + "\t" + "验证码错误");
							weiXinLoger.info("调用注册接口:验证码错误 ");
							return new ModelAndView(isFromRegistPage?"/account/wxmobile-regist.ftl":"/account/wxlogininformation.ftl")
		//							.addObject("token", token)
									.addObject("fromType", fromType)
									.addObject("mobile", mobile)
									.addObject("openid", openId)
									.addObject("backUrl",backUrl).addObject("name", name)
									.addObject("isExist", isExist)
									.addObject("errorMsg", "验证码错误 ");
						} else if (vo.getRtnCode() == 102) {
							weiXinLoger.error("cxg_userRegister_info:\t 微信服务号注册失败\t" + mobile + "\t" + inputCode + "\t" + openId + "\t" + getCookieUUid(request) + "\t" + "验证码失效");
							weiXinLoger.info("调用注册接口:验证码失效 ");
							return new ModelAndView(isFromRegistPage?"/account/wxmobile-regist.ftl":"/account/wxlogininformation.ftl")
		//							.addObject("token", token)
									.addObject("fromType", fromType)
									.addObject("mobile", mobile)
									.addObject("openid", openId)
									.addObject("backUrl",backUrl)
									.addObject("isExist", isExist).addObject("name", name)
									.addObject("errorMsg", "验证码失效");
						} else{
							//更新用户注册的来源
							try {
								UserVO userVO = new UserVO();
								userVO.setUserId(vo.getUserId());
								//更新用户注册来源为车享购29
								userVO.setSource(Integer.valueOf(Constants.MDM_USER_SAIC_SOURCE));
								userVO.setName(name);
								userService.updateUser(userVO);
								weiXinLoger.info("updateUser|success|:" + JSON.toJSONString(userVO));
							} catch (InParamException e) {
								weiXinLoger.info("updateUser|error|:" + e.getLocalizedMessage());
							}
						}
					} catch (Exception e) {
						weiXinLoger.info("调用注册接口:验证码异常 ");
						return new ModelAndView(isFromRegistPage?"/account/wxmobile-regist.ftl":"/account/wxlogininformation.ftl")
//							        addObject("velBrandModel", velBrandModel)
						//.addAllObjects(  velBrandModel)
		//						.addObject("token", token)
								.addObject("fromType", fromType).addObject("name", name)
								.addObject("mobile", mobile)
								.addObject("openid", openId)
								.addObject("backUrl",backUrl)
								.addObject("isExist", isExist)
								.addObject("errorMsg", "验证码错误");
					} 
		
		}
		if (isFromRegistPage) {
			userId = vo.getUserId()+"";
			weiXinLoger.info("-------------VO----------------"+userId);
		}else{
			if (null != openId && !"".equals(openId)) {
				WebAccountVO webAccountVO = new WebAccountVO();
				webAccountVO.setType(Constants.MDM_USER_SAIC_TYPE);
				webAccountVO.setSource(29);
				webAccountVO.setNumber(openId);
				List<WebAccountVO> webAccountVOList = webAccountService.findWebAccountByCondition(webAccountVO);
				if (null != webAccountVOList && webAccountVOList.size() >0) {
					userId =webAccountVOList.get(0).getUserId()+"";
				}
				
			}else{
				userId=request.getParameter("userid");
				weiXinLoger.info("-----移动端获取userid-----"+userId);
			}
		}
		
		//微信绑定
		if ("0".equals(isExist)) {
			weiXinLoger.info("---------------开始进行绑定操作-----------------");
			 //绑定
			   if(StringUtils.isNotBlank(fromType) && StringUtils.isNotEmpty(fromType)&&"29".equals(fromType.trim())){
		        	if(StringUtils.isNotBlank(openId)&&StringUtils.isNotEmpty(openId))
		        	{
		        		weiXinLoger.info("绑定的openId="+openId);
		        		//2,openid,userid,调用MDM保存关联信息
		        		try {
		        			if (!isFromRegistPage) {
		        				weiXinLoger.info("绑定手机号userId="+userId+",inputCode="+inputCode+",mobile="+mobile);
		        				int bandPhone = validateService.toVerifyAuthCodeAndBind(Long.valueOf(userId), 2, inputCode, mobile, 7);
		        				weiXinLoger.info("绑定手机号结果bandPhone="+bandPhone);
		        				if(bandPhone!=1){//失败
						   			weiXinLoger.info("调用认证验证码接口，结果returncode="+bandPhone+",验证码错误");
						   			return new	 ModelAndView("redirect:/account/wxinformation.htm")
						   			//.addAllObjects(velBrandModel)
											.addObject("fromType", fromType)
											.addObject("mobile", mobile)
											.addObject("openid", openId)
											.addObject("backUrl",backUrl)
											.addObject("isExist", isExist)
											.addObject("errorMsg", "验证码错误");
						   		  }
		        			}else{
			        			weiXinLoger.info("调用绑定接口");
			        			boolean isS=accountService.addWinxinOpenIDAndUserIdReleation(vo.getUserId(), openId);
			        			weiXinLoger.info("绑定结果：isS"+isS);
			        			operateType = "2";
			        			
			        			String accessToken = ticketJob.getToken();
			        			SendMessageUtil.sendTextMessage(openId, appId, appSecret, "恭喜您已成功绑定车享账号！！！",accessToken);
			        			  weiXinLoger.info("调用微信和账户绑定接口结束"+openId+vo.getUserId());
					        	 if(!isS){
					        			//注销
					        	        accountService.userLogout(NumberUtils.LONG_ZERO, request, response);
					        	        return new ModelAndView("redirect:/account/wxlogin.htm?"+"fromType="+fromType + "&token=" + token + "&openid"+openId+"&backUrl="+backUrl+"&isExist="+isExist);
					        		}else{
					        			weiXinLoger.info("绑定成功--");	
					        		}
		        			}
		        		} catch (Exception e) {
		        			weiXinLoger.info("addWinxinOpenIDAndUserIdReleation Error",  e);
							accountService.userLogout(NumberUtils.LONG_ZERO, request, response);
							return new ModelAndView("redirect:/account/wxlogin.htm?"+"fromType="+fromType + "&token=" + token + "&openid"+openId+"&backUrl="+backUrl+"&isExist="+isExist);
						}
		        		//3,通知微信用户绑定成功
		        	}
		      }
			   weiXinLoger.info("--------绑定成功-------------");
		}
		
		ModelAndView modelAndView = new ModelAndView(
				"/account/wxbindingSuccess.ftl");
		if (null != backUrl && !"".equals(backUrl)) {
			backUrl = URLDecoder.decode(backUrl);
			backUrl = backUrl.replace("-1", String.valueOf(userId));
			int ishttp = backUrl.indexOf("http");
			backUrl=ishttp!=-1?("redirect:"+backUrl):backUrl;
			modelAndView = new ModelAndView(backUrl);
		}
		
		modelAndView.addObject("backUrl", backUrl);
		modelAndView.addObject("operateType", operateType);
		modelAndView.addObject("userId", userId).addObject("fromType", fromType);
		modelAndView.addObject("openId", openId).addObject(RequestConstants.OPEN_ID, openId);
		weiXinLoger.error("cxg_userRegister_info:\t 微信服务号注册成功\t" + mobile + "\t" + userId + "\t" + openId + "\t" + getCookieUUid(request) + "\t" + backUrl);
		weiXinLoger.info("出参：backUrl=" + backUrl + ",operateType="
				+ operateType + ",userId=" + userId + ",openId=" + openId);
		try {
			if ("2".equals(operateType)) {
				// TBD
			    String accessToken = ticketJob.getToken();
				SendMessageUtil.sendTextMessage(openId, appId, appSecret, "恭喜您成为车享新车会员！！！",accessToken);
			}
		} catch (Exception e) {
		}
		//
		return modelAndView;
	}
		
		/**
		 * 获取客户端ip
		 * 
		 * @param request
		 * @return
		 */
		public String getIp(HttpServletRequest request) {
			weiXinLoger.info("获取客户端ip地址");
			String ip = null;
			try {
				ip = request.getHeader("x-forwarded-for");
				if (ip == null || ip.length() == 0
						|| "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("Proxy-Client-IP");
				}
				if (ip == null || ip.length() == 0
						|| "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("WL-Proxy-Client-IP");
				}
				if (ip == null || ip.length() == 0
						|| "unknown".equalsIgnoreCase(ip)) {
					ip = request.getRemoteAddr();
				}
				weiXinLoger.info("客户端ip地址为：" + ip);
				return ip;
			} catch (Exception e) {
				e.printStackTrace();
				weiXinLoger.info("发生异常ip地址获取失败");
				return null;
			}

		}
	
}
