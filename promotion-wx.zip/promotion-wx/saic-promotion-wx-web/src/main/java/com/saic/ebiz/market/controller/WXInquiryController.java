/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * 
 */
package com.saic.ebiz.market.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.entity.InquiryOrderVO;

/**
 * @author hejian
 * 
 */
@RestController
@RequestMapping("/weixin")
public class WXInquiryController {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	 /**  登录模板路径. */
    private static final String FTL_INQUIRY = "/wxsales/inquiry.ftl";

    @RequestMapping(value="/inquiry",method={RequestMethod.GET})
	public ModelAndView inquire(HttpServletRequest request) {
		ModelAndView model = new ModelAndView(FTL_INQUIRY);
		return model;
	}
    
    @RequestMapping(value="/inquiry",method={RequestMethod.POST})
    public ModelAndView inquire(InquiryOrderVO inquiryOrderVO) {
		ModelAndView model = new ModelAndView(FTL_INQUIRY);
		logger.info("InquiryOrderVO : " + JSONObject.toJSONString(inquiryOrderVO));
		return model;
	}
}
