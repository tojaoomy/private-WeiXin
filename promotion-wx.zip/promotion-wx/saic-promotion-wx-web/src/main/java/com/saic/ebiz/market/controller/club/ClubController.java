/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller.club;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.meidusa.toolkit.common.util.Base64;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.util.CommonUtil;
import com.saic.ebiz.market.controller.vo.AnswerWrapper;
import com.saic.ebiz.market.controller.vo.StatusVO;
import com.saic.ebiz.market.util.ControllerUtil;
import com.saic.ebiz.society.bo.AnswerGoodBadBO;
import com.saic.ebiz.society.entity.question.AnswerGoodBadEntity;
import com.saic.ebiz.society.enumeration.AnswerTypes;
import com.saic.ebiz.society.enumeration.DeleteFlag;
import com.saic.ebiz.society.service.api.IAnswerService;
import com.saic.ebiz.society.service.api.IQuestionService;
import com.saic.ebiz.society.vo.query.AnswerGoodBadQuery;
import com.saic.ebiz.society.vo.query.AnswerQuery;
import com.saic.ebiz.society.vo.query.QuestionQuery;
import com.saic.ebiz.society.vo.question.AnswerVO;
import com.saic.ebiz.society.vo.question.QuestionVO;
import com.saic.framework.redis.client.IRedisClient;
import com.saic.sso.client.SSOClient;

/**
 * @author hejian
 *
 */
@RestController
@RequestMapping("/club")
public class ClubController {
	
	private static Logger logger = LoggerFactory.getLogger(ClubController.class);
	
	@Autowired
	private IQuestionService questionService;
	
	@Autowired
	private IAnswerService answerService;

	@Autowired
	private SSOClient ssoClient;
	
	/**缓存接口.*/
    @Resource(name="springRedisClient")
    private IRedisClient springRedisClient;
    
    @Value("${ebiz.wap.web.appId:}")
	private String appId;
	
//	private static AtomicInteger increase = new AtomicInteger();
	
	private static String DOMAIN = Constants.DOMAIN;
	
	@RequestMapping("/detail")
	public ModelAndView qustionDetail(
			@RequestParam("questionId") Long questionId,
			@RequestParam(value = "userId", required = false) Long userId,
			HttpServletRequest request) {
		ModelAndView view = new ModelAndView("/club/question_detail.ftl");
		QuestionQuery query = new QuestionQuery();
		query.setQuestionId(questionId);
		query.setSearchAnswers(true);
		QuestionVO question = questionService.querySimpleObjectQuestion(query);
		
		view.addObject("pagination", question.getAnswerPage().getPagination())
		.addObject("question", question)
		.addObject("userId", getUserId(request, userId))
		.addObject("questionId", questionId);
//		view.addObject("question", question).addObject("userId", getUserId(request, userId));
		//查询该用户是否赞过该回答
		List<AnswerVO> answers = question.getAnswerPage().getR();
		List<Long> answerIds = Lists.newArrayList();
		for(AnswerVO answer : answers){
			answerIds.add(answer.getId());
		}
		AnswerGoodBadQuery q = new AnswerGoodBadQuery();
		q.setAnswerIds(answerIds);
		q.setDeleteFlag(DeleteFlag.NO.getValue());
		q.setTypes(Arrays.asList(AnswerTypes.GOOD.getValue()));
		q.setUserId(userId);
		List<AnswerGoodBadEntity> goodBadByQuery = answerService.findAnswerGoodBadByQuery(q);
		Map<Long,String> answerGoodBadMap = Maps.newHashMap();
		if(goodBadByQuery != null){
			for(AnswerGoodBadEntity entity : goodBadByQuery){
				answerGoodBadMap.put(entity.getAnswerId(), "true");
			}
		}
		List<AnswerWrapper> wrappers = Lists.newArrayList();
		for(AnswerVO answer : answers){
			AnswerWrapper wrapper = new AnswerWrapper();
			wrapper.setAnswerVO(answer);
			if(answerGoodBadMap.get(answer.getId()) != null){
				wrapper.setOnGood("true");
			}
			wrappers.add(wrapper);
		}
		view.addObject("answers", wrappers);
		//freemarker页面判断map是否包含该answerId，如果包含，则不能点赞
		view.addObject("answerGoodBadMap", answerGoodBadMap);
		return view;
	}
	
	@RequestMapping("/more")
	public ModelAndView loadMore(
			@RequestParam(value = "currentPage", defaultValue = "1") Integer currentPage,
			@RequestParam(value = "userId", required = false) Long userId,
			@RequestParam(value = "questionId") Long questionId,
			HttpServletRequest request) {
		ModelAndView view = new ModelAndView("/club/answer_more.ftl");
		AnswerQuery query = new AnswerQuery();
		query.setQuestionId(questionId);
		query.setPagination(new Pagination(5, currentPage));
		PaginationResult<List<AnswerVO>> result = answerService
				.findAnswerByQuery(query);
		List<AnswerVO> answers = result.getR();
		List<Long> answerIds = Lists.newArrayList();
		for(AnswerVO answer : answers){
			answerIds.add(answer.getId());
		}
		AnswerGoodBadQuery q = new AnswerGoodBadQuery();
		q.setAnswerIds(answerIds);
		q.setDeleteFlag(DeleteFlag.NO.getValue());
		q.setTypes(Arrays.asList(AnswerTypes.GOOD.getValue()));
		q.setUserId(userId);
		List<AnswerGoodBadEntity> goodBadByQuery = answerService.findAnswerGoodBadByQuery(q);
		Map<Long,String> answerGoodBadMap = Maps.newHashMap();
		if(goodBadByQuery != null){
			for(AnswerGoodBadEntity entity : goodBadByQuery){
				answerGoodBadMap.put(entity.getAnswerId(), "true");
			}
		}
		List<AnswerWrapper> wrappers = Lists.newArrayList();
		for(AnswerVO answer : answers){
			AnswerWrapper wrapper = new AnswerWrapper();
			wrapper.setAnswerVO(answer);
			if(answerGoodBadMap.get(answer.getId()) != null){
				wrapper.setOnGood("true");
			}
			wrappers.add(wrapper);
		}
		view.addObject("answers", wrappers).addObject("userId", getUserId(request, userId));
		view.addObject("answerGoodBadMap", answerGoodBadMap);
		return view;
	}
	
	private Long getUserId(HttpServletRequest request,Long userId){
		String requestUrl = request.getRequestURL().toString();
		if(StringUtils.isNotBlank(requestUrl)){
			//说明是生产环境，需要使用单点登录
			if(requestUrl.contains(DOMAIN)){
				userId = ssoClient.getLoginStatus(request);
			}
		}
		return userId;
	}
	
	/***
	 * 问题点赞
	 * @param questionId
	 * @return
	 */
	@RequestMapping("/good")
	@ResponseBody
	public void onGood(@RequestParam("questionId") Long questionId,@RequestParam("answerId") Long answerId,
			@RequestParam(value="userId",required=false) Long userId, HttpServletRequest request,
			HttpServletResponse response) {
		userId = getUserId(request, userId);
		AnswerGoodBadBO bo = new AnswerGoodBadBO();
		bo.setAnswerId(answerId);
		bo.setUserId(userId);
		bo.setType(1);
		Long num = this.answerService.onGoodBad(bo);
		StatusVO statusVO = new StatusVO();
		statusVO.setMsg("保存成功");
		statusVO.setNum(num.intValue());
		statusVO.setStatus(true);
		ControllerUtil.response2JSON(response, statusVO);
	}
	
	@RequestMapping("/help")
	public ModelAndView help(
			@RequestParam(value = "content", required = false, defaultValue = "") String content,
			@RequestParam(value = "openid", required = false, defaultValue = "") String openid,
			@RequestParam(value="userId",required=false) Long userId, HttpServletRequest request,
			HttpServletResponse response) {
		//+在http请求被转码成空格，所以把空格替换成+
		content = content.replace(" ", "+");
		//如果有%号，说明浏览器对链接URLEncode了，需要对其解码，content是Base64加密过来的，只可能是字母数字+=/
		if(content.contains("%")){
			try {
				content = URLDecoder.decode(content,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		ModelAndView view = new ModelAndView("/club/help.ftl");
		view.addObject("content", new String(Base64.decode(content)));
		view.addObject("openid", openid);
		view.addObject("userId", userId);
		return view;
	}

	@RequestMapping("/askHelp")
	public void askHelp(
			@RequestParam(value = "content") String content,
			@RequestParam(value = "openid") String openid,
			@RequestParam(value="userId",required=false) Long userId, HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("openid : " + openid + " userId : " + userId + " 提问 : " + content);
		String token = springRedisClient.get(getRedisCacheKey(com.saic.ebiz.component.wx.Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE,null);
		CommonUtil.sendMessage(token, openid, "主人，我们将48小时内解决，并用公众号通知到您!!!");
	}
	
	/** 根据appid获取rediskey */
	protected String getRedisCacheKey(String prefixKey) {
		return prefixKey + appId;
	}
	
}
