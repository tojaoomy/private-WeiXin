/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller.club;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.util.ControllerUtil;
import com.saic.sso.client.SSOClient;

/**
 * @author hejian
 *
 */
@RestController
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private SSOClient ssoClient;
	
	private static String DOMAIN = Constants.DOMAIN;
	
	private Long getUserId(HttpServletRequest request,Long userId){
		String requestUrl = request.getRequestURL().toString();
		if(StringUtils.isNotBlank(requestUrl)){
			//说明是生产环境，需要使用单点登录
			if(requestUrl.contains(DOMAIN)){
				userId = ssoClient.getLoginStatus(request);
			}
		}
		return userId;
	}
	
	/**
	 * 判断登录状态
	 * @param questionId
	 * @param answerId
	 * @param userId
	 * @param request
	 * @param response
	 */
	@RequestMapping("/checkLoginStatus")
	@ResponseBody
	public void checkLoginStatus(@RequestParam(value="userId",required=false) Long userId, HttpServletRequest request,
			HttpServletResponse response) {
		userId = getUserId(request, userId);
		boolean status = false;
		if(userId != null && userId > 0){
			status = true;
		}
		ControllerUtil.response2JSON(response, status);
	}
	
}
