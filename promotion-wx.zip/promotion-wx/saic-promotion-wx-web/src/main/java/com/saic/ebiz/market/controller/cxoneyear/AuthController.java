/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: AuthController.java
 * Author:   xiejuan
 * Date:     2014年11月6日 下午6:44:40
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.controller.cxoneyear;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.market.oneyear.entity.UserAccessToken;
import com.saic.ebiz.market.oneyear.service.AccessTokenService;
import com.saic.ebiz.market.oneyear.service.UserInfoService;
import com.saic.ebiz.market.service.AuthorizationService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author xiejuan
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/auth")
public class AuthController extends BaseController{
    private static final Logger logger = LoggerFactory
            .getLogger(AuthController.class);
    
    /**跳转授权页面*/
    private static final String INDEX="/wx_cxoneyear/auth.ftl";
    
    @Resource
    private AuthorizationService authorizationService;
    
    @Resource
    private UserInfoService userInfoService;
 
    /***微信权限信息   */
    @Resource
    private AccessTokenService accessTokenService;
    
//    /** 缓存接口. */
//    @Resource(name = "springRedisClient")
//    private IRedisClient redisClient;

    @Value("${ebiz.wap.web.domain:}")
    private String domain;
    /***
     * 
     * 功能描述: <br>
     * 〈功能详细描述〉
     *
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value="/index",method=RequestMethod.GET)
    public  void  index(HttpServletResponse response,HttpServletRequest request){
        String sourceOpenId=request.getParameter("sourceOpenId");
        logger.info("=====授权页面的sourceOpenId="+sourceOpenId);
        StringBuilder  url=new StringBuilder();
        //url.append("redirect:");
        url.append(accessTokenService.auth(domain+"auth/redirect.htm?sourceOpenId="+sourceOpenId));
        Cookie cookie = new Cookie("scookie0", "");
        response.addCookie(cookie);
        logger.info(" url : " + url.toString());
        try {
            response.sendRedirect(url.toString());
        } catch (IOException e) {
            logger.info("异常");
            e.printStackTrace();
        }
//        return url.toString();
    }
     
    
    /***
     * 
     * 功能描述: <br>
     * 〈功能详细描述〉
     *
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value="/weixin",method=RequestMethod.GET)
    public  ModelAndView  weixin(@RequestParam(value="code",required=false) String code,@RequestParam(value="state",required=false) String state,Model model,HttpServletRequest request,HttpServletResponse response){
        logger.info("=======进入weixin=================");
        HttpSession session = request.getSession();
        String sessionId=session.getId();
        logger.info("code:{},state:{}",code,state);
        UserAccessToken userAccessToken=accessTokenService.getUserAccessToken(sessionId,code);
//        UserInfo userInfo=userInfoService.getSNSUserInfo(userAccessToken.getOpenid(), userAccessToken.getAccess_token());
        String sourceOpenId=request.getParameter("sourceOpenId");
        logger.info("=====授权页面的redirect weixin="+sourceOpenId);
        return new ModelAndView(this.redirect("/oneyear/forhelp.htm?currentOpenId="+userAccessToken.getOpenid()+"&sourceOpenId="+sourceOpenId+"&token="+userAccessToken.getAccess_token()));
    }
    
    
    /***
     * 
     * 功能描述:Ajax请求 <br>
     * 〈功能详细描述〉
     *
     * @param userLoginParam 登录参数请求对象
     * @return  返回AjaxObject对象
     * @throws IOException
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "/redirect", method = RequestMethod.GET)
    public String redirect(@RequestParam("code") String code,@RequestParam("state") String state,HttpServletRequest request,Model model){
        model.addAttribute("code",code);
        model.addAttribute("state", state);
        
        String sourceOpenId=request.getParameter("sourceOpenId");
        logger.info("=====授权页面的redirect sourceOpenId="+sourceOpenId);
        model.addAttribute("sourceOpenId", sourceOpenId);
        return INDEX;
    }
    
}
