///*
// * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
// * FileName: IndexController.java
// * Author:   xiejuan
// * Date:     2014年11月5日 下午5:22:30
// * Description: //模块目的、功能描述      
// * History: //修改记录
// * <author>      <time>      <version>    <desc>
// * 修改人姓名             修改时间            版本号                  描述
// */
//package com.saic.ebiz.market.controller.cxoneyear;
//
//import java.math.BigDecimal;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.List;
//import java.util.Map;
//
//import javax.annotation.Resource;
//import javax.servlet.http.Cookie;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.apache.commons.collections.CollectionUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.ibm.framework.dal.pagination.Pagination;
//import com.ibm.framework.dal.pagination.PaginationResult;
//import com.meidusa.fastjson.JSONObject;
//import com.saic.ebiz.ending.battle.service.api.CashTradeService;
//import com.saic.ebiz.ending.battle.service.api.ICheXiangCarNumberRuleService;
//import com.saic.ebiz.ending.battle.service.api.IShareCardService;
//import com.saic.ebiz.ending.battle.service.entity.AccBalanceInfo;
//import com.saic.ebiz.ending.battle.service.entity.CashTradeDto;
//import com.saic.ebiz.ending.battle.service.entity.MyShareFriendsInfo;
//import com.saic.ebiz.ending.battle.service.exception.CashTradeException;
//import com.saic.ebiz.ending.battle.service.exception.CashTradeRedoException;
//import com.saic.ebiz.market.oneyear.entity.UserInfo;
//import com.saic.ebiz.market.oneyear.service.UserInfoService;
//import com.saic.ebiz.market.service.AuthorizationService;
//import com.saic.ebiz.market.service.BoundingService;
//import com.saic.ebiz.market.util.BASE64;
//import com.saic.ebiz.mdm.api.UserService;
//import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
//import com.saic.ebiz.mdm.entity.WebAccountVO;
//
///**
// * 〈一句话功能简述〉<br>
// * 〈功能详细描述〉
// * 
// * @author xiejuan
// * @see [相关类/方法]（可选）
// * @since [产品/模块版本] （可选）
// */
//@Controller
//@RequestMapping("/oneyear")
//public class IndexController extends BaseController {
//    private static final Logger logger = LoggerFactory.getLogger(IndexController.class);
//
//    /** 用户行为跟踪logger. */
//    private Logger usertraceLogger = LoggerFactory.getLogger("weixin-trace");
//
//    /** 跳转到本人擦车牌页面 */
//    private static final String INDEX_FTL = "/wx_cxoneyear/index.ftl";
//
//    /** 跳转到擦车牌结果页面 */
//    private static final String RESULT_FTL = "/wx_cxoneyear/result.ftl";
//
//    /** 跳转到求帮助页面 */
//    private static final String HELP_FTL = "/wx_cxoneyear/help.ftl";
//
//    /** 跳转到兑换成功页面 */
//    private static final String SUCCESS_FTL = "/wx_cxoneyear/success.ftl";
//
//    /** 跳转到排名页面 */
//    private static final String BILL_FTL = "/wx_cxoneyear/bill.ftl";
//
//    @Resource
//    private AuthorizationService authorizationService;
//
//    @Resource
//    private UserInfoService userInfoService;
//
//    @Resource
//    private BoundingService boundingService;
//
//    @Resource
//    private CashTradeService cashTradeService;
//
//    @Resource
//    private IShareCardService iShareCardService;
//
//    @Resource
//    private ICheXiangCarNumberRuleService iCheXiangCarNumberRuleService;
//
//    @Resource
//    private UserService userService;
//
//    @Value("${ebiz.wap.web.domain:}")
//    private String domain;
//
//
//    /**
//     * 
//     * 功能描述: <br>
//     * 首页推送---本人进去擦车牌页面
//     * 
//     * @param request
//     * @param modelMap
//     * @param response
//     * @return
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    @RequestMapping(value = "/wipePlatesBymyself", method = { RequestMethod.GET })
//    public ModelAndView wipePlatesBymyself(HttpServletRequest request, ModelMap modelMap) {
//        logger.info("=================进入wipePlatesBymyself===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("wipePlatesBymyself currentOpenId="+currentOpenId);
//
//        CashTradeDto cashTradeDto = new CashTradeDto();
//        cashTradeDto.setOpenId(currentOpenId);
//        cashTradeDto.setOwnerOpenId(currentOpenId);
//        cashTradeDto.setTradeChannel(1);
//        cashTradeDto.setTradeType(1);
//        boolean flag = cashTradeService.checkAccountTradeInfo(cashTradeDto);
//
//        logger.info("#####首页自己是否擦了车牌：" + flag);
//
//        if (flag) {
//            return new ModelAndView(this.redirect("/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId));
//        } else {
//            UserInfo userInfo = userInfoService.getUserInfo(currentOpenId);
//            AccBalanceInfo info = new AccBalanceInfo();
//            info.setOpenId(currentOpenId);
//            // 如果登录后再点击的擦车牌，调接口查询userId
//            List<WebAccountVO> webAccountVOList = boundingService.checkBounding(currentOpenId);
//            if (!CollectionUtils.isEmpty(webAccountVOList)) {
//                Long userId = webAccountVOList.get(0).getUserId();
//                info.setUserId(userId + "");
//            }
//            info.setWeixinImageUrl(userInfo.getHeadimgurl());
//            info.setWeixinNick(userInfo.getNickname());
//            // 创建账户
//            cashTradeService.createAccount(info);
//            // 已有多少人参加擦车牌
//            Long countPeople = cashTradeService.countActivityUser();
//            modelMap.addAttribute("countPeople", countPeople);
//            
//            modelMap.addAttribute("currentOpenId", currentOpenId);
////            // 加密三次
//            modelMap.addAttribute("base64CurrentOpenId",
//                    BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//            ModelAndView model = new ModelAndView(INDEX_FTL);
//            return model;
//        }
//    }
//
//    /**
//     * 
//     * 功能描述: <br>
//     * 首页擦车牌后跳转到结果页面
//     * 
//     * @param request
//     * @return
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    @RequestMapping(value = "/result", method = { RequestMethod.GET })
//    public ModelAndView result(HttpServletRequest request, ModelMap modelMap) {
//        logger.info("=================进入result===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("result currentOpenId=" + currentOpenId);
//        try {
//            // 擦自己的车牌
//            BigDecimal reward = iShareCardService.firstShareAmount(currentOpenId);
//            modelMap.addAttribute("reward", reward);
//        } catch (CashTradeException e) {
//            // 为自己擦过
//            return new ModelAndView(this.redirect("/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId));
//
//        } catch (CashTradeRedoException e) {
//            logger.info("自己擦重复车牌.....");
//            // 为自己擦过
//            return new ModelAndView(this.redirect("/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId));
//        }
//
//        // 获取谁帮我擦车牌（openId,昵称，头像） 根据openId查询明细表
//        Pagination pagination = new Pagination();
//        pagination.setCurrentPage(1);
//        pagination.setPagesize(3);
//
//        PaginationResult<List<MyShareFriendsInfo>> paginationResult = cashTradeService.queryMyShareFriends(
//                currentOpenId, pagination);
//        List<MyShareFriendsInfo> friendList = paginationResult.getR();
//
//        if (!CollectionUtils.isEmpty(friendList)) {
//            for (MyShareFriendsInfo info : friendList) {
//                if (StringUtils.isEmpty(info.getWeixinImage())) {
//                    info.setWeixinImage(domain + "/resources/images/wx_cxoneyear/weixintouxiang.jpg");
//                }else{
//                 String headimgurl=info.getWeixinImage();
//                 headimgurl=headimgurl.replace(headimgurl.substring(headimgurl.lastIndexOf("0"),headimgurl.length()),
//                 "96");
//                 logger.info("我的个人头像："+headimgurl);
//                 info.setWeixinImage(headimgurl);
//                }
//                logger.info("好友的昵称：" + info.getWeixinNick() + "，好友的图片：" + info.getWeixinImage() + ",好友的钱:"
//                        + info.getOwnerAmount());
//            }
//        }
//        modelMap.addAttribute("friendList", friendList);// 获取好友列表
//        modelMap.addAttribute("currentOpenId", currentOpenId);
//        // 加密三次
//        modelMap.addAttribute("base64CurrentOpenId",
//                BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//
//        // 擦完车牌到成功页面
//        ModelAndView modelAndView = new ModelAndView(RESULT_FTL);
//        return modelAndView;
//    }
//
//    /**
//     * 
//     * 功能描述: <br>
//     * 链接到我的小钱钱排行页面
//     * 
//     * @param request
//     * @return
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    @RequestMapping(value = "/billBymyself", method = { RequestMethod.GET })
//    public ModelAndView billBymyself(HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) {
//        logger.info("=================进入billBymyself===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("billBymyself currentOpenId=" + currentOpenId);
//        // 根据openId查询账号信息 获取擦出来话费总额，排行
//        AccBalanceInfo accBalanceInfo = cashTradeService.queryAccountInfo(currentOpenId);
//
//        // 2014.11.20号上线，默认设置第一天排行为120
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        String dateStr = "2014-11-20";
//        Date date = new Date();
//        String dateStrs = sdf.format(date);
//        if ((dateStrs.equals(dateStr))) {
//            accBalanceInfo.setCurrRanking(120);
//        }
//        modelMap.addAttribute("accBalanceInfo", accBalanceInfo);
//
//        // 获取谁帮我擦车牌（openId,昵称，头像） 根据openId查询明细表
//        Pagination pagination = new Pagination();
//        pagination.setCurrentPage(1);
//        pagination.setPagesize(6);
//
//        PaginationResult<List<MyShareFriendsInfo>> paginationResult = cashTradeService.queryMyShareFriends(
//                currentOpenId, pagination);
//        List<MyShareFriendsInfo> friendList = paginationResult.getR();
//        int pageCount = paginationResult.getPagination().getPageCount();
//
//        if (!CollectionUtils.isEmpty(friendList)) {
//            for (MyShareFriendsInfo info : friendList) {
//                if (StringUtils.isEmpty(info.getWeixinImage())) {
//                    info.setWeixinImage(domain + "/resources/images/wx_cxoneyear/weixintouxiang.jpg");
//                }else{
//                 String headimgurl=info.getWeixinImage();
//                 //
//                 headimgurl=headimgurl.replace(headimgurl.substring(headimgurl.lastIndexOf("0"),headimgurl.length()),
//                 "96");
//                 logger.info("我的个人头像："+headimgurl);
//                 info.setWeixinImage(headimgurl);
//                }
//                logger.info("好友的昵称：" + info.getWeixinNick() + "，好友的图片：" + info.getWeixinImage() + ",好友的钱:"
//                        + info.getOwnerAmount());
//            }
//        }
//
//        modelMap.addAttribute("pageCount", pageCount);// 总页数
//        modelMap.addAttribute("friendList", friendList);// 获取好友列表
//        modelMap.addAttribute("currentOpenId", currentOpenId);// 自己的openId
////        // 加密三次
//        modelMap.addAttribute("base64CurrentOpenId",
//                BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//
//        // 判断车牌,如果没有 需要生成车牌
//        String carCard = "";
//        List<WebAccountVO> webAccountVOList = boundingService.checkBounding(currentOpenId);
//        if (!CollectionUtils.isEmpty(webAccountVOList)) {
//            Long userId = webAccountVOList.get(0).getUserId();
//            carCard = iCheXiangCarNumberRuleService.findUserCarNumber(userId);
//            if (!StringUtils.isEmpty(carCard)) {
//                logger.info("从pc端生成了车牌，车牌号为：" + carCard);
//                modelMap.addAttribute("carCard", carCard);
//            }
//        }
//        ModelAndView modelAndView = new ModelAndView(BILL_FTL);
//        return modelAndView;
//    }
//
//    // load加载更多
//    @RequestMapping(value = "/loadingMore", method = { RequestMethod.GET })
//    @ResponseBody
//    public List<MyShareFriendsInfo> loadingMore(HttpServletRequest request, ModelMap modelMap,
//            HttpServletResponse response) {
//        logger.info("=================进入loadingMore===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("billBymyself currentOpenId=" + currentOpenId);
//        modelMap.addAttribute("currentOpenId", currentOpenId);
//
//        String currentPageStr = request.getParameter("currentPage");
//
//        // 获取谁帮我擦车牌（openId,昵称，头像） 根据openId查询明细表
//        Pagination pagination = new Pagination();
//        pagination.setCurrentPage(Integer.parseInt(currentPageStr));
//        pagination.setPagesize(6);
//
//        PaginationResult<List<MyShareFriendsInfo>> paginationResult = cashTradeService.queryMyShareFriends(
//                currentOpenId, pagination);
//        List<MyShareFriendsInfo> friendList = paginationResult.getR();
//        int pageCount = paginationResult.getPagination().getPageCount();
//
//        modelMap.addAttribute("pageCount", pageCount);// 总页数
//        modelMap.addAttribute("friendList", friendList);// 获取好友列表
//
//        return friendList;
//    }
//
//    // 立即兑换
//    @RequestMapping(value = "/exchange", method = { RequestMethod.GET })
//    @ResponseBody
//    public String exchange(HttpServletRequest request, ModelMap modelMap) {
//        logger.info("=================进入exchange===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("exchange currentOpenId=" + currentOpenId);
//        modelMap.addAttribute("currentOpenId", currentOpenId);
//
//        // 根据openId查询账号信息 获取擦出来的金额
//        AccBalanceInfo accBalanceInfo = cashTradeService.queryAccountInfo(currentOpenId);
//        logger.info("exchange ######  cashTradeService.queryAccountInfo({}) return : {}", currentOpenId, JSONObject.toJSONString(accBalanceInfo));
//        modelMap.addAttribute("accBalanceInfo", accBalanceInfo);
//
////        String redirectUri = "redirect:/account/wxlogin?";
//        String redirectUri = domain+"/account/wxlogin?";
//        String backUrl = domain + "/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId;
//        String fromType = "29";// 来源
//        String token = "";
//        String errcode = "";
//
//        if (!boundingService.checkResultBounding(currentOpenId)) {
//            StringBuilder url = new StringBuilder(redirectUri);
//            url.append("openid=");
//            url.append(currentOpenId);
//            url.append("&backUrl=");
//            url.append(backUrl);
//            url.append("&fromType=");
//            url.append(fromType);
//            url.append("&token=");
//            url.append(token);
//            url.append("&errcode=");
//            url.append(errcode);
//            logger.info("重新登陆 url : " + url.toString());
//            return url.toString();
//        } else {
//            logger.info("已经绑定了微信用户信息了，直接链接到成功页面");
//            // 监控代码
//            //如果userId不为空 就去调用监控代码
//            if(StringUtils.isNotEmpty(accBalanceInfo.getUserId())){
//                UserBaseInfoVO user = userService.findBaseInfoByUserId(Long.valueOf(accBalanceInfo.getUserId()));
//                if (!StringUtils.isEmpty(user.getMobile())) {
//                    String mobile = user.getMobile();
//                    // 用户追踪
//                    Cookie[] cookies = request.getCookies();
//                    String userTraceCookie = "";
//                    for (Cookie cookie : cookies) {
//                        String username = cookie.getName();
//                        if ("user_trace_cookie".equals(username)) {
//                            userTraceCookie = cookie.getValue();
//                            break;
//                        }
//                    }
//                    usertraceLogger.info(userTraceCookie + "\t" + user.getUserId() + "\t" + -1L + "\t" + "m-车享号牌:"
//                            + accBalanceInfo.getCarCard() + "\t" + mobile);
//                }
//            }
//            //  立即兑换 充值兑换话费
//            CashTradeDto cashTradeDto = new CashTradeDto();
//            cashTradeDto.setOpenId(currentOpenId);
//            // 如果登录后再点击的擦车牌，调接口查询userId
//            List<WebAccountVO> webAccountVOList = boundingService.checkBounding(currentOpenId);
//            if (!CollectionUtils.isEmpty(webAccountVOList)) {
//                Long userId = webAccountVOList.get(0).getUserId();
//                cashTradeDto.setUserId(Long.valueOf(userId));
//            }
//            cashTradeDto.setTradeAmount(accBalanceInfo.getBalance());
//            int money = accBalanceInfo.getBalance().intValue();
//            logger.info("可用余额  money : " + money);
//            String url="";
//            if (money >= 10) {// 大于10才能兑换成功
//                try {
//                    cashTradeService.recharge(cashTradeDto);
//                    url = domain + "/oneyear/success.htm?currentOpenId=" + currentOpenId;
//                } catch (CashTradeException e) {
//                    logger.debug(e.getMessage());
//                   return "error";
//                }
//            } else {
//                url = domain + "/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId;
//                logger.info("直接返回余额查询页面  Url " + url);
//            }
//            return url;
//        }
//    }
//    
//    @RequestMapping(value = "/success", method = { RequestMethod.GET })
//    public String success(HttpServletRequest request, ModelMap modelMap) {
//        // 加密三次
//        String currentOpenId = request.getParameter("currentOpenId");
//        modelMap.addAttribute("base64CurrentOpenId",
//                BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//        return SUCCESS_FTL;
//    }
//
//    /**
//     * 
//     * 功能描述: <br>
//     * 马上去领
//     * 
//     * @param request
//     * @param modelMap
//     * @return
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    @RequestMapping(value = "/draw", method = { RequestMethod.GET })
//    public String draw(HttpServletRequest request, ModelMap modelMap) {
//        logger.info("=================进入draw===========================");
//        usertraceLogger.info("user_trance_debug test ...");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("马上领取currentOpenId：" + currentOpenId);
//        String redirectUri = "redirect:/account/wxlogin.htm?";
//        String backUrl = /*domain + */"oneyear/billBymyself.htm?currentOpenId=" + currentOpenId;
//        String fromType = "29";// 来源
//        String token = "";
//        String errcode = "";
//
//        // 根据openId查询账号信息 获取车牌
//        AccBalanceInfo accBalanceInfo = cashTradeService.queryAccountInfo(currentOpenId);
//        logger.info("call cashTradeService.queryAccountInfo{} ###### return {} ",currentOpenId , JSONObject.toJSON(accBalanceInfo));
//
//        modelMap.addAttribute("accBalanceInfo", accBalanceInfo);
//
//        logger.info("检查是否绑定：" + boundingService.checkResultBounding(currentOpenId));
//
//        if (!boundingService.checkResultBounding(currentOpenId)) {
//            StringBuilder url = new StringBuilder(redirectUri);
//            url.append("&openid=");
//            url.append(currentOpenId);
//            url.append("&backUrl=");
//            url.append(backUrl);
//            url.append("&fromType=");
//            url.append(fromType);
//            url.append("&token=");
//            url.append(token);
//            url.append("&errcode=");
//            url.append(errcode);
//            logger.info("马上去领未登录链接到登陆页面，url地址:" + url.toString());
//            return url.toString();
//        } else {
//            logger.info("用户已登录，链接到话费查询页面。。。。");
//
//            // 判断车牌,如果没有 需要生成车牌
//            CashTradeDto cashTrade = new CashTradeDto();
//            cashTrade.setOpenId(currentOpenId);
//            List<WebAccountVO> webAccountVOList = boundingService.checkBounding(currentOpenId);
//            if (!CollectionUtils.isEmpty(webAccountVOList)) {
//                cashTrade.setUserId(webAccountVOList.get(0).getUserId());
//            }
//            String carCard = cashTradeService.getCarCard(cashTrade);
//
//            // 监控代码
//            UserBaseInfoVO user = userService.findBaseInfoByUserId(new Long(accBalanceInfo.getUserId()));
//            if (!StringUtils.isEmpty(user.getMobile())) {
//                String mobile = user.getMobile();
//                // 用户追踪
//                Cookie[] cookies = request.getCookies();
//                String userTraceCookie = "";
//                for (Cookie cookie : cookies) {
//                    String username = cookie.getName();
//                    if ("user_trace_cookie".equals(username)) {
//                        userTraceCookie = cookie.getValue();
//                        break;
//                    }
//                }
//                usertraceLogger.info(userTraceCookie + "\t" + user.getUserId() + "\t" + -1L + "\t" + "m-车享号牌:"
//                        + carCard + "\t" + mobile);
//            }
//
//            if (StringUtils.isEmpty(carCard)) {
//                logger.info("carCard车牌号为空");
//                return null;
//            }
//
//            modelMap.addAttribute("carCard", carCard);
//            // 加密三次
//            modelMap.addAttribute("base64CurrentOpenId",
//                    BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//            return this.redirect("/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId);
//        }
//    }
//
//    /**
//     * 
//     * 功能描述: <br>
//     * 跳转到求帮助页面(任何分享的页面都跳转到此页面)
//     * 
//     * @return
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    @RequestMapping(value = "/forhelp", method = { RequestMethod.GET })
//    public ModelAndView forhelp(HttpServletRequest request, ModelMap modelMap) {
//        logger.info("=================进入forhelp===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("求帮助currentOpenId:" + currentOpenId);
//
//        // 微信授权成功后第二次进来，request中不存在sourceOpenId
//        String sourceOpenId = request.getParameter("sourceOpenId");
//        logger.info("求帮助sourceOpenId:" + sourceOpenId);
//
//        if (StringUtils.isEmpty(currentOpenId)) {
//            logger.info("currentOpenId擦sourceOpenId的车牌，currentOpenId：" + currentOpenId);
//            return new ModelAndView(this.redirect("/auth/index.htm?sourceOpenId=" + sourceOpenId));
//        }
//
//        logger.info("currentOpenId擦sourceOpenId的车牌且微信授权成功后，sourceOpenId：{},currentOpenId:{}", new Object[] {
//                sourceOpenId, currentOpenId });
//
//        modelMap.addAttribute("currentOpenId", currentOpenId);
//        // 获取好友的授权后的数据
//        String token = request.getParameter("token");
//        UserInfo userInfo = userInfoService.getSNSUserInfo(currentOpenId, token);
//        logger.info("求转发，好友的昵称nickname:" + userInfo.getNickname());
//
//        String decodeSource=new String(BASE64.decode(new String(BASE64.decode(new String(BASE64.decode(sourceOpenId))))));
//        if (decodeSource.equals(currentOpenId)) {
//            return new ModelAndView(this.redirect("/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId));
//        }
//
//        // 先判断有没有为别人擦过，如果为别人擦过，再判断有没有为自己擦过
//        CashTradeDto cashTradeDto = new CashTradeDto();
//        cashTradeDto.setOpenId(currentOpenId);
//        cashTradeDto.setOwnerOpenId(decodeSource);
//        cashTradeDto.setTradeChannel(2);
//        cashTradeDto.setTradeType(1);
//        boolean flagr = cashTradeService.checkAccountTradeInfo(cashTradeDto);
//        logger.info("求帮助是否擦了车牌=" + flagr);
//        // 先判断有没有为别人擦过
//        if (flagr) {
//            // 为别人擦过
//            CashTradeDto cashforme = new CashTradeDto();
//            cashforme.setOpenId(currentOpenId);
//            cashforme.setOwnerOpenId(currentOpenId);
//            cashforme.setTradeChannel(1);
//            cashforme.setTradeType(1);
//            boolean flagm = cashTradeService.checkAccountTradeInfo(cashforme);
//            logger.info("求帮助页面判断是否为自己擦过：" + flagm);
//
//            if (flagm) {
//                // 如果为自己擦过，链接到话费查询页面
//                return new ModelAndView(this.redirect("/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId));
//            } else {
//                // 没为自己擦过链接到车享第一年页面
//                return new ModelAndView(this.redirect("/oneyear/wipePlatesBymyself.htm?currentOpenId=" + currentOpenId));
//            }
//        } else {
//            // 创建好友账户
//            AccBalanceInfo friendAccount = new AccBalanceInfo();
//            friendAccount.setOpenId(currentOpenId);
//            friendAccount.setWeixinImageUrl(userInfo.getHeadimgurl());
//            friendAccount.setWeixinNick(userInfo.getNickname());
//            cashTradeService.createAccount(friendAccount);
//            modelMap.addAttribute("sourceOpenId", sourceOpenId);
//            AccBalanceInfo accBalanceInfo = cashTradeService.queryAccountInfo(decodeSource);
//            modelMap.addAttribute("wxUser", accBalanceInfo);
////            // 加密三次
//            modelMap.addAttribute("base64CurrentOpenId",
//                    BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//            ModelAndView modelAndView = new ModelAndView(HELP_FTL);
//            return modelAndView;
//        }
//    }
//
//    /**
//     * 
//     * 功能描述: <br>
//     * 好友点击擦车牌
//     * 
//     * @param modelMap
//     * @param currentOpenId
//     * @return
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    @RequestMapping("/clickByFriends")
//    @ResponseBody
//    public String clickByFriends(Model modelMap, HttpServletRequest request) {
//        logger.info("=================进入clickByFriends===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        String sourceOpenId = request.getParameter("sourceOpenId");
//        BigDecimal friendBalance = new BigDecimal(0);
//        String url = "";
//        try {
//            if(sourceOpenId.length() > 28){
//                sourceOpenId = new String(BASE64.decode(new String(BASE64.decode(new String(BASE64.decode(sourceOpenId))))));
//            }
//            //判断currentOpenId，sourceOpenId是否存在于库里，如果都存在
//            AccBalanceInfo currentInfo = cashTradeService.queryAccountInfo(currentOpenId);
//            AccBalanceInfo sourceInfo = cashTradeService.queryAccountInfo(sourceOpenId);
//            if(sourceInfo == null || currentInfo ==null){
//                return "擦车牌异常";
//            }
//            modelMap.addAttribute("wxUser", sourceInfo);
//            
//            Map<String, BigDecimal> mapParam = iShareCardService.shareCardAmount(currentOpenId, sourceOpenId);
//
//            // 前端展示自己擦出的话费
//            friendBalance = mapParam.get(currentOpenId);
//            logger.info("currentOpenId{},friendBalance{}", new Object[] { currentOpenId, friendBalance.toString() });
//
//            // 前端展示自己擦出的话费
//            BigDecimal sourceBalance = mapParam.get(sourceOpenId);
//            logger.info("sourceOpenId{},sourceBalance{}", new Object[] { sourceOpenId, sourceBalance.toString() });
//
//        } catch (CashTradeException e) {
//            // 为别人擦过
//            CashTradeDto cashforme = new CashTradeDto();
//            cashforme.setOpenId(currentOpenId);
//            cashforme.setOwnerOpenId(currentOpenId);
//            cashforme.setTradeChannel(1);
//            cashforme.setTradeType(1);
//            boolean flagm = cashTradeService.checkAccountTradeInfo(cashforme);
//            logger.info("求帮助页面判断是否为自己擦过：" + flagm);
//
//            if (flagm) {
//                // 如果为自己擦过，链接到话费查询页面
//                url = domain + "/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId;
//            } else {
//                // 没为自己擦过链接到车享第一年页面
//                url = domain + "/oneyear/wipePlatesBymyself.htm?currentOpenId=" + currentOpenId;
//            }
//        } catch (CashTradeRedoException e) {
//            // 为别人擦过
//            CashTradeDto cashforme = new CashTradeDto();
//            cashforme.setOpenId(currentOpenId);
//            cashforme.setOwnerOpenId(currentOpenId);
//            cashforme.setTradeChannel(1);
//            cashforme.setTradeType(1);
//            boolean flagm = cashTradeService.checkAccountTradeInfo(cashforme);
//            logger.info("求帮助页面判断是否为自己擦过：" + flagm);
//
//            if (flagm) {
//                // 如果为自己擦过，链接到话费查询页面
//                url = domain + "/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId;
//            } else {
//                // 没为自己擦过链接到车享第一年页面
//                url = domain + "/oneyear/wipePlatesBymyself.htm?currentOpenId=" + currentOpenId;
//            }
//        }
//        modelMap.addAttribute("currentOpenId", currentOpenId);
//        // 加密三次
//        modelMap.addAttribute("base64CurrentOpenId",
//                BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//        modelMap.addAttribute("sourceOpenId", sourceOpenId);
//
//        
//        
//        url = friendBalance.toString();
//        return url;
//    }
//
//    /**
//     * 
//     * 功能描述: <br>
//     * 好友点击我也要车享号牌链接到车享第一年页面
//     * 
//     * @param request
//     * @param modelMap
//     * @return
//     * @see [相关类/方法](可选)
//     * @since [产品/模块版本](可选)
//     */
//    @RequestMapping("/friendClickPlates")
//    public ModelAndView friendClickPlates(HttpServletRequest request, ModelMap modelMap) {
//        logger.info("=================进入friendClickPlates===========================");
//        String currentOpenId = request.getParameter("currentOpenId");
//        logger.info("好友点击我也要车享号牌,我自己的currentOpenId=" + currentOpenId);
//        modelMap.addAttribute("currentOpenId", currentOpenId);
//        // 加密三次
//        modelMap.addAttribute("base64CurrentOpenId",
//                BASE64.encode(BASE64.encode(BASE64.encode(currentOpenId.getBytes()).getBytes()).getBytes()));
//
//        CashTradeDto cashTradeDto = new CashTradeDto();
//        cashTradeDto.setOpenId(currentOpenId);
//        cashTradeDto.setOwnerOpenId(currentOpenId);
//        cashTradeDto.setTradeChannel(1);
//        cashTradeDto.setTradeType(1);
//        boolean flag = cashTradeService.checkAccountTradeInfo(cashTradeDto);
//        logger.info("好友点击我也要车享号牌=" + flag);
//
//        if (flag) {
//            return new ModelAndView(this.redirect("/oneyear/billBymyself.htm?currentOpenId=" + currentOpenId));
//        } else {
//            // 没为自己擦过链接到车享第一年页面
//            return new ModelAndView(this.redirect("/oneyear/wipePlatesBymyself.htm?currentOpenId=" + currentOpenId));
//        }
//    }
//}
