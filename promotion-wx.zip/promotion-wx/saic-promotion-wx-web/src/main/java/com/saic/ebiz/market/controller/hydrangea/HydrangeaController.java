/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller.hydrangea;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.ibm.framework.uts.util.StringUtils;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.entity.praise.PraiseResult;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.util.CookieUtil;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.promotion.service.api.IPraiseService;
import com.saic.ebiz.promotion.service.commons.enums.PromotionResultCode;
import com.saic.ebiz.promotion.service.vo.Praise;
import com.saic.ebiz.promotion.service.vo.PraiseInfo;
import com.saic.ebiz.promotion.service.vo.PromotionResult;

/**
 * 
 * 2015 328绣球活动控制器
 * 
 * @author hejian
 *
 */
@RestController
@RequestMapping("/hydrangea")
public class HydrangeaController {
	private static final Logger LOGGER = LoggerFactory.getLogger(HydrangeaController.class); 
	
	/** 用户行为跟踪logger. */
	private static final Logger usertraceLogger = LoggerFactory.getLogger("weixin-trace");
	
	//24小时制
	private static final String DATE_FOMATE = "yyyyMMddHHmmss";
	
	//2015年3月28号0时0分0秒
	private static final String FIRST_PROMOTIN_TIME_START = "20150328000000";
	private static final Date FIRST_PROMOTION_DATE_START = new Date();
	
	//2015年4月3号23时59分59秒
	private static final String FIRST_PROMOTIN_TIME_END = "20150403235959";
	private static final Date FIRST_PROMOTION_DATE_END = new Date();
	
	//2015年4月1号0时0分0秒
	private static final String SECOND_PROMOTIN_TIME_START = "20150401000000";
	private static final Date SECOND_PROMOTION_DATE_START = new Date();
	
	//2015年4月10号23时59分59秒
	private static final String SECOND_PROMOTIN_TIME_END = "20150410235959";
	private static final Date SECOND_PROMOTION_DATE_END = new Date();
	
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(DATE_FOMATE);
	
	//活动代码前缀 Xiuqiu328_a01 Xiuqiu328_a02(a01,a02分别代表绣球点赞活动的第一场和第二场)
	private static final String PROMOTION_CODE_PREFIX = "Xiuqiu328_a0";
	
	/**
	 *  1：电商主站；
	 *	2：车享宝；
	 *	3：营销子站；
	 *	4：保养管家；
	 *	5：第三方联合登陆；
	 *	6：别克联合登陆；
	 *	7：微信服务号；
	 *	8：微信订阅号；
	 *	9：微信红包 
	 *	11：呼叫中心；
	 *	12：平安保险（PC）；
	 *	13：订单系统；
	 *	14：车畅销；
	 *	20：车知道（内部账号）；
	 *	21：别克微信商城；
	 *	22：荣威俱乐部；
	 *	23：crm；
	 *	24：运营平台；
	 *	29：车享购微信服务号；
	 *	31：平安微信；
	 *	35：新浪微博PC；
	 *	36：新浪微博移动；
	 *	60：Other
	 */
	private static final String TRACE_SOURCE = "7";
	
	/**
	 * 线索类型
	 *	10.促销车订购
	 *	11.预约试乘试驾
	 *	12.在线询价
	 *	13.促销活动
	 *	14.常规车预定
	 *	15.来电咨询
	 *	16.在线留言咨询
	 *	17.贷款购车
	 *	18.拉手电话
	 *	20.其他
	 */
	private static final String TRACE_TYPE = "20";
	
	static {
		try {
			FIRST_PROMOTION_DATE_START.setTime(DATE_FORMAT.parse(FIRST_PROMOTIN_TIME_START).getTime());
			FIRST_PROMOTION_DATE_END.setTime(DATE_FORMAT.parse(FIRST_PROMOTIN_TIME_END).getTime());
			SECOND_PROMOTION_DATE_START.setTime(DATE_FORMAT.parse(SECOND_PROMOTIN_TIME_START).getTime());
			SECOND_PROMOTION_DATE_END.setTime(DATE_FORMAT.parse(SECOND_PROMOTIN_TIME_END).getTime());
		} catch (ParseException e) {
			LOGGER.error("格式化日期失败");
		}
	}
	/**
	 * 绣球点赞服务
	 */
	@Resource
	private IPraiseService iPraiseService;
	
	/**
	 * 用户服务
	 */
	@Resource(name = "userService")
    private UserService userService;
	
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
	@Autowired
	private JsSDKSign jsSDKSign;
	
	
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@RequestMapping("/update/{level}/{startTime}/{endTime}")
	private String updatePromotionTime(@PathVariable("level")int level,@PathVariable("startTime")String startTime,
			@PathVariable("endTime")String endTime){
		StringBuilder builder = new StringBuilder();
		if(1 == level){
			builder.append("first group promotion start time :").append(DATE_FORMAT.format(FIRST_PROMOTION_DATE_START))
			.append("\n").append("first group promotion end time :").append(DATE_FORMAT.format(FIRST_PROMOTION_DATE_END));
			try {
				FIRST_PROMOTION_DATE_START.setTime(DATE_FORMAT.parse(startTime).getTime());
				FIRST_PROMOTION_DATE_END.setTime(DATE_FORMAT.parse(endTime).getTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else{
			builder.append("second group promotion start time :").append(DATE_FORMAT.format(FIRST_PROMOTION_DATE_START))
			.append("\n").append("second group promotion end time :").append(DATE_FORMAT.format(FIRST_PROMOTION_DATE_END));
			try {
				SECOND_PROMOTION_DATE_START.setTime(DATE_FORMAT.parse(startTime).getTime());
				SECOND_PROMOTION_DATE_END.setTime(DATE_FORMAT.parse(endTime).getTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return builder.toString();
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return 绣球活动首页
	 */
	@RequestMapping("/main")
	public ModelAndView main(HttpServletRequest request,HttpServletResponse response){
		ModelAndView model = null;
		String uId = request.getParameter(RequestConstants.USER_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		LOGGER.info("request parameters userId = {}, openId = {} ", uId, openId);
		
//		uId = "559464";
		if(StringUtils.isEmpty(uId) || "-1".equals(uId)){
			String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.xiuqiu_main.name());
			LOGGER.debug("未知的用户，使用授权获取openId来查询对应userId######");
			LOGGER.debug("授权url : {} ######", autorizationUrl);
			model = new ModelAndView(autorizationUrl);
		}else{
			model = new ModelAndView("/xiuqiu_328/main/index.ftl");
			model.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
		}
		//微信分享JSSDK分享
		Map<String,String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
		model.addObject("jssdk", map);
		return model;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return 绣球点赞页
	 */
	@RequestMapping("/praiseHome")
	public ModelAndView praiseHome(HttpServletRequest request,HttpServletResponse response){
		//0 未开始或结束, 1第一场活动, 2第二场活动
		String promotionStatus = "0";
		//微信端首先判断用户的userId,如果为-1，则授权，否则正常跳转
		Long userId = -1L;
		String uId = request.getParameter(RequestConstants.USER_ID);
		String keyId = request.getParameter(RequestConstants.KEY_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
//		uId = "559464";
		if(StringUtils.isEmpty(uId) || "-1".equals(uId)){
			String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.xiuqiu.name());
			LOGGER.debug("未知的用户，使用授权获取openId来查询对应userId######");
			LOGGER.debug("授权url : {} ######", autorizationUrl);
			return new ModelAndView(autorizationUrl);
		}else{
			try {
				userId = Long.parseLong(uId);
			} catch (NumberFormatException e) {
				LOGGER.error("HydrangeaController => home userId 转换失败 : " + e.getMessage());
				throw new BaseException("HydrangeaController => home userId 转换失败 " + e.getMessage());
			}
		}
		usertraceLogger.info("微信端进入点赞页\t" + getCookieByName(request) + "\t"
				+ userId + "\t" + "成功" + "\t" + "keyId = " + keyId +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
		promotionStatus = checkPromotionStatus();
		ModelAndView view = new ModelAndView("/xiuqiu_328/hydrangea.ftl");
		setViewProperties(view, promotionStatus, userId,"1");
		view.addObject(RequestConstants.OPEN_ID, openId);
		//微信分享JSSDK分享
		Map<String,String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
		view.addObject("jssdk", map);
		//后门
		String flag = request.getParameter("test");
		if(StringUtils.hasText(flag)){
			view.addObject("test", "true");
		}
		return view;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return 绣球点赞页
	 */
	@RequestMapping("/praise312")
	public ModelAndView praiseHomeSecond(HttpServletRequest request,HttpServletResponse response){
		//0 未开始或结束, 1第一场活动, 2第二场活动
		String promotionStatus = "0";
		//微信端首先判断用户的userId,如果为-1，则授权，否则正常跳转
		Long userId = -1L;
		
		String uId = request.getParameter(RequestConstants.USER_ID);
		String keyId = request.getParameter(RequestConstants.KEY_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		
//		uId = "559464";
		if(StringUtils.isEmpty(uId) || "-1".equals(uId)){
			String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.xiuqiu_312.name());
			LOGGER.debug("未知的用户，使用授权获取openId来查询对应userId######");
			LOGGER.debug("授权url : {} ######", autorizationUrl);
			return new ModelAndView(autorizationUrl);
		}else{
			try {
				userId = Long.parseLong(uId);
			} catch (NumberFormatException e) {
				LOGGER.error("HydrangeaController => home userId 转换失败 : " + e.getMessage());
				throw new BaseException("HydrangeaController => home userId 转换失败 " + e.getMessage());
			}
		}
		usertraceLogger.info("微信端进入点赞页\t" + getCookieByName(request) + "\t"
				+ userId + "\t" + "成功" + "\t" + "keyId = " + keyId +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
		promotionStatus = checkPromotionStatus312();
		ModelAndView view = new ModelAndView("/xiuqiu_328/hydrangea.ftl");
		setViewProperties(view, promotionStatus, userId,"2");
		//微信分享JSSDK分享
		Map<String,String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
		view.addObject("jssdk", map);
		view.addObject(RequestConstants.OPEN_ID, openId);
		//后门
		String flag = request.getParameter("test");
		if(StringUtils.hasText(flag)){
			view.addObject("test", "true");
		}
		return view;
	}
	
	private String getCookieByName(HttpServletRequest request){
		Cookie cookie = CookieUtil.getCookieByName(request, "user_trace_cookie");
		String cookieName = null;
		if(cookie != null){
			cookieName = cookie.getValue();
		}
		return cookieName;		
	}
	
	/**
	 * 设置通用的View属性
	 * @param view
	 * @param promotionStatus 当前活动状态
	 * @return
	 */
	private void setViewProperties(ModelAndView view ,String promotionStatus,Long userId,String sts){
		List<String> couponList = new ArrayList<String>();
		Map<String, Praise> praiseData = null;
		Map<String, Boolean> userPraiseData = null; 
//		String mobile = "18721432848";
		String mobile = "";
		UserBaseInfoVO vo = userService.findBaseInfoByUserId(userId);
		if(vo != null){
			mobile = vo.getMobile();
		}
		String status = sts;
		/*//给Freemarker标志是活动1还是活动2
		String status = "1";
		//如果大于1说明活动2开始，显示活动2的数据，否则显示活动1的数据
		if(Integer.parseInt(promotionStatus) > 1){
			status = "2";
		}*/
		//获取用户第一场红包
		//Xiuqiu328_a0 + promotionStatus 
		couponList = this.iPraiseService.getTaxiCouponList(PROMOTION_CODE_PREFIX + status, userId);
		//获取点赞的数据
		praiseData = this.iPraiseService.getTotalPraiseNum(PROMOTION_CODE_PREFIX + status);
		
		//用户当天的点赞状态
		userPraiseData = this.iPraiseService.isTodayPraise(PROMOTION_CODE_PREFIX + status, userId);
		
		//判断用户是否留资
		boolean hasInfo = hasInfo(userId);
		
		view.addObject("promotionStatus", promotionStatus)
		.addObject("promotionStatus16", checkPromotionStatus())
		.addObject("promotionStatus312", checkPromotionStatus312())
		//红包信息
		.addObject("couponList", couponList)
		//点赞的信息，与用户无关
		.addObject("praiseData", praiseData)
		//用户当天点赞的信息
		.addObject("userPraiseData", userPraiseData)
		.addObject("PROMOTION_CODE_PREFIX", PROMOTION_CODE_PREFIX + status)
		.addObject("status", status)
		.addObject("mobile", mobile)
		//前端JS是否弹框留资
		.addObject("hasInfo", String.valueOf(hasInfo))
		.addObject("showAlert", System.getProperty("system.show.alert"))
		.addObject("userId", userId);
	}
	
	/**
	 * 判断当前活动的状态
	 * @return
	 */
	private String checkPromotionStatus(){
		String promotionStatus = "";
		//判断当前时间，是第一场还是第二场活动
		Date now = Calendar.getInstance().getTime();
		if(now.before(FIRST_PROMOTION_DATE_START)){
			//活动未开始
			promotionStatus = "0";
		}else if(now.before(FIRST_PROMOTION_DATE_END)){
			//第一场活动进行中
			promotionStatus = "1";
		}else if(now.before(SECOND_PROMOTION_DATE_END)){
			//第二场活动进行中
			promotionStatus = "2";
		}else if(now.after(SECOND_PROMOTION_DATE_END)){
			//所有活动都结束
			promotionStatus = "3";
		}
		return promotionStatus;
	}
	
	/**
	 * 判断当前活动的状态
	 * @return
	 */
	private String checkPromotionStatus312(){
		String promotionStatus = "";
		//判断当前时间，是第一场还是第二场活动
		Date now = Calendar.getInstance().getTime();
		if(now.before(SECOND_PROMOTION_DATE_START)){
			//活动未开始
			promotionStatus = "0";
		}else if(now.before(SECOND_PROMOTION_DATE_END)){
			//第二场活动进行中
			promotionStatus = "2";
		}else if(now.after(SECOND_PROMOTION_DATE_END)){
			//所有活动都结束
			promotionStatus = "3";
		}
		return promotionStatus;
	}
	
	private boolean hasInfo(Long userId){
		return this.iPraiseService.hasPraiseInfo(userId, 2);
	}
	
	@RequestMapping("/{rounds}.round/{level}")
	public ModelAndView loadMoreFirst(@PathVariable("rounds")String rounds, @PathVariable("level") String level,
			@RequestParam("userId") Long userId,@RequestParam("test") String test,HttpServletRequest request){
		String promotionStatus = checkPromotionStatus();
		//如果是第二波切换
		if("2nd".equals(rounds)){
			promotionStatus = checkPromotionStatus312();
		}
		
		String status = "1";
		if(rounds.startsWith("2")){
			status = "2";
		}
		
		ModelAndView view = new ModelAndView("/xiuqiu_328/" + rounds + ".round." + level + ".ftl");
		setViewProperties(view, promotionStatus, userId,status);
		if(StringUtils.hasText(test)){
			view.addObject("test", "true");
		}
		return view;
	}
	
	/**
	 * 绣球活动页，用户点赞操作
	 * 
	 * @see PromotionResultCode
	 * @param promotionId 活动id
	 * @param velModelId  车型id
	 * @param mobile	    用户关联的手机号
	 * @param userId	    用户id
	 * @return 用户点赞的状态
	 * 
	 * 该车型该活动用户首次点赞返回状态
	 *  0	SUCCESS	成功
	 *	4	NOTSTARTED	未开始
	 *	5	ENDED	已结束
	 *
	 * 该车型该活动用户已经点赞，重复点赞返回状态
	 *  1	TWICE	同一活动同一车型今天已点赞
	 *	2	UNQUALIFIED	用户今天已点赞，不能领券
	 *	5	ENDED	车型点赞次数已满，不能领券
	 *	8	FULL	用户已领3张券
	 *	9	RESULT_FAIL	券已领完
	 *
	 */
	@RequestMapping("/praise")
	public PraiseResult praiseByUser(HttpServletRequest request, @RequestParam("promotionCode") String promotionCode,
							   @RequestParam("mobile") String mobile, @RequestParam("userId") Long userId,
							   @RequestParam("keyId") String keyId){
		PromotionResult promotionResult = this.iPraiseService.praiseEveryDay(promotionCode, mobile, userId);
		usertraceLogger.info("微信端点赞\t" + getCookieByName(request) + "\t"
				+ userId + "\t" + "成功" + "\t" + "keyId = " + keyId +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
		PraiseResult praiseResult = new PraiseResult();
		//先check返回状态 0 成功
		if(promotionResult.getResultCode() == 0){
			praiseResult.setPraiseStatus(promotionResult.getPraiseStatus());
			if(promotionResult.getPraiseStatus() == 0){
				//查询滴滴券
				List<String> didiCoupon = this.iPraiseService.getTaxiCouponList(promotionCode.substring(0, promotionCode.lastIndexOf("_")), userId);
				praiseResult.setDidiCoupon(didiCoupon);
			}
		}
//		praiseResult.setPraise(praise);
		return praiseResult;
	}
	
	@RequestMapping("/createPraiseInfo")
	public String createPraiseInfo(HttpServletRequest request,@RequestParam("userId")Long userId,
			@RequestParam("mobile")String mobile,PraiseInfo entity){
		//-1 用户未绑定手机号, 0 留资失败 , 1 留资成功
		String data = "-1";
		//获取用户电话号码
		UserBaseInfoVO vo = userService.findBaseInfoByUserId(userId);
		if(vo == null){
			return data;
		}
		//点赞2
		entity.setPraiseType(2);
		entity.setMobile(mobile);
		try{
			LOGGER.info("微信点赞留资 : " + JSONObject.toJSONString(entity));
			this.iPraiseService.createPraiseInfo(entity);
			data = "1";
		} catch(Exception e){
			data = "0";
		}
		return data;
	}
	
	/**
	 * 
	 * 根据用户和活动查询获取的滴滴打车券
	 * 
	 * @param promotionId 活动id
	 * @param userId	    用户id
	 * @return 
	 * 		用户在该活动下获得的滴滴红包券码(最多3个)
	 */
	@RequestMapping("/queryDidiCoupon")
	public List<String> queryDidiCoupon(@RequestParam("promotionCode") String promotionCode, @RequestParam("userId") Long userId){
		return this.iPraiseService.getTaxiCouponList(promotionCode, userId);
	}
	
	/**
	 * 返回该活动下所有车型对应的点赞数据
	 * 
	 * @param preCode 活动代码前缀 Xiuqiu328_a01 Xiuqiu328_a02(a01,a02分别代表绣球点赞活动的第一场和第二场)
	 * @return 
	 */
	@RequestMapping("/fetchPromotionPraiseData")
	public Map<String, Praise> fetchPromotionPraiseData(@RequestParam("preCode") String preCode){
		return this.iPraiseService.getTotalPraiseNum(preCode);
	}
	
	public static void main(String[] args) {
		System.out.println("aaaa_sdfds_bbb".substring(0, "aaaa_sdfds_bbb".lastIndexOf("_")));
	}
}