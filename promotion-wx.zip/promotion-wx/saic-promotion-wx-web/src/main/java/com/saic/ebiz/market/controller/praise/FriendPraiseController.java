package com.saic.ebiz.market.controller.praise;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.market.common.entity.authentication.SNSUserInfo;
import com.saic.ebiz.market.controller.BaseController;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.util.BrowserUtil;
import com.saic.ebiz.market.util.FreemarkerUtils;
import com.saic.ebiz.market.util.StringUtils2;
import com.saic.ebiz.market.vo.WxAuthInfo;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtDetailService;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtLaunchService;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtPrizeService;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtService;
import com.saic.ebiz.promotion.service.commons.enums.LaunchStatus;
import com.saic.ebiz.promotion.service.commons.result.Result;
import com.saic.ebiz.promotion.service.commons.result.ResultConst;
import com.saic.ebiz.promotion.service.entity.wx.WxPrmtLaunchEntity;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmt;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmtDetail;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmtPrize;
import com.saic.ebiz.web.entity.WXShareVO;

import freemarker.template.TemplateModel;


/**
 * 被邀请者帮助好友点赞
 * 
 */
@Controller
@RequestMapping("/friendPraise")
public class FriendPraiseController extends BaseController{
    
    private static final String FRIEND_PRAISE_FTL = "/baba/promotion-detail.ftl";
    
    /*日志*/
    private final Logger logger = LoggerFactory.getLogger(FriendPraiseController.class);
    
    @Autowired
    private AuthorizationService authorizationService;
    
    
    @Autowired
    private IWxPrmtLaunchService wxPrmtLaunchService;
    
    @Autowired
    private IWxPrmtDetailService wxPrmtDetailService;
    
    @Autowired
    private IWxPrmtPrizeService wxPrmtPrizeService;
    
    
    @Autowired
    private IWxPrmtService wxPrmtService;
    /**
     * 
     * 功能描述: <br>
     * 好友点赞首页
     *
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/index")
    public ModelAndView index(HttpServletRequest request) {
        
        //活动结束就直接返回新车首页
        WxPrmt wxPrmt = wxPrmtService.getWxPrmtByCode(PRAIS_ACTIVE_CODE);
        if(wxPrmt != null && wxPrmt.getOfflineTime().before(new Date())) {
            return new ModelAndView("redirect:"+mcarBase);
        }
        
        Long launchId = StringUtils2.toLong(request.getParameter("launchId"));
        String openId = request.getParameter("openId");
        
        logger.info("进入点赞:launchId:{}",launchId);
        ModelAndView mv = new ModelAndView(FRIEND_PRAISE_FTL);

        TemplateModel templateMode = FreemarkerUtils.getStaticModel(ResultConst.class);
        mv.addObject("ResultConst", templateMode);
        mv.addObject("result",  ResultConst.SUCCESS);
        if(launchId == null) {
            mv.addObject("result",  ResultConst.ILLEGAL_ARGUMENT);
        }

        WxAuthInfo wxAuthInfo = authorizationService.getWxAuthInfoNoLoginCX(
                request, Scope.snsapi_base,domain+WX_STATIC_URL);
        
        logger.info("进入点赞:wxAuthInfo:{}",wxAuthInfo);
        if(wxAuthInfo.getRedirectUrl() != null) {
            return new ModelAndView("redirect:"+wxAuthInfo.getRedirectUrl());
        }
        
        
        //开始走正常的流程....
        logger.info("进入点赞，开始准备数据");
        SNSUserInfo snsUserInfo = wxAuthInfo.getSNSUserInfo();       
        String friendOpenid = snsUserInfo.getOpenId();

        preparePraiseData(launchId, friendOpenid, request, mv);
        
        //方便测试，测试时自己输入openId
        if(StringUtils.isNotBlank(openId) && authorizationService.isTestEnv() && !authorizationService.isWeiXinBrowser(request)) {
            mv.addObject("testEnv", true);
            mv.addObject("openId",openId);
        }
        
        logger.info("进入点赞数据准备完成");
        return mv;
    }
    
    
    /**
     * 
     * 功能描述: <br>
     * 帮好友点赞
     *
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping("/praise")
    public ModelAndView praise(HttpServletRequest request) {
        
        WxPrmt wxPrmt = wxPrmtService.getWxPrmtByCode(PRAIS_ACTIVE_CODE);
        if(wxPrmt != null && wxPrmt.getOfflineTime().before(new Date())) {
            return new ModelAndView("redirect:"+mcarBase);
        }
        
        Long launchId = StringUtils2.toLong(request.getParameter("launchId"));
        String friendOpenid = request.getParameter("friendOpenid");
        
        
        ModelAndView mv = new ModelAndView("redirect:/friendPraise/index.htm?launchId="+launchId);
        
        //方便测试，测试时自己输入openId
        String openId = request.getParameter("openId");
        if(StringUtils.isNotBlank(openId) && authorizationService.isTestEnv() 
                && !authorizationService.isWeiXinBrowser(request)) {
            mv = new ModelAndView("redirect:/friendPraise/index.htm?launchId="+launchId+"&openId="+openId);
        }
        
        logger.info("点赞 launchId:{},friendOpenid:{}, ",launchId,friendOpenid);
        
        Result result = ResultConst.SUCCESS;
        if(friendOpenid == null || launchId == null) {
            result = ResultConst.ILLEGAL_ARGUMENT;
            return mv;
        }

        if(wxPrmtDetailService.isPraised(launchId, friendOpenid)) {
            logger.info("已经点过赞 launchId:{},friendOpenid:{}, ",launchId, friendOpenid);
            result = ResultConst.PRAISE_DUPLCATION;
        } else {
        
            WxAuthInfo wxAuthInfo = authorizationService.getWxAuthInfoNoLoginCX(
                    request, Scope.snsapi_userinfo,domain+WX_STATIC_URL);
            
            logger.info("点赞 wxAuthInfo:{}", wxAuthInfo);
            
            if(wxAuthInfo.getRedirectUrl() != null) {
                return new ModelAndView("redirect:"+wxAuthInfo.getRedirectUrl());
            }
            
            logger.info("点赞开始准备数据");
            SNSUserInfo snsUserInfo = wxAuthInfo.getSNSUserInfo();
            
            Long friendUserId = authorizationService.getUserIdByOpenid(snsUserInfo.getOpenId());
            WxPrmtLaunchEntity wxPrmtLaunch = wxPrmtLaunchService.queryLaunchByLaunchId(launchId);
            
            WxPrmtDetail wxPrmtDetail = new WxPrmtDetail();
            wxPrmtDetail.setWxPrmtId(wxPrmtLaunch.getWxPrmtId());
            wxPrmtDetail.setLaunchId(launchId);
            wxPrmtDetail.setLaunchUserId(wxPrmtLaunch.getLaunchUserId());
            wxPrmtDetail.setFriendUserId(friendUserId);
            wxPrmtDetail.setFriendOpenid(snsUserInfo.getOpenId());
            wxPrmtDetail.setFriendNickname(StringUtils2.encodeNickName(snsUserInfo.getNickname()));
            wxPrmtDetail.setFriendHeadimgurl(snsUserInfo.getHeadimgurl());
            
            logger.info("点赞数据wxPrmtDetail:",wxPrmtDetail);
            result = wxPrmtDetailService.friendPraise(wxPrmtDetail);
            
            logger.info("点赞结果:result:{}", result);
        }
        
        //mv.addObject("result", result);
        
        //preparePraiseData(launchId, openId, request, mv);
        
        //重新回到点赞页面
        logger.info("点赞完成");
        return  mv;
    }
    
    
    /**
     * 
     * 功能描述: <br>
     * 准备好友点赞页面的数据
     *
     * @param launchId
     * @param friendOpenid
     * @param request
     * @param mv
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    private void preparePraiseData(Long launchId, String friendOpenid, HttpServletRequest request, ModelAndView mv) {
        
        logger.info("preparePraiseData: launchId:{}, friendOpenid:{}",launchId, friendOpenid);
        
        mv.addObject("launchId", launchId);
        mv.addObject("friendOpenid", friendOpenid);
        
        //活动基本信息，判断当前状态
        
        WxPrmtLaunchEntity wxPrmtLaunch = wxPrmtLaunchService.queryLaunchByLaunchId(launchId);
        
        if(wxPrmtLaunch != null) {
            wxPrmtLaunch.setLaunchNickname(StringUtils2.decodeNickName(wxPrmtLaunch.getLaunchNickname()));
            mv.addObject("wxPrmtLaunch", wxPrmtLaunch);
            
            if(wxPrmtLaunch.getLaunchStatus() == LaunchStatus.EXCHANGED.code()
                    && wxPrmtLaunch.getPrizeId() != null && wxPrmtLaunch.getPrizeId() !=0) {
                WxPrmtPrize wxPrmtPrize = wxPrmtPrizeService.getWxPrmtPrize(wxPrmtLaunch.getPrizeId());
                
                mv.addObject("wxPrmtPrize", wxPrmtPrize);
            }
            
            //活动结束
            WxPrmt wxPrmt = wxPrmtService.getWxPrmt(wxPrmtLaunch.getWxPrmtId());
            mv.addObject("wxPrmt", wxPrmt);
            
            if(wxPrmt != null && wxPrmt.getEndTime().before(new Date())) {
                mv.addObject("prmtFinished", true);
            }
        }
        logger.info("queryLaunchByLaunchId完成, launchId:{},wxPrmtLaunch:{}",launchId,wxPrmtLaunch);
        
        //查询发起者的点赞列表
        List<WxPrmtDetail> detailList = wxPrmtDetailService.getPraiseList(launchId, 30);
        
        StringUtils2.decodeNickName(detailList);
        mv.addObject("detailList", detailList);
        logger.info("getPraiseList完成, launchId:{}",launchId);
        
        //是否点过赞了
        boolean isPraised = wxPrmtDetailService.isPraised(launchId, friendOpenid);
        if(isPraised) {
            mv.addObject("result", ResultConst.PRAISE_DUPLCATION);
        }
        logger.info("isPraised完成, launchId:{},friendOpenid:{},isPraised:{}",launchId,friendOpenid,isPraised);
        
        Long praiseNum = wxPrmtDetailService.getPraiseNum(launchId);
        
        mv.addObject("praiseNum", praiseNum);
        
        //签名
        Map<String, String> map = authorizationService.getSdkSignMap(request);
        mv.addObject("jssdk", map);
        mv.addObject("isWx", BrowserUtil.isWeixinBrowser(request));
        WXShareVO shareVO = new WXShareVO();
        shareVO.setShareContentDesc("");
        shareVO.setShareImgUrl("/baba/images/201688praise.jpg");
        shareVO.setShareLinkUrl("");
        shareVO.setShareTitle("");
        mv.addObject("shareVO", shareVO);
    }
    
}
