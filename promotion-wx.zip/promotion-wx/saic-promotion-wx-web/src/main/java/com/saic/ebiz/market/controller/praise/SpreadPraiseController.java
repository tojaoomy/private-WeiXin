package com.saic.ebiz.market.controller.praise;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.saic.bigdata.realtime.camonitor.CaLogger;
import com.saic.bigdata.realtime.camonitor.Message;
import com.saic.bigdata.realtime.camonitor.MessageGenerator;
import com.saic.ebiz.market.controller.BaseController;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.util.CookieUtil;
import com.saic.ebiz.market.util.IpAddressUtil;
import com.saic.ebiz.market.util.StringUtils2;
import com.saic.ebiz.market.vo.WxAuthInfo;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtDetailService;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtLaunchService;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtPrizeService;
import com.saic.ebiz.promotion.service.api.wx.IWxPrmtService;
import com.saic.ebiz.promotion.service.entity.wx.WxPrmtLaunchEntity;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmt;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmtDetail;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmtLaunch;
import com.saic.ebiz.promotion.service.vo.wx.WxPrmtPrize;

/**
 * 
 * 〈一句话功能简述〉<br>
 * 〈2016.88节 发起集赞〉
 * 
 * @author zcm
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping(value = "spreadPraise")
public class SpreadPraiseController extends BaseController {

	private static final Logger log = LoggerFactory
			.getLogger(SpreadPraiseController.class);
	
	@Value("${ebiz.member.web.memberBase:}")
	private String memberBase;;

	//去88节查看使用车型
	private static final String WX_GO88HOME_URL = "/mall/list.htm?marketTagName=babajie";
	//去使用兑换券
	private static final String WX_UES_COUPON_URL = "/mall/list.htm?marketTagName=babajie";
	//去特价车看看
	private static final  String WX_TEJIA_CAR_URL = "/mall/list.htm?marketTagName=babajie";
	//去查看兑换券
	private static final String WX_SHOW_COUPON_URL = "/m/coupon.htm";
	
	
	/** 点赞页 */
	//private static final String FRIENDPRAISE_PATH = "friendPraise/index.htm";
	/** 红包页 */
	private static final String SPREADPRAISE_PATH = "spreadPraise/home.htm";

	/** 授权服务 */
	@Resource
	private AuthorizationService authorizationService;

	@Autowired
	private IWxPrmtLaunchService wxPrmtLaunchService;

	@Autowired
	private IWxPrmtDetailService wxPrmtDetailService;

	@Autowired
	private IWxPrmtPrizeService wxPrmtPrizeService;

	@Autowired
	private IWxPrmtService wxPrmtService;

	/**
	 * 
	 * 功能描述: <br>
	 * 〈集赞首页〉
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return 属性参数 ModelAndView 返回信息
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping(value = "home")
	public ModelAndView spreadHome(HttpServletRequest request,
			HttpServletResponse response, Model model) {
		ModelAndView mv = new ModelAndView();
		// *. 获取活动信息接口（时间状态）
		WxPrmt wxPrmt = wxPrmtService.getWxPrmtByCode(PRAIS_ACTIVE_CODE);
		log.info("spreadHome>>getWxPrmtByCode:"
				+ (wxPrmt != null ? wxPrmt.getWxPrmtId() : null));
		int praisestatu = this.activeState(wxPrmt,request);
		//活动下线去主站
		if(praisestatu==-2){
			mv.setViewName("redirect:"+mcarBase);
			return mv;
		}
		// *判断是否微信进入
		WxAuthInfo wxAuthInfo = authorizationService.getWxAuthInfoNoLoginCX(request,
				Scope.snsapi_base,domain+WX_STATIC_URL);
		if (wxAuthInfo.getRedirectUrl() != null) {
			return new ModelAndView("redirect:" + wxAuthInfo.getRedirectUrl());
		}
		Long userid = authorizationService.getUserIdByOpenid(wxAuthInfo.getSNSUserInfo().getOpenId());
		// 1.launchId判断发起活动
		WxPrmtLaunch wxLaunchVo = wxPrmtLaunchService
				.queryLaunchByOpenId(wxAuthInfo.getSNSUserInfo().getOpenId());
		log.info("spreadHome>>queryLaunchByOpenId:"
				+ (wxLaunchVo != null ? wxLaunchVo.getLaunchId() : null));
			
		if (wxLaunchVo != null && userid != null) {
			// 1.2.已发页
			String isTest =request.getParameter("isTest");
			mv.addObject("isTest", isTest);
			setInviteModel(mv, wxLaunchVo, wxPrmt, praisestatu);
			
		} else {
			String isTest =request.getParameter("isTest"); 
			// 1.3.发起页
			Long cntAll = wxPrmtLaunchService.countLauncherNum(wxPrmt
					.getWxPrmtId());
			mv.addObject("praisecnt", cntAll);
			mv.addObject("isTest", isTest);
			mv.addObject("praisestatu", praisestatu);
			mv.addObject("wxPrmt", wxPrmt);
			mv.setViewName("/baba/promotion-start.ftl");
		}
		 mv.addObject("gotejiacar", mcarBase+ WX_TEJIA_CAR_URL);
		 
        //签名
        Map<String, String> map = authorizationService.getSdkSignMap(request);
        mv.addObject("jssdk", map);
        
		return mv;

	}

	/** 设置已发页 mv */
	private void setInviteModel(ModelAndView mv, WxPrmtLaunch wxLaunchVo,
			WxPrmt wxPrmt, int praisestatu) {
		List<WxPrmtDetail> wxPrmtDetail = wxPrmtDetailService
				.getPraiseList(wxLaunchVo.getLaunchId(), 30);
		StringUtils2.decodeNickName(wxPrmtDetail);
		List<WxPrmtPrize> wxPrizesList = wxPrmtPrizeService
				.getWxPrmtPrizeList(wxPrmt.getWxPrmtId());
		 Long praiseNum = wxPrmtDetailService.getPraiseNum(wxLaunchVo.getLaunchId());
		 if(wxLaunchVo.getLaunchStatus()==2&&wxLaunchVo.getPrizeId()!=null){
			 WxPrmtPrize cur_prmtPrize = wxPrmtPrizeService.getWxPrmtPrize(wxLaunchVo.getPrizeId());
			 mv.addObject("curPrmtPrize", cur_prmtPrize);
		 }
	        
		 String  nname = StringUtils2.decodeNickName(wxLaunchVo.getLaunchNickname());
		 wxLaunchVo.setLaunchNickname(nname);
		 
		 mv.addObject("showCoupon", memberBase+WX_SHOW_COUPON_URL);
		 mv.addObject("uesCoupon", mcarBase+WX_UES_COUPON_URL);
		 mv.addObject("go88Home", mcarBase+WX_GO88HOME_URL);
		mv.addObject("praisestatu", praisestatu);
		mv.addObject("praiseNum", praiseNum);
		mv.addObject("dznum", praiseNum);
		mv.addObject("prmt", wxLaunchVo);
		mv.addObject("prizesList", wxPrizesList);
		mv.addObject("detailList", wxPrmtDetail);
		mv.addObject("wxPrmt", wxPrmt);
		mv.setViewName("/baba/promotion-invite.ftl");
	}

	/**
	 * 
	 * 一句话功能简述 <br>
	 * 〈集赞活动发起〉
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return 属性参数 ModelAndView 返回信息
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping(value = "create")
	public ModelAndView spreadCreate(HttpServletRequest request,
			HttpServletResponse response, Model model) {
		ModelAndView mv = new ModelAndView();
		// *判断是否微信进入
		WxAuthInfo wxAuthInfo = authorizationService.getWxAuthInfoWithLoginCX(request,
				Scope.snsapi_userinfo,domain+WX_STATIC_URL);
		if (wxAuthInfo.getRedirectUrl() != null) {
			return new ModelAndView("redirect:" + wxAuthInfo.getRedirectUrl());
		}
		if(wxAuthInfo.getSNSUserInfo()!=null
				&&wxAuthInfo.getSNSUserInfo().getNickname() != null
				&&wxAuthInfo.getSNSUserInfo().getOpenId() != null){
			// 0. 获取活动信息接口（时间状态） 
			WxPrmt wxPrmt = wxPrmtService.getWxPrmtByCode(PRAIS_ACTIVE_CODE);
			log.info("spreadHome>>getWxPrmtByCode:"
					+ (wxPrmt != null ? wxPrmt.getWxPrmtId() : null));
			int praisestatu = this.activeState(wxPrmt,request);
			// 1.是否已发起集赞
			WxPrmtLaunchEntity launch = wxPrmtLaunchService
					.queryLaunchByOpenId(wxAuthInfo.getSNSUserInfo()
							.getOpenId());
			if (praisestatu == 1&& ( launch == null || launch.getLaunchId() == null)) {
				// 1.2.发起活动
				 createActive(wxAuthInfo, wxPrmt);
			}
		}
		String isTest =request.getParameter("isTest");
		isTest=isTest==null?"":("?isTest="+isTest);
		String redirect_uri = "redirect:"
				+ authorizationService.buildAuthorizationLink(appId, domain
						+ SPREADPRAISE_PATH+isTest, Scope.snsapi_base);
		log.info("spreadCreate>>buildAuthorizationLink:redirect_uri="
				+ redirect_uri);
		mv.setViewName(redirect_uri);
		return mv;
	}
	/** 发起活动*/
	private void createActive(WxAuthInfo wxAuthInfo, WxPrmt wxPrmt) {
		Long userid = authorizationService.getUserIdByOpenid(wxAuthInfo.getSNSUserInfo().getOpenId());
		if (userid!=null) {
			WxPrmtLaunchEntity wxLaunchVo = new WxPrmtLaunchEntity();
			wxLaunchVo.setWxPrmtId(wxPrmt.getWxPrmtId());
			wxLaunchVo.setLaunchUserId(userid);
			wxLaunchVo.setLaunchStatus(1);
			wxLaunchVo.setCreateTime(new Date());
			wxLaunchVo.setLaunchOpenid(wxAuthInfo.getSNSUserInfo()
					.getOpenId());
			wxLaunchVo.setLaunchHeadimgurl(wxAuthInfo.getSNSUserInfo()
					.getHeadimgurl());
			wxLaunchVo.setLaunchNickname(StringUtils2
					.encodeNickName(wxAuthInfo.getSNSUserInfo()
							.getNickname()));

			Long launchid = wxPrmtLaunchService
					.launchWxPrmt(wxLaunchVo);
			wxLaunchVo.setLaunchId(launchid);
			
			log.info("spreadCreate>>launchWxPrmt:lid=" + launchid
					+ ",uid=" + userid);

		}
	}

	/**
	 * 
	 * 功能描述: <br>
	 * 〈兑换红包券〉
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return 属性参数 ModelAndView 返回信息
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping(value = "exchange", method = RequestMethod.POST)
	@ResponseBody
	public JSONObject exchangeByPraise(HttpServletRequest request,
			HttpServletResponse response, Model model) {
		JSONObject rjson = new JSONObject();
		String isTest =request.getParameter("isTest"); //测试入口
		isTest=isTest==null?"":("?isTest="+isTest);
		rjson.put("r_url", domain+SPREADPRAISE_PATH+isTest);
		// 0. 获取活动信息接口（时间状态） 
		Long launchId = StringUtils2.toLong(request.getParameter("launchId"));  
		WxPrmt wxPrmt = wxPrmtService.getWxPrmtByCode(PRAIS_ACTIVE_CODE);
		log.info("spreadHome>>getWxPrmtByCode:"
				+ (wxPrmt != null ? wxPrmt.getWxPrmtId() : null)+",launchId:"+launchId);
		int praisestatu = this.activeState(wxPrmt,request);
		rjson.put("praisestatu", praisestatu);
		rjson.put("isok", -1);
		if(praisestatu!=1||launchId==null){
			return rjson;
		}
		// 1. 兑换红包券接口(是否已兑换，校验当前用户已集赞数) 
		long isok = wxPrmtLaunchService.acceptPrize(launchId, null);
		
		logMaidian(request, launchId, isok);
		
		rjson.put("isok", isok);
		// 2.设置使用url+查看url
		log.info("exchangeByPraise>>acceptPrize:"+rjson.toJSONString());
		return rjson;
	}

	/**	日志埋点领券	*/
	private void logMaidian(HttpServletRequest request, Long launchId, long isok) {
		WxPrmtLaunchEntity launchvo = wxPrmtLaunchService.queryLaunchByLaunchId(launchId);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Message message = MessageGenerator.gen("zc", "wx88jie");
		message.addPayload("Userid", launchvo.getLaunchUserId());
		message.addPayload("Ip", IpAddressUtil.getRemoteHost(request));
		message.addPayload("WCID", CookieUtil.getCookieByKey(request, "wcid"));
		message.addPayload("User_trace_cookie",CookieUtil.getCookieByKey(request, "user_trace_cookie"));
		message.addPayload("Prizeid", launchvo.getPrizeId());
		message.addPayload("Launchid ", launchId);
		message.addPayload("Isok ", isok);
		message.addPayload("Time ", sdf.format(new Date()));
		CaLogger.emit(message);
	}

	/** 获取活动状态： 0 = 未开始，1 = 已开始 ， -1 = 已结束 , -2 = 下线 */
	private int activeState(WxPrmt wxPrmt,HttpServletRequest request) {
		String isTest =request.getParameter("isTest"); //测试入口
		if(wxPrmt==null) return -2;
		if("slogan178".equals(isTest)) return 1;
		long ctime = System.currentTimeMillis();
		// 活动状态
		if (ctime < wxPrmt.getStartTime().getTime()) {
			return 0;
		} else if (ctime >= wxPrmt.getStartTime().getTime()
				&& ctime <= wxPrmt.getEndTime().getTime()) {
			return 1;
		} else if(ctime >=wxPrmt.getEndTime().getTime() 
				&& ctime <= wxPrmt.getOfflineTime().getTime()){
			return -1;
		}else {
			return -2;
		}
	}
}
