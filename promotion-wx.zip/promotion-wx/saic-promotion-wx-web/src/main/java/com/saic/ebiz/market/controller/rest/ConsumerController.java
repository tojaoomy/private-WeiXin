/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller.rest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saic.framework.redis.client.IRedisClient;
import com.ibm.framework.uts.util.StringUtils;
import com.saic.ebiz.component.wx.Constants;
import com.saic.ebiz.component.wx.util.AppIdSecretHelper;
import com.saic.ebiz.market.common.util.SHA1Util;
import com.saic.ebiz.market.entity.ConsumerData;

/**
 * 给第三方系统提供api接口获取数据
 * 
 * @author hejian
 *
 */
@RestController
@RequestMapping("/customer")
public class ConsumerController {
	/**缓存接口.*/
    @Resource(name="springRedisClient")
    private IRedisClient springRedisClient;

	@Autowired
	private AppIdSecretHelper appIdSecretHelper;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	@RequestMapping("/token")
	public ConsumerData getToken(HttpServletRequest request){
		ConsumerData consumerData = new ConsumerData();
		//首先从缓存中获取，否则重新调用微信API
		String token = springRedisClient.get(getRedisCacheKey(Constants.PREFIX_REDIS_ACCESS_TOKEN),Constants.REDIS_NAME_SPACE,null);
		if(!StringUtils.hasText(token)){
			consumerData.setData("");
			consumerData.setStatus("failure");
			consumerData.setErrMessage("系统异常,redis为取到数据,请联系车享管理员!!!");
		}else{
			consumerData.setData(token);
			consumerData.setSign(new SHA1Util().getDigestOfString(token.getBytes()));
		}
		return consumerData;
	}
	
	@RequestMapping("/ticket")
	public ConsumerData getTicket(HttpServletRequest request){
		ConsumerData consumerData = new ConsumerData();
		//首先从缓存中获取，否则重新调用微信API
		String ticket = springRedisClient.get(getRedisCacheKey(Constants.PREFIX_REDIS_TICKET),Constants.REDIS_NAME_SPACE,null);
		if(!StringUtils.hasText(ticket)){
			consumerData.setData("");
			consumerData.setStatus("failure");
			consumerData.setErrMessage("系统异常,redis为取到数据,请联系车享管理员!!!");
		}else{
			consumerData.setData(ticket);
			consumerData.setSign(new SHA1Util().getDigestOfString(ticket.getBytes()));
		}
		return consumerData;
	}
	
	/** 根据appid获取rediskey */
	protected String getRedisCacheKey(String prefixKey) {
		return prefixKey + appId;
	}

}
