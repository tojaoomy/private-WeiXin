/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.controller.vo;

import com.saic.ebiz.society.vo.question.AnswerVO;

/**
 * @author hejian
 * 
 */
public class AnswerWrapper {
	/** 答案对象 */
	private AnswerVO answerVO;
	
	/** 是否赞过 */
	private String onGood;
	
	/** 是否踩过 */
	private String onBad;

	/**
	 * @return the answerVO
	 */
	public AnswerVO getAnswerVO() {
		return answerVO;
	}

	/**
	 * @param answerVO the answerVO to set
	 */
	public void setAnswerVO(AnswerVO answerVO) {
		this.answerVO = answerVO;
	}

	/**
	 * @return the onGood
	 */
	public String getOnGood() {
		return onGood;
	}

	/**
	 * @return the onBad
	 */
	public String getOnBad() {
		return onBad;
	}

	/**
	 * @param onGood the onGood to set
	 */
	public void setOnGood(String onGood) {
		this.onGood = onGood;
	}

	/**
	 * @param onBad the onBad to set
	 */
	public void setOnBad(String onBad) {
		this.onBad = onBad;
	}

}
