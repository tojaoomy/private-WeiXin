/*
 * Copyright (C), 2013-2013, 上海汽车集团股份有限公司
 * FileName: VehicleBindVO.java
 * Author:   v_wangzhaolin01
 * Date:     2013年12月25日 下午5:57:17
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.controller.vo;

import com.saic.ebiz.promotion.service.vo.Auction;

/**
 * 车主绑定申请记录VO对象<br>
 * 
 * 该类对应查询车主绑定申请记录返回的接口信息
 * 
 * @author v_wangzhaolin01
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class AuctionVo extends Auction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2355009410960853209L;

	//活动结束倒计时
	private String promUrl;
	
	//活动结束倒计时
	private String promEndTime;
	
	//拍卖中标确认倒计时
	private Long auctioinEndDay;
	
	//拍卖中标确认倒计时
	private Long auctioinEndHour;
	
	//下订单URl
	private String orderUrl;
	
	public String getPromUrl() {
		return promUrl;
	}

	public void setPromUrl(String promUrl) {
		this.promUrl = promUrl;
	}

	public String getPromEndTime() {
		return promEndTime;
	}

	public void setPromEndTime(String promEndTime) {
		this.promEndTime = promEndTime;
	}

	public Long getAuctioinEndDay() {
		return auctioinEndDay;
	}

	public void setAuctioinEndDay(Long auctioinEndDay) {
		this.auctioinEndDay = auctioinEndDay;
	}

	public Long getAuctioinEndHour() {
		return auctioinEndHour;
	}

	public void setAuctioinEndHour(Long auctioinEndHour) {
		this.auctioinEndHour = auctioinEndHour;
	}

	public String getOrderUrl() {
		return orderUrl;
	}

	public void setOrderUrl(String orderUrl) {
		this.orderUrl = orderUrl;
	}
	
}
