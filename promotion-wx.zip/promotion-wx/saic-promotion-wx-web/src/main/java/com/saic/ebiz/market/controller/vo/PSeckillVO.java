package com.saic.ebiz.market.controller.vo;

import com.saic.ebiz.promotion.service.vo.UserSubscriptionOrderInfoResult;

public class PSeckillVO extends UserSubscriptionOrderInfoResult{

	private static final long serialVersionUID = 2483786064514065281L;

	//活动结束倒计时
	private String promUrl;
	
	//活动结束倒计时
	private String promEndTime;
	
	//活动开始倒计时
	private String promStartTime;
	
	//拍卖中标确认倒计时
	private Long auctioinEndDay;
	
	//拍卖中标确认倒计时
	private Long auctioinEndHour;
	
	//下订单URl
	private String orderUrl;
	
	//页面倒计时时间
	private long startLongTime;
	
	//页面距开始时间
	private String startStrTime;
	
	public String getPromUrl() {
		return promUrl;
	}

	public void setPromUrl(String promUrl) {
		this.promUrl = promUrl;
	}

	public String getPromEndTime() {
		return promEndTime;
	}

	public void setPromEndTime(String promEndTime) {
		this.promEndTime = promEndTime;
	}

	public String getPromStartTime() {
		return promStartTime;
	}

	public void setPromStartTime(String promStartTime) {
		this.promStartTime = promStartTime;
	}

	public Long getAuctioinEndDay() {
		return auctioinEndDay;
	}

	public void setAuctioinEndDay(Long auctioinEndDay) {
		this.auctioinEndDay = auctioinEndDay;
	}

	public Long getAuctioinEndHour() {
		return auctioinEndHour;
	}

	public void setAuctioinEndHour(Long auctioinEndHour) {
		this.auctioinEndHour = auctioinEndHour;
	}

	public String getOrderUrl() {
		return orderUrl;
	}

	public void setOrderUrl(String orderUrl) {
		this.orderUrl = orderUrl;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public long getStartLongTime() {
		return startLongTime;
	}

	public void setStartLongTime(long startLongTime) {
		this.startLongTime = startLongTime;
	}

	public String getStartStrTime() {
		return startStrTime;
	}

	public void setStartStrTime(String startStrTime) {
		this.startStrTime = startStrTime;
	}
	
	
}
