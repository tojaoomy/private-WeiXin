package com.saic.ebiz.market.controller.vo;

import com.saic.ebiz.promotion.service.vo.UserSubscriptionOrderInfoResult;

public class PromotionVO extends UserSubscriptionOrderInfoResult{

	private static final long serialVersionUID = -2730793509227447849L;
	
	/**
	 * 状态,用于页面显示
	 * (1 已抽奖，未购车；2 已购车未支付；3 已支付，未到店;  4 已到店，未提车; 5 已交车)
	 */
	private Integer pageShowStatus;

	/**
	 * 订单状态：未支付,已支付,已到店,已交车
	 */
	private String pageOrderStatus;
	
	private String remainTime;
	
	private long remainLongTime;
	
	/**
	 * 开始倒计时
	 */
	private String startRemainTime;
	
	private long startRemainLong;
	
	/**
	 * 结束倒计时
	 */
	private String endRemainTime;
	
	private long endRemainLong;
	
	/**
	 * 留资倒计时long
	 */
	private long depositValidDayLong;
	
	private long depositValidHourLong;
	
	/**
	 * 留资到期时间long
	 */
	private long depositValidDateLong;
	
	/**
	 * 开始时间long
	 */
	private long startTimeLong;
	
	/**
	 * 结束时间long
	 */
	private long endTimeLong;
	
	/**
	 * 拍卖VO
	 */
	private AuctionVo auctionVo;
	
	/**
	 * 秒杀VO
	 */
	private PSeckillVO pseckillVO;
	
	/**
	 * 下单url
	 */
	private String orderUrl;
	
	public String getOrderUrl() {
		return orderUrl;
	}

	public void setOrderUrl(String orderUrl) {
		this.orderUrl = orderUrl;
	}

	public Integer getPageShowStatus() {
		return pageShowStatus;
	}

	public void setPageShowStatus(Integer pageShowStatus) {
		this.pageShowStatus = pageShowStatus;
	}

	public String getPageOrderStatus() {
		return pageOrderStatus;
	}

	public void setPageOrderStatus(String pageOrderStatus) {
		this.pageOrderStatus = pageOrderStatus;
	}

	public AuctionVo getAuctionVo() {
		return auctionVo;
	}

	public void setAuctionVo(AuctionVo auctionVo) {
		this.auctionVo = auctionVo;
	}

	public PSeckillVO getPseckillVO() {
		return pseckillVO;
	}

	public void setPseckillVO(PSeckillVO pseckillVO) {
		this.pseckillVO = pseckillVO;
	}
	
	public long getDepositValidDayLong() {
		return depositValidDayLong;
	}

	public void setDepositValidDayLong(long depositValidDayLong) {
		this.depositValidDayLong = depositValidDayLong;
	}

	public long getDepositValidHourLong() {
		return depositValidHourLong;
	}

	public void setDepositValidHourLong(long depositValidHourLong) {
		this.depositValidHourLong = depositValidHourLong;
	}

	public long getDepositValidDateLong() {
		return depositValidDateLong;
	}

	public void setDepositValidDateLong(long depositValidDateLong) {
		this.depositValidDateLong = depositValidDateLong;
	}

	public long getStartTimeLong() {
		return startTimeLong;
	}

	public void setStartTimeLong(long startTimeLong) {
		this.startTimeLong = startTimeLong;
	}

	public long getEndTimeLong() {
		return endTimeLong;
	}

	public void setEndTimeLong(long endTimeLong) {
		this.endTimeLong = endTimeLong;
	}

	public String getStartRemainTime() {
		return startRemainTime;
	}

	public void setStartRemainTime(String startRemainTime) {
		this.startRemainTime = startRemainTime;
	}

	public long getStartRemainLong() {
		return startRemainLong;
	}

	public void setStartRemainLong(long startRemainLong) {
		this.startRemainLong = startRemainLong;
	}

	public String getEndRemainTime() {
		return endRemainTime;
	}

	public void setEndRemainTime(String endRemainTime) {
		this.endRemainTime = endRemainTime;
	}

	public long getEndRemainLong() {
		return endRemainLong;
	}

	public void setEndRemainLong(long endRemainLong) {
		this.endRemainLong = endRemainLong;
	}

	public String getRemainTime() {
		return remainTime;
	}

	public void setRemainTime(String remainTime) {
		this.remainTime = remainTime;
	}

	public long getRemainLongTime() {
		return remainLongTime;
	}

	public void setRemainLongTime(long remainLongTime) {
		this.remainLongTime = remainLongTime;
	}
	
}
