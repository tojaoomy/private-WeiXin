package com.saic.ebiz.market.controller.vo;

import com.saic.ebiz.promotion.service.vo.SeckillVO;

public class SeckillVo extends SeckillVO {

		/**
	 * 
	 */
	private static final long serialVersionUID = 587441047009662413L;

		//活动结束倒计时
		private String promUrl;
		
		//活动结束倒计时
		private String promEndTime;
		
		//活动开始倒计时
		private String promStartTime;
		
		//拍卖中标确认倒计时
		private Long auctioinEndDay;
		
		//拍卖中标确认倒计时
		private Long auctioinEndHour;
		
		//下订单URl
		private String orderUrl;
		
		
		
		
		
		public String getPromStartTime() {
			return promStartTime;
		}

		public void setPromStartTime(String promStartTime) {
			this.promStartTime = promStartTime;
		}

		public String getPromUrl() {
			return promUrl;
		}

		public void setPromUrl(String promUrl) {
			this.promUrl = promUrl;
		}

		public String getPromEndTime() {
			return promEndTime;
		}

		public void setPromEndTime(String promEndTime) {
			this.promEndTime = promEndTime;
		}

		public Long getAuctioinEndDay() {
			return auctioinEndDay;
		}

		public void setAuctioinEndDay(Long auctioinEndDay) {
			this.auctioinEndDay = auctioinEndDay;
		}

		public Long getAuctioinEndHour() {
			return auctioinEndHour;
		}

		public void setAuctioinEndHour(Long auctioinEndHour) {
			this.auctioinEndHour = auctioinEndHour;
		}

		public String getOrderUrl() {
			return orderUrl;
		}

		public void setOrderUrl(String orderUrl) {
			this.orderUrl = orderUrl;
		}
	
	
}
