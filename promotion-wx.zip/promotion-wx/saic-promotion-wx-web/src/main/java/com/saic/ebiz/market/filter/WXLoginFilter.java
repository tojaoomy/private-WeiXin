/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.sso.client.filter.SSOFilter;

/**
 * @author hejian
 *
 */
public class WXLoginFilter extends SSOFilter {
	
	//	微信公众号的域名
	private static final String DOMAIN = Constants.DOMAIN;
	/* (non-Javadoc)
	 * @see com.saic.sso.client.filter.SSOFilter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		//微信公众号因需要与腾讯连接，因此域名是.chexiang.com，但是测试环境的用户登录信息域名分别是
		//.sit.com,.pre.com，登录之后用户信息不能保存，因此折中方案是传递userId,但是只在测试环境才有效
		String requestUrl = request.getRequestURL().toString();
		String userId = request.getParameter(RequestConstants.USER_ID);
		//如果登录成功了，则会传递userId，并且如果是测试环境，则认为是登录过的
		if(StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(requestUrl) && !requestUrl.contains(DOMAIN)){
			requestUrl = requestUrl.replaceAll(".htm", StringUtils.EMPTY);
			requestUrl = requestUrl.replaceAll(".html", StringUtils.EMPTY);
			requestUrl = requestUrl.replaceAll(".do", StringUtils.EMPTY);
			//filter只拦截htm结尾
			response.sendRedirect(requestUrl + "?" + request.getQueryString());
//			request.getRequestDispatcher().forward(request, response);
		}else{
			super.doFilter(req, response, chain);
		}
	}
}
