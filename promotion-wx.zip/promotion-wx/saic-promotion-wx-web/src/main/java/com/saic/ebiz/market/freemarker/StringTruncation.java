/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.freemarker;

import java.util.List;

import freemarker.template.TemplateMethodModelEx;
import freemarker.template.TemplateModelException;

/**
 * @author hejian
 *
 */
public class StringTruncation implements TemplateMethodModelEx {

	/**
	 * 第一个参数 必填 为读取页面 url 全路径
	 * 第二个参数 可选 为读取时使用的编码格式，默认为 UTF-8
	 * @param arguments
	 * @return
	 * @throws TemplateModelException
	 */
	@Override
	public Object exec(@SuppressWarnings("rawtypes") List arguments) throws TemplateModelException {
		String str = "";
		if(arguments != null && arguments.size() > 0){
			str = arguments.get(0).toString();
			if(str.length() > 14){
				str = str.substring(0, 14) + "...";
			}
		}
		return str;
	}
	
}
