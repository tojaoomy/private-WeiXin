package com.saic.ebiz.market.interceptor;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.saic.ebiz.market.common.constant.WXconstant;
import com.saic.ebiz.market.util.JsSDKSign;

/**
 * 获取ua中信息
 * @author liu_yong
 *
 */
public class UserAgentInterceptor implements HandlerInterceptor{

	private final static Logger logger = LoggerFactory.getLogger(UserAgentInterceptor.class);
	
	/** 渠道 */
	private static final String APPCODE_CXB = "MongoToC";//appCode:MongoToC这个key/value就是车享宝的渠道号

	private static final String WEIXIN_CXB="micromessenger";
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView mv) throws Exception {
		if(null != mv){
			String isAjax = request.getHeader("x-requested-with");
			if(!"XMLHttpRequest".equals(isAjax))
			{
				String ua = request.getHeader("user-agent");
				logger.debug("user-agent:{}", ua);
				String code = "";
				if(null != ua){
					if(ua.toLowerCase().contains(WEIXIN_CXB)){
						code = "WeiXin";
						StringBuilder urlBuilder = new StringBuilder();
						urlBuilder.append(request.getRequestURL().toString());
						if(request.getQueryString() != null && request.getQueryString().length() > 0){
							urlBuilder.append("?").append(request.getQueryString());
						}
						//微信分享JSSDK分享
						Map<String,String> map = JsSDKSign.sign(WXconstant.APPID, urlBuilder.toString());
						mv.addObject("jssdk", map);
					}else if(ua.contains(APPCODE_CXB)){
						code = APPCODE_CXB;
					}
				}
				mv.addObject("source", code);
			}
		}
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		
	}

}
