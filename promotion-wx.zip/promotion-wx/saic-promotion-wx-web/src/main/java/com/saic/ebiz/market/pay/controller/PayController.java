package com.saic.ebiz.market.pay.controller;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.util.payment.SignUtil;
import com.saic.ebiz.market.constant.PreOrderQueryBean;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.service.MemberOrderService;
import com.saic.ebiz.order.service.api.PreOrderUpdateService;
import com.saic.ebiz.promotion.service.api.IActOrderQueryService;
import com.saic.ebiz.promotion.service.api.IActOrderUpdateService;
import com.saic.ebiz.promotion.service.api.routine.IGlobalRuleService;
import com.saic.ebiz.promotion.service.commons.enums.ActOrderStatus;
import com.saic.ebiz.promotion.service.commons.enums.routine.PayStatus;
import com.saic.ebiz.promotion.service.vo.ActOrderQueryResultDTO;


/**.
 * 
 *  支付
 * 	notifyUrl 异步回调地址	支付完成之后，用来更新订单的状态
 *  returnUrl 同步回调地址	支付完成之后，提示用户支付成功还是失败
 *  finishUrl 支付完成之后，回调的地址。
 *  
 *  同步走公网，异步走内网
 *
 * @author 何剑
 */
@RestController
@RequestMapping("/pay")
public class PayController {
	
   /**.
    * callback域名
    */
    private @Value("${ebiz.wap.web.domainCallback:}") String domainCallback;
    
    /**.
     * 订单二级域名
     */
    private @Value("${ebiz.wap.web.domain:}") String domain;
    
    /**
     * 活动订单查询
     */
    @Resource
    private IActOrderQueryService iActOrderQueryService;
    
    /**
     * 活动订单更新
     */
    @Resource
    private IActOrderUpdateService iActOrderUpdateService;
    
    /**
     * 订单查询
     */
    @Resource
	private MemberOrderService memberOrderService;
    
    @Autowired
    private PreOrderUpdateService preOrderUpdateService;
    
    /**
     * 绑定服务
     */
    @Resource
    private BoundingService boundingService;
    
    /**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	@Resource
	private IGlobalRuleService iGlobalRuleService;
	
    /** The Constant LOGGER.  */
    private static final Logger LOGGER = LoggerFactory.getLogger(PayController.class);

    /**
     * 常规车支付页面
     */
    @RequestMapping("/prepayment")
    public ModelAndView prepayment(HttpServletRequest req,ModelMap modelMap){
        String orderId = req.getParameter(RequestConstants.ORDER_ID);
        if(StringUtils.isEmpty(orderId)){
        	orderId = (String) modelMap.get(RequestConstants.ORDER_ID);
        }
        
        String url = "/pay/payment.ftl";
        ActOrderQueryResultDTO order = null;
        LOGGER.info("PayController => prepayment ###### 订单号 : " + orderId);
        //根据订单ID获取订单相关信息
        if(StringUtils.isBlank(orderId)){
        	throw new BaseException("订单号不能为空!!!");
        }else{
        	order = this.iActOrderQueryService.getActOrderById(orderId);
        }
        
        LOGGER.info("调用iActOrderQueryService.getActOrderById(" + orderId + ") 返回 : " + JSONObject.toJSONString(order));
        
        ModelAndView model = null;
        if(order!=null){
        	Long userId = order.getUserId();
        	LOGGER.debug("询价单 userId : " + userId);
            if(userId == null){
            	throw new BaseException("没找到userId");
            }
            //授权回调会传入openId
            String openId = req.getParameter("openId");
            //如果不是授权的回调，则通过userId从数据库中query
            if(StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)){
            	openId = this.boundingService.getOpenIdByUserId(userId);
            	LOGGER.debug("询价单 openId : " + openId);
            	//如果查询不到，则走授权获取
            	if(StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)){
            		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm?orderId=" + orderId), Scope.snsapi_base);
            		autorizationUrl = autorizationUrl.replace("STATE", Authorization.payment.name());
            		LOGGER.debug("未知的用户，使用授权获取openId######");
            		LOGGER.debug("授权url : {} ######", autorizationUrl);
            		model = new ModelAndView(autorizationUrl);
            		return model;
            		//throw new BaseException("没找到openId");
            	}
            }
            
            //活动订单状态为11 且 如果订单支付状态为1--未支付    或    3--支付失败
            if (ActOrderStatus.COMMIT.code().equals(order.getActOrderStatus()) && (PayStatus.PAY_FAILURE.code().equals(order.getPayStatus()) || PayStatus.UNPAY.code().equals(order.getPayStatus()))) {
                url = "/pay/payment.ftl"; //订单支付信息页
                Map<String,String> map = this.buildRequestPara(order,openId);
                model = new ModelAndView(url);
                model.addObject("requestPara", map);
                LOGGER.debug("跳转到支付页面,参数map:"+ JSONObject.toJSON(map));
            } else {
                // 1 已支付 4 已退款
                // 跳到我的询价中心
                 url = "redirect:" + domain + "/inquiry/enquiryList/-1/1.htm";
                 model = new ModelAndView(url);
            }
        }else{
            LOGGER.error("orderService.getOrderById(" + orderId + ")返回null");
            throw new BaseException("订单号(" + orderId + ")不存在!!!");
        }
        model.addObject("order", order);
        return model;
    }
    
    
    /**
     * 订单支付页面
     */
    @RequestMapping("/prepayorder")
    public ModelAndView prepayorder(HttpServletRequest req,ModelMap modelMap){
        String orderId = req.getParameter(RequestConstants.ORDER_ID);
        String userIds = req.getParameter(RequestConstants.USER_ID);
        if(StringUtils.isEmpty(orderId)){
        	orderId = (String) modelMap.get(RequestConstants.ORDER_ID);
        }
        if(StringUtils.isEmpty(userIds)){
        	userIds = (String) modelMap.get(RequestConstants.USER_ID);
        }
        String url = "/pay/payment.ftl";
        PreOrderQueryBean order = null;
        LOGGER.info("PayController => prepayment ###### 订单号 : " + orderId);
        //根据订单ID获取订单相关信息
        if(StringUtils.isBlank(orderId)){
        	throw new BaseException("订单号不能为空!!!");
        }else{
        	order = this.memberOrderService.queryOrderDetailByParmes(orderId, Long.valueOf(userIds));
        }
        
        LOGGER.info("调用memberOrderService.queryOrderDetailByParmes(" + orderId + ") 返回 : " + JSONObject.toJSONString(order));
        
        ModelAndView model = null;
        if(order!=null){
        	Long userId = order.getUserId();
        	LOGGER.debug("订单 userId : " + userId);
            if(userId == null){
            	throw new BaseException("没找到userId");
            }
            //授权回调会传入openId
            String openId = req.getParameter("openId");
            //如果不是授权的回调，则通过userId从数据库中query
            if(StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)){
            	openId = this.boundingService.getOpenIdByUserId(userId);
            	LOGGER.debug("订单 openId : " + openId);
            	//如果查询不到，则走授权获取
            	if(StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)){
            		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm?orderId=" + orderId), Scope.snsapi_base);
            		autorizationUrl = autorizationUrl.replace("STATE", Authorization.order328.name());
            		LOGGER.debug("未知的用户，使用授权获取openId######");
            		LOGGER.debug("授权url : {} ######", autorizationUrl);
            		model = new ModelAndView(autorizationUrl);
            		return model;
            		//throw new BaseException("没找到openId");
            	}
            }
            
            //如果订单支付状态为5--未支付    或    2--支付失败
            if (order.getPayStatusCode().equals("2") || order.getPayStatusCode().equals("5")) {
                url = "/pay/payment.ftl"; //订单支付信息页
                Map<String,String> map = this.buildRequestOrderPara(order,openId);
                model = new ModelAndView(url);
                model.addObject("requestPara", map);
                LOGGER.debug("跳转到支付页面,参数map:"+ JSONObject.toJSON(map));
            } else {
                // 1 已支付 4 已退款
                // 跳到我的询价中心
                 url = "redirect:" + domain + "/myorder/orderList/-1/1.htm";
                 model = new ModelAndView(url);
            }
        }else{
            LOGGER.error("memberOrderService.queryOrderDetailByParmes(" + orderId + ")返回null");
            throw new BaseException("订单号(" + orderId + ")不存在!!!");
        }
        model.addObject("order", order);
        return model;
    }

    
    /**
     * . 功能描述: 支付同步回调反馈支付状态(支付完成之后，open一个页面说明支付成功或者失败)<br>
     * 
     */
    @RequestMapping("/syncCallBack")
    @ResponseBody
    public ModelAndView getSyncCallBack (
            HttpServletRequest req, HttpServletResponse rep) {
    	String ip = req.getRemoteAddr();
        LOGGER.info("syncCallBack ip:" +ip);
        String url = "";
        Map<String, String> params  = this.getRequestParams(req);
        LOGGER.debug("PayController => syncCallBack ###### params : " + JSONObject.toJSONString(params));
        String orderId = params.get(RequestConstants.ORDER_ID);
        String status = params.get("status");
        LOGGER.debug("orderId : " + orderId + "###### payStatus : " + status );
        String sign= params.get("sign");
		LOGGER.debug("orderId : " + orderId + "###### payStatus : " + status + " ###### sign : " + sign);
        boolean verify = SignUtil.verifySign(params, Constants.PUBLIC_KEY, sign);
		LOGGER.debug("订单号 orderId : " + orderId + " 校验签名 : " + (verify ? " 成功" : " 失败"));
		
		ActOrderQueryResultDTO order = null;
        //根据订单ID获取订单相关信息
        if(StringUtils.isBlank(orderId)){
        	throw new BaseException("订单号不能为空!!!");
        }else{
        	order = this.iActOrderQueryService.getActOrderById(orderId);
        }
        LOGGER.info("调用iActOrderQueryService.getActOrderById(" + orderId + ") 返回 : " + JSONObject.toJSONString(order));
        Long userId = null;
        if(order!=null){
        	userId = order.getUserId();
        }else{
        	throw new BaseException("未找到订单 ：" + orderId);
        }
        if (verify && status.equals(Constants.SUCCESS)) {
			url = "/pay/pay_success.ftl";
		} else {
			url = "/pay/pay_error.ftl";
		}
        return new ModelAndView(url).addObject(RequestConstants.ORDER_ID, orderId).addObject(RequestConstants.USER_ID, userId);
    }
    
    /**
     * . 功能描述: 支付同步回调反馈支付状态(支付完成之后，open一个页面说明支付成功或者失败)<br>
     * 
     */
    @RequestMapping("/syncCallBackOrder")
    @ResponseBody
    public ModelAndView getSyncCallBackOrder (
            HttpServletRequest req, HttpServletResponse rep) {
    	String ip = req.getRemoteAddr();
        LOGGER.info("syncCallBack ip:" +ip);
        String url = "";
        Map<String, String> params  = this.getRequestParams(req);
        LOGGER.debug("PayController => syncCallBack ###### params : " + JSONObject.toJSONString(params));
        String orderId = params.get(RequestConstants.ORDER_ID);
        String status = params.get("status");
        LOGGER.debug("orderId : " + orderId + "###### payStatus : " + status );
        String sign= params.get("sign");
		LOGGER.debug("orderId : " + orderId + "###### payStatus : " + status + " ###### sign : " + sign);
        boolean verify = SignUtil.verifySign(params, Constants.PUBLIC_KEY, sign);
		LOGGER.debug("订单号 orderId : " + orderId + " 校验签名 : " + (verify ? " 成功" : " 失败"));
		String haoedai = null;
//		PreOrderQueryBean order = this.memberOrderService.queryOrderDetailByEDai(orderId);
//		if(order != null){
//			haoedai = order.geteDaiUrl();
//        }
		if (verify && status.equals(Constants.SUCCESS)) {
			url = "/pay/order_pay_success.ftl";
		} else {
			url = "/pay/order_pay_error.ftl";
		}
        return new ModelAndView(url).addObject(RequestConstants.ORDER_ID, orderId).addObject(RequestConstants.USER_ID, "-1").addObject("edai", haoedai);
    }

    /**
     * . 功能描述: 支付异步回调更改订单的状态<br>
     * 
     */
    @RequestMapping("/asyncCallBack")
    @ResponseBody
    public String asyncCallBack(HttpServletRequest req,
            HttpServletResponse rep) {
    	LOGGER.info("异步回调 asyncCallBack 开始");
    	String ip = req.getRemoteAddr();
        String orderId = ""; //订单编号
        String notifyType = ""; //通知类型payment
        String status = ""; //支付状态
        String txnDate = ""; //付款时间
        PrintWriter out = null;
        Map<String, String> params = null;
        String sign = ""; //签名
        boolean verify = false;

        try {
        	out = rep.getWriter();
        	params  = this.getRequestParams(req);
            LOGGER.info("PayController => asyncCallBack ###### params " +JSONObject.toJSONString(params));
            orderId = params.get("orderId");
            status = params.get("status");
            notifyType = params.get("notifyType");
            txnDate = params.get("txnDate");
            LOGGER.info("ip : {} , 订单号 : {} , 支付状态 : {} , 支付类型 : {} , 付款时间 : {} ",
            		ip, orderId, status, notifyType, txnDate);
            sign = params.get("sign");
			LOGGER.info("ip : {} , 订单号 : {} , 支付状态 : {} , 支付类型 : {} , 付款时间 : {} , 签名 : {} ",
					ip, orderId, status, notifyType, txnDate, sign);
			verify = SignUtil.verifySign(params, Constants.PUBLIC_KEY, sign);
			LOGGER.info("订单号 orderId : " + orderId + "校验签名 : " + (verify ? " 成功" : " 失败"));
			
			try {
	        	 if (verify && status.equals(Constants.SUCCESS) && notifyType.equals(Constants.PAYMENT)) {  //支付通知逻辑
	                 //支付
					LOGGER.info("orderId : " + orderId + " payment asyncCallBack start !!!");
					iActOrderUpdateService.payActOrderComplete(orderId, Constants.PAY_STATUS_SUCCESS);
					LOGGER.info("orderId : " + orderId + " payment asyncCallBack end !!!");
	                out.print(Constants.SUCCESS);//输出success
				} else if (verify && status.equals(Constants.SUCCESS) && notifyType.equals(Constants.REFUND)){  //如果需要退款成功通知逻辑
	        		//退款
					LOGGER.debug("orderId : " + orderId + " refund asyncCallBack start !!!");
					iActOrderUpdateService.dealRefundResult(orderId, Constants.REFUND_STATUS_SUCCESS);
	                LOGGER.debug("orderId : " + orderId + " refund asyncCallBack end !!!");
	        		out.print(Constants.SUCCESS);//输出success
	        	} else {
	        		out.println(Constants.FAIL);
	            }
	        } catch (Exception e) {
				LOGGER.error("订单 : " + orderId + " 支付回调状态异步更改接口异常" + e.getMessage());
				if(out != null){
					out.println(Constants.FAIL);
				}
	        }
        } catch (Exception e) {
			LOGGER.error("订单 : " + orderId + " 异步回调签名校验异常" + e.getMessage());
			if(out != null){
				out.println(Constants.FAIL);
			}
        }

        return null;
    }
    
    /**
     * . 功能描述: 支付异步回调更改订单的状态<br>
     * 
     */
    @RequestMapping("/asyncCallBackOrder")
    @ResponseBody
    public String asyncCallBackOrder(HttpServletRequest req,
            HttpServletResponse rep) {
    	LOGGER.info("异步回调 asyncCallBack 开始");
    	String ip = req.getRemoteAddr();
        String orderId = ""; //订单编号
        String notifyType = ""; //通知类型payment
        String status = ""; //支付状态
        String channel =""; //支付渠道
        String txnAmount = ""; //支付金额
        String txnDate = ""; //付款时间
        PrintWriter out = null;
        Map<String, String> params = null;
        String sign = ""; //签名
        boolean verify = false;

        try {
        	out = rep.getWriter();
        	params  = this.getRequestParams(req);
            LOGGER.info("PayController => asyncCallBack ###### params " +JSONObject.toJSONString(params));
            orderId = params.get("orderId");
            status = params.get("status");
            channel = params.get("channel");
            txnAmount = params.get("txnAmount");
            notifyType = params.get("notifyType");
            txnDate = params.get("txnDate");
            LOGGER.info("ip : {} , 订单号 : {} , 支付状态 : {} , 支付类型 : {} , 付款时间 : {} ",
            		ip, orderId, status, notifyType, txnDate);
            sign = params.get("sign");
			LOGGER.info("ip : {} , 订单号 : {} , 支付状态 : {} , 支付类型 : {} , 付款时间 : {} , 签名 : {} ",
					ip, orderId, status, notifyType, txnDate, sign);
			verify = SignUtil.verifySign(params, Constants.PUBLIC_KEY, sign);
			LOGGER.info("订单号 orderId : " + orderId + "校验签名 : " + (verify ? " 成功" : " 失败"));
			
			try {
	        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        	java.util.Date date = sdf.parse(txnDate);
	        	if (verify && status.equals(Constants.SUCCESS) && notifyType.equals(Constants.PAYMENT)) {  //支付通知逻辑
	                 //支付
					LOGGER.info("orderId : " + orderId + " payment asyncCallBack start !!!");
					preOrderUpdateService.dealPayResult(orderId, Constants.PAY_STATUS_SUCCESS.toString(),channel,new BigDecimal(txnAmount),null,date);
					LOGGER.info("orderId : " + orderId + " payment asyncCallBack end !!!");
					if(out!=null){
						out.print(Constants.SUCCESS);//输出success
					}
				} else if (verify && status.equals(Constants.SUCCESS) && notifyType.equals(Constants.REFUND)){  //如果需要退款成功通知逻辑
	        		//退款
					LOGGER.debug("orderId : " + orderId + " refund asyncCallBack start !!!");
					preOrderUpdateService.dealRefundResult(orderId, Constants.REFUND_STATUS_SUCCESS.toString());
	                LOGGER.debug("orderId : " + orderId + " refund asyncCallBack end !!!");
	                if(out!=null){
	                	out.print(Constants.SUCCESS);//输出success
	                }
	        	} else {
	        		if(out!=null){
	        			out.println(Constants.FAIL);
	        		}
	            }
	        } catch (Exception e) {
				LOGGER.error("订单 : " + orderId + " 支付回调状态异步更改接口异常" + e.getMessage());
				if(out!=null){
					out.println(Constants.FAIL);
				}
	        }
        } catch (Exception e) {
			LOGGER.error("订单 : " + orderId + " 异步回调签名校验异常" + e.getMessage());
			if(out!=null){
				out.println("fail");
			}
        }

        return null;
    }
    
    /**
     * 
     * 功能描述: 创建支付请求签名参数<br>
     * 〈功能详细描述〉
     *
     * @param orderId 订单编号
     * @param productDesc 订单名称
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public Map<String,String> buildRequestPara(ActOrderQueryResultDTO order,String openId) {
        Map<String,String> tempParams = new HashMap<String,String>();
        //支付者编号  固定值
        tempParams.put("partner", Constants.PARTNER_CODE );
        //订单 编号 长度不超过18位
        tempParams.put("orderId", order.getActOrderId());
        //商品名称 TBD
        tempParams.put("mdseName", Constants.MERCHANDISE_NAME);
        //商品描述 TBD
        tempParams.put("body", Constants.MERCHANDISE_DESC);
        //店铺id
//        tempParams.put("storeId", String.valueOf(order.getStoreId()));
        //终端类型
//        tempParams.put("terminalType", Constants.TERMINALTYPE);
        //交易类型
//        tempParams.put("txnType", Constants.TRADE_TYPE_PAYMENT);
        //异步通知URL 支付系统会执行job来update订单状态
        tempParams.put("notifyUrl", "http://" + domainCallback +"/pay/asyncCallBack.htm");
        //同步通知URL 支付完成后，打开一个页面，支付成功还是失败
        tempParams.put("returnUrl", domain +"/pay/syncCallBack.htm");
        //支付金额
        tempParams.put("txnAmount", String.valueOf(order.getDeposit()));
        //交易关闭时间，以分钟为单位  TBD 全局变量
        tempParams.put("timeout", Constants.ORDER_TIME_OUT);
//        GlobalRule gr = this.iGlobalRuleService.findGlobalRule();
//        tempParams.put("timeout", String.valueOf(gr.getPreorderExpireTime() * 60));
        //service	PC端的支付值为WEB_PAY 微信端的值WEIXIN_PAY
        tempParams.put("service", "WEIXIN_PAY");
        //交易完成返回地址,一般为订单中心地址
//        tempParams.put("finishUrl", domain+"/member/myInquiry.htm");
        //TBD
        tempParams.put("openId", openId);
//        tempParams.put("openId", "o9987szKf2fn2SsGJgrF6EU3-2Ds");
        Map<String,String> values = SignUtil.buildRequestPara(tempParams,Constants.PRIVATE_KEY);
        return values;
    }
    
    /**
     * 
     * 功能描述: 创建支付请求签名参数<br>
     * 〈功能详细描述〉
     *
     * @param orderId 订单编号
     * @param productDesc 订单名称
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public Map<String,String> buildRequestOrderPara(PreOrderQueryBean order,String openId) {
        Map<String,String> tempParams = new HashMap<String,String>();
        //支付者编号  固定值
        tempParams.put("partner", Constants.PARTNER_CODE );
        //订单 编号 长度不超过18位
        tempParams.put("orderId", order.getPreOrderId());
        //商品名称 TBD
        tempParams.put("mdseName", order.getVelModelName());
        //商品描述 TBD
        tempParams.put("body", order.getVelModelName());
        //店铺id
//        tempParams.put("storeId", String.valueOf(order.getStoreId()));
        //终端类型
//        tempParams.put("terminalType", Constants.TERMINALTYPE);
        //交易类型
//        tempParams.put("txnType", Constants.TRADE_TYPE_PAYMENT);
        //异步通知URL 支付系统会执行job来update订单状态
        tempParams.put("notifyUrl", "http://" + domainCallback +"/pay/asyncCallBackOrder.htm");
        //同步通知URL 支付完成后，打开一个页面，支付成功还是失败
        tempParams.put("returnUrl", domain +"/pay/syncCallBackOrder.htm");
        //支付金额
        tempParams.put("txnAmount", String.valueOf(order.getDeposit()));
        //交易关闭时间，以分钟为单位  TBD 全局变量
        tempParams.put("timeout", Constants.ORDER_TIME_OUT);
//        GlobalRule gr = this.iGlobalRuleService.findGlobalRule();
//        tempParams.put("timeout", String.valueOf(gr.getPreorderExpireTime() * 60));
        //service	PC端的支付值为WEB_PAY 微信端的值WEIXIN_PAY
        tempParams.put("service", "WEIXIN_PAY");
        //交易完成返回地址,一般为订单中心地址
//        tempParams.put("finishUrl", domain+"/member/myInquiry.htm");
        //TBD
        tempParams.put("openId", openId);
//        tempParams.put("openId", "o9987szKf2fn2SsGJgrF6EU3-2Ds");
        Map<String,String> values = SignUtil.buildRequestPara(tempParams,Constants.PRIVATE_KEY);
        return values;
    }
    
    /**
     * 
     * 功能描述: 获取回调请求参数<br>
     * 
     */
    private Map<String,String> getRequestParams(HttpServletRequest req){
        Map<String,String> params = new HashMap<String,String>();
        Map<?,?> requestParams = req.getParameterMap();
        
        for (Iterator<?> iter = requestParams.keySet().iterator(); iter.hasNext();) {
            String name = (String) iter.next();
            String[] values = (String[]) requestParams.get(name);
            StringBuffer buffer = new StringBuffer("");
            String valueStr = "";
            for (int i = 0; i < values.length; i++) {
            	buffer.append(values[i] + ",");
            }
            valueStr = buffer.toString();
            valueStr = valueStr.substring(0, valueStr.length() - 1);
            params.put(name, valueStr);
        }
        return params;
    }
    
    private static class Constants{
    	/** 订单超时时间 */
    	public static final String ORDER_TIME_OUT = "60";
    	
    	/** 支付成功 */
    	public static final String SUCCESS = "success";
        
        /** 支付失败 */
    	public static final String FAIL = "fail";
        
        /** 支付者合作伙伴编号 */
    	public static final String PARTNER_CODE = "000003";

        /** 支付状态 ：1  未支付,2  支付成功,3   支付失败 */
    	public static final Integer PAY_STATUS_SUCCESS = 2;
        
        /** 退款状态 ：2 退款成功*/
    	public static final Integer REFUND_STATUS_SUCCESS = 2;
    	
    	/** 支付 */
    	public static final String PAYMENT = "payment";
    	
    	/** 退款 */
    	public static final String REFUND = "refund";
    	
		/** 交易类型(1-支付，2-退款) */
//    	public static String TRADE_TYPE_PAYMENT = "1";

		/** 终端类型(1-主站，2-手机App，3-手机网站)*/
//    	public static String TERMINAL_TYPE = "1";

		/** 支付渠道(默认为1-支付宝) */       
//    	public static String PAYMENT_CHANNEL = "1";

		/** 支付状态(支付失败) */
//    	public static String PAYSTATUS_PAY_FAIL = "3";

		/** 支付状态(未支付) */
//    	public static String PAYSTATUS_NOT_PAY = "1";

    	/** 常规车微信私有密钥 */
    	public static final String PRIVATE_KEY = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBANyWvzVkGwFB7UjJexKy1Ewx8FnlVEkLxYvz8zTYT64oUQjhm+bsikcbqtymU07b/CwjW9+6eLYhLdjn6A5SEZvtvm0+d/pWG6uHEwovxFYYw5pzdRyIZyjzu5IUAptS9K/sAUSa958MMp1MJt8eGR+8ZqV2RHw6NoJHvic2X2rpAgMBAAECgYEAy1GPEDEiyvfvM+WxsLxv/YMSHGnKVEGrZaIHCzBN0SKL/nmkbyabFYuk4xfTNZ6CQlSc/Awt8wGF9qVaOMjgPHiwqBAg1q/4g0ASK6SbFn/Q0KwRXTBS6nB/p+Bf6ge8Dp1JQ2zJEMYbxdToj/tFUB20nPZM5y4Otp83BUTeXNkCQQDyWVWUZx5bU/bCFD42RlBbfB1Qe6AmY3B7XnfdbYtk/s6RSKNL1WKKH7YkmiBbgjvzniHieXj0uUeg9gbwyzzrAkEA6QOh53qefc4gMQyugBRJ0rWdeiqzV6o4ME8ZNoHCvYLrSn+rJBuKzeF0T4D+YatpqHhAiXPw9ZHSpsqvCqnyewJBAOPQ9LD/yrqhkHpbGyxcJtgJMWlh/Wd43NksMdOWUY5MNZS/SrpTykD7lHaN6FL9dywI/+NsuzaaIWp/PIEJHKcCQDh/8/sf5VxV5cJe89UEll3sQbIEtpXUJWm5VEC+OA0huJHI4SORNhfzyfMZMRVXrff2qJdrsIqrACwHS2hHiw8CQQCOqAdMVtenb8WVtbn6VX7f/tZ6JeyfpmmxtT2koJUx5B/DrzXZpz9/LMoX1MgqQH2USg95pevvllhzqrt/i3/f";
    	
    	/** 共有密钥 */
    	public static final String PUBLIC_KEY="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC1j5RFCiw5bKY72+m9eUjnyVFccniN6GDItUiv1adwauEYygi44JWIxNYfbGB8VspIEjMCQKi6Oww94h0tSTqqarjqATF1jybSvNtqAddcrXWd3W13crQ6i2L5b9HS1jfds1oL94zxi1qcIm/AnH54BYHVv7Y8p3ltDhk3P9QD6QIDAQAB";
        
    	/** 支付商品名称  */
    	public static final String MERCHANDISE_NAME = "常规车询价单支付";

    	/** 支付商品描述  */
    	public static final String MERCHANDISE_DESC = "常规车询价单支付";
    }
    
}


