package com.saic.ebiz.market.pay.controller;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.util.payment.SignUtil;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.promotion.service.api.IActOrderCreateService;
import com.saic.ebiz.promotion.service.api.IActOrderQueryService;
import com.saic.ebiz.promotion.service.api.IActOrderUpdateService;
import com.saic.ebiz.promotion.service.api.IGroupBuyService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.commons.enums.ActOrderStatus;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;
import com.saic.ebiz.promotion.service.commons.exception.IllegalActOrderUserException;
import com.saic.ebiz.promotion.service.entity.ActOrderEntity;
import com.saic.ebiz.promotion.service.vo.ActOrderQueryParamDTO;
import com.saic.ebiz.promotion.service.vo.ActOrderQueryResultDTO;
import com.saic.ebiz.promotion.service.vo.GroupBuyExt;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionExtend;
import com.saic.ebiz.promotion.service.vo.UserInfo;


/**.
 * 
 *  支付
 * 	notifyUrl 异步回调地址	支付完成之后，用来更新订单的状态
 *  returnUrl 同步回调地址	支付完成之后，提示用户支付成功还是失败
 *  finishUrl 支付完成之后，回调的地址。
 *  
 *  同步走公网，异步走内网
 *
 * @author zhagnhui
 */
@RestController
@RequestMapping("/payPrmt")
public class PayPromotionController {
	
   /**.
    * callback域名
    */
    private @Value("${ebiz.wap.web.domainCallback:}") String domainCallback;
    
    /**.
     * 订单二级域名
     */
    private @Value("${ebiz.wap.web.domain:}") String domain;
    
    
    @Autowired
    private IMemberService iMemberService;
    
    
    @Autowired
    private IActOrderCreateService iActOrderCreateService;
    
    
    
    @Autowired
    private  IActOrderQueryService iActOrderQueryService;
    
    @Autowired
    private  IActOrderUpdateService iActOrderUpdateService;
    
    /**
	 * 活动服务
	 */
	@Autowired
	private IGroupBuyService iGroupBuyService;
    
    @Resource
    private IPromotionExtendService iPromotionExtendService;
    
    
    @Autowired
    private IPromotionService iPromotionService;
    
    /**
     * 绑定服务
     */
    @Resource
    private BoundingService boundingService;
    
    /**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 *    本地测试192.168.26.141
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	
    /** The Constant LOGGER.  */
    private final Logger logger = LoggerFactory.getLogger(PayPromotionController.class);

    /**
     *活动支付页面
     */
    @RequestMapping("/prepayprmt")
    public ModelAndView prepayment(HttpServletRequest req,ModelMap modelMap){
    	ModelAndView model = null;
    	//前端orderId传递的是promotionId
        String promotionId = req.getParameter(RequestConstants.ORDER_ID);
        String userIds = req.getParameter(RequestConstants.USER_ID);
        Long userId = 0l;
        if(StringUtils.isEmpty(promotionId)){
        	promotionId = (String) modelMap.get(RequestConstants.ORDER_ID);
        }
        if(StringUtils.isEmpty(userIds)){
        	userIds = (String) modelMap.get(RequestConstants.USER_ID);
        }
        userId = Long.valueOf(userIds);
        GroupBuyExt groupBuy = iGroupBuyService.getGroupBuyExtByPromotionId(Long.valueOf(promotionId));
        logger.info("活动配额还剩余：" + groupBuy.getAvailableNum());
        if(groupBuy.getAvailableNumber() <= 0){
        	model = new ModelAndView("/jieti/quota.ftl");
        	model.addObject("userId", userId);
        	model.addObject("msg", "活动配额已经用完");
        	return model;
        }
        Date now = new Date();
        if(now.after(groupBuy.getEndTime())){
        	model = new ModelAndView("/jieti/quota.ftl");
        	model.addObject("userId", userId);
        	model.addObject("msg", "活动已经结束");
        	return model;
        }
        UserInfo user = iMemberService.findMembCentInfo(userId);
        // 查询改用户是否已有有效订单
        ActOrderQueryParamDTO queryParam = new ActOrderQueryParamDTO();
        queryParam.setMobileNo(user.getMobile());
        queryParam.setPrmtActId(Integer.parseInt(promotionId));
        queryParam.setUserId(userId);
        List<Integer> status = new ArrayList<Integer>();
        status.add(ActOrderStatus.COMMIT.code());
        status.add(ActOrderStatus.PAYMENT.code());
        status.add(ActOrderStatus.DEAL.code());
        queryParam.setStatus(status);

        List<ActOrderQueryResultDTO> orderList = this.iActOrderQueryService.getExportActOrderList(queryParam);

        ActOrderEntity order = new ActOrderEntity();
        // 如果没有有效订单，则新创建订单
        if (orderList == null || orderList.isEmpty()) {
            Promotion promotion = iPromotionService.getPromotion(Long.valueOf(promotionId));
            if (promotion == null) {
            	model = new ModelAndView("/jieti/quota.ftl");
            	model.addObject("userId", userId);
            	model.addObject("msg", "活动信息错误");
            	return model;
            }
            // 保证金
            BigDecimal deposit = null;
            PromotionExtend pe = this.iPromotionExtendService.findPromotionExtendByPromotionId(Long.valueOf(promotionId));
            if (pe == null) {
            	model = new ModelAndView("/jieti/quota.ftl");
            	model.addObject("userId", userId);
            	model.addObject("msg", "保证金信息错误");
            	return model;
            }
            deposit = pe.getDeposit();
            // 活动id
            order.setPrmtActId(Integer.parseInt(promotionId));
            // 活动名称
            order.setPrmtActName(promotion.getTitle());
            // 金额
            order.setDeposit(deposit);
            // 会员id
            order.setUserId(userId);
            // 会员姓名
            order.setUserName(user.getUserName());
            // 手机号码
            order.setMobileNo(user.getMobile());
            //营销类型
            order.setMarketType(MarketType.GROUP_BUY_GRADATION_PRICE.code());
            logger.info("调用createActOrder接口，传入参数：" + order.toString());
            String orderId = null;
			try {
				orderId = this.iActOrderCreateService.createActOrder(order);
			} catch (IllegalActOrderUserException e) {
				e.printStackTrace();
			}
            logger.info("调用createActOrder接口，返回订单编号：" + orderId);
            // 预定单编码
            order.setActOrderId(orderId);
        } else {
            if (orderList.size() > 1) {
            	return model;
            }
            ActOrderQueryResultDTO result = orderList.get(0);
            if (ActOrderStatus.PAYMENT.code().equals(result.getStatus())
                    || ActOrderStatus.DEAL.code().equals(result.getStatus())) {
                return model;
            }
            // 活动id
            order.setPrmtActId(Integer.parseInt(promotionId));
            // 活动名称
            order.setPrmtActName(result.getPrmtActName());
            // 金额
            order.setDeposit(result.getDeposit());
            // 会员id
            order.setUserId(userId);
            // 会员姓名
            order.setUserName(user.getUserName());
            // 手机号码
            order.setMobileNo(user.getMobile());
            // 预定单编码
            order.setActOrderId(result.getActOrderId());
            //营销类型
            order.setMarketType(MarketType.GROUP_BUY_GRADATION_PRICE.code());

            logger.info("该用户已生成订单：" + order.toString());
        }
        String url = "/pay/payment.ftl";
        logger.info("PayPrmtController => prepayment ###### 订单号 : " + order.getActOrderId());
        
        if(order.getActOrderId()!=null){
            //授权回调会传入openId
            String openId = req.getParameter("openId");
            //如果不是授权的回调，则通过userId从数据库中query
            if(StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)){
            	openId = this.boundingService.getOpenIdByUserId(userId);
            	logger.debug("团购订单 openId : " + openId);
            	//如果查询不到，则走授权获取
            	if(StringUtils.isEmpty(openId) || StringUtils.isBlank(openId)){
            		String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm?orderId=" + order.getActOrderId()), Scope.snsapi_base);
            		autorizationUrl = autorizationUrl.replace("STATE", Authorization.payprmt.name());
            		logger.debug("未知的用户，使用授权获取openId######");
            		logger.debug("授权url : {} ######", autorizationUrl);
            		model = new ModelAndView(autorizationUrl);
            		return model;
            	}
            }
            url = "/pay/payment.ftl"; //订单支付信息页
            Map<String,String> map = this.buildRequestPara(order,openId);
            model = new ModelAndView(url);
            model.addObject("requestPara", map);
            logger.debug("跳转到支付页面,参数map:"+ JSONObject.toJSON(map));
        }else{
            throw new BaseException("订单号(" + order.getActOrderId() + ")不存在!!!");
        }
        model.addObject("order", order);
        return model;
    }
    
    
    
    /**
     * . 功能描述: 支付同步回调反馈支付状态(支付完成之后，open一个页面说明支付成功或者失败)<br>
     * 
     */
    @RequestMapping("/syncCallBack")
    @ResponseBody
    public ModelAndView getSyncCallBack (HttpServletRequest req, HttpServletResponse rep) {
    	String ip = req.getRemoteAddr();
        logger.info("syncCallBack ip:" +ip);
        String url = "";
        Map<String, String> params  = this.getRequestParams(req);
        logger.debug("PayPrmtController => syncCallBack ###### params : " + JSONObject.toJSONString(params));
        String orderId = params.get(RequestConstants.ORDER_ID);
        String status = params.get("status");
        logger.debug("orderId : " + orderId + "###### payStatus : " + status );
        String sign= params.get("sign");
		logger.debug("orderId : " + orderId + "###### payStatus : " + status + " ###### sign : " + sign);
        boolean verify = SignUtil.verifySign(params, Constants.PUBLIC_KEY, sign);
		logger.debug("订单号 orderId : " + orderId + " 校验签名 : " + (verify ? " 成功" : " 失败"));
		
		ActOrderQueryResultDTO order = null;
        //根据订单ID获取订单相关信息
        if(StringUtils.isBlank(orderId)){
        	throw new BaseException("订单号不能为空!!!");
        }else{
        	order = this.iActOrderQueryService.getActOrderById(orderId);
        }
        logger.info("调用iActOrderQueryService.getActOrderById(" + orderId + ") 返回 : " + JSONObject.toJSONString(order));
        Long userId = null;
        if(order!=null){
        	userId = order.getUserId();
        }else{
        	throw new BaseException("未找到订单 ：" + orderId);
        }
        if (verify && status.equals(Constants.SUCCESS)) {
			url = "/pay/payprmt_success.ftl";
		} else {
			url = "/pay/payprmt_error.ftl";
		}
        return new ModelAndView(url).addObject(RequestConstants.ORDER_ID, orderId).addObject(RequestConstants.USER_ID, userId);
    }
    
    
    @RequestMapping("/asyncCallBack")
    public void updateOrder(HttpServletRequest request, HttpServletResponse response) {
        logger.info("进入异步通知流程");
        response.setContentType("text/html");
        PrintWriter out;
        try {
            out = response.getWriter();
            Map<String, String> params = getRequestParams(request);
            String orderid = params.get("orderId"); // 订单编号
            String status = params.get("status"); // 支付状态
            String notifyType = params.get("notifyType"); // 通知类型payment
            // String txnDate = params.get("txnDate"); // 付款时间
            boolean verify = SignUtil.verifySign(params, Constants.PUBLIC_KEY, params.get("sign"));
            if (verify && notifyType.equals("payment") && status.equals("success")) { // 支付通知逻辑
                logger.info("支付成功" + orderid);
                // 更新订单状态
                iActOrderUpdateService.dealPayResult(orderid, Constants.PAY_STATUS_SUCCESS);
                logger.info("更新订单状态为已支付" + orderid);
                out.print("success");// 输出success
            }
            if (verify && notifyType.equals("refund") && status.equals("success")) { // 如果需要退款通知逻辑
                logger.info("退款成功" + orderid);
                // 更新订单状态
                iActOrderUpdateService.dealRefundResult(orderid, Constants.REFUND_STATUS_SUCCESS);
                logger.info("更新订单状态为已退款" + orderid);
                out.print("success");// 输出success
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    
    /**
     * 
     * 功能描述: 创建支付请求签名参数<br>
     * 〈功能详细描述〉
     *
     * @param orderId 订单编号
     * @param productDesc 订单名称
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public Map<String,String> buildRequestPara(ActOrderEntity order,String openId) {
        Map<String,String> tempParams = new HashMap<String,String>();
        //支付者编号  固定值
        tempParams.put("partner", Constants.PARTNER_CODE );
        //订单 编号 长度不超过18位
        tempParams.put("orderId", order.getActOrderId());
        //商品名称 TBD
        tempParams.put("mdseName", Constants.MERCHANDISE_NAME);
        //商品描述 TBD
        tempParams.put("body", Constants.MERCHANDISE_DESC);
        //异步通知URL 支付系统会执行job来update订单状态
        tempParams.put("notifyUrl", "http://" + domainCallback +"/payPrmt/asyncCallBack.htm");   //用拍卖的回调
        //同步通知URL 支付完成后，打开一个页面，支付成功还是失败
        tempParams.put("returnUrl", domain +"/payPrmt/syncCallBack.htm");
        //支付金额
        tempParams.put("txnAmount", String.valueOf(order.getDeposit()));
        //交易关闭时间，以分钟为单位  TBD 全局变量
        tempParams.put("timeout", Constants.ORDER_TIME_OUT);
        tempParams.put("service", "WEIXIN_PAY");
        tempParams.put("openId", openId);
        Map<String,String> values = SignUtil.buildRequestPara(tempParams,Constants.PRIVATE_KEY);
        return values;
    }
    
    /**
     * 
     * 功能描述: 获取回调请求参数<br>
     * 
     */
    private Map<String,String> getRequestParams(HttpServletRequest req){
        Map<String,String> params = new HashMap<String,String>();
        Map<?,?> requestParams = req.getParameterMap();
        for (Iterator<?> iter = requestParams.keySet().iterator(); iter.hasNext();) {
            String name = (String) iter.next();
            String[] values = (String[]) requestParams.get(name);
            StringBuffer valueStr = new StringBuffer();
            for (int i = 0; i < values.length; i++) {
                valueStr.append(values[i] + ",");
            }
            String tempString = valueStr.toString();
            tempString = tempString.substring(0, tempString.length() - 1);
            params.put(name, tempString);
        }
        return params;
    }
    
    private static class Constants{
    	/** 订单超时时间 */
    	public static final String ORDER_TIME_OUT = "60";
    	
    	/** 支付成功 */
    	public static final String SUCCESS = "success";
        
        /** 支付者合作伙伴编号 */
    	public static final String PARTNER_CODE = "000003";

        /** 支付状态 ：1  未支付,2  支付成功,3   支付失败 */
    	public static final Integer PAY_STATUS_SUCCESS = 2;
        
        /** 退款状态 ：2 退款成功*/
    	public static final Integer REFUND_STATUS_SUCCESS = 2;
    	
    	/** 常规车微信私有密钥 */
    	public static final String PRIVATE_KEY = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBANyWvzVkGwFB7UjJexKy1Ewx8FnlVEkLxYvz8zTYT64oUQjhm+bsikcbqtymU07b/CwjW9+6eLYhLdjn6A5SEZvtvm0+d/pWG6uHEwovxFYYw5pzdRyIZyjzu5IUAptS9K/sAUSa958MMp1MJt8eGR+8ZqV2RHw6NoJHvic2X2rpAgMBAAECgYEAy1GPEDEiyvfvM+WxsLxv/YMSHGnKVEGrZaIHCzBN0SKL/nmkbyabFYuk4xfTNZ6CQlSc/Awt8wGF9qVaOMjgPHiwqBAg1q/4g0ASK6SbFn/Q0KwRXTBS6nB/p+Bf6ge8Dp1JQ2zJEMYbxdToj/tFUB20nPZM5y4Otp83BUTeXNkCQQDyWVWUZx5bU/bCFD42RlBbfB1Qe6AmY3B7XnfdbYtk/s6RSKNL1WKKH7YkmiBbgjvzniHieXj0uUeg9gbwyzzrAkEA6QOh53qefc4gMQyugBRJ0rWdeiqzV6o4ME8ZNoHCvYLrSn+rJBuKzeF0T4D+YatpqHhAiXPw9ZHSpsqvCqnyewJBAOPQ9LD/yrqhkHpbGyxcJtgJMWlh/Wd43NksMdOWUY5MNZS/SrpTykD7lHaN6FL9dywI/+NsuzaaIWp/PIEJHKcCQDh/8/sf5VxV5cJe89UEll3sQbIEtpXUJWm5VEC+OA0huJHI4SORNhfzyfMZMRVXrff2qJdrsIqrACwHS2hHiw8CQQCOqAdMVtenb8WVtbn6VX7f/tZ6JeyfpmmxtT2koJUx5B/DrzXZpz9/LMoX1MgqQH2USg95pevvllhzqrt/i3/f";
    	
    	/** 共有密钥 */
    	public static final String PUBLIC_KEY="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC1j5RFCiw5bKY72+m9eUjnyVFccniN6GDItUiv1adwauEYygi44JWIxNYfbGB8VspIEjMCQKi6Oww94h0tSTqqarjqATF1jybSvNtqAddcrXWd3W13crQ6i2L5b9HS1jfds1oL94zxi1qcIm/AnH54BYHVv7Y8p3ltDhk3P9QD6QIDAQAB";
        
    	/** 支付商品名称  */
    	public static final String MERCHANDISE_NAME = "团购活动保证金支付";

    	/** 支付商品描述  */
    	public static final String MERCHANDISE_DESC = "团购活动保证金支付";
    }
    
}


