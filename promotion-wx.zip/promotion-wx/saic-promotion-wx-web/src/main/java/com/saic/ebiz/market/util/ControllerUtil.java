/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: ControllerUtil.java
 * Author:   v_fanjx
 * Date:     2014年1月22日 下午4:23:36
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.saic.ebiz.market.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.meidusa.fastjson.JSONObject;

/**
 * controller包公用的工具类<br>
 * 〈功能详细描述〉
 * 
 * @author v_fanjx
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public final class ControllerUtil {

    /**
     * 隐藏工具类的构造方法
     */
    private ControllerUtil() {

    }

    /**
     * 校验请求来源是否来自手机 <br>
     * 〈功能详细描述〉
     * 
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static boolean checkMobile(HttpServletRequest request) {
        String regexMatch = "nokia|iphone|ipod|iuc|android|motorola|^mot\\-|softbank|foma|docomo|kddi|up\\.browser|up\\.link|";
        regexMatch += "htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|";
        regexMatch += "blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|";
        regexMatch += "symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\\-|longcos|pantech|gionee|^sie\\-|portalmmm|";
        regexMatch += "jig\\s browser|hiptop|ucweb|^ucweb|^benq|haier|^lct|opera\\s*mobi|opera\\*mini|320x320|240x320|176x220";

        String userAgent = request.getHeader("user-agent").toLowerCase();
        if (StringUtils.isBlank(userAgent)) {
            return true;
        } else {
            Pattern p = Pattern.compile(regexMatch);
            Matcher m = p.matcher(userAgent);
            if (m.find()) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 判断当前日期是否在某日期之后 <br>
     * @author v_lijialiang
     * @param format 日期格式
     * @param dateTime	设定日期
     * @return true 在某日期后 false 不在
     */
    public static boolean isTimeLater(String format,String dateTime) {
        // 判断当前日期是否在某日期之后
    	Date nowsysdate = new Date();
		SimpleDateFormat formatLink = new SimpleDateFormat(format);
		Date TurnTime = null;
		boolean isTimeLater=false;
		try {
			TurnTime = formatLink.parse(dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (null != TurnTime) {
			if (nowsysdate.after(TurnTime)) {
				isTimeLater = true;
			}
		}
		return isTimeLater;
    }
    
    /**
     * 判断当前日期是否在2015年328活动日期开始之后 <br>
     * @author v_lijialiang
     * @param format 日期格式
     * @return true 在某日期后 false 不在
     */
    public static boolean isTimeLaterFor328() {
        // 判断当前日期是否在某日期之后
    	String dateTime="2015-3-28 00:00:00";
    	String format = "yyyy-MM-dd HH:mm:ss";
    	Date nowsysdate = new Date();
		SimpleDateFormat formatLink = new SimpleDateFormat(format);
		Date TurnTime = null;
		boolean isTimeLater=false;
		try {
			TurnTime = formatLink.parse(dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (null != TurnTime) {
			if (nowsysdate.after(TurnTime)) {
				isTimeLater = true;
			}
		}
		return isTimeLater;
    }
    /**
     * 判断当前日期是否在2015年4月1日活动日期开始之后 <br>
     * @author v_lijialiang
     * @param format 日期格式
     * @return true 在某日期后 false 不在
     */
    public static boolean isTimeLaterFor401() {
    	// 判断当前日期是否在某日期之后
    	String dateTime="2015-04-01 00:00:00";
    	String format = "yyyy-MM-dd HH:mm:ss";
    	Date nowsysdate = new Date();
    	SimpleDateFormat formatLink = new SimpleDateFormat(format);
    	Date TurnTime = null;
    	boolean isTimeLater=false;
    	try {
    		TurnTime = formatLink.parse(dateTime);
    	} catch (ParseException e) {
    		e.printStackTrace();
    	}
    	if (null != TurnTime) {
    		if (nowsysdate.after(TurnTime)) {
    			isTimeLater = true;
    		}
    	}
    	return isTimeLater;
    }
    
    public static void response2JSON(HttpServletResponse response,Object obj){
    	//将实体对象转换为JSON Object转换  
        response.setCharacterEncoding("UTF-8");  
        response.setContentType("application/json; charset=utf-8");  
        PrintWriter out = null;  
        try {  
            out = response.getWriter();  
            out.write(JSONObject.toJSONString(obj));
            out.flush();
        } catch (IOException e) {  
            e.printStackTrace();  
        } finally {  
            if (out != null) {  
                out.close();  
            }  
        }  
    }
}
