/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.market.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.util.SHA1Util;
import com.saic.ebiz.market.entity.ConsumerData;

/**
 * @author hejian
 *
 */
public class JsSDKSign {
	
	/**
	 * 
	 */
	private static final String SUCCESS = "success";
	private static Logger LOGGER = LoggerFactory.getLogger(JsSDKSign.class);
	
    /***
     * 
     * @param appId 微信服务号应用ID
     * @param url 要访问页面的url eg. http://mgo.chexiang.com/account/login.html
     * 		且从url的#号后面截断(如果有)
     * @return
     */
    public static Map<String, String> sign(String appId, String url) {
    	Map<String, String> result = null;
    	String jsapi_ticket = getJsapiTicket();
    	if(jsapi_ticket != null){
    		result = sign(jsapi_ticket, appId, url);
    	}
		return result;
	}
    /***
     * 
     * @param jsapi_ticket 签名的票据
     * @param appId 应用服务号ID
     * @param url 要访问页面的url
     * @return
     */
	
	public static Map<String, String> sign(String jsapi_ticket,String appId, String url) {
		Map<String, String> ret = new HashMap<String, String>();
		String nonce_str = create_nonce_str();
		String timestamp = create_timestamp();
//		String nonce_str = "82693e11-b9bc-448e-892f-f5289f46cd0f";
//		String timestamp = "1419835025";
		String data;
		String signature = "";
		//截断#
		int index = url.indexOf("#");
		if(index > 0){
			url = url.substring(0,index);
		}

		// 注意这里参数名必须全部小写，且必须有序
		data = "jsapi_ticket=" + jsapi_ticket + "&noncestr=" + nonce_str
				+ "&timestamp=" + timestamp + "&url=" + url;
		LOGGER.info("需要签名的数据串 : " + data);

		try {
			MessageDigest crypt = MessageDigest.getInstance("SHA-1");
			crypt.reset();
			crypt.update(data.getBytes("UTF-8"));
			signature = byteToStr(crypt.digest());
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error(e.getMessage());
		} catch (UnsupportedEncodingException e) {
			LOGGER.error(e.getMessage());
		}

		ret.put("url", url);
		ret.put("appId", appId);
		ret.put("jsapi_ticket", jsapi_ticket);
		ret.put("nonceStr", nonce_str);
		ret.put("timestamp", timestamp);
		ret.put("signature", signature);

		return ret;
	}

	/**
	 * 将字节数组转换为十六进制字符串
	 * 
	 * @param byteArray
	 * @return
	 */
	private static String byteToStr(byte[] byteArray) {
		StringBuffer buffer = new StringBuffer("");
		for (int i = 0; i < byteArray.length; i++) {
			buffer.append(byteToHexStr(byteArray[i]));
		}
		return buffer.toString();
	}

	/**
	 * 将字节转换为十六进制字符串
	 * 
	 * @param mByte
	 * @return
	 */
	private static String byteToHexStr(byte mByte) {
		char[] Digit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a',
				'b', 'c', 'd', 'e', 'f' };
		char[] tempArr = new char[2];
		tempArr[0] = Digit[(mByte >>> 4) & 0X0F];
		tempArr[1] = Digit[mByte & 0X0F];
		String s = new String(tempArr);
		return s;
	}

	private static String create_nonce_str() {
		return UUID.randomUUID().toString();
	}

	private static String create_timestamp() {
		return Long.toString(System.currentTimeMillis()/1000);
	}
	
	private static String getJsapiTicket(){
		String jsapiTicket = null;
		CloseableHttpClient httpclient = HttpClients.createDefault();
        try {
            HttpGet httpget = new HttpGet("http://mgo.chexiang.com/customer/ticket");
            // Create a custom response handler
            ResponseHandler<String> responseHandler = new ResponseHandler<String>() {
                @Override
                public String handleResponse(final HttpResponse response) throws IOException  {
                    int status = response.getStatusLine().getStatusCode();
                    if (status >= 200 && status < 300) {
                        HttpEntity entity = response.getEntity();
                        return entity != null ? EntityUtils.toString(entity) : null;
                    } else {
                    	LOGGER.error("Unexpected response status: " + status);
                    	return null;
                    }
                }
            };
            String responseBody;
			try {
				responseBody = httpclient.execute(httpget, responseHandler);
				LOGGER.info("----------------------------------------");
				LOGGER.info(responseBody);
				//json数据必定是{|[开始
				if(responseBody != null && (responseBody.startsWith("{") || responseBody.startsWith("["))){
					ConsumerData consumerData = JSONObject.parseObject(responseBody, ConsumerData.class);
					//status为success说明是成功状态并且签名不为空
					if(consumerData != null && consumerData.getStatus() != null && consumerData.getSign() != null){
						if(SUCCESS.equals(consumerData.getStatus()) && consumerData.getSign().equals(new SHA1Util().getDigestOfString(consumerData.getData().getBytes()))){
							jsapiTicket = consumerData.getData();
						}
					}
				}
			} catch (IOException e) {
				LOGGER.error("获取Jsapi_Ticket异常", e);
			}
        } finally {
            try {
				httpclient.close();
			} catch (IOException e) {
				LOGGER.error("关闭HttpClient", e);
			}
        }
        return jsapiTicket;
	}
}
