package com.saic.ebiz.mg.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.dal.pagination.Pagination;
import com.ibm.framework.dal.pagination.PaginationResult;
import com.ibm.framework.web.gson.GsonView;
import com.meidusa.fastjson.JSON;
import com.saic.ebiz.bc.utils.UrlUtil;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.util.CookieUtil;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.vo.CxgMerchandiseVO;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionExtend;
import com.saic.ebiz.promotion.service.vo.PromotionResult;

/**
 * 名爵活动Controller
 * 
 * @author v_hexiang
 * 
 */
@Controller
@RequestMapping("/mggs")
public class MggsController {

    /** The Constant logger. */
    private final static Logger logger = LoggerFactory.getLogger(MggsController.class);

    /** 用户行为跟踪logger. */
    private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");

    @Autowired
    private UserService userService;

    @Autowired
    private IPromotionService promotionService;

    // 活动服务
    @Autowired
    private IPromotionService remotePromotionService;

    // 活动扩展
    @Autowired
    private IPromotionExtendService remotePromotionExtendService;
    @Autowired
    private IPromotionQualificationService iPromotionQualificationService;

    /**
     * 授权服务
     */
    @Resource
    private AuthorizationService authorizationService;

    /**
     * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
     * mgo.chexiang.com
     */
    @Value("${ebiz.wap.web.redirectHost:}")
    private String redirectHost;

    /**
     * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
     * 
     */
    @Value("${ebiz.wap.web.appId:}")
    private String appId;

    /**
     * 报用户行为跟踪logger.source来源业务渠道 1：电商主站2：车享宝3：营销子站
     */
    public static final int source_YXZZ = 3;

    /**
     * 报用户行为跟踪logger.type订单类型 13.促销活动-------即营销子站，即cxzz来源的销售线索，比如大转盘，
     */
    public static final int type_YXZZ = 13;
    

    /**
     * 报用户行为跟踪logger.type订单类型 13.促销活动-------即营销子站，即cxzz来源的销售线索，比如大转盘，
     */

    /**
     * 1：电商主站； 2：车享宝； 3：营销子站； 4：保养管家； 5：第三方联合登陆； 6：别克联合登陆； 7：微信服务号； 8：微信订阅号；
     * 9：微信红包 11：呼叫中心； 12：平安保险（PC）； 13：订单系统； 14：车畅销； 20：车知道（内部账号）； 21：别克微信商城；
     * 22：荣威俱乐部； 23：crm； 24：运营平台； 29：车享购微信服务号； 31：平安微信； 35：新浪微博PC； 36：新浪微博移动；
     * 60：Other
     */
    private static final String TRACE_SOURCE = "7";

    /**
     * 线索类型 10.促销车订购 11.预约试乘试驾 12.在线询价 13.促销活动 14.常规车预定 15.来电咨询 16.在线留言咨询
     * 17.贷款购车 18.拉手电话 20.其他
     */
    private static final String TRACE_TYPE = "20";

    
    @RequestMapping("/index")
    private ModelAndView mgGS(HttpServletRequest request) {
        ModelAndView mav = null;
        String uId = request.getParameter(RequestConstants.USER_ID);
        String openId = request.getParameter(RequestConstants.OPEN_ID);
        logger.info("request parameters userId = {}, openId = {} ", uId, openId);

        // uId = "559464";
        if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
            String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
            autorizationUrl = autorizationUrl.replace("STATE", Authorization.mggs2.name());
            logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
            logger.debug("授权url : {} ######", autorizationUrl);
            mav = new ModelAndView(autorizationUrl);
        } else {
            mav = new ModelAndView("/mggs/MG-GS.ftl");
            mav.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
        }
        List<String> mg3Code = new ArrayList<String>();
        mg3Code.add("c518_2_mggs02");
        logger.info("promotionCode= {}", "c518_2_mggs02");
        Map<String, Promotion> xiuqiuByCodes = promotionService.getXiuqiuByCodes(mg3Code);
        mav.getModelMap().put("xiuqiuByCodes", xiuqiuByCodes);
        mav.getModelMap().put("userId", uId);
        mav.getModelMap().put("code", "c518_2_mggs02");
        return mav;
    }

    @ResponseBody
    @RequestMapping("/qiangGou")
    public GsonView qiangGou(String promotionCode, String keyId, Long userId, HttpServletRequest request, HttpServletResponse response,Integer level) {
        usertraceLogger.info("微信端MG活动\t" + getCookieByName(request) + "\t" + userId + "\t" + "成功" + "\t" + "keyId = " + keyId + "\t" + TRACE_SOURCE + "\t" + TRACE_TYPE);
        GsonView gv = new GsonView();
        try {

            // UserLoginVO userLoginVO = checkLoginStatus(request, gv);
            // if (!userLoginVO.getIsLoginSuccess()) {
            // return gv;
            // }
            UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(userId);
            String mobile = userBaseInfoVO.getMobile();
            Long promotionId = promotionService.getPromotionIdByCode(promotionCode);

            CxgMerchandiseVO cxgMerchandiseVO=getPromotionWithCode(promotionId, level);
            
            // String mobile = "13641754374";
            long customerId = remotePromotionService.getCustomerId(userId, mobile);

            PromotionResult subscribeResult = null;
            boolean isAvailable = false;
            String url = "";
            logger.info("promotionId=" + promotionId + ",mobile=" + mobile + ",userId=" + userId);
            subscribeResult = remotePromotionService.newSubscribe(promotionId, mobile, userId);
            logger.debug("subscribe：接口返回结果:" + JSON.toJSONString(subscribeResult) + "--调用参数:promotionId:" + promotionId + "--mobile:" + mobile + "--userId:" + userId + "--customerId:" + customerId);

            if (subscribeResult != null) {

//                Cookie[] cookies = request.getCookies();
//                String userTraceCookie = "";
//                for (Cookie cookie : cookies) {
//                    String name = cookie.getName();
//                    if ("user_trace_cookie".equals(name)) {
//                        userTraceCookie = cookie.getValue();
//                        break;
//                    }
//                }
//                usertraceLogger.info(userTraceCookie + "\t" + userId + "\t" + promotionId + "\t" + PropertiesUtil.getValue(String.valueOf(subscribeResult.getResultCode())) + "\t" + mobile + "\t" + source_YXZZ + "\t" + type_YXZZ + "\t" + keyId);

                if (subscribeResult.getResultCode() == 0) {
                    long velBrandId =cxgMerchandiseVO.getVelBrandId() ;
                    long velSeriesId = cxgMerchandiseVO.getVelSeriesId();

                    Long velModelId =cxgMerchandiseVO.getVelModelId()  == null ? -1L : cxgMerchandiseVO.getVelModelId();
                    url = UrlUtil.getCheXiangGouOrderUrl(promotionId, subscribeResult.getSubscriptionId(), -1L, velBrandId, velSeriesId, velModelId, checkMobile(request), null, userId);
                    logger.debug("拼接后的URL为:" + url);
                }

                if (subscribeResult.getSubscription() != null) {
                    isAvailable = subscribeResult.getSubscription().isAvailable();
                }
            }

            PromotionExtend promotionExtend = remotePromotionExtendService.findPromotionExtendByPromotionId(promotionId);
            if (promotionExtend != null) {
                gv.addStaticAttribute("userPrmtLimit", promotionExtend.getUserPrmtLimit());
            }
            gv.addStaticAttribute("isAvailable", isAvailable);
            gv.addStaticAttribute("subscribeResult", subscribeResult);
            gv.addStaticAttribute("url", url);
            if (cxgMerchandiseVO != null) {
                gv.addStaticAttribute("members", cxgMerchandiseVO.getAvailableNum());
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("车享购抢购错误,错误信息:{}", e.getMessage());
        }
        return gv;
    }

    private String getCookieByName(HttpServletRequest request) {
        Cookie cookie = CookieUtil.getCookieByName(request, "user_trace_cookie");
        String cookieName = null;
        if (cookie != null) {
            cookieName = cookie.getValue();
        }
        return cookieName;
    }

    /**
     * 校验请求来源是否来自手机 <br>
     * 〈功能详细描述〉
     * 
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static boolean checkMobile(HttpServletRequest request) {
        String regexMatch = "nokia|iphone|ipod|iuc|android|motorola|^mot\\-|softbank|foma|docomo|kddi|up\\.browser|up\\.link|";
        regexMatch += "htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|";
        regexMatch += "blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|";
        regexMatch += "symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\\-|longcos|pantech|gionee|^sie\\-|portalmmm|";
        regexMatch += "jig\\s browser|hiptop|ucweb|^ucweb|^benq|haier|^lct|opera\\s*mobi|opera\\*mini|320x320|240x320|176x220";

        String userAgent = request.getHeader("user-agent").toLowerCase();
        if (StringUtils.isBlank(userAgent)) {
            return true;
        } else {
            Pattern p = Pattern.compile(regexMatch);
            Matcher m = p.matcher(userAgent);
            if (m.find()) {
                return true;
            }
        }
        return false;
    }
    
 private CxgMerchandiseVO getPromotionWithCode(Long promotionId,Integer velDisplayType){
        
        
        Pagination pagination = new Pagination();
        pagination.setCurrentPage(1);
        pagination.setPagesize(10);
        PaginationResult<List<CxgMerchandiseVO>> paginationResult = 
                iPromotionQualificationService.queryCxgMerchandiseByCombinedCondition(
                        promotionId, null, null, null, false, velDisplayType, pagination);

        
        List<CxgMerchandiseVO> r = paginationResult.getR();
        CxgMerchandiseVO cxgMerchandiseVO = r.get(0);
        return cxgMerchandiseVO;
    }

}
