package com.saic.ebiz.oem.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.gson.GsonView;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.oneyear.service.AccessTokenService;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.util.ControllerUtil;
import com.saic.ebiz.mdm.api.WebAccountService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.framework.redis.client.IRedisClient;

/**
 * MG车系微信88节
 * @author huangzhong
 * @since 2015-7-4
 */
@Controller
@RequestMapping("/mgbrand")
public class MgOemActivityControler {
	
	private final Logger logger = LoggerFactory.getLogger(MgOemActivityControler.class);
	
	//微信授权
	@Resource
	private AuthorizationService authorizationService;
	
	@Autowired
	private JsSDKSign jsSDKSign;
	
	
	//微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
	
	//URL配置IP地址
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	@Value("${ebiz.wap.web.domain:}")
	private String domain;
	
	//活动服务实现类
	@Autowired
	private IPromotionService iPromotionService;
	
	/** 缓存接口. */ 
	@Resource(name = "springRedisClient")
	private IRedisClient redisClient;
	
    @Autowired
    private WebAccountService webAccountService;
	
    /**
     * 微信权限信息   
     */
    @Resource
    private AccessTokenService accessTokenService;
    
	/** 验证码key */
	public static final String VALIDATECODE_REDIS_KEY = "mini:promotion:authCode:validateCode:";

	//静态块初始化MG活动code
	static List<String> codeList = new ArrayList<String>();
	static {
		codeList.add("MGALL_BRAND_MG3");
		codeList.add("MGALL_BRAND_MG5");
		codeList.add("MGALL_BRAND_MG6");
		codeList.add("MGALL_BRAND_MGGS");
		codeList.add("MGALL_BRAND_MGGT");
	}
	       
	static List<String> codeList2 = new ArrayList<String>();
	static {
		codeList2.add("OEM_MGALL_TWO_MG3");
		codeList2.add("OEM_MGALL_TWO_MG5");
		codeList2.add("OEM_MGALL_TWO_MG6");
		codeList2.add("OEM_MGALL_TWO_MGGS");
		codeList2.add("OEM_MGALL_TWO_MGGT");
	}
	
	static List<String> codeList3 = new ArrayList<String>();
	static {
		codeList3.add("OEM_MGALL_FOUR_MG3");
		codeList3.add("OEM_MGALL_FOUR_MG5");
		codeList3.add("OEM_MGALL_FOUR_MG6");
		codeList3.add("OEM_MGALL_FOUR_MGGS");
		codeList3.add("OEM_MGALL_FOUR_MGGT");
	}
	
	static List<String> codeList4 = new ArrayList<String>();
	static {
		codeList4.add("OEM_MGALL_ROEWEMG_RW350");
		codeList4.add("OEM_MGALL_ROEWEMG_RW550");
		codeList4.add("OEM_MGALL_ROEWEMG_RW950");
		codeList4.add("OEM_MGALL_ROEWEMG_RWW5");
		codeList4.add("OEM_MGALL_ROEWEMG_MG3");
		codeList4.add("OEM_MGALL_ROEWEMG_MG5");
		codeList4.add("OEM_MGALL_ROEWEMG_MGRT");
		codeList4.add("OEM_MGALL_ROEWEMG_MG6");
		
	}
	
	/**
	 * MG品牌活动跳转
	 * @author huangzhong
	 * @param userId
	 * @param request
	 * @return
	 */
	@RequestMapping("/index")
	public ModelAndView main(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request) {
		ModelAndView mv = null;
	  // boolean isClosedTime = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-10-14 23:59:59");
	   boolean isClosedTime = false;
	   if(!isClosedTime){
		   String uId = request.getParameter(RequestConstants.USER_ID);
			String openId = request.getParameter(RequestConstants.OPEN_ID);
			logger.info("请求的用户ID userId ： {}, openId = {} ", uId, openId);
			if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
				String autorizationUrl = "redirect:" + authorizationService.
						buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
				autorizationUrl = autorizationUrl.replace("STATE", Authorization.mgbrand.name());
				logger.info("授权url : {} ", autorizationUrl);
				mv = new ModelAndView(autorizationUrl);
			} else {
				mv = new ModelAndView("/oem/mgActivity.ftl");
				mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
			}
			// 微信分享JSSDK分享
		    Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + 
		    		"?" + request.getQueryString());
		    mv.addObject("jssdk", map);
			// 判断状态
			Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList);
			mv.addObject("codeMap", codeMap);
	   }else{
		   mv = new ModelAndView("redirect:http://www.chexiang.com/");
	   }
		
		return mv;
	}
	
	@RequestMapping("/mgTwoArea")
	public ModelAndView mgTwoArea(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request){
		ModelAndView mv = null;
	   boolean isClosedTime = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-10-14 23:59:59");
	   if(!isClosedTime){
		   String uId = request.getParameter(RequestConstants.USER_ID);
			String openId = request.getParameter(RequestConstants.OPEN_ID);
			logger.info("请求的用户ID userId ： {}, openId = {} ", uId, openId);
			if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
				String autorizationUrl = "redirect:" + authorizationService.
						buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
				autorizationUrl = autorizationUrl.replace("STATE", Authorization.mgTwoArea.name());
				logger.info("授权url : {} ", autorizationUrl);
				mv = new ModelAndView(autorizationUrl);
			}else{
				mv = new ModelAndView("/oem/mgTwoArea.ftl");
				mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
			}
			// 微信分享JSSDK分享
		    Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + 
		    		"?" + request.getQueryString());
		    mv.addObject("jssdk", map);
		    // 判断状态
	 		Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList2);
	 		mv.addObject("codeMap", codeMap);
	   }else{
		   mv = new ModelAndView("redirect:http://www.chexiang.com/");
	   }
		
		return mv;
	}
	
	@RequestMapping("/mgFourArea")
	public ModelAndView mgFourArea(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request){
		ModelAndView mv = null;
	   boolean isClosedTime = false;
	   if(!isClosedTime){
		   String uId = request.getParameter(RequestConstants.USER_ID);
			String openId = request.getParameter(RequestConstants.OPEN_ID);
			logger.info("请求的用户ID userId ： {}, openId = {} ", uId, openId);
			if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
				String autorizationUrl = "redirect:" + authorizationService.
						buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
				autorizationUrl = autorizationUrl.replace("STATE", Authorization.mgFourArea.name());
				logger.info("授权url : {} ", autorizationUrl);
				mv = new ModelAndView(autorizationUrl);
			}else{
				mv = new ModelAndView("/oem/mgFourArea.ftl");
				mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
			}
			// 微信分享JSSDK分享
		    Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + 
		    		"?" + request.getQueryString());
		    mv.addObject("jssdk", map);
		    // 判断状态
	 		Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList3);
	 		mv.addObject("codeMap", codeMap);
	   }else{
		   mv = new ModelAndView("redirect:http://www.chexiang.com/");
	   }
		return mv;
	}
	
	@RequestMapping("/mgRoewe")
	public ModelAndView mgRoewe(HttpServletRequest request,HttpServletResponse response){
		String groupId = request.getParameter("groupId");
		ModelAndView mv = null;
		String userId = request.getParameter(RequestConstants.USER_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		logger.info("请求的用户ID userId ： {}, openId = {} ", userId, openId);
		if (StringUtils.isEmpty(userId) || "-1".equals(userId)) {
			String autorizationUrl = "redirect:" + authorizationService.
					buildAuthorizationLink(appId, (redirectHost + "/oauthNoLogin.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.mgRoewe.name());
			logger.info("授权url : {} ", autorizationUrl);
			String[] urls = autorizationUrl.split(".htm");
			autorizationUrl = urls[0]+".htm?groupId="+groupId+urls[1];
			logger.info("处理后授权url : {} ", autorizationUrl);
			mv = new ModelAndView(autorizationUrl);
		}
		else{
			//获取分享标题
			String content = getContent(groupId);
			
			//判断分享内容
			String desContent = "上汽员工购车会";
			if(StringUtils.isBlank(groupId) || "1".equals(groupId)){
				desContent="上汽集团乘用车分公司专场";
			}
			//获取分享图片
			String imageName = getImage(groupId);
			mv = new ModelAndView("/oem/mgRoewe.ftl");
			mv.addObject(RequestConstants.USER_ID, userId).addObject(RequestConstants.OPEN_ID, openId).addObject("nowTime", new Date().getTime()).addObject("groupId", groupId)
			.addObject("content",content).addObject("desContent",desContent).addObject("imageName",imageName);
		}
		
		// 微信分享JSSDK分享
	    Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + 
	    		"?" + request.getQueryString());
	    mv.addObject("jssdk", map);
	    // 判断状态
 		Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList4);
 		mv.addObject("codeMap", codeMap);
		return mv;
	}
	
	public String getContent(String groupId){
		if(StringUtils.isBlank(groupId) || "1".equals(groupId)){
			return "2015年上汽乘用车内部员工购车会";
		}else if("2".equals(groupId)){
			return "2015年上海纳铁福传动系统有限公司员工专场";
		}else if("3".equals(groupId)){
			return "2015年上柴、商用车公司、商用车技术中心员工专场";
		}else if("4".equals(groupId)){
			return "2015年上海汇众汽车制造有限公司员工专场";
		}else if("5".equals(groupId)){
			return "2015年延锋汽车饰件系统有限公司员工专场";
		}else if("6".equals(groupId)){
			return "2015年上海汽车集团股份有限公司员工专场";
		}else if("7".equals(groupId)){
			return "2015年上海小糸车灯有限公司员工专场";
		}else if("8".equals(groupId)){
			return "2015年上海华域三电汽车空调有限公司员工专场";
		}else if("9".equals(groupId)){
			return "2015年上海圣德曼铸造有限公司员工专场";
		}else if("10".equals(groupId)){
			return "2015年上海法雷奥汽车电器系统有限公司员工专场";
		}else if("11".equals(groupId)){
			return "2015年上海赛科利汽车模具技术应用有限公司员工专场";
		}else if("12".equals(groupId)){
			return "2015年上海汽车变速器有限公司员工专场";
		}else if("13".equals(groupId)){
			return "2015年联合汽车电子有限公司员工专场";
		}
		return "2015年上汽乘用车内部员工购车会";
	}
	
	public String getImage(String groupId){
		if(StringUtils.isBlank(groupId) || "1".equals(groupId)){
			return "350x350-1.jpg";
		}else if("2".equals(groupId)){
			return "350x350-2.jpg";
		}else if("3".equals(groupId)){
			return "350x350-3.jpg";
		}else if("4".equals(groupId)){
			return "350x350-4.jpg";
		}else if("5".equals(groupId)){
			return "350x350-5.jpg";
		}else if("6".equals(groupId)){
			return "350x350-6.jpg";
		}else if("7".equals(groupId)){
			return "350x350-7.jpg";
		}else if("8".equals(groupId)){
			return "350x350-8.jpg";
		}else if("9".equals(groupId)){
			return "350x350-9.jpg";
		}else if("10".equals(groupId)){
			return "350x350-10.jpg";
		}else if("11".equals(groupId)){
			return "350x350-11.jpg";
		}else if("12".equals(groupId)){
			return "350x350-12.jpg";
		}else if("13".equals(groupId)){
			return "350x350-13.jpg";
		}
		return "2015年上汽乘用车内部员工购车会";
	}
	@RequestMapping("/checkImg")
	public GsonView checkImg(@RequestParam(value = "userId", required = false) Long userId,String inputValidCode){
		GsonView gv = new GsonView();
		/** 检查验证码是否输入正确,0--->输入正确,1--->输入错误 */
		int validateCodeErr = 0;
		/** 获取验服务器验证码 */
		String key = VALIDATECODE_REDIS_KEY + "checkCodeWap" + userId;
		String validCode = StringUtils.EMPTY;
		if (redisClient.exists(key,Constants.REDIS_NAME_SPACE)) {
			/** 获取redis缓存的Value,赋值给validCode */
			validCode = redisClient.get(key,Constants.REDIS_NAME_SPACE,null);
			logger.debug("redis中获取到的验证码：key={}, value={}", key, redisClient.get(key,Constants.REDIS_NAME_SPACE,null));
			/** 删除redis缓存验证码 */
			redisClient.del(key,Constants.REDIS_NAME_SPACE);
		}
		if (StringUtils.isBlank(validCode)) {
			validateCodeErr = 1;
			gv.addStaticAttribute("result", validateCodeErr);
			return gv;
		} else if (!inputValidCode.equalsIgnoreCase(validCode)) {
			validateCodeErr = 1;
			gv.addStaticAttribute("result", validateCodeErr);
			return gv;
		}
		return gv;
	}
	
	/**
	 * 获取授权code
	 * @param url
	 * @param response
	 */
	public void getAuthorizationCode(String url,HttpServletResponse response){
		if(null!=url){
			url=accessTokenService.auth(domain+url);
		}
	        logger.info("getAuthorizationCode--授权  url : " + url);
	        try {
	            response.sendRedirect(url);
	        } catch (IOException e) {
	            logger.info("授权活动时异常"+e.getMessage());
	            e.printStackTrace();
	        }
	
	}
}
