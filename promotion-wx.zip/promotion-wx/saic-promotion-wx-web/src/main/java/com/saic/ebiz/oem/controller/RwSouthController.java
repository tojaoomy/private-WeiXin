package com.saic.ebiz.oem.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.gson.GsonView;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.util.ControllerUtil;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.client.PromotionClient;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.framework.redis.client.IRedisClient;
import com.saic.sso.client.SSOClient;

/**
 * 
 * @author V_hexiang
 *
 */
@Controller
@RequestMapping("/roewe")
public class RwSouthController {

	/**
	 * 日志
	 */
	private final Logger logger = LoggerFactory
			.getLogger(RwSouthController.class);

	/** 缓存接口. */
	@Resource(name = "springRedisClient")
	private IRedisClient redisClient;
	/**
	 * SSO服务
	 */
	@Autowired
	private SSOClient ssoClient;
	

	/** 验证码key */
	public static final String VALIDATECODE_REDIS_KEY = "mini:promotion:authCode:validateCode:";


	/**
	 * 活动服务
	 */
	@Autowired
	private PromotionClient promotionClient;
	
	/**
	 * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	/** 活动服务 */
	@Autowired
	private IPromotionService iPromotionService;

	/**
	 * 活动扩展
	 */
	@Autowired
	private IPromotionExtendService remotePromotionExtendService;
	
	@Autowired
	private JsSDKSign jsSDKSign;
	
	/**
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;

	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;

	static List<String> codeList = new ArrayList<String>();
	static {
		codeList.add("roewe_south_350");
		codeList.add("roewe_south_550");
		codeList.add("roewe_south_750");
		codeList.add("roewe_south_950");
		codeList.add("roewe_south_e50");
		codeList.add("roewe_south_w5");
		codeList.add("roewe_south_360");
	}
	
	
	static List<String> codeList1 = new ArrayList<String>();
	static {
		codeList1.add("roewe_midsouth_350");
		codeList1.add("roewe_midsouth_550");
		codeList1.add("roewe_midsouth_750");
		codeList1.add("roewe_midsouth_950");
		codeList1.add("roewe_midsouth_e50");
		codeList1.add("roewe_midsouth_w5");
		codeList1.add("roewe_midsouth_360");
	}

	static List<String> codeList2 = new ArrayList<String>();
	static {
		codeList2.add("ROEWE_WAREA_350");
		codeList2.add("ROEWE_WAREA_550");
		codeList2.add("ROEWE_WAREA_750");
		codeList2.add("ROEWE_WAREA_950");
		codeList2.add("ROEWE_WAREA_E50");
		codeList2.add("ROEWE_WAREA_W5");
		codeList2.add("ROEWE_WAREA_360");
	}
	
	static List<String> codeList3 = new ArrayList<String>();
	static {
		codeList3.add("ROEWE_RAREA_350");
		codeList3.add("ROEWE_RAREA_550");
		codeList3.add("ROEWE_RAREA_750");
		codeList3.add("ROEWE_RAREA_950");
		codeList3.add("ROEWE_RAREA_E50");
		codeList3.add("ROEWE_RAREA_W5");
		codeList3.add("ROEWE_RAREA_360");
	}

	@RequestMapping("/south")
	public ModelAndView main(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request) {
		ModelAndView mv = null;
	   boolean isClosedTime = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2016-10-14 23:59:59");
	   if(!isClosedTime){
		   String uId = request.getParameter(RequestConstants.USER_ID);
			String openId = request.getParameter(RequestConstants.OPEN_ID);
			logger.info("request parameters userId = {}, openId = {} ", uId, openId);
			if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
				String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
				autorizationUrl = autorizationUrl.replace("STATE", Authorization.rwsouth.name());
				logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
				logger.debug("授权url : {} ######", autorizationUrl);
				mv = new ModelAndView(autorizationUrl);
			} else {
				mv = new ModelAndView("/oem/rwsouth.ftl");
				mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
			}
			
			// 微信分享JSSDK分享
	        Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
	        mv.addObject("jssdk", map);
			
			// 判断状态
			Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList);
			mv.addObject("codeMap", codeMap);

	   }else{
		   mv = new ModelAndView("redirect:http://www.chexiang.com/");
	   }
		
		return mv;
	}
	
	
	@RequestMapping("/midsouth")
	public ModelAndView index(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request) {
		ModelAndView mv = null;
		 boolean isAfterNow = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-10-14 23:59:59");
		 if (!isAfterNow) {
			 String uId = request.getParameter(RequestConstants.USER_ID);
				String openId = request.getParameter(RequestConstants.OPEN_ID);
				logger.info("request parameters userId = {}, openId = {} ", uId, openId);
				if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
					String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
					autorizationUrl = autorizationUrl.replace("STATE", Authorization.rwmidsouth.name());
					logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
					logger.debug("授权url : {} ######", autorizationUrl);
					mv = new ModelAndView(autorizationUrl);
				} else {
					mv = new ModelAndView("/oem/rwmidsouth.ftl");
					mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
				}
				
				// 微信分享JSSDK分享
		        Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
		        mv.addObject("jssdk", map);
				
				// 判断状态
				Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList1);
				mv.addObject("codeMap", codeMap);
		 }else{
			  mv = new ModelAndView("redirect:http://www.chexiang.com/");
		 }
		
		return mv;
	}
	
	@RequestMapping("/checkImg")
	public GsonView checkImg(@RequestParam(value = "userId", required = false) Long userId,String inputValidCode){
		GsonView gv = new GsonView();
		/** 检查验证码是否输入正确,0--->输入正确,1--->输入错误 */
		int validateCodeErr = 0;

		/** 获取验服务器验证码 */
		String key = VALIDATECODE_REDIS_KEY + "checkCodeWap" + userId;
		String validCode = StringUtils.EMPTY;
		if (redisClient.exists(key,Constants.REDIS_NAME_SPACE)) {
			/** 获取redis缓存的Value,赋值给validCode */
			validCode = redisClient.get(key,Constants.REDIS_NAME_SPACE,null);
			logger.debug("redis中获取到的验证码：key={}, value={}", key, redisClient.get(key,Constants.REDIS_NAME_SPACE,null));
			/** 删除redis缓存验证码 */
			redisClient.del(key,Constants.REDIS_NAME_SPACE);
		}
		if (StringUtils.isBlank(validCode)) {
			validateCodeErr = 1;
			gv.addStaticAttribute("result", validateCodeErr);
			return gv;
		} else if (!inputValidCode.equalsIgnoreCase(validCode)) {
			validateCodeErr = 1;
			gv.addStaticAttribute("result", validateCodeErr);
			return gv;
		}
		return gv;
	}
	
	@RequestMapping("/warea")
	public ModelAndView mainWarea(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request){
		ModelAndView mv =null;
	   boolean isClosedTime = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-10-14 23:59:59");
	   String hiddenEntrance = request.getParameter("HiddenEntrance");
	   if(!isClosedTime || (StringUtils.isNotBlank(hiddenEntrance) && hiddenEntrance.equals("rwoem201511041500"))){
		   String uId = request.getParameter(RequestConstants.USER_ID);
			String openId = request.getParameter(RequestConstants.OPEN_ID);
			logger.info("request parameters userId = {}, openId = {} ", uId, openId);
			if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
				String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
				autorizationUrl = autorizationUrl.replace("STATE", Authorization.warea.name());
				logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
				logger.debug("授权url : {} ######", autorizationUrl);
				mv = new ModelAndView(autorizationUrl);
			} else {
				mv = new ModelAndView("/oem/roweWarea.ftl");
				mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
			}
			
			// 微信分享JSSDK分享
	        Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
	        mv.addObject("jssdk", map);
			
			// 判断状态
			Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList2);
			mv.addObject("codeMap", codeMap);
	   }else{
		   mv = new ModelAndView("redirect:http://www.chexiang.com/");
	   }
		
		return mv;
	}
	
	@RequestMapping("/summer")
	public ModelAndView summer(@RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
	   boolean isClosedTime = ControllerUtil.isTimeLater("yyyy-MM-dd HH:mm:ss","2015-10-14 23:59:59");
	   if(!isClosedTime){
		   String uId = request.getParameter(RequestConstants.USER_ID);
			String openId = request.getParameter(RequestConstants.OPEN_ID);
			logger.info("request parameters userId = {}, openId = {} ", uId, openId);
			if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
				String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
				autorizationUrl = autorizationUrl.replace("STATE", Authorization.rarea.name());
				logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
				logger.debug("授权url : {} ######", autorizationUrl);
				mv = new ModelAndView(autorizationUrl);
			} else {
				mv = new ModelAndView("/oem/rwSummer.ftl");
				mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
			}
			
			// 微信分享JSSDK分享
	        Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
	        mv.addObject("jssdk", map);
			
			// 判断状态
			Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList3);
			mv.addObject("codeMap", codeMap);
	   }else{
		   mv = new ModelAndView("redirect:http://www.chexiang.com/");
	   }
		
		return mv;
	}
	

}
