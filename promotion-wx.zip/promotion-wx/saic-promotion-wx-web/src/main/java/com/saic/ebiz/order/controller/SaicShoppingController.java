/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 * FileName: CheXiangShoppingController.java
 * Author:   Michael He
 * Date:     2014
 * Description: 预订单控制器   
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名                修改时间                版本号                     描述
 */
package com.saic.ebiz.order.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.ibm.framework.uts.util.StringUtils;
import com.ibm.framework.web.gson.GsonView;
import com.ibm.framework.web.validate.ReDistortFormUtil;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.constant.entity.DataItemBean;
import com.saic.ebiz.constant.service.ConstantCodeService;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.entity.authentication.Oauth2Token;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.event.Handler;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.market.util.IpAddressUtil;
import com.saic.ebiz.market.util.UserDeviceUtil;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.ebiz.mdm.partner.client.StoreClient;
import com.saic.ebiz.oms.service.api.IServerOrderService;
import com.saic.ebiz.oms.vo.ServerOrderVO;
import com.saic.ebiz.order.entity.AccessCondition;
import com.saic.ebiz.order.entity.BrandVO;
import com.saic.ebiz.order.entity.CityVO;
import com.saic.ebiz.order.entity.ColorImageVO;
import com.saic.ebiz.order.entity.PreOrderVO;
import com.saic.ebiz.order.entity.PromotionStore;
import com.saic.ebiz.order.entity.ProvinceVO;
import com.saic.ebiz.order.service.SaicOrderService;
import com.saic.ebiz.order.service.SaicShoppingService;
import com.saic.ebiz.order.service.api.PreOrderAddressService;
import com.saic.ebiz.order.service.entity.PreOrder;
import com.saic.ebiz.order.service.entity.PreOrderAdress;
import com.saic.ebiz.order.service.exception.PreOrderQuotaLackException;
import com.saic.ebiz.order.utils.CookieUtil;
import com.saic.ebiz.order.utils.OrderUtil;
import com.saic.ebiz.promotion.service.api.IFollowOrderForMainSiteService;
import com.saic.ebiz.promotion.service.api.IGiftManagerService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.api.IQuotaFacadeService;
import com.saic.ebiz.promotion.service.commons.enums.MarketType;
import com.saic.ebiz.promotion.service.commons.enums.PromotionResultCode;
import com.saic.ebiz.promotion.service.commons.enums.QuotaFunction;
import com.saic.ebiz.promotion.service.commons.enums.VelDisplayType;
import com.saic.ebiz.promotion.service.entity.GiftQuotaEntity;
import com.saic.ebiz.promotion.service.entity.PromotionMerchandiseEntity;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionExtend;
import com.saic.ebiz.promotion.service.vo.PromotionResult;
import com.saic.ebiz.promotion.service.vo.PromotionSubscription;
import com.saic.sso.client.SSOClient;

/**
 * 控制器 ：车享购3期活动
 * 
 * @author Michael He
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/saicOrder")
public class SaicShoppingController implements Handler {
	/** logger. */
	private Logger logger = LoggerFactory.getLogger(SaicShoppingController.class);

	/** 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("weixin-trace");
	
	/** The channel no. 主站91 wap 92 */
	private static final String CHANNEL_NO = "92";
	
	/**The default deposit account*/
	private static final String DEFAULT_DEPOSIT = "0.01";
	
//	private static String GIFT_TEMPLATE = "超值会员礼";
	
	private static final String USER_PRMT_LIMIT = "抱歉，本次活动每用户限购";
	
	private static final String USER_STORE_LIMIT = "抱歉，该经销商本次活动每用户限购";
	
	/** 配额不足. */
	private static final String NO_QUOTA = "NO_QUOTA";
	
	/** & mark */
	private static final String AND_MARK = "&";
	
	/** ? mark */
	private static final String QUESTION_MARK = "?";
	
	/** = mark */
	private static final String EQUALS_MARK = "=";
	
	/** 配额不足. */
	private static final String NO_GIFT = "NO_GIFT";
	
	private final String successFtl = "forward:/pay/prepayorder.htm";
	private final String failedFtl = "/error/errorMsg.ftl";
	private final String pqexceptionFtl = "/error/errorMsg.ftl";
	private final String placeOrderFtl = "/wxorder/saicShopping.ftl";
	private static final String WXLOGIN = "redirect:/account/wxlogin.htm";
	
	/**
	 *  1：电商主站；
	 *	2：车享宝；
	 *	3：营销子站；
	 *	4：保养管家；
	 *	5：第三方联合登陆；
	 *	6：别克联合登陆；
	 *	7：微信服务号；
	 *	8：微信订阅号；
	 *	9：微信红包 
	 *	11：呼叫中心；
	 *	12：平安保险（PC）；
	 *	13：订单系统；
	 *	14：车畅销；
	 *	20：车知道（内部账号）；
	 *	21：别克微信商城；
	 *	22：荣威俱乐部；
	 *	23：crm；
	 *	24：运营平台；
	 *	29：车享购微信服务号；
	 *	31：平安微信；
	 *	35：新浪微博PC；
	 *	36：新浪微博移动；
	 *	60：Other
	 */
	static final String TRACE_SOURCE = "7";
	
	/**
	 * 线索类型
	 *	10.促销车订购
	 *	11.预约试乘试驾
	 *	12在线询价
	 *	13.促销活动
	 *	14.常规车预定
	 *	15.来电咨询
	 *	16在线留言咨询
	 *	17.贷款购车
	 *	18.拉手电话
	 *	20.其他
	 */
	static final String TRACE_TYPE = "10";
	
	// 日志来源 1：订单系统   2：线索
	private static String log_source_one = "1";

	// 订单来源 1：pc 2：wap  3：车享购微信
	private static String order_source_one = "3";

	@Resource(name = "userService")
    private UserService userService;

	/** 车享购服务 */
	@Resource
	private SaicShoppingService saicShoppingService;
	
	@Autowired
	private IPromotionService iPromotionService;

	/** 获取新活动扩展信息 */
	@Resource
	private IPromotionExtendService iPromotionExtendService;

	/** 获取配额新服务 */
    @Autowired
    private IQuotaFacadeService quotaFacadeService;
    
    /** 店铺客户端服务  */
    @Resource
    private StoreClient storeClient;
    
    /** 子站回调接口. */
    @Resource
    private IFollowOrderForMainSiteService iFollowOrderForMainSiteService;
//    
//    /** 礼包地址信息 */
//    @Resource
//    private PreOrderAddressService preOrderAddressService;
    
    @Resource
    private SSOClient ssoClient;
    
	/** 车享订单服务 */
	@Resource
	private SaicOrderService saicOrderService;
	
	/** 车享服务订单服务 */
	@Resource
	private IServerOrderService iServerOrderService;
	
	@Resource
	private IGiftManagerService iGiftManagerService;
	
	@Resource
	private PreOrderAddressService preOrderAddressService;
	
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;

	@Resource
	private BoundingService boundingService;
	
	@Autowired
	private JsSDKSign jsSDKSign;
	
	/**
	 * sit
	 * 	  mgo.sit.chexiang.com
	 * pre
	 * 	  mgo.pre.chexiang.com
	 * pro
	 *    mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;
	
	/**
	 * 微信应用唯一ID
	 * 车享购服务号 wxc2c9c0c1d5115808
	 * 测试账号        wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;

	@ResponseBody
	@RequestMapping("/test")
	public ModelAndView test(){
		return new ModelAndView(placeOrderFtl);
	}
	
	@RequestMapping("/{promotionId}/{brandId}/{seriesId}/{vehicleModelId}/{subscriptionId}/{cityId}/{token}/{userId}")
	public ModelAndView orderFromWx(@PathVariable("promotionId") Long promotionId,
			@PathVariable("brandId") Long brandId,
			@PathVariable("seriesId") Long seriesId,
			@PathVariable("vehicleModelId") Long vehicleModelId,
			@PathVariable("subscriptionId") Long subscriptionId,
			@PathVariable("cityId") Long cityId,
			@PathVariable("token") Long token,
			@PathVariable("userId") Long userId){
		ModelAndView model = null;
		StringBuilder parameters = new StringBuilder("/saicOrder/oauth");
		if(userId == -1){
			parameters.append("/").append(promotionId).append("/")
			.append(brandId).append("/")
			.append(seriesId).append("/")
			.append(vehicleModelId).append("/")
			.append(subscriptionId).append("/")
			.append(cityId).append("/")
			.append(token);
			
			String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + parameters.toString()), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.shopping.name());
			logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
			logger.debug("授权url : {} ######", autorizationUrl);
			model = new ModelAndView(autorizationUrl);
		}else{
			parameters = new StringBuilder("promotionId=");
			parameters.append(promotionId)
			.append("&brandId").append(brandId)
			.append("&seriesId").append(seriesId)
			.append("&vehicleModelId").append(vehicleModelId)
			.append("&subscriptionId").append(subscriptionId)
			.append("&cityId").append(cityId)
			.append("&token").append(token)
			.append("&userId").append(userId);
			model = new ModelAndView("forward:/saicOrder.html?" + parameters.toString());
		}
		return model;
	}
	
	@RequestMapping("/oauth/{promotionId}/{seriesId}/{vehicleModelId}/{subscriptionId}/{cityId}/{cityId}/{token}")
	public ModelAndView oauthFromWx(@PathVariable("promotionId") Long promotionId,
			@PathVariable("brandId") Long brandId,
			@PathVariable("seriesId") Long seriesId,
			@PathVariable("vehicleModelId") Long vehicleModelId,
			@PathVariable("subscriptionId") Long subscriptionId,
			@PathVariable("cityId") Long cityId,
			@PathVariable("token") Long token,HttpServletRequest request){
		ModelAndView model ;
		logger.info("返回的参数 : " + JSONObject.toJSONString(request.getParameterMap()));
		String code = request.getParameter("code");
		String state = request.getParameter("state");
		StringBuffer parameters = new StringBuffer("promotionId=");
		parameters.append(promotionId)
		.append("&brandId=").append(brandId)
		.append("&seriesId=").append(seriesId)
		.append("&vehicleModelId=").append(vehicleModelId)
		.append("&subscriptionId=").append(subscriptionId)
		.append("&cityId=").append(cityId)
		.append("&token=").append(token);
		
		if(StringUtils.isEmpty(state)){
			throw new BaseException("微信未返回state参数。。。");
		}
		
		logger.info("授权返回代码 code : {}, state : {} ", code, state);
		Oauth2Token oauth2Token = authorizationService.getOauth2Token(appId, appSecret, code);
		logger.info("返回Oauth2Token : " + JSONObject.toJSONString(oauth2Token));
		String openId = oauth2Token.getOpenId();
		
		logger.info("AuthorizationController => openId : " + openId);
		List<WebAccountVO> accounts = boundingService.checkBounding(openId);
		boolean isBounding = (accounts != null && accounts.size() > 0);
		// 未绑定则跳到登录页，进行绑定
		if (!isBounding) {
			logger.info("openId {" + openId + "} is not bounded... 跳转登录页面");
			parameters.append("&userId=-1").append(FLAG + state);
			String backUrl = parameters.toString();
			model = new ModelAndView(WXLOGIN + "?"+"fromType=" + Constants.MDM_USER_SAIC_SOURCE + "&openid=" + openId + "&backUrl=" + backUrl);
		}else{
			Long userId = accounts.get(0).getUserId();
			parameters.append("&userId=").append(userId);
			model = new ModelAndView("forward:/saicOrder.htm?" + parameters.toString());
			logger.info("对应关系  openId {} <----> userId {}", openId, userId);
		}
		logger.info("授权返回页面" + model.getViewName());
		return model;
	}
	/**
	 * 
	 * @param promotionId 活动ID
	 * @param brandId	品牌ID 大众 1；斯柯达 2；别克 3；雪佛兰 4；凯迪拉克 5；荣威 6；MG 7；宝骏 8；五菱 9；上汽大通 10
	 * @param seriesId 车系ID	如：科迈罗 51
	 * @param vehicleModelId	车型ID	如：{2012款 雪佛兰科迈罗3.6 V6传奇性能版  : 5410002}
	 * @param subscriptionId	报名ID	与用户手机关联
	 * @param cityId	城市ID	如： 上海	310000
	 * @param token		标记		
	 * @return
	 */
	@RequestMapping
	public ModelAndView preOrderPage(
			@RequestParam(value = "promotionId", required = true) Long promotionId,
			@RequestParam(value = "brandId", required = true) Long brandId,
			@RequestParam(value = "seriesId", required = true) Long seriesId,
			@RequestParam(value = "vehicleModelId", required = false) Long vehicleModelId,
			@RequestParam(value = "subscriptionId", required = true) Long subscriptionId,
			@RequestParam(value = "cityId", required = true) Long cityId,
			@RequestParam(value = "giftId", required = false) String gift,
			@RequestParam(value = "token", required = true) String token,
			@RequestParam(value = "userId", required = true)Long userId,HttpServletRequest request){
		if(userId < 0){
			StringBuffer parameters = new StringBuffer("/saicOrder");
			parameters.append("/").append(promotionId).append("/")
			.append(brandId).append("/")
			.append(seriesId).append("/")
			.append(vehicleModelId).append("/")
			.append(subscriptionId).append("/")
			.append(cityId).append("/")
			.append(token).append("/")
			.append(userId);
			return new ModelAndView("forward:" + parameters.toString());
		}
		String params = buildParams(request);
		ModelAndView model = new ModelAndView(placeOrderFtl);
		//验证url是否有效，跳转到预定页面
		if(OrderUtil.verifyToken(params, token)){
			Promotion promotionInfo = iPromotionService.getPromotion(promotionId);
			//活动异常
			if(promotionInfo == null){
				logger.error("活动 id : {}异常 ",promotionId);
				throw new BaseException("活动获取异常 promotionId = "+promotionId);
			}else{
				//活动类型
				Integer marketType = promotionInfo.getMarketType();
				logger.info("活动类型   marketType = "+ MarketType.fromCode(marketType).display());
				PreOrderVO preOrderVO = buildPreOrderVO(promotionId, brandId,
						seriesId, vehicleModelId, subscriptionId, cityId,
						token, request);
				preOrderVO.setUserId(String.valueOf(userId));
				UserBaseInfoVO memberCentInfoVO = userService.findBaseInfoByUserId(userId);
		    	if (memberCentInfoVO != null) {
		    		// 设置真实名称
		    		preOrderVO.setUserName(memberCentInfoVO.getName());
		    	}
				if(gift != null){
					preOrderVO.setGift(gift);
				}
			    model.addObject("preOrderVO", preOrderVO);
			    model.addObject("modelName", "预定");
			}
			//微信分享JSSDK分享
			Map<String,String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
			model.addObject("jssdk", map);
			return model;
		}else{
			logger.error("token验证失败");
			throw new BaseException("token验证失败");
		}

	}
	
	/**
	 * 
	 * @param request 
	 * @return 返回&符号连接字符串,不包括token
	 */
	String buildParams(HttpServletRequest request){
		//返回 ？后面的字符，比如
		//http://order.chexiang.com/buildorder.htm?promotionId=2720&subscriptionId=70996&cityId=310100&token=bE1Ma1VpbCtIVlNVMiswdlpaclpUdz09
		//返回 promotionId=2720&subscriptionId=70996&cityId=310100&token=bE1Ma1VpbCtIVlNVMiswdlpaclpUdz09
		String queryString = request.getQueryString();
		//Get方式提交表单时getQueryString和getParameter组装参数的效果是一样的
		//如果是Post方式提交，则必须以getParameter方法构建参数
		if(StringUtils.isEmpty(queryString)){
			logger.info("request.getQueryString() 返回为空，通过getParameter方式构建参数");
			StringBuilder builder = new StringBuilder();
			builder.append("promotionId=")
			.append(request.getParameter("promotionId"))
			.append("&subscriptionId=")
			.append(request.getParameter("subscriptionId"))
			.append("&cityId=")
			.append(request.getParameter("cityId"));
			if(StringUtils.hasText(request.getParameter("giftId"))){
				builder.append("&giftId=").append(request.getParameter("giftId"));
			}
			builder.append("&token=")
			.append(request.getParameter("token"));
			queryString = builder.toString();
		}
		this.logger.info("parems value : " + queryString);
		return queryString.substring(0, queryString.lastIndexOf(AND_MARK));
	}
	
	/**
   * @param promotionId  活动ID
   * @param subscriptionId  报名资格ID
   * @param cityId  城市ID，如上海310100
   * @param token   防篡改标记
   * @param req     通用Servlet请求
   * @return     订单对象  @see PreOrderVO
   */
   private PreOrderVO buildPreOrderVO(Long promotionId,Long brandId, Long seriesId,Long vehicleModelId,Long subscriptionId,Long cityId,String token,HttpServletRequest req){
     PreOrderVO preOrderVO = new PreOrderVO();
     //获取报名信息
     PromotionSubscription promotionSubscription = iFollowOrderForMainSiteService.getPromtionSubscriptionById(subscriptionId);
     if (promotionSubscription == null) {
        throw new BaseException("获取promotionSubscription失败 >> subscriptionId="+ subscriptionId);
     }
     //权益
     String benefit = promotionSubscription.getPromotionBenefit();
     benefit = (benefit==null ? "":benefit);
     //设置车享购活动的预定金和权益
     PromotionExtend promotionExtend = this.iPromotionExtendService.findPromotionExtendByPromotionId(promotionId);
     //设置车享购权益
     benefit = getSaicBenefit(benefit);
     if(promotionExtend != null){
    	 this.logger.info("promotion {} 's deposit is {}",promotionId,promotionExtend.getDeposit());
    	 if(promotionExtend.getDeposit() == null){
    		 preOrderVO.setDeposit(DEFAULT_DEPOSIT);
    	 }else{
    		 preOrderVO.setDeposit(promotionExtend.getDeposit().toString());
    	 }
     }else{
    	 this.logger.info("promotion {} promotionExtend is null",promotionId);
    	 preOrderVO.setDeposit(DEFAULT_DEPOSIT);
     }
     // 页面显示信息
     preOrderVO.setPromotionId(promotionId);
     preOrderVO.setBrandId(brandId);
     preOrderVO.setBrandName(this.saicShoppingService.findBrandById(brandId).getVelBrandChsName());
     preOrderVO.setSeriesId(seriesId);
     preOrderVO.setSeriesName(this.saicShoppingService.findSeriesById(seriesId).getVelSeriesChsName());
     if(vehicleModelId != -1){
    	 preOrderVO.setProductId(vehicleModelId.toString());
    	 preOrderVO.setProductName(this.saicShoppingService.findModelById(vehicleModelId).getVelModelName());
     }
     preOrderVO.setSubscriptionId(subscriptionId);
     preOrderVO.setPrmtDesc(benefit);
     
     benefit = new String(Base64.encodeBase64(benefit.getBytes()));
     //设置权益
     preOrderVO.setBenefit(benefit);
     preOrderVO.setTokenCode(token);
     preOrderVO.setUserTel(promotionSubscription.getMobile());
     //因为有SessionFilter，所以从SsoClient一定可以获取userid
     Long uid = this.ssoClient.getLoginStatus(req);
     logger.info("从ssoClient中得到用户userId=" + uid);
     // 得到用户的信息
     if(uid != null && !NumberUtils.LONG_ZERO.equals(uid)){
    	 UserBaseInfoVO memberCentInfoVO = userService.findBaseInfoByUserId(uid);
    	 if (memberCentInfoVO != null) {
    		 // 设置真实名称
    		 preOrderVO.setUserName(memberCentInfoVO.getName());
    	 }
     }

     if(cityId != null && cityId == -1){
         String cookieCityId=CookieUtil.cookie2map(req).get("city.id");
         if(cookieCityId == null){
             cookieCityId = "310100";
         }
    	 cityId = Long.valueOf(cookieCityId);
     }
     
     DataItemBean dataItemBean = ConstantCodeService
          .getRegionInfo(String.valueOf(cityId));
     // 设置用户默认城市和省
     if (dataItemBean != null) {
        preOrderVO.setProvinceId(dataItemBean.getParentCode());
        preOrderVO.setProvinceName(dataItemBean.getParentName());
        preOrderVO.setCityId(dataItemBean.getCode());
        preOrderVO.setCityName(dataItemBean.getName());
     }
     return preOrderVO;
   }
   
   /**
    * 获取车享购模板权益
    * @param benefit 权益
    * @return
    */
   private String getSaicBenefit(String benefit){
     StringBuffer sb = new StringBuffer(benefit);
     //经产品经理确认，不需要加超值会员信息
    /* if(sb.length() == 0){
    	 sb.append(GIFT_TEMPLATE);
     }else{
    	 sb.append("+").append(GIFT_TEMPLATE);
     }*/
     return sb.toString();
   }
   
   /**
	 * 功能描述: 根据活动和车型，获取预订单车型信息列表.<br>
	 * 
	 * @param promotionId 活动
	 *            
	 * @param vehicleModelId 车型
	 *             
	 * @return json
	 * 
	 * 返回样式
	 * 品牌 
	 * 	车系 
	 * 	    车型	
	 * 	       颜色	
	 * -----------------------------
	 * 雪佛兰
	 * 	迈锐宝
	 * 	 2013款 2.4L AT 旗舰版
	 * 	     伯爵黑，罗紫兰
	 * 
	 * @since 从车享购三期开始，一个活动定位多个商品，但是根据需求，活动页会点击具体的商品，无需查询数据库
	 * 
	 * 
	 */
	@RequestMapping("/saic/vehicleModelList")
	public GsonView getVehicleModelList(
			@RequestParam(value = "promotionId", required = true) Long promotionId,
			@RequestParam(value = "brandId", required = false) Long brandId,
			@RequestParam(value = "seriesId", required = false) Long seriesId,
			@RequestParam(value = "vehicleModelId", required = false) Long vehicleModelId) {
		GsonView gson = new GsonView();
		List<BrandVO> brandList = null;
		PromotionExtend promotionExtend = this.iPromotionExtendService.findPromotionExtendByPromotionId(promotionId);
		if(promotionExtend.getVelDisplayType() == null || promotionExtend.getVelDisplayType().equals(VelDisplayType.MODEL.code())){
			brandList = saicShoppingService.getVehicleModelList(promotionId, vehicleModelId);
		}else if(promotionExtend.getVelDisplayType().equals(VelDisplayType.SERIES.code())){
			brandList = saicShoppingService.getListBySeriesId(promotionId,brandId, seriesId);
		}
		// 配额判断
		if (brandList == null || brandList.size() == 0) {
			// 设置为“”，因为js中判断的时候data的长度
			gson.addStaticAttribute("modelList", "");
		} else {
			gson.addStaticAttribute("modelList", brandList);
		}
		return gson;
	}
	
	/**
	 * 功能描述: 根据活动和车型，获取预订单颜色信息列表.<br>
	 * 
	 * @param promotionId 活动
	 * @param vehicleModelId 车型
	 * @return json
	 * 返回样式
	 * 品牌 
	 * 	车系 
	 * 	    车型	
	 * 	       颜色	
	 * -----------------------------
	 * 雪佛兰
	 * 	迈锐宝
	 * 	 2013款 2.4L AT 旗舰版
	 * 	     伯爵黑，罗紫兰
	 * 
	 * @since 从车享购三期开始，一个活动定位多个商品，但是根据需求，活动页会点击具体的商品，无需查询数据库
	 * 
	 * 
	 */
	@RequestMapping("/saic/colorList")
	public GsonView getColorlList(
			@RequestParam(value = "promotionId", required = true) Long promotionId,
			@RequestParam(value = "vehicleModelId", required = false) Long vehicleModelId) {
		GsonView gson = new GsonView();
		List<ColorImageVO> colorList = saicShoppingService.getColorListBySeriesId(promotionId,vehicleModelId);
		// 配额判断
		if (colorList == null || colorList.size() == 0) {
			// 设置为“”，因为js中判断的时候data的长度
			gson.addStaticAttribute("modelList", "");
		} else {
			gson.addStaticAttribute("modelList", colorList);
		}
		return gson;
	}
	   
	/**
	 * 
	 * 功能描述: （车享购订单）动态获取订单预定金额<br>
	 * 			一个活动下面所有的车都是一个定金
	 * @param promotionId 活动ID
	 * @param request
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping("/saic/getDeposit")
	@ResponseBody
	public String getDeposit(
			@RequestParam(value = "promotionId", required = true) Long promotionId,
			HttpServletRequest request) {
		BigDecimal deposit = this.saicShoppingService.getDeposit(promotionId);
		if(deposit != null){
			return deposit.toString();
		}else{
			return DEFAULT_DEPOSIT;
		}
	}

	/**
	 * 
	 * 功能描述: 获取(车享购活动活动)店铺的列表 包括库存和QQ<br>
	 * 〈功能详细描述〉
	 * 
	 * @param promotionId 	活动ID
	 * @param productId		车型ID
	 * @param colorId		颜色ID
	 * @param cityId		城市ID
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping("/saic/getDealerStoreList")
	public GsonView getDealerStoreList(
			@RequestParam(value = "promotionId" , required=true) Long promotionId,
			@RequestParam(value = "vehicleModelId" , required=true) Long vehicleModelId,
			@RequestParam(value = "colorId" , required=true) Long colorId,
			@RequestParam(value = "cityId" , required=true) Long cityId) {
		GsonView gson = new GsonView();
		this.logger.info("-=-=-=-=活动ID : {},车型ID : {},颜色ID : {}, 城市ID : {} -=-=-=-=- ", promotionId,vehicleModelId,colorId,cityId);
		List<PromotionStore> storeList = this.saicShoppingService.getDealerStoreList(promotionId, vehicleModelId, colorId, cityId);
		Promotion promotion = this.iPromotionService.getPromotion(promotionId);
		if(promotion != null){
			Integer quotaMode = promotion.getQuotaMode();
			//全局配额模式1，车系库存限额设置到车系3或者车型7 ，在前台不显示配额
			if(quotaMode == 1 || quotaMode == 3 || quotaMode == 7){
				gson.addStaticAttribute("displayStock", false);
			}else{
				gson.addStaticAttribute("displayStock", true);
			}
		}
		gson.addStaticAttribute("storeList", storeList);
		return gson;
	}

	/**
	 * 功能描述: 提交订单.<br>
	 * 
	 * @param preOrderVO
	 * @param backURL 
	 * @param result
	 * @param request
	 * @return 调到支付页面
	 * 
	 */
	@RequestMapping("/order/submitSaicShopping")
	public ModelAndView submitSaicShoppingOrder(@ModelAttribute("preOrderVO") @Valid PreOrderVO preOrderVO,@RequestParam("backURL") String backURL,
			BindingResult result, HttpServletRequest request) {
		logger.info("PreOrderVO {}",JSONObject.toJSON(preOrderVO));
		logger.info("backURL : {}",backURL);
		ModelAndView model = null;
		// true表示表单被篡改
		boolean isDistorToken = ReDistortFormUtil.isDistorToken(request);
		// 表单被篡改，调到失败页面
		if (isDistorToken) {
			logger.info("SaicShoppingController->submitSaicShoppingOrder():订单表单被篡改，跳转失败页面");
			model = new ModelAndView(pqexceptionFtl);
			model.addObject("modelName", "提交失败").addObject("errorMessage", "表单篡改");
			return model;
		}
		//前置检查用户是否可以参加该活动和该经销商的活动TBD
		AccessCondition accessCondition = preOrderConditionCheck(preOrderVO.getPromotionId(), preOrderVO.getUserTel(), preOrderVO.getStoreId());
		if(accessCondition.isUserLimit() || accessCondition.isUserStoreLimit()){
			model = new ModelAndView(pqexceptionFtl);
			String content = "";
			if(accessCondition.isUserLimit()){
				content = USER_PRMT_LIMIT + accessCondition.getUser_prmt_limit_num();
			}else if(accessCondition.isUserStoreLimit()){
				content = USER_STORE_LIMIT + accessCondition.getUser_store_limit_num();
			}
			model.addObject("modelName", "提交失败").addObject("errorMessage", content + "次");
			return model;
		}
		
		// 表单后台验证失败
		if (result.hasErrors()) {
			logger.info("SaicShoppingController->submitSaicShoppingOrder():订单表单后台验证失败");
			model = new ModelAndView(placeOrderFtl);
			model.addObject("preOrderVO", preOrderVO).addObject("modelName", "预订");
			// 验证成功
		} else {
			logger.info("SaicShoppingController->submitSaicShoppingOrder():订单后台验证成功");
			if(StringUtils.isEmpty(preOrderVO.getUserId())){
				throw new BaseException("unkown user!!!");
			}
			Long userId = Long.valueOf(preOrderVO.getUserId());
			UserBaseInfoVO memberCentInfoVO = userService.findBaseInfoByUserId(userId);
			if(memberCentInfoVO != null){
				preOrderVO.setEmail(memberCentInfoVO.getEmail());
			}
			// 获取商品信息
			Long promotionId = preOrderVO.getPromotionId();
			//车型ID
			String productId = preOrderVO.getProductId();
			String colorId = preOrderVO.getColorId();
			//经销商
			Long storeId = preOrderVO.getStoreId();
			//商品信息
			PromotionMerchandiseEntity promotionMerchandise = this.quotaFacadeService.findAvailableNumByPreOrderConditions(promotionId, Long.valueOf(productId), Long.valueOf(colorId), storeId);
			//对查询结果的判断
			if(promotionMerchandise == null || promotionMerchandise.getAvailableNum() < 1){
				logger.info("this.quotaFacadeService.findAvailableNumByPreOrderConditions() 返回空或者配额为0 ");
				model = new ModelAndView(pqexceptionFtl);
				model.addObject("modelName", "提交失败").addObject("errorMessage",
						"<span style='font-size:22px;font-family:\"Microsoft Yahei\"'>对不起，名额已被抢光，请关注车享网的其他活动</span>");
				return model;
			}
			logger.info("orderService.getPromotionMerchandise 返回" + JSONObject.toJSONString(promotionMerchandise));
			// 预订单信息 存储预订单信息
			PreOrder preOrder = new PreOrder();
			Integer merchandiseId = null;
			if(promotionMerchandise.getMerchandiseId() != null){
				merchandiseId = promotionMerchandise.getMerchandiseId().intValue();
			}
			preOrder.setMerchandiseId(merchandiseId);// 商品id
			preOrder.setPrmtMdseId(promotionMerchandise.getPrmtMdseId().intValue());// 促销商品id
			if(promotionMerchandise.getDealerId() == null){
				preOrder.setDealerId(this.storeClient.findStoreDetailByStoreId(storeId).getDealerId().intValue());
			}else{
				preOrder.setDealerId(promotionMerchandise.getDealerId().intValue());// 经销商id
			}
			// 从商品视图获取活动商品意向金
			BigDecimal deposit = this.saicShoppingService.getDeposit(promotionId);
			if (deposit == null) {
				logger.info("SaicShoppingController->submitSaicShoppingOrder():validate deposit");
				deposit = BigDecimal.valueOf(0.01);
//				throw new BaseException("意向金为空,提交失败!");
			}
			preOrder.setDeposit(deposit);//预定金
			//线索日志：
			Cookie[] cookies = request.getCookies();
			String userTraceCookie = "";
			for (Cookie cookie : cookies) {
				String name = cookie.getName();
				if ("user_trace_cookie".equals(name)) {
					userTraceCookie = cookie.getValue();
					break; 
				}
			}
			// 获取订单编号
			
			String orderCode = placeOrder(preOrderVO, preOrder, userId,userTraceCookie,request);
			model = orderPostProcess(orderCode,userId,request);
		}
		return model;
	}

	/**
	 * 功能描述: 创建订单.<br>
	 * @param preOrderVO
	 * @param preOrder
	 * @param userId
	 * @param userTraceCookie
	 * @return
	 */
	private String placeOrder(PreOrderVO preOrderVO, PreOrder preOrder,
			Long userId, String userTraceCookie, HttpServletRequest request) {
		logger.info("订单创建开始", "preOrderVO>>" + JSONObject.toJSONString(preOrderVO));
		Promotion promotion = iPromotionService.getPromotion(preOrderVO.getPromotionId());
		String promotionCode = promotion.getPromotionCode();
		logger.info("活动编码:>>" + promotionCode);
		// true表示锁定礼包信息配额成功
		if((promotionCode.startsWith("Xiuqiu328_b") || promotionCode.startsWith("C518_3")|| promotionCode.startsWith("c518_3")) && preOrderVO.getGift() != null && preOrderVO.getGift().trim().length() > 0){
			boolean isCheck = iGiftManagerService.changeQuota(Integer.valueOf(preOrderVO.getGift()),QuotaFunction.LOCK);
			// 礼包信息配额锁定失败，调到失败页面
			if (!isCheck) {
				logger.info("SaicShoppingController->submitSaicShoppingOrder():礼包信息锁定失败，跳转失败页面");
				return NO_GIFT;
			}
		}
		// 设置订单信息
		preOrder.setChannelNo(CHANNEL_NO);// 渠道编号
		preOrder.setPrmtActId(Integer.valueOf(preOrderVO.getPromotionId().toString()));// 促销活动编号
		preOrder.setStoreId(Integer.valueOf(preOrderVO.getStoreId().toString()));// 店铺id
		preOrder.setBrandId(preOrderVO.getBrandId());// 品牌id
		preOrder.setVelSeriesId(preOrderVO.getSeriesId());// 车系id
		preOrder.setVelModelId(Long.valueOf(preOrderVO.getProductId()));// 车型id
		preOrder.setColorId(Long.valueOf(preOrderVO.getColorId()));// 车型颜色id
		preOrder.setAmount(1);// 预订数量
		// Y:表示选择 N：表示未选择
		preOrder.setLoanFlag(preOrderVO.getLoanFlag());
		preOrder.setNeedInsuranceFlag(preOrderVO.getNeedInsuranceFlag());
		preOrder.setRegisterLicenceFlag(preOrderVO.getRegisterLicenceFlag());
		// 会员信息
		preOrder.setUserId(Long.valueOf(preOrderVO.getUserId()));
		preOrder.setUserName(preOrderVO.getUserName());
		preOrder.setMobileNo(preOrderVO.getUserTel());
		preOrder.setEmail(preOrderVO.getEmail());
		// 促销说明
		String prmtDesc = new String(Base64.decodeBase64(preOrderVO.getBenefit()));
		if ((promotionCode.startsWith("Xiuqiu328_b") || promotionCode.startsWith("C518_3")|| promotionCode.startsWith("c518_3")) && preOrderVO.getGift() != null && preOrderVO.getGift().trim().length() > 0) {
			List<GiftQuotaEntity> giftList = null;
			int[] giftSource = new int[]{1,2,3,4};
			for (int i = 0; i < giftSource.length; i++) {
				giftList = iGiftManagerService.queryGifts(giftSource[i]);
				if (giftList != null) {
					for (int j = 0; j < giftList.size(); j++) {
						if (preOrderVO.getGift().equals(giftList.get(j).getGiftId().toString())) {
							if (prmtDesc != null && prmtDesc.trim().length() > 0) {
								preOrder.setPrmtDesc(prmtDesc + " + " + giftList.get(j).getGiftName());
							} else {
								preOrder.setPrmtDesc(giftList.get(j).getGiftName());
							}
							break;
						}
					}
				}
			}
			
			/*giftList = iGiftManagerService.queryGifts(2);
			if (giftList != null) {
				for (int i = 0; i < giftList.size(); i++) {
					if (preOrderVO.getGift().equals(giftList.get(i).getGiftId().toString())) {
						if (prmtDesc != null && prmtDesc.trim().length() > 0) {
							preOrder.setPrmtDesc(prmtDesc + " + " + giftList.get(i).getGiftName());
						} else {
							preOrder.setPrmtDesc(giftList.get(i).getGiftName());
						}
						break;
					}
				}
			}*/
		} else {
			preOrder.setPrmtDesc(prmtDesc);
		}
//		preOrder.setPrmtDesc(prmtDesc);
		preOrder.setRemarkDesc(prmtDesc);
		preOrder.setDealerPresent(prmtDesc);
		String brandName = this.saicShoppingService.findBrandById(preOrderVO.getBrandId()).getVelBrandChsName();
		String seriesName = this.saicShoppingService.findSeriesById(preOrderVO.getSeriesId()).getVelSeriesChsName();
		String modelName = this.saicShoppingService.findModelById(Long.valueOf(preOrderVO.getProductId())).getVelModelName();
		preOrder.setPrmtMdseName(brandName+seriesName+modelName);
		logger.info("create order bean：" + JSONObject.toJSONString(preOrder));
		String orderCode = null;
		try {
			orderCode = saicOrderService.createPreOrder(preOrder, preOrderVO.getSubscriptionId());
			logger.info("调用订单接口成功，生成订单编号：" + orderCode);
			// 订单创建成功
			if (orderCode != null && !"-1".equals(orderCode)) {
				PreOrderAdress preOrderAdress = new PreOrderAdress();
				preOrderAdress.setUserId(userId);
				//礼品邮寄地址
				preOrderAdress.setAddress(preOrderVO.getReceiveAddress());
				preOrderAdress.setMobile(preOrderVO.getUserTel());
				preOrderAdress.setConsignee(preOrderVO.getUserName());
				if(!StringUtils.isEmpty(preOrderVO.getAddressProvince())){
					preOrderAdress.setProvince(Integer.valueOf(preOrderVO.getAddressProvince()));
				}
				if(!StringUtils.isEmpty(preOrderVO.getAddressCity())){
					preOrderAdress.setCity(Integer.valueOf(preOrderVO.getAddressCity()));
				}
				if(!StringUtils.isEmpty(preOrderVO.getAddressArea())){
					preOrderAdress.setTown(Integer.valueOf(preOrderVO.getAddressArea()));
				}
				preOrderAdress.setZipcode(preOrderVO.getZipCode());
				//设置订单id
				preOrderAdress.setPreOrderId(orderCode);
				preOrderAdress.setCreateTime(new Date());
				preOrderAdress.setConsignee(preOrderVO.getUserName());
				logger.info("call preOrderAddressService.bindAddress PreOrderAdress : [{}] ", JSONObject.toJSONString(preOrderAdress));
				boolean bindStatus = this.preOrderAddressService.creatPreOrderAddress(preOrderAdress);
				if(bindStatus){
					logger.info("生成地址成功(ˇˍˇ） 想～");
				}else{
					logger.error("生成地址失败%>_<%");
				}
				usertraceLogger.info(log_source_one + "\t" + order_source_one + "\t" + userTraceCookie + "\t" + userId + "\t" + orderCode + "\t下单成功\t" + 
						preOrderVO.getBrandId() + "\t" + preOrderVO.getSeriesId() + "\t" + preOrderVO.getStoreId() + "\t" + preOrderVO.getUserName() + "\t" + 
						preOrderVO.getUserTel() + "\t" + preOrderVO.getPromotionId()+"\t"+ IpAddressUtil.parseIpAddr(request) + "\t" + UserDeviceUtil.getDeviceType(request.getHeader("user-agent")));
//				usertraceLogger.info("微信端创建订单\t" + userTraceCookie + "\t"
//						+ userId + "\t" + "创建成功" + "\t" + orderCode +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
				logger.info("开始回调营销子站接口");
				if((promotionCode.startsWith("Xiuqiu328_b") || promotionCode.startsWith("C518_3")|| promotionCode.startsWith("c518_3")) && preOrderVO.getGift() != null && preOrderVO.getGift().trim().length() > 0){
					//创建服务订单
					ServerOrderVO serverOrder = new ServerOrderVO();
					serverOrder.setGiftId(preOrderVO.getGift());
					serverOrder.setOrderId(orderCode);
					serverOrder.setMobile(preOrderVO.getUserTel());
					serverOrder.setAddress(preOrderVO.getReceiveAddress());
					serverOrder.setConsignee(preOrderVO.getUserName());
					if(!StringUtils.isEmpty(preOrderVO.getAddressProvince())){
						serverOrder.setProvince(Integer.valueOf(preOrderVO.getAddressProvince()));
					}
					if(!StringUtils.isEmpty(preOrderVO.getAddressCity())){
						serverOrder.setCity(Integer.valueOf(preOrderVO.getAddressCity()));
					}
					if(!StringUtils.isEmpty(preOrderVO.getAddressArea())){
						serverOrder.setDistrict(Integer.valueOf(preOrderVO.getAddressArea()));
					}
					serverOrder.setZipCode(preOrderVO.getZipCode());
					//后续调用withGift接口
					List<GiftQuotaEntity> giftList = null;
					int[] giftSource = new int[]{1,2,3,4};
					for (int i = 0; i < giftSource.length; i++) {
						giftList = iGiftManagerService.queryGifts(giftSource[i]);
						if(giftList != null){
							for (int j = 0; j < giftList.size(); j++) {
								if(preOrderVO.getGift().equals(giftList.get(j).getGiftId().toString())){
									serverOrder.setGiftDescription(giftList.get(j).getGiftName());
									break;
								}
							}
						}
					}
					
					/*giftList = iGiftManagerService.queryGifts(2);
					if(giftList != null){
						for (int i = 0; i < giftList.size(); i++) {
							if(preOrderVO.getGift().equals(giftList.get(i).getGiftId().toString())){
								serverOrder.setGiftDescription(giftList.get(i).getGiftName());
								break;
							}
						}
					}*/
					Long serverId = iServerOrderService.createServierOrder(serverOrder);
					if(serverId != null){
						iFollowOrderForMainSiteService.createFollowOrderWithGift(Long.valueOf(preOrderVO.getUserId()),
								preOrderVO.getSubscriptionId(), orderCode,Long.valueOf(preOrder.getPrmtMdseId()),Long.valueOf(preOrderVO.getGift()));
					} else{
						// 328活动创建订单失败解锁礼包配额
						if (promotionCode != null && (promotionCode.startsWith("Xiuqiu328_b") || promotionCode.startsWith("C518_3")|| promotionCode.startsWith("c518_3")) && preOrderVO.getGift() != null && preOrderVO.getGift().trim().length() > 0) {
							boolean isCheck = iGiftManagerService.changeQuota(Integer.valueOf(preOrderVO.getGift()), QuotaFunction.UNLOCK);
							if (isCheck) {
								logger.info("订单生成失败，解锁礼包信息成功！！！");
							} else {
								logger.error("订单生成失败，解锁礼包信息失败！！！");
							}
						}
						throw new BaseException("创建createServierOrder");
					}
				}else{
					iFollowOrderForMainSiteService.createFollowOrder(Long.valueOf(preOrderVO.getUserId()),
							preOrderVO.getSubscriptionId(), orderCode,Long.valueOf(preOrder.getPrmtMdseId()));
				}
				logger.info("回调营销子站接口结束");
				//礼包地址信息
//				PreOrderAdress poa = new PreOrderAdress();
//				if(preOrderVO.getAddressArea()!=null && preOrderVO.getAddressArea()!="-1"){
//					poa.setTown(Integer.parseInt(preOrderVO.getAddressArea()));
//				}
//				if(preOrderVO.getAddressCity()!=null && preOrderVO.getAddressCity()!="-1"){
//					poa.setCity(Integer.parseInt(preOrderVO.getAddressCity()));
//				}
//				if(preOrderVO.getAddressProvince()!=null && preOrderVO.getAddressProvince()!="-1"){
//					poa.setProvince(Integer.parseInt(preOrderVO.getAddressProvince()));
//				}
//				poa.setAddress(preOrderVO.getReceiveAddress());
//				poa.setZipcode(preOrderVO.getZipCode());
//				poa.setPreOrderId(orderCode);
//				boolean isbuild = preOrderAddressService.bindAddress(poa);
//				if(isbuild){
//					logger.info("添加礼包地址信息成功！");
//				}else{
//					logger.info("添加礼包地址信息失败！");
//				}
			} else {   
				//328活动创建订单失败解锁礼包配额
				if((promotionCode.startsWith("Xiuqiu328_b") || promotionCode.startsWith("C518_3")|| promotionCode.startsWith("c518_3")) && preOrderVO.getGift() != null && preOrderVO.getGift().trim().length() > 0){
					boolean isCheck = iGiftManagerService.changeQuota(Integer.valueOf(preOrderVO.getGift()),QuotaFunction.UNLOCK);
					if(isCheck){
						logger.info("订单生成失败，解锁礼包信息成功！！！");
					}else{
						logger.error("订单生成失败，解锁礼包信息失败！！！");
					}
				}
				// 订单创建失败:
				usertraceLogger.info(log_source_one + "\t" + order_source_one + "\t" + userTraceCookie + "\t" + userId + "\t" 
						+ orderCode + "\t下单失败\t" + preOrderVO.getBrandId() + "\t" + preOrderVO.getSeriesId() + "\t" + preOrderVO.getStoreId() 
						+ "\t" + preOrderVO.getUserName() + "\t" + preOrderVO.getUserTel() + "\t" + preOrderVO.getPromotionId()+"\t"+ IpAddressUtil.parseIpAddr(request) + "\t" + UserDeviceUtil.getDeviceType(request.getHeader("user-agent")));
//				usertraceLogger.info("微信端创建订单\t" + userTraceCookie + "\t"
//						+ userId + "\t" + "创建失败(其他)" + "\t" + orderCode +  "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
			}
		} catch (PreOrderQuotaLackException e) {
			logger.info("配额不足", e);
			usertraceLogger.info(log_source_one + "\t" + order_source_one + "\t" + userTraceCookie + "\t" + userId + "\t" 
					+ orderCode + "\t下单失败\t" + preOrderVO.getBrandId() + "\t" + preOrderVO.getSeriesId() + "\t" + preOrderVO.getStoreId() 
					+ "\t" + preOrderVO.getUserName() + "\t" + preOrderVO.getUserTel() + "\t" + preOrderVO.getPromotionId()+"\t"+ IpAddressUtil.parseIpAddr(request) + "\t" + UserDeviceUtil.getDeviceType(request.getHeader("user-agent")));
//			usertraceLogger.info("微信端创建订单\t" + userTraceCookie + "\t" + userId
//					+ "\t" + "创建失败(配额不足)" + "\t" + orderCode + "\t" + TRACE_SOURCE+ "\t" + TRACE_TYPE);
			return NO_QUOTA;
		}
		return orderCode;
	}
	
	/**
	 * 下单订单后，处理下单的状态，下单失败、重复下单等操作对应不同页面
	 * 
	 * @param model View Object
	 * @param orderCode 订单号
	 * @param request	
	 * 
	 */
	private ModelAndView orderPostProcess(String orderCode,Long userId, HttpServletRequest request){
		ModelAndView model = null;
		// 订单生成失败
		if (orderCode == null) {
			logger.info("SaicShoppingController->orderPostProcess():订单生成失败");
			model = new ModelAndView(failedFtl);
			model.addObject("modelName", "提交失败");
			// 配额没有了
		} else if (NO_QUOTA.equals(orderCode)) {
			logger.info("SaicShoppingController->orderPostProcess(): 配额没有了 ");
			model = new ModelAndView(pqexceptionFtl);
			model.addObject("modelName", "提交失败");
			model.addObject( "errorMessage", "对不起，名额已被抢光，请关注车享网的其他活动");
			// 订单已经存在
		} else if ("-1".equals(orderCode)) {
			logger.info("SaicShoppingController->orderPostProcess():订单已经存在 ");
			model = new ModelAndView(pqexceptionFtl);
			model.addObject("modelName", "提交失败").addObject("returnPage", "myAllOrders").addObject("errorMessage", "该活动您已下单");
			// 订单生成成功
		} else if (NO_GIFT.equals(orderCode)) {
			logger.info("SaicShoppingController->orderPostProcess(): 礼包锁定失败 ");
			model = new ModelAndView(pqexceptionFtl);
			model.addObject("modelName", "提交失败");
			model.addObject( "errorMessage", "对不起，您选择的礼包已被抢光，请重新选择礼包");
			// 订单已经存在
		} else {
			logger.info("SaicShoppingController->orderPostProcess() 订单{}生成成功", orderCode);
			StringBuffer buffer = new StringBuffer(QUESTION_MARK);
			buffer.append(RequestConstants.ORDER_ID).append(EQUALS_MARK)
			.append(orderCode).append(AND_MARK)
			.append(RequestConstants.USER_ID).append(EQUALS_MARK).append(userId);
			
			model = new ModelAndView(successFtl + buffer.toString());
		}
		return model;
	}
	
	/**
	 * @param promotionId
	 * @param showProvince TRUE显示省份和城市列表 ,FALSE在预订单页只显示城市
	 * @return
	 */
	@RequestMapping("/province/city")
    @ResponseBody
	public GsonView getProvinceCityByPromotionId(@RequestParam(value = "promotionId" , required=true) Long promotionId,
			@RequestParam(value = "vehicleModelId" , required=true) Long vehicleModelId,
			@RequestParam(value = "colorId" , required=true) Long colorId,
			@RequestParam(value = "showProvince" , required=false) Boolean showProvince){
		GsonView gv = new GsonView();
		if(showProvince == null || Boolean.FALSE.equals(showProvince)){
			List<CityVO> cityVO = this.saicShoppingService.getCityOnly(promotionId,vehicleModelId,colorId);
			gv.addStaticAttribute("cityVO", cityVO);
		}else{
			showProvince = Boolean.TRUE;
			List<ProvinceVO> provinceCity = this.saicShoppingService.getProvinceVOByPromotionId(promotionId,vehicleModelId, showProvince,colorId);
			gv.addStaticAttribute("provinceCity", provinceCity);
		}
		
		return gv;
	}
	
	@RequestMapping("/checkAccessCondition")
    public GsonView checkAccessCondition(@RequestParam(value = "promotionId" , required=true) Long promotionId,
			@RequestParam(value = "mobile" , required=true) String mobile,
			@RequestParam(value = "storeId" , required=true) Long storeId){
		GsonView gv = new GsonView();
		AccessCondition condition = preOrderConditionCheck(promotionId,mobile,storeId);
		gv.addStaticAttribute("condition", condition);
		return gv;
	}
	
	private AccessCondition preOrderConditionCheck(Long promotionId,String mobile,Long storeId){
		AccessCondition condition = new AccessCondition();
		PromotionExtend promotionExtend = this.iPromotionExtendService.findPromotionExtendByPromotionId(promotionId);
		PromotionResult promotionResult = this.iPromotionService.getAccessCondition(promotionId, mobile);
		if(!(PromotionResultCode.SUCCESS.getValue() == promotionResult.getResultCode() || PromotionResultCode.HAS_SUBSCRIBE.getValue() == promotionResult.getResultCode())){
			condition.setUserLimit(true);
			condition.setUser_prmt_limit_num(promotionExtend.getUserPrmtLimit().intValue());
		}else{
			promotionResult = this.iPromotionService.getAccessConditionForDealer(promotionId, mobile, storeId);
			if(PromotionResultCode.SUCCESS.getValue() != promotionResult.getResultCode()){
				condition.setUserStoreLimit(true);
				condition.setUser_store_limit_num(promotionExtend.getUserStoreLimit().intValue());
			}
		}
		return condition;
	}
}
