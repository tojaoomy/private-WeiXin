package com.saic.ebiz.pmt.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.exception.BaseException;
import com.meidusa.fastjson.JSONObject;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.entity.authentication.Oauth2Token;
import com.saic.ebiz.market.common.entity.authentication.SNSUserInfo;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.common.util.ImageUtil;
import com.saic.ebiz.market.common.util.SHA1Util;
import com.saic.ebiz.market.event.AuthorizationHandler;
import com.saic.ebiz.market.oneyear.service.AccessTokenService;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.BoundingService;
import com.saic.ebiz.mdm.entity.WebAccountVO;
import com.saic.ebiz.promotion.service.api.IWxService;

/**
 * 微信授权
 * @author liqiaoyan
 * @date 2015.07.01 21:53
 */
@Controller
@RequestMapping("/accredit")
public class AccreditPromotionController {
	// 授权日志
	private Logger logger = LoggerFactory.getLogger(AccreditPromotionController.class);
	
	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;
	
	/**
	 * 微信服务
	 */
	@Resource
	private IWxService iWxService;
	
	/**
	 * 图片
	 */
	@Resource
	private ImageUtil imageUtil;
	
	/**
	 * 登录、注册
	 */
	@Resource
	private AuthorizationHandler authorizationHandler;
	
    /**
     * 微信权限信息   
     */
    @Resource
    private AccessTokenService accessTokenService;
	
	/**
	 * 用户绑定
	 */
	@Resource
	private BoundingService boundingService;
	
	@Value("${ebiz.wap.web.domain:}")
	private String domain;
	
	@Value("${ebiz.wap.web.appSecret:}")
	private String appSecret;
	
	private static final String INDEX = "/index.htm";
	/**
	 * 组团半价车url
	 */
	private static final String GROUP_HAIFPRICE_CAR = "redirect:http://www.jiahaisc.com/halfprice/callback2.php?";
	/**
	 * 定制T恤url
	 */
	private static final String T_SHIRT_URL=  "redirect:http://www.yourtee.cn/yourteeflip/act/20150708/index.php?id=10&from=singlemessage&isappinstalled=0?";
	/**
	 * 聚合页url
	 */
	private static final String PROMOTION_MAIN_URL =  "redirect:http://mc.autoshow-sh.com?";
	
	private static final String GAME_URL_04 =  "redirect:http://baidu.com";
	
	private static final String WXLOGIN = "redirect:/account/wxlogin.htm";

	/**
	 * 微信应用appID
	 * 车享购服务号  wxc2c9c0c1d5115808
	 * 测试账号    wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@RequestMapping("/getAccreditMsg")
	public ModelAndView accredit(HttpServletRequest request ) {
		ModelAndView model = null;
		logger.info("lqy--AccreditPromotionController--accredit--返回的参数 : " + JSONObject.toJSONString(request.getParameterMap()));
		String code = request.getParameter("code");
		String state = request.getParameter("state");
		String backUrl = INDEX;
		
		if(StringUtils.isBlank(state)){
			throw new BaseException("微信未返回state参数。。。");
		}
		
		if(StringUtils.isNotBlank(state)){
			backUrl = authorizationHandler.buildBackUrl(request);
		}
		
		logger.info("lqy--AccreditPromotionController--accredit--授权返回代码 code : {}, state : {} ", code, state);
		Oauth2Token oauth2Token = authorizationService.getOauth2Token(appId, appSecret, code);
		logger.info("lqy--AccreditPromotionController--accredit--返回Oauth2Token : " + JSONObject.toJSONString(oauth2Token));
		String openId = oauth2Token.getOpenId();
		logger.info("lqy--AccreditPromotionController--accredit--AuthorizationController => openId : " + openId);
		SNSUserInfo snsUserInfo = this.authorizationService.getUserInfo(oauth2Token.getAccessToken(), oauth2Token.getOpenId());
		logger.info("lqy--AccreditPromotionController--accredit--微信User Info授权 SNSUserInfo : " + JSONObject.toJSONString(snsUserInfo));
		List<WebAccountVO> accounts = boundingService.checkBounding(openId);
		//组团半价车活动
		if(state.startsWith(Authorization.groupHaifPriceCar.name())){
			logger.info("lqy--AccreditPromotionController--accredit--活动： "+Authorization.groupHaifPriceCar.name());
			String userNickName = snsUserInfo.getNickname();
			String userHeadImg = snsUserInfo.getHeadimgurl();
			long time = new Date().getTime();
			StringBuilder builder = new StringBuilder("openId=");
			builder.append(openId).append("&userNickName=")
			.append(Base64.encodeBase64String(userNickName.getBytes())).append("&userHeadImg=")
			.append(userHeadImg).append("&state=")
			.append(state).append("&time=")
			.append(time);
			String sign = new SHA1Util().getDigestOfString(builder.toString().getBytes());
			builder.append("&sign=").append(sign);
			logger.info("lqy--AccreditPromotionController--accredit--传参builder : " + builder);
			String url=GROUP_HAIFPRICE_CAR + builder.toString();
			logger.info("lqy--AccreditPromotionController--accredit--组团半价车回调URL ： " + url);
			return new ModelAndView(url);
		}else if(state.startsWith(Authorization.tShirtPomt.name())){
			logger.info("lqy--AccreditPromotionController--accredit--定制T恤活动： "+Authorization.tShirtPomt.name());
			String userNickName = snsUserInfo.getNickname();
			String userHeadImg = snsUserInfo.getHeadimgurl();
			long time = new Date().getTime();
			StringBuilder builder = new StringBuilder("openId=");
			builder.append(openId).append("&userNickName=")
			.append(Base64.encodeBase64String(userNickName.getBytes())).append("&userHeadImg=")
			.append(userHeadImg).append("&state=")
			.append(state).append("&time=")
			.append(time);
			String sign = new SHA1Util().getDigestOfString(builder.toString().getBytes());
			builder.append("&sign=").append(sign);
			logger.info("lqy--AccreditPromotionController--accredit--传参builder : " + builder);
			String url=T_SHIRT_URL + builder.toString();
			logger.info("lqy--AccreditPromotionController--accredit--定制T恤授权回调URL ： " + url);
			return new ModelAndView(url);
		}else if(state.startsWith(Authorization.promotionMain.name())){
			logger.info("lqy--AccreditPromotionController--accredit--聚合页： "+Authorization.promotionMain.name());
			String userNickName = snsUserInfo.getNickname();
			String userHeadImg = snsUserInfo.getHeadimgurl();
			long time = new Date().getTime();
			StringBuilder builder = new StringBuilder("openId=");
			builder.append(openId).append("&userNickName=")
			.append(Base64.encodeBase64String(userNickName.getBytes())).append("&userHeadImg=")
			.append(userHeadImg).append("&state=")
			.append(state).append("&time=")
			.append(time);
			String sign = new SHA1Util().getDigestOfString(builder.toString().getBytes());
			builder.append("&sign=").append(sign);
			logger.info("lqy--AccreditPromotionController--accredit--传参builder : " + builder);
			String url=PROMOTION_MAIN_URL + builder.toString();
			logger.info("lqy--AccreditPromotionController--accredit--聚合页授权回调URL ： " + url);
			return new ModelAndView(url);
		}else if(state.startsWith(Authorization.customization_04.name())){
			logger.info("lqy--AccreditPromotionController--accredit--活动： "+Authorization.customization_04.name());
			String userNickName = snsUserInfo.getNickname();
			String userHeadImg = snsUserInfo.getHeadimgurl();
			long time = new Date().getTime();
			StringBuilder builder = new StringBuilder("openId=");
			builder.append(openId).append("&userNickName=")
			.append(Base64.encodeBase64String(userNickName.getBytes())).append("&userHeadImg=")
			.append(userHeadImg).append("&state=")
			.append(state).append("&time=")
			.append(time);
			String sign = new SHA1Util().getDigestOfString(builder.toString().getBytes());
			builder.append("&sign=").append(sign);
			logger.info("lqy--AccreditPromotionController--accredit--传参builder : " + builder);
			String url=GAME_URL_04 + builder.toString();
			logger.info("lqy--AccreditPromotionController--accredit--游戏授权回调URL ： " + url);
			return new ModelAndView(url);
		}
		//
		boolean isBounding = (accounts != null && accounts.size() > 0);
		// 未绑定则跳到登录页，进行绑定
		if (!isBounding) {
			logger.info("lqy--AccreditPromotionController--accredit--openId {" + openId + "} is not bounded... 跳转登录页面");
			model = new ModelAndView(WXLOGIN + "?"+"fromType=" + Constants.MDM_USER_SAIC_SOURCE + "&openid=" + openId + "&backUrl=" + backUrl);
			return model;
		}else{
			Long userId = accounts.get(0).getUserId();
			model = authorizationHandler.buildView(request,backUrl,openId,userId);
			logger.info("lqy--AccreditPromotionController--accredit--对应关系  openId {} <----> userId {}", openId, userId);
		}
		logger.info("lqy--AccreditPromotionController--accredit--授权返回页面" + model.getViewName());
		return model;
	}

	/**
	 * 直接授权
	 * @param response 
	 * @param request
	 */
    @RequestMapping(value="/htmlAccredit/{promotionName}",method=RequestMethod.GET)
    public  void  htmlAccredit(@PathVariable("promotionName")String promotionName,HttpServletResponse response,HttpServletRequest request){
        String url=accessTokenService.auth(domain+"accredit/getAccreditMsg.htm");
        url = url.replace(url.substring(url.length()-18,url.length()-16), promotionName);
        logger.info("授权活动标识promotionName："+promotionName+" 授权  url : " + url.toString());
        try {
            response.sendRedirect(url);
        } catch (IOException e) {
            logger.info("授权活动时异常"+e.getMessage());
            e.printStackTrace();
        }
	}


}
