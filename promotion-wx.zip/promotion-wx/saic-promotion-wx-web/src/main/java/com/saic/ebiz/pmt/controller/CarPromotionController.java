package com.saic.ebiz.pmt.controller;

import java.awt.image.BufferedImage;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.gson.GsonView;
import com.meidusa.fastjson.JSON;
import com.saic.ebiz.bc.utils.PropertiesUtil;
import com.saic.ebiz.bc.utils.UrlUtil;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.Constants;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.entity.ProvinceVO;
import com.saic.ebiz.market.service.AreaService;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.market.util.CookieUtil;
import com.saic.ebiz.mdm.api.UserService;
import com.saic.ebiz.mdm.entity.UserBaseInfoVO;
import com.saic.ebiz.promotion.service.api.ICustomerInfoTraceService;
import com.saic.ebiz.promotion.service.api.IGiftManagerService;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionBtoService;
import com.saic.ebiz.promotion.service.api.IPromotionExtendService;
import com.saic.ebiz.promotion.service.api.IPromotionQualificationService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.api.IVenueService;
import com.saic.ebiz.promotion.service.commons.constants.RedisConstants;
import com.saic.ebiz.promotion.service.commons.enums.BusinessType;
import com.saic.ebiz.promotion.service.entity.GiftQuotaEntity;
import com.saic.ebiz.promotion.service.entity.PromotionBtoInfoEntity;
import com.saic.ebiz.promotion.service.entity.PromotionDispIndexEntity;
import com.saic.ebiz.promotion.service.util.DateUtils;
import com.saic.ebiz.promotion.service.vo.CustomerInfo;
import com.saic.ebiz.promotion.service.vo.CustomerInfoQuery;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.PromotionBtoVo;
import com.saic.ebiz.promotion.service.vo.PromotionExtend;
import com.saic.ebiz.promotion.service.vo.PromotionResult;
import com.saic.ebiz.promotion.service.vo.UserInfo;
import com.saic.ebiz.promotion.service.vo.VenueRemind;
import com.saic.framework.redis.client.IRedisClient;
import com.saic.sso.client.SSOClient;

/**
 * 2015年5月18日活动WAP活动控制器<br>
 * 
 * @author qiuym
 * 
 */
@Controller
@RequestMapping("/518wx")
public class CarPromotionController {

	static List<String> codeList = new ArrayList<String>();
	static {
		codeList.add("Xiuqiu328_b01_027");
		codeList.add("c518_2_buickyl01");
		codeList.add("c518_2_buickyl02");
		codeList.add("c518_2_chevrolet01");
		codeList.add("c518_2_cadillac01");
		codeList.add("c518_2_mggs01");
		codeList.add("c518_2_BaoJun630_01");
		codeList.add("c518_2_BaoJun630_02");
		codeList.add("DTwang001");
		codeList.add("c518_2_roewe01");
		codeList.add("SGMMRK2015000157");
		codeList.add("c518_oem_fabia_02");
	}

	/**
	 * 每一页显示数据条数
	 */
	static final Integer PAGE_SIZE = 12;
	
	@Autowired
	private IMemberService memberService;

	/**
	 * 日志
	 */
	private final Logger logger = LoggerFactory.getLogger(CarPromotionController.class);

	/** 缓存接口. */
	@Resource(name = "springRedisClient")
	private IRedisClient redisClient;

	@Autowired
	private JsSDKSign jsSDKSign;
	
	  /**
	   * 消息推送
	   */
	  @Autowired
	  private IVenueService iVenueService;

	/**
	 * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	/**
	 * SSO服务
	 */
	@Autowired
	private SSOClient ssoClient;

	@Autowired
	private com.saic.ebiz.promotion.service.client.PromotionClient promotionClient;

	@Autowired
	private UserService userService;

	@Autowired
	private IPromotionBtoService promotionBtoService;


	/** 活动服务 */
	@Autowired
	private IPromotionService iPromotionService;

	// 活动扩展
	@Autowired
	private IPromotionExtendService remotePromotionExtendService;

	@Autowired
	private AreaService areaService;

	@Autowired
	private IPromotionQualificationService iPromotionQualificationService;

	/**
	 * B类车礼包领取状态
	 */
	@Autowired
	private IGiftManagerService iGiftManagerService;

	@Autowired
	private ICustomerInfoTraceService iCustomerInfoTraceService;

	/** 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");

	/** 注册验证码过期时间，秒 */
	//private static final int VALIDCODE_EXPIRE = 180;

	/** 验证码key */
	public static final String VALIDATECODE_REDIS_KEY = "mini:promotion:authCode:validateCode:";

	/**
	 * 报用户行为跟踪logger.source来源业务渠道 1：电商主站2：车享宝3：营销子站
	 */
	public static final int source_YXZZ = 3;

	/**
	 * 报用户行为跟踪logger.type订单类型 13.促销活动-------即营销子站，即cxzz来源的销售线索，比如大转盘，
	 */
	public static final int type_YXZZ = 13;

	/**
	 * 1：电商主站； 2：车享宝； 3：营销子站； 4：保养管家； 5：第三方联合登陆； 6：别克联合登陆； 7：微信服务号； 8：微信订阅号；
	 * 9：微信红包 11：呼叫中心； 12：平安保险（PC）； 13：订单系统； 14：车畅销； 20：车知道（内部账号）； 21：别克微信商城；
	 * 22：荣威俱乐部； 23：crm； 24：运营平台； 29：车享购微信服务号； 31：平安微信； 35：新浪微博PC； 36：新浪微博移动；
	 * 60：Other
	 */
	static final String TRACE_SOURCE = "7";

	/**
	 * 线索类型 10.促销车订购 11.预约试乘试驾 12.在线询价 13.促销活动 14.常规车预定 15.来电咨询 16.在线留言咨询
	 * 17.贷款购车 18.拉手电话 20.其他
	 */
	static final String TRACE_TYPE = "20";

	/**
	 * 授权服务
	 */
	@Resource
	private AuthorizationService authorizationService;

	/**
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;

	/**
	 * 活动主入口
	 */
	@RequestMapping("/bcarlist")
	public ModelAndView getBcarList(@RequestParam(value = "page", required = false) Integer page, @RequestParam(value = "userId", required = false) Long userId, HttpServletRequest request) {
		//ModelAndView  mv = new ModelAndView("redirect:http://www.chexiang.com/");
		ModelAndView mv = null;
	
		// 当前日期是否在2015年2-13 活动日期开始之后
		 boolean isAfterNow = isTimeLater("yyyy-MM-dd HH:mm:ss",
		 "2015-5-18 00:00:00");
		 if (!isAfterNow) {
		 mv = new ModelAndView("/518/preheat_518.ftl");
		 return mv;
		 }

		String uId = request.getParameter(RequestConstants.USER_ID);

		String openId = request.getParameter(RequestConstants.OPEN_ID);
		logger.info("request parameters userId = {}, openId = {} ", uId, openId);

		// uId = "559464";
		if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
			String autorizationUrl = "redirect:" + authorizationService.buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.promotion518.name());
			logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
			logger.debug("授权url : {} ######", autorizationUrl);
			mv = new ModelAndView(autorizationUrl);
		} else {
			mv = new ModelAndView("/518/main_518.ftl");
			mv.addObject(RequestConstants.USER_ID, uId).addObject(RequestConstants.OPEN_ID, openId);
		}
		// 1F 的数据
		String key=currentKey();
		String submitCodes = PropertiesUtil.getValue(key);
		Promotion pro = promotionBtoService.queryPromotionStatusByCode(submitCodes);
		if (pro != null) {
			if (pro.getPromotionCode() == null || "".equals(pro.getPromotionCode())) {
				pro.setPromotionCode("-1");
			}
			mv.addObject("promotionCode", pro.getPromotionCode());
			if (pro.getPromotionStatus() == null || "".equals(pro.getPromotionStatus())) {
				pro.setPromotionStatus(-1);
			}
			// 活动状态 5 未开始/ 6 进行中/ 7已结束
			mv.addObject("promotionStatus", pro.getPromotionStatus());
			// 活动总配额-已使用配额
			// if totalNum>usedNum 有配额，提交按钮可用
			mv.addObject("validNum", pro.getTotalNum() - pro.getUsedNum());
		}
//		 boolean isAfterNow = isTimeLater("yyyy-MM-dd HH:mm:ss","2015-7-27 00:00:00");
		// boolean isAfterNow =false;
	 mv.addObject("isAfterNow",isAfterNow);
		 //如果活动没有结束，查询2F、3F的数据
		 if (!isAfterNow) {
				List<PromotionDispIndexEntity> promotionList = iPromotionService.getPromotionImagByBrandId((long) -1);
				List<ProvinceVO> list = areaService.getAllProvinces();
				Map<String, Promotion> codeMap = iPromotionService.getXiuqiuByCodes(codeList);
				mv.addObject("provices", list);
				mv.addObject("codeMap", codeMap);
				mv.addObject("provices", list);
				mv.addObject("codeMap", codeMap);
				mv.addObject("promotionList", promotionList);
		 }
		mv.addObject("userId", userId);
		mv.addObject("isLogin", this.isLogin(request));
		mv.addObject("isMobileAuth", this.isMobileAuth(request));
		// 微信分享JSSDK分享
		Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
		mv.addObject("jssdk", map);
		int currentCode = current();
		mv.addObject("currentCode", currentCode);
		return mv;
	}

	/**
	 * 活动主入口(分页数据)
	 */
	@RequestMapping("/bcarpagelist")
	public ModelAndView getBcarPageList(@RequestParam(value = "page", required = false) Integer page, HttpServletRequest request) {
		ModelAndView  mv = new ModelAndView("redirect:http://www.chexiang.com/");
		return mv;
	}

	private Integer isLogin(HttpServletRequest request) {
		Long userId = ssoClient.getLoginStatus(request);
		Integer isLogin = 0;
		if (userId > 0) {
			isLogin = 1;
		}
		return isLogin;
	}

	private Integer isMobileAuth(HttpServletRequest request) {
		Long userId = ssoClient.getLoginStatus(request);
		UserInfo user = null;
		Integer isAuth = 0;
		if (userId > 0) {
			// user = memberService.findMembCentInfo(userId);
			 user = memberService.findMembCentInfo(userId);
			if (user.getMobileAuthFlag() == 1) {
				isAuth = 1;
			}
		}
		return isAuth;
	}

	@RequestMapping("/gosubscribe")
	public GsonView gosubscribe(Long promotionId, String keyId, Long userId, Long giftId, Long velBrandId, Long velSeriesId, Long velModelId, HttpServletRequest request, HttpServletResponse response) {
	usertraceLogger.info("\t rx \t"+getCookieByName(request) + "\t" + userId + "\t"
				 + DateUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"\t "+this.getIp(request)+" \t"+ "88_wx_mainVenue_yxzc_order_" +keyId+ "\t" 
				 + "八八节热销车下订" +"\t "+ request.getHeader("user-agent") 
				 + "\t" + 3 + "\t" + 13);
		
		GsonView gv = new GsonView();
		try {

			// UserLoginVO userLoginVO = checkLoginStatus(request, gv);
			// if (!userLoginVO.getIsLoginSuccess()) {
			// return gv;
			// }
			UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(userId);
			String mobile = userBaseInfoVO.getMobile();

			Promotion promotion = iPromotionService.getPromotion(promotionId);
			// promotionCodes.add(promotionCode);
			// Map<String, Promotion> promotionMap =
			// promotionService.getXiuqiuByCodes(promotionCodes);
			// Promotion promotion = promotionMap.get(promotionCode);
			// String mobile = "13641754374";
			long customerId = iPromotionService.getCustomerId(userId, mobile);

			PromotionResult subscribeResult = null;
			boolean isAvailable = false;
			String url = "";

			subscribeResult = iPromotionService.newSubscribe(promotionId, mobile, userId);
			logger.debug("subscribe：接口返回结果:" + JSON.toJSONString(subscribeResult) + "--调用参数:promotionId:" + promotionId + "--mobile:" + mobile + "--userId:" + userId + "--customerId:" + customerId);

			if (subscribeResult != null) {

				Cookie[] cookies = request.getCookies();
				String userTraceCookie = "";
				for (Cookie cookie : cookies) {
					String name = cookie.getName();
					if ("user_trace_cookie".equals(name)) {
						userTraceCookie = cookie.getValue();
						break;
					}
				}
				usertraceLogger.info(userTraceCookie + "\t" + userId + "\t" + promotionId + "\t" + PropertiesUtil.getValue(String.valueOf(subscribeResult.getResultCode())) + "\t" + mobile + "\t" + source_YXZZ + "\t" + type_YXZZ + "\t" + keyId);

				if (subscribeResult.getResultCode() == 0) {
					// long velBrandId = promotion.getVelBrandId();
					// long velSeriesId = promotion.getVelSeriesId();
					//
					// Long velModelId = promotion.getVelModelId() == null ? -1L
					// : promotion.getVelModelId();
					url = UrlUtil.getCheXiangGouOrderUrl(promotionId, subscribeResult.getSubscriptionId(), -1L, velBrandId, velSeriesId, velModelId, checkMobile(request), giftId, userId);
					logger.debug("拼接后的URL为:" + url);
				}

				if (subscribeResult.getSubscription() != null) {
					isAvailable = subscribeResult.getSubscription().isAvailable();
				}
			}

			PromotionExtend promotionExtend = remotePromotionExtendService.findPromotionExtendByPromotionId(promotionId);
			if (promotionExtend != null) {
				gv.addStaticAttribute("userPrmtLimit", promotionExtend.getUserPrmtLimit());
			}
			gv.addStaticAttribute("isAvailable", isAvailable);
			gv.addStaticAttribute("subscribeResult", subscribeResult);
			gv.addStaticAttribute("url", url);
			if (promotion != null) {
				gv.addStaticAttribute("members", promotion.getTotalMembers());
			}
		} catch (Exception e) {
			logger.error("车享购抢购错误,错误信息:{}", e.getMessage());
		}
		return gv;
	}

	private String getCookieByName(HttpServletRequest request) {
		Cookie cookie = CookieUtil.getCookieByName(request, "user_trace_cookie");
		String cookieName = null;
		if (cookie != null) {
			cookieName = cookie.getValue();
		}
		return cookieName;
	}

	/**
	 * 校验请求来源是否来自手机 <br>
	 * 〈功能详细描述〉
	 * 
	 * @param request
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static boolean checkMobile(HttpServletRequest request) {
		String regexMatch = "nokia|iphone|ipod|iuc|android|motorola|^mot\\-|softbank|foma|docomo|kddi|up\\.browser|up\\.link|";
		regexMatch += "htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|";
		regexMatch += "blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|";
		regexMatch += "symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\\-|longcos|pantech|gionee|^sie\\-|portalmmm|";
		regexMatch += "jig\\s browser|hiptop|ucweb|^ucweb|^benq|haier|^lct|opera\\s*mobi|opera\\*mini|320x320|240x320|176x220";

		String userAgent = request.getHeader("user-agent").toLowerCase();
		if (StringUtils.isBlank(userAgent)) {
			return true;
		} else {
			Pattern p = Pattern.compile(regexMatch);
			Matcher m = p.matcher(userAgent);
			if (m.find()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 功能描述: 获取验证码<br>
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping("/validateCode")
	public void validateCode(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			String promotionId = request.getParameter("promotionId");
			String userId = request.getParameter("userId");
			String d = request.getParameter("d");
			String sessAtt = "valcode_" + promotionId;
			Object curSessCode = session.getAttribute(sessAtt);
			if (curSessCode == null || !curSessCode.toString().equals(d)) {
				session.setAttribute(sessAtt, d);
				System.setProperty("java.awt.headless", "true");

				// 设置相应类型,告诉浏览器输出的内容为图片
				response.setContentType("image/jpeg");
				// 设置响应头信息，告诉浏览器不要缓存此内容
				response.setHeader("Pragma", "No-cache");
				response.setHeader("Cache-Control", "no-cache");
				response.setDateHeader("Expire", 0);

				RandomValidateCode validateCode = new RandomValidateCode();
				BufferedImage image = validateCode.getValidateImage();

				// 将生成的code放入redis, 并设置VALIDCODE_EXPIRE秒过期
				String key = VALIDATECODE_REDIS_KEY + promotionId + userId;
				redisClient.setex(key,Constants.REDIS_NAME_SPACE, RedisConstants.EXPIRE_TIME_HALF_AN_HOUR, validateCode.getCodeString());
				logger.debug("redis中设置验证码：key={}, value={}", key, redisClient.get(key,Constants.REDIS_NAME_SPACE,null));

				ImageIO.write(image, "JPEG", response.getOutputStream());
				System.setProperty("java.awt.headless", "true");

			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * 校验验证码
	 * 
	 * @param actitvtycode
	 * @param inputValidCode
	 * @param request
	 * @return
	 */
	@RequestMapping("/checkImg")
	public GsonView generateOrderURL(@RequestParam String actitvtycode, @RequestParam String inputValidCode, HttpServletRequest request,
									String promotionCode, int city, long userId, String name1, String name2, String name3) {
		GsonView gsonView = new GsonView();
		/** 检查验证码是否输入正确,0--->输入正确,1--->输入错误 */
		int validateCodeErr = 0;

		/** 获取验服务器验证码 */
		String key = VALIDATECODE_REDIS_KEY + actitvtycode + userId;
		String validCode = StringUtils.EMPTY;
		if (redisClient.exists(key,Constants.REDIS_NAME_SPACE)) {
			/** 获取redis缓存的Value,赋值给validCode */
			validCode = redisClient.get(key,Constants.REDIS_NAME_SPACE,null);
			logger.debug("redis中获取到的验证码：key={}, value={}", key, redisClient.get(key,Constants.REDIS_NAME_SPACE,null));
			/** 删除redis缓存验证码 */
			redisClient.del(key,Constants.REDIS_NAME_SPACE);
		}
		if (StringUtils.isBlank(validCode)) {
			validateCodeErr = 1;
			gsonView.addStaticAttribute("result", validateCodeErr);
			return gsonView;
		} else if (!inputValidCode.equalsIgnoreCase(validCode)) {
			validateCodeErr = 1;
			gsonView.addStaticAttribute("result", validateCodeErr);
			return gsonView;
		}
		//判断状态
		Promotion promotion = checkStauts(promotionCode);
		if (promotion.getPromotionStatus()==6||promotion.getPromotionStatus()==7) {
			if (promotion.getTotalNum()>promotion.getUsedNum()) {
				PromotionResult pr = submitPart(request, promotionCode, city, userId, name1, name2, name3,key,validCode);
				gsonView.addStaticAttribute("pr", pr);
			} else {
				gsonView.addStaticAttribute("status","2" );
			}
		} else {
			gsonView.addStaticAttribute("status", "3");
		}
		return gsonView;
	}

	/**
	 * 功能描述: 获取B类车活动礼包页面<br>
	 * 
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping("/bcargiftlist")
	public GsonView getBcarGiftList(@RequestParam(value = "giftSource", required = false) int giftSource, HttpServletRequest request) {
		GsonView gsonView = new GsonView();
		List<GiftQuotaEntity> queryGifts = iGiftManagerService.queryGifts(giftSource);
		gsonView.addStaticAttribute("result", queryGifts);
		return gsonView;
	}

	/**
	 * 获得指定promotionCode的活动信息（AJAX访问）
	 * 
	 * @param promotionCode
	 *            活动code
	 * @return 活动信息
	 */
	@RequestMapping("/getActivityStatusJSON.json")
	public GsonView getActivityStatusJSON() {
		
		//所有活动code
		List<String> promotionCodes = new ArrayList<String>();
		promotionCodes.add("C518_1_ORDER_01_1");
		promotionCodes.add("C518_1_ORDER_02_1");
		promotionCodes.add("C518_1_ORDER_03_1");
		promotionCodes.add("C518_1_ORDER_04_1");
		promotionCodes.add("C518_1_ORDER_05_1");
		promotionCodes.add("C518_1_ORDER_06_1");
		promotionCodes.add("C518_1_ORDER_07_1");
		promotionCodes.add("C518_1_ORDER_08_1");
		promotionCodes.add("C518_1_ORDER_09_1");
		promotionCodes.add("C518_1_ORDER_10_1");
		GsonView gv = new GsonView();
		//页面显示历史数量
		int showSize = compareDate(new Date());
			List<PromotionBtoVo> pmtList = null;
			Map<String,Object> promotionBtoVoMap = new HashMap<String,Object>();
			for (int i = 0; i < showSize; i++) {
					pmtList = promotionBtoService.queryPromotionByCode(promotionCodes.get(i));
					if (pmtList != null && pmtList.size() > 0) {
						String mobile = pmtList.get(0).getMobile();
						pmtList.get(0).setMobile(mobile.substring(0, 3) + "****" + mobile.substring(7, mobile.length()));
						promotionBtoVoMap.put(promotionCodes.get(i),pmtList.get(0));
					} else {
						promotionBtoVoMap.put(promotionCodes.get(i),"null");
					}
			}
			gv.addStaticAttribute("pmtMap", promotionBtoVoMap);
			gv.addStaticAttribute("showSize", showSize);

		return gv;
	}

	/**
	 * 提交配件数据
	 */
	public PromotionResult submitPart(HttpServletRequest request, String promotionCode, int city, long userId, String name1, String name2, String name3,String verifyCodeKey,String verifyCode) {

		PromotionBtoInfoEntity pro = new PromotionBtoInfoEntity();

		String[] name1Part = new String[6];
		if (!"".equals(name1) && name1 != null) {
			if (name1.indexOf(",") < 0) {
				name1Part[0] = name1;
				pro.setAutoPartA01(name1Part[0]);
			} else {
				name1Part = name1.split(",");
				pro.setAutoPartA01(name1Part[0]);
				pro.setAutoPartA02(name1Part[1]);
			}
		}
		String[] name2Part = new String[6];
		if (!"".equals(name2) && name2 != null) {
			if (name2.indexOf(",") < 0) {
				name2Part[0] = name2;
				pro.setAutoPartB01(name2Part[0]);
			} else {
				name2Part = name2.split(",");
				pro.setAutoPartB01(name2Part[0]);
				pro.setAutoPartB02(name2Part[1]);
			}
		}
		String[] name3Part = new String[6];
		if (!"".equals(name3) && name3 != null) {
			if (name3.indexOf(",") < 0) {
				name3Part[0] = name3;
				pro.setAutoPartC01(name3Part[0]);
			} else {
				name3Part = name3.split(",");
				pro.setAutoPartC01(name3Part[0]);
				pro.setAutoPartC02(name3Part[1]);
			}
		}

		pro.setPromotionCode(promotionCode);
		pro.setUserid(userId);
		UserInfo user = memberService.findMembCentInfo(userId);
		pro.setUsername(user.getName());
		pro.setMobile(user.getMobile());
		pro.setCityId(city);
		String ipAdd = getIp(request);
		pro.setIpAddress(ipAdd);
		pro.setVerifyCodeKey(verifyCodeKey);
		pro.setVerifyCode(verifyCode);
		

		PromotionResult pr = promotionBtoService.participateBtoEveryweekDay(pro);
		return pr;
	}

	/**
	 * 用户是否已领奖（已下订单），跳转预定页
	 * 
	 * @param promotionId
	 *            活动id
	 * @param mobile
	 *            手机号
	 * @param userId
	 *            用户id
	 * @param brandId
	 *            品牌id
	 * @param seriesId
	 *            车系id
	 * @param modelId
	 *            车型id
	 * @param request
	 * @return 领奖用户跳转的订单URL
	 */
	@RequestMapping("/userIsGetReward")
	public GsonView userIsGetReward(@RequestParam String promotionCode, @RequestParam Long userId, HttpServletRequest request) {
		logger.info("CarPromotionPcController--getBrandPromotion--入参userId:" + userId);
		PromotionBtoVo promotionBtoVo = null;
		List<PromotionBtoVo> pmtList = null;
		if (promotionCode != null && !promotionCode.equals("")) {
			pmtList = promotionBtoService.queryPromotionByCode(promotionCode);
			if (pmtList != null && pmtList.size() > 0) {
				promotionBtoVo = pmtList.get(0);
			}
		}

		GsonView gv = new GsonView();
		if (promotionBtoVo != null) {
			Long promotionId = promotionBtoVo.getPromotionId();
			List<String> promotionCodes = new ArrayList<String>();
			promotionCodes.add(promotionCode);
			Map<String, Promotion> promotionMap = iPromotionService.getXiuqiuByCodes(promotionCodes);
			Promotion promotion = promotionMap.get(promotionCode);
			Long velBrandId = promotion.getVelBrandId();
			Long velSeriesId = promotion.getVelSeriesId();
			Long velModelId = promotion.getVelModelId();
			if (velModelId==null) {
				velModelId = -1l;
			}
			

			PromotionResult ptResult = null;// 活动参与vo
			List<CustomerInfo> CustomerInfoList = null;// 客户vo

			CustomerInfoQuery cmInfo = new CustomerInfoQuery();
			cmInfo.setPromotionId(promotionBtoVo.getPromotionId());
			cmInfo.setUserId(userId);
			cmInfo.setTelephone(promotionBtoVo.getMobile());
			// isGetReward 1 中奖用户，0 不是中奖用户
			int isGetReward = 0;
			// isGetOrder 1 已下单，0 未下单
			int isGetOrder = 1;

			String url = "";// 订单跳转地址
			if (promotionBtoVo.getPromotionId() != null) {
				// 1.1是否是中奖用户
				CustomerInfoList = iCustomerInfoTraceService.queryCustomerInfo(cmInfo);
				if (CustomerInfoList != null && CustomerInfoList.size() > 0) {
					isGetReward = 1;
					// 1.2用户是否已领奖（已下订单）
					ptResult = iPromotionService.newSubscribe(promotionBtoVo.getPromotionId(), promotionBtoVo.getMobile(), userId);
					// 1.3 如果没有下单，获得预定单页URL
					if (ptResult.getResultCode() == 0) {
						isGetOrder = 0;
						url = UrlUtil.getCheXiangGouOrderUrl(promotionId, ptResult.getSubscriptionId(), -1L, velBrandId, velSeriesId, velModelId, checkMobile(request), (long) -1, userId);

						// url =
						// UrlUtil.getOrderUrl(promotionBtoVo.getPromotionId(),
						// ptResult.getSubscriptionId(), checkMobile(request));
						logger.debug("CarPromotionPcController--getBrandPromotion--拼接后的URL为:" + url);
					}
				}
			}
			logger.info("CarPromotionPcController--getBrandPromotion--返回isGetReward（1 中奖用户，0 不是中奖用户）：" + isGetReward + "--isGetOrder（ 1 已下单，0 未下单）:" + isGetOrder);

			gv.addStaticAttribute("isGetReward", isGetReward);
			gv.addStaticAttribute("isGetOrder", isGetOrder);
			gv.addStaticAttribute("url", url);
		}
		return gv;
	}

	public Promotion checkStauts(String promotionCode) {
		Promotion promotion = promotionBtoService.queryPromotionStatusByCode(promotionCode);
		return promotion;
	}

	@ResponseBody
	@RequestMapping("/oemToOrder")
	public GsonView oemToOrder(String promotionCode, Long userId, HttpServletRequest request, HttpServletResponse response) {
		// usertraceLogger.info("微信端MG活动\t" + getCookieByName(request) + "\t" +
		GsonView gv = new GsonView();
		if (userId<=0 && (promotionCode.equals("OEM_MGALL_ROEWEMG_RW350") || promotionCode.equals("OEM_MGALL_ROEWEMG_RW550") 
				|| promotionCode.equals("OEM_MGALL_ROEWEMG_RW950")|| promotionCode.equals("OEM_MGALL_ROEWEMG_RWW5") 
				|| promotionCode.equals("OEM_MGALL_ROEWEMG_MG3")|| promotionCode.equals("OEM_MGALL_ROEWEMG_MG5")
				|| promotionCode.equals("OEM_MGALL_ROEWEMG_MGRT")|| promotionCode.equals("OEM_MGALL_ROEWEMG_MG6"))) {
		
			String autorizationUrl =authorizationService.
					buildAuthorizationLink(appId, (redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE", Authorization.mgRoewe.name());
			logger.info("授权url : {} ", autorizationUrl);
			String[] urls = autorizationUrl.split(".htm");
			autorizationUrl = urls[0]+".htm?groupId=null"+urls[1];
			logger.info("处理后授权url : {} ", autorizationUrl);
			gv.addStaticAttribute("autorizationUrl", autorizationUrl);
			gv.addStaticAttribute("flag", false);
			return gv;
		}
		try {

			UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(userId);
			String mobile = userBaseInfoVO.getMobile();
			// Long promotionId =
			// promotionService.getPromotionIdByCode(promotionCode);
			// Promotion promotion =
			// iPromotionService.getPromotion(promotionId);

			List<String> codeList = new ArrayList<String>();
			codeList.add(promotionCode);
			Map<String, Promotion> promotionMap = iPromotionService.getXiuqiuByCodes(codeList);
			Promotion promotion = promotionMap.get(promotionCode);
			Long promotionId = promotion==null?null:promotion.getPromotionId();
			// CxgMerchandiseVO cxgMerchandiseVO =
			// getPromotionWithCode(promotionId, 2);

			// String mobile = "13641754374";
			long customerId = iPromotionService.getCustomerId(userId, mobile);

			PromotionResult subscribeResult = null;
			boolean isAvailable = false;
			String url = "";
			logger.info("promotionId=" + promotionId + ",mobile=" + mobile + ",userId=" + userId);
			subscribeResult = iPromotionService.newSubscribe(promotionId, mobile, userId);
			logger.debug("subscribe：接口返回结果:" + JSON.toJSONString(subscribeResult) + "--调用参数:promotionId:" + promotionId + "--mobile:" + mobile + "--userId:" + userId + "--customerId:" + customerId);

			if (subscribeResult != null) {

				if (subscribeResult.getResultCode() == 0) {
					Long velBrandId = promotion.getVelBrandId();
					if (velBrandId==null) {
						velBrandId=-1L;
					}
					Long velSeriesId = promotion.getVelSeriesId() == null ? -1L : promotion.getVelSeriesId();

					Long velModelId = promotion.getVelModelId() == null ? -1L : promotion.getVelModelId();
					url = UrlUtil.getCheXiangGouOrderUrl(promotionId, subscribeResult.getSubscriptionId(), -1L, velBrandId, velSeriesId, velModelId, checkMobile(request), null, userId);
					logger.debug("拼接后的URL为:" + url);
				}

				if (subscribeResult.getSubscription() != null) {
					isAvailable = subscribeResult.getSubscription().isAvailable();
				}
			}

			PromotionExtend promotionExtend = remotePromotionExtendService.findPromotionExtendByPromotionId(promotionId);
			if (promotionExtend != null) {
				gv.addStaticAttribute("userPrmtLimit", promotionExtend.getUserPrmtLimit());
			}
			gv.addStaticAttribute("isAvailable", isAvailable);
			gv.addStaticAttribute("subscribeResult", subscribeResult);
			gv.addStaticAttribute("url", url);
			gv.addStaticAttribute("flag",true);
			if (promotion != null) {
				gv.addStaticAttribute("members", promotion.getAvailableNum());
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("车享购抢购错误,错误信息:{}", e.getMessage());
		}
		return gv;
	}

	@RequestMapping("/rule")
	public String rule() {
		return "518/wx518-rule.ftl";
	}

	/**
	 * 判断当前日期是否在某日期之后 <br>
	 * 
	 * @author v_lijialiang
	 * @param format
	 *            日期格式
	 * @param dateTime
	 *            设定日期
	 * @return true 在某日期后 false 不在
	 */
	public boolean isTimeLater(String format, String dateTime) {
		// 判断当前日期是否在某日期之后
		Date nowsysdate = new Date();
		SimpleDateFormat formatLink = new SimpleDateFormat(format);
		Date TurnTime = null;
		boolean isTimeLater = false;
		try {
			TurnTime = formatLink.parse(dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (null != TurnTime) {
			if (nowsysdate.after(TurnTime)) {
				isTimeLater = true;
			}
		}
		return isTimeLater;
	}
	
	/**
	 * 判断当前页面显示多少条数据
	 * return 显示数量
	 * 隐藏所有的历史，显示已过期的数据
	 */
	public int compareDate(Date date){
		int i = 0;
		List<String> endDate = new ArrayList<String>();
		endDate.add("2015.5.24 23:59:59");
		endDate.add("2015.5.31 23:59:59");
		endDate.add("2015.6.7 23:59:59");
		endDate.add("2015.6.14 23:59:59");
		endDate.add("2015.6.21 23:59:59");
		endDate.add("2015.6.28 23:59:59");
		endDate.add("2015.7.5 23:59:59");
		endDate.add("2015.7.12 23:59:59");
		endDate.add("2015.7.19 23:59:59");
		endDate.add("2015.7.26 23:59:59");
		for(int j=0; j<endDate.size(); j++) {
			Date endDa = formatDate(endDate.get(i));
			if (date.after(endDa)) {
				i++;
			}
		}
		return i;
	}
	
	/**
	 * 格式化日期
	 */
	public Date formatDate(String str) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd hh:mm:ss");
		Date date;
		try {
			date = sdf.parse(str);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 即将开始显示
	 * return 隐藏数量
	 * 即将开始全部显示，隐藏已经过期的。
	 */
	@RequestMapping("/come")
	public GsonView comeView() {
		GsonView gv = new GsonView();
		int i = 0;
		List<String> startDate = new ArrayList<String>();
		startDate.add("2015.5.25 00:00:00");
		startDate.add("2015.6.1 00:00:00");
		startDate.add("2015.6.8 00:00:00");
		startDate.add("2015.6.15 00:00:00");
		startDate.add("2015.6.22 00:00:00");
		startDate.add("2015.6.29 00:00:00");
		startDate.add("2015.7.6 00:00:00");
		startDate.add("2015.7.13 00:00:00");
		startDate.add("2015.7.20 00:00:00");
		Date date = new Date();
		for(int j=0; j<startDate.size(); j++) {
			Date startDa = formatDate(startDate.get(i));
			if (date.after(startDa)) {
				i++;
			}
		}
		gv.addStaticAttribute("index", i);
		return gv;
	}
	
	/**
	 * 判断1F当前页信息
	 * 1.第一周 2.第二周……
	 */
	public int current() {
		int i = 0;
		String startDate = "2015.5.18 00:00:00";
		String endDate = "2015.5.25 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 1;
		}
		startDate = "2015.5.25 00:00:00";
		endDate = "2015.6.1 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 2;
		}
		startDate = "2015.6.1 00:00:00";
		endDate = "2015.6.8 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 3;
		}
		startDate = "2015.6.8 00:00:00";
		endDate = "2015.6.15 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 4;
		}
		startDate = "2015.6.15 00:00:00";
		endDate = "2015.6.22 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 5;
		}
		startDate = "2015.6.22 00:00:00";
		endDate = "2015.6.29 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 6;
		}
		startDate = "2015.6.29 00:00:00";
		endDate = "2015.7.6 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 7;
		}
		startDate = "2015.7.6 00:00:00";
		endDate = "2015.7.13 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 8;
		}
		startDate = "2015.7.13 00:00:00";
		endDate = "2015.7.20 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 9;
		}
		startDate = "2015.7.20 00:00:00";
		endDate = "2020.7.27 00:00:00";
		if (isDate(startDate, endDate)) {
			i = 10;
		} 
		
		return i;
	}
	
	/**
	 * 判断1F当前页日期状态
	 */
	public boolean isDate(String startDate,String endDate){
		boolean flag = false;
		Date date = new Date();
		if (date.after(formatDate(startDate))&&date.before(formatDate(endDate))) {
			return true;
		}
		return flag;
	}
	
	/**
	 * 判断1F当前页信息
	 * 1.第一周 2.第二周……
	 */
	public String currentKey() {
		String key="";
		String startDate = "2015.5.18 00:00:00";
		String endDate = "2015.5.25 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit";
		}
		startDate = "2015.5.25 00:00:00";
		endDate = "2015.6.1 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit2";
		}
		startDate = "2015.6.1 00:00:00";
		endDate = "2015.6.8 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit3";
		}
		startDate = "2015.6.8 00:00:00";
		endDate = "2015.6.15 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit4";
		}
		startDate = "2015.6.15 00:00:00";
		endDate = "2015.6.22 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit5";
		}
		startDate = "2015.6.22 00:00:00";
		endDate = "2015.6.29 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit6";
		}
		startDate = "2015.6.29 00:00:00";
		endDate = "2015.7.6 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit7";
		}
		startDate = "2015.7.6 00:00:00";
		endDate = "2015.7.13 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit8";
		}
		startDate = "2015.7.13 00:00:00";
		endDate = "2015.7.20 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit9";
		}
		startDate = "2015.7.20 00:00:00";
		endDate = "2020.7.27 00:00:00";
		if (isDate(startDate, endDate)) {
			key = "518-submit10";
		}
		return key;
	}
	
	public String getIp(HttpServletRequest request) {
		logger.info("获取客户端ip地址");
		String ip = null;
		try{
			ip = request.getHeader("x-forwarded-for");  
	       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	           ip = request.getHeader("Proxy-Client-IP");  
	       }  
	       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	           ip = request.getHeader("WL-Proxy-Client-IP");  
	       }  
	       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	           ip = request.getRemoteAddr();  
	       }  
	       if(ip.indexOf(",")>0) {
	    	   ip = ip.split(",")[0];
	       }
	       logger.info("客户端ip地址为：" + ip);
	       return ip;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("发生异常ip地址获取失败");
			return null;
		}
		
	}
	
	/**
     * 活动提醒
     * @param venueCode
     * @param request
     * @param userId
     * @param mobile
     * @return
     */
    @SuppressWarnings("all")
    @RequestMapping("/activitiesRemind")
    public GsonView activitiesRemind(HttpServletRequest request,
    		@RequestParam String venueCode,
    		@RequestParam String userId,
    		@RequestParam String starTime,
    		@RequestParam String weekDate){
    	GsonView Gv = new GsonView();
    	//时间格式错误
    	if(StringUtils.isBlank(starTime)){Gv.addStaticAttribute("resultMsg", "提醒时间不存在!");return Gv;}
    	if(StringUtils.isBlank(venueCode)){Gv.addStaticAttribute("resultMsg", "活动周期不存在!");return Gv;}
    	long uId = Long.parseLong(userId);
    	UserBaseInfoVO userBaseInfoVO = userService.findBaseInfoByUserId(uId);
		String mobile = userBaseInfoVO.getMobile();
    	//参数缺少(用户ID,或者手机号)
    	if(StringUtils.isBlank(userId) || StringUtils.isBlank(mobile)){Gv.addStaticAttribute("resultMsg", "用户或者手机号不存在!");return Gv;}
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	Date remindTime = null;
    	boolean addVenueRemind = false;
    	try {
    		remindTime = format.parse(starTime);
		} catch (ParseException e) {
			e.printStackTrace();
			Gv.addStaticAttribute("resultMsg", "时间格式错误!");
		}
    	boolean isRemind = iVenueService.isVenueRemind(venueCode, Long.valueOf(userId));
    	if(!isRemind){
    		VenueRemind venueRemind = new VenueRemind();
    		venueRemind.setAppId("ma");
    		venueRemind.setMsgCode("066");
    		venueRemind.setMobile(mobile);	    			    		
    		venueRemind.setVenueCode(venueCode);
    		venueRemind.setRemindTime(remindTime);
    		venueRemind.setHdId(Long.valueOf(26));
    		venueRemind.setWeekDate(weekDate);
    		venueRemind.setUserId(Long.parseLong(userId));
    		venueRemind.setBusinessType(BusinessType.ACTIVITY.code());
    		addVenueRemind = iVenueService.addVenueRemind(venueRemind);
    		if (addVenueRemind) {
            	  Cookie[] cookies = request.getCookies();
                  String userTraceCookie = "";
                  for(Cookie cookie : cookies) {
                      String name = cookie.getName();
                      if ("user_trace_cookie".equals(name)) {
                          userTraceCookie = cookie.getValue();
                          break;
                      }
                  }
                  usertraceLogger.info(userTraceCookie + "\t" + userId + "\t" + "Xiuqiu328PreHeat" + "\t"
                           + "518选配车得半价活动提醒成功"+ "\t"  + mobile + "\t" + source_YXZZ+ "\t" + type_YXZZ);
                 Gv.addStaticAttribute("resultMsg", "预约成功，活动当天我们将以短信的形式通知您，期待您的参与！");  
                 return Gv;
             }else{
            	 Gv.addStaticAttribute("resultMsg", "预约失败，请稍后重试！");
            	 return Gv;
             }
    	}
    	Gv.addStaticAttribute("resultMsg", "您已预约，感谢您的参与！");
    	return Gv;
    }

}
