package com.saic.ebiz.pmt.controller;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.utils.IpUtils;
import com.meidusa.fastjson.JSON;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.promotion.service.api.IShareInfoService;
import com.saic.ebiz.promotion.service.vo.ShareInfoVo;

/**
 * 记录分享信息
 * @author liqiaoyan
 *
 */
@Controller
@RequestMapping("/share")
public class RecordShareInfo {
	
	/**
	 * 分享服务
	 */
	@Autowired
	private IShareInfoService  ishareInfoService;
	
	/**
	 * 日志
	 */
	 private static Logger logger = LoggerFactory.getLogger(RecordShareInfo.class); 
	/**
	 * 微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx867e1eccd949be40
	 * 
	 */
	@Value("${ebiz.wap.web.appId:}")
	private String appId;
	
	@Autowired
	private JsSDKSign jsSDKSign;
	/**
	 * 记录分享内容
	 * @return
	 */
	@ResponseBody
	 @RequestMapping("/saveshare")
		public void saveshare(HttpServletRequest req,@RequestBody ShareInfoVo sInfo ){
			logger.info("RecordShareInfo--saveshare---分享信息插入开始--ShareInfoVo："+JSON.toJSONString(sInfo));
			String userIp=IpUtils.getIpAddr(req);
			sInfo.setUserIp(userIp);
//			sInfo.setEnterTime(new Date());
			sInfo.setInsertTime(new Date());
			sInfo.setUpdateTime(new Date());
				try {
					boolean saveShareInfo = ishareInfoService.saveShareInfo(sInfo);
					logger.info("saveshare|saveShareInfo|"+saveShareInfo+"|sInfo|"+JSON.toJSONString(sInfo));
				} catch (Exception e) {
					logger.info("RecordShareInfo--saveshare--分享信息插入error"+e);
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			logger.info("RecordShareInfo--saveshare--分享信息插入完毕");
		}
		
		@RequestMapping("/testPage")
		public ModelAndView testPage(HttpServletRequest request){
			ModelAndView mv=new ModelAndView("/test/test01.ftl");
			Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
			mv.addObject("jssdk", map);
			mv.addObject("nowTime",new Date().getTime());
//			mv.addObject("nowTime",DateUtils.(, "yyyy-MM-dd HH:mm:ss"));
			return mv ;
		}
		
		@RequestMapping("/hideShare")
		public ModelAndView hideShare(HttpServletRequest request){
			ModelAndView mv=new ModelAndView("/test/test02.ftl");
			Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
			mv.addObject("jssdk", map);
			return mv ;
		}

}
