package com.saic.ebiz.pmt.controller.entity;



/**
 *  implements Serializable
 * @author Administrator
 *
 */
public class CarPromotionText {
	
	private static final long serialVersionUID = 1L;

	private Integer status = 0;

	private String vehicleImg;
	private String vehicleName;
	private String vehicleCost;
	private int vehicleNumber;
	
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getVehicleImg() {
		return vehicleImg;
	}
	public void setVehicleImg(String vehicleImg) {
		this.vehicleImg = vehicleImg;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public String getVehicleCost() {
		return vehicleCost;
	}
	public void setVehicleCost(String vehicleCost) {
		this.vehicleCost = vehicleCost;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(int vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	
}
