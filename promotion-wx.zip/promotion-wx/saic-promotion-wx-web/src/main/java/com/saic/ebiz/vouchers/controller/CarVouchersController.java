package com.saic.ebiz.vouchers.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.framework.web.gson.GsonView;
import com.saic.ebiz.component.wx.util.JsSDKSign;
import com.saic.ebiz.market.common.constant.RequestConstants;
import com.saic.ebiz.market.common.enumeration.Authorization;
import com.saic.ebiz.market.service.AuthorizationService;
import com.saic.ebiz.market.service.AuthorizationService.Scope;
import com.saic.ebiz.oem.controller.RwSouthController;
import com.saic.ebiz.promotion.service.api.IMemberService;
import com.saic.ebiz.promotion.service.api.IPromotionCarWashService;
import com.saic.ebiz.promotion.service.api.IPromotionService;
import com.saic.ebiz.promotion.service.vo.BaBaLotteryResultVo;
import com.saic.ebiz.promotion.service.vo.Promotion;
import com.saic.ebiz.promotion.service.vo.UserInfo;

@Controller
@RequestMapping("/carVouchers")
public class CarVouchersController {

	/*日志*/
	private final Logger logger = LoggerFactory.getLogger(RwSouthController.class);

	/*微信应用唯一ID 车享购服务号 wxc2c9c0c1d5115808 测试账号 wx38a0b3a7cc7761f9*/
	@Value("${ebiz.wap.web.appId:}")
	private String appId;

	/*洗车券服务接口 */
	@Autowired
	private IPromotionCarWashService iPromotionCarWashService;

	@Autowired
	private IPromotionService promotionService;

	@Autowired
	private JsSDKSign jsSDKSign;

	/*
	 * sit mgo.sit.chexiang.com 本地测试192.168.26.141 pre mgo.pre.chexiang.com pro
	 * mgo.chexiang.com
	 */
	@Value("${ebiz.wap.web.redirectHost:}")
	private String redirectHost;

	/*授权服务*/
	@Resource
	private AuthorizationService authorizationService;

	@Autowired
	private IMemberService memberService;

	/* 用户行为跟踪logger. */
	private Logger usertraceLogger = LoggerFactory.getLogger("USER-TRACER");

	@RequestMapping("/index")
	public ModelAndView main(@RequestParam(value = "userId", required = false) Long userId,HttpServletRequest request){
		ModelAndView mv = null;
		String uId = request.getParameter(RequestConstants.USER_ID);
		String openId = request.getParameter(RequestConstants.OPEN_ID);
		logger.info("request parameters userId = {}, openId = {} ", uId, openId);
		if (StringUtils.isEmpty(uId) || "-1".equals(uId)) {
			String autorizationUrl = "redirect:"
					+ authorizationService.buildAuthorizationLink(appId,
							(redirectHost + "/oauth.htm"), Scope.snsapi_base);
			autorizationUrl = autorizationUrl.replace("STATE",
					Authorization.lovecar.name());
			logger.debug("未知的用户，使用授权获取openId来查询对应userId######");
			logger.debug("授权url : {} ######", autorizationUrl);
			mv = new ModelAndView(autorizationUrl);
		} else {
			mv = new ModelAndView("/carVouchers/index.ftl");
			mv.addObject(RequestConstants.USER_ID, uId).addObject(
					RequestConstants.OPEN_ID, openId);

			// 获得活动ID
			long promotionID = getPromotionID();
			// 判断是否存在洗车券 0->不存在洗车券 1->存在洗车券 2->已抢过洗车券
			long vouchersCounts = iPromotionCarWashService
					.queryTicketCount(promotionID);
			if (vouchersCounts == -1) {// 参数校验失败
				mv.addObject("ifExistVouchers", 1);
			} else if (vouchersCounts == -2 || vouchersCounts == 0) {// 没有奖品
				mv.addObject("ifExistVouchers", 0);
			} else if (vouchersCounts > 0) {// 有奖品
				mv.addObject("ifExistVouchers", 1);
			}
		}

		// 微信分享JSSDK分享
		Map<String, String> map = jsSDKSign.sign(appId, request.getRequestURL().toString() + "?" + request.getQueryString());
		mv.addObject("jssdk", map);
		return mv;
	}

	/**
	 * 由于网络原因未领取到洗车券，重新刷新页面
	 * 
	 * @return
	 */
	@RequestMapping("/refreshIndex")
	public ModelAndView refreshIndex(
			@RequestParam(value = "userId", required = false) long userId) {
		logger.info("由于网络原因无法获取到洗车券，刷新页面重新获取洗车券！");
		ModelAndView mv = new ModelAndView("/carVouchers/index.ftl");

		// 获得活动ID
		long promotionID = getPromotionID();

		// 获取电话号码
		UserInfo user = memberService.findMembCentInfo(userId);
		String mobile = user.getMobile();

		iPromotionCarWashService.delLotteryTag(promotionID, userId, mobile);
		mv.addObject("ifExistVouchers", 1);
		return mv;
	}

	/**
	 * 获得活动ID
	 * 
	 * @return 活动ID
	 */
	public long getPromotionID() {
		// 根据活动代码获得活动ID
		List<String> mg3Code = new ArrayList<String>();
		mg3Code.add("C_OUTSOURCE_03");
		logger.info("promotionCode= {}", "C_OUTSOURCE_03");
		Map<String, Promotion> xiuqiuByCodes = promotionService
				.getXiuqiuByCodes(mg3Code);
		Promotion promotion = xiuqiuByCodes.get("C_OUTSOURCE_03");
		long promotionID = promotion.getPromotionId();
		return promotionID;
	}

	@RequestMapping("/use")
	public GsonView use(
			@RequestParam(value = "userId", required = false) Long userId,
			HttpServletRequest request) {
		GsonView gv = new GsonView();
		// 【获得洗车券码的接口】 【是否获得洗车券的接口】
		BaBaLotteryResultVo babaLotteryResultVo = getResultVo(request, userId);
		int resultCode = babaLotteryResultVo.getResultCode();
		String content = babaLotteryResultVo.getContent();

		gv.addStaticAttribute("result", resultCode);
		gv.addStaticAttribute("content", content);
		gv.addStaticAttribute("userId", userId);
		// 记录用户日志
		Cookie[] cookies = request.getCookies();
		String userTraceCookie = "";
		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if ("user_trace_cookie".equals(name)) {
				userTraceCookie = cookie.getValue();
				break;
			}
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		usertraceLogger.info("\t" + userTraceCookie + "\t" + userId + "\t"
				+ "yzsgc_wx_promotion_yxzc_xiche" + "\t"
				+ format.format(new Date()) + "\t " + this.getIp(request)
				+ " \t" + request.getHeader("user-agent") + "爱车清洁免费洗车券活动"
				+ "\t" + 3 + "\t" + 13);
		return gv;
	}

	public BaBaLotteryResultVo getResultVo(HttpServletRequest request,
			long userId) {
		String uId = request.getParameter(RequestConstants.USER_ID);
		UserInfo user = memberService.findMembCentInfo(Integer.valueOf(uId));
		String mobile = user.getMobile();
		long promotionID = getPromotionID();
		// 【获得洗车券码的接口】 【是否获得洗车券的接口】
		BaBaLotteryResultVo babaLotteryResultVo = iPromotionCarWashService
				.getTicketSerialCode(promotionID, userId, mobile);
		return babaLotteryResultVo;
	}

	public String getIp(HttpServletRequest request) {
		logger.info("获取客户端ip地址");
		String ip = null;
		try {
			ip = request.getHeader("x-forwarded-for");
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0
					|| "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
			if (ip.indexOf(",") > 0) {
				ip = ip.split(",")[0];
			}
			logger.info("客户端ip地址为：" + ip);
			return ip;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("发生异常ip地址获取失败");
			return null;
		}

	}
}
