package com.saic.ebiz.web.entity;


public class BaBaJie3FModel {

	//品牌名称
	private String brandName;
	//车型名称
	private String modelName;
	//图片名称
	private String imgName;
	//指导价
	private String guidePrice;
	
	//预约人数
	private long count;
	//价格
	private String price;
	private String code;
	private String modelUrl;
	
	private boolean isConcern;
	public BaBaJie3FModel() {
		super();
	}
	
	
	public BaBaJie3FModel(String brandName, String modelName, String imgName,
			String guidePrice, String price, String code) {
		super();
		this.brandName = brandName;
		this.modelName = modelName;
		this.imgName = imgName;
		this.guidePrice = guidePrice;
		this.price = price;
		this.code = code;
		
	}

	
	
	
	
	public String getModelUrl() {
		return modelUrl;
	}


	public void setModelUrl(String modelUrl) {
		this.modelUrl = modelUrl;
	}


	public boolean getIsConcern() {
		return isConcern;
	}


	public void setIsConcern(boolean isConcern) {
		this.isConcern = isConcern;
	}


	public long getCount() {
		return count;
	}


	public void setCount(long count) {
		this.count = count;
	}


	public String getImgName() {
		return imgName;
	}


	public void setImgName(String imgName) {
		this.imgName = imgName;
	}


	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	public String getGuidePrice() {
		return guidePrice;
	}
	public void setGuidePrice(String guidePrice) {
		this.guidePrice = guidePrice;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	
}
