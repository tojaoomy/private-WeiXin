package com.saic.ebiz.web.entity;

public class BaBaOneInfo {

	private String brandName;
	
	private String modelName;
	
	private String guidePrice;
	
	private String halfPice;
	
	private String modelPicUrl;

	
	
	
	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	
	public BaBaOneInfo(String brandName, String modelName, String guidePrice,
			String halfPice, String modelPicUrl) {
		super();
		this.brandName = brandName;
		this.modelName = modelName;
		this.guidePrice = guidePrice;
		this.halfPice = halfPice;
		this.modelPicUrl = modelPicUrl;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getGuidePrice() {
		return guidePrice;
	}

	public void setGuidePrice(String guidePrice) {
		this.guidePrice = guidePrice;
	}

	public String getHalfPice() {
		return halfPice;
	}

	public void setHalfPice(String halfPice) {
		this.halfPice = halfPice;
	}

	public String getModelPicUrl() {
		return modelPicUrl;
	}

	public void setModelPicUrl(String modelPicUrl) {
		this.modelPicUrl = modelPicUrl;
	}
	
	
}
