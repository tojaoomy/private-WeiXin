/*
 * Copyright (C), 2013-2014, 上海汽车集团股份有限公司
 */
package com.saic.ebiz.web.entity;

/**
 * @author hejian
 *
 */
public class WXShareVO {
	/** 分享图片的url */
	private String shareImgUrl;
	
	/** 分享页面的url */
	private String shareLinkUrl;
	
	/** 分享页面的标题 */
	private String shareTitle;
	
	/** 分享页面内容 */
	private String shareContentDesc;
	
	/**
	 * 
	 */
	public WXShareVO() {
	}

	public WXShareVO(WXShareVO shareVO){
		this.shareImgUrl = shareVO.getShareImgUrl();
		this.shareLinkUrl = shareVO.getShareLinkUrl();
		this.shareTitle = shareVO.getShareTitle();
		this.shareContentDesc = shareVO.getShareContentDesc();
	}
	
	/**
	 * @return the shareImgUrl
	 */
	public String getShareImgUrl() {
		return shareImgUrl;
	}

	/**
	 * @return the shareLinkUrl
	 */
	public String getShareLinkUrl() {
		return shareLinkUrl;
	}

	/**
	 * @return the shareTitle
	 */
	public String getShareTitle() {
		return shareTitle;
	}

	/**
	 * @return the shareContentDesc
	 */
	public String getShareContentDesc() {
		return shareContentDesc;
	}

	/**
	 * @param shareImgUrl the shareImgUrl to set
	 */
	public void setShareImgUrl(String shareImgUrl) {
		this.shareImgUrl = shareImgUrl;
	}

	/**
	 * @param shareLinkUrl the shareLinkUrl to set
	 */
	public void setShareLinkUrl(String shareLinkUrl) {
		this.shareLinkUrl = shareLinkUrl;
	}

	/**
	 * @param shareTitle the shareTitle to set
	 */
	public void setShareTitle(String shareTitle) {
		this.shareTitle = shareTitle;
	}

	/**
	 * @param shareContentDesc the shareContentDesc to set
	 */
	public void setShareContentDesc(String shareContentDesc) {
		this.shareContentDesc = shareContentDesc;
	}
}
