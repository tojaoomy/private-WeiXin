package com.saic.ebiz.web.entity;

import java.io.Serializable;
import java.util.Map;

import com.saic.ebiz.market.common.entity.authentication.SNSUserInfo;

/**
 * 
 * 〈一句话功能简述〉<br>
 * 〈微信web授权基本信息实体〉
 * 
 * @author zcm
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class WxWebBaseInfo implements Serializable {
	private static final long serialVersionUID = -3444738675995484126L;
	
	private long userId = 0; // 默认0 ：无
	private SNSUserInfo snsUserInfo = null; // 授权后微信用户信息
	private Map<String, String> jssdk; // jssdk 签名信息
	
	public WxWebBaseInfo() {
		super();
	}
	/**  
	 * @return snsUserInfo  
	 */
	public SNSUserInfo getSnsUserInfo() {
		return snsUserInfo;
	}
	/**  
	 * @param snsUserInfo 要设置的 snsUserInfo  
	 */
	public void setSnsUserInfo(SNSUserInfo snsUserInfo) {
		this.snsUserInfo = snsUserInfo;
	}
	/**  
	 * @return userId  
	 */
	public long getUserId() {
		return userId;
	}
	/**  
	 * @param userId 要设置的 userId  
	 */
	public void setUserId(long userId) {
		this.userId = userId;
	}
	/**  
	 * @return jssdk  
	 */
	public Map<String, String> getJssdk() {
		return jssdk;
	}
	/**  
	 * @param jssdk 要设置的 jssdk  
	 */
	public void setJssdk(Map<String, String> jssdk) {
		this.jssdk = jssdk;
	}
	
	
	
}
