//Date:2014-11-8 
//Author:kangmingfei
//Email:kangmingfei@163.com
;(function($){
  //擦车牌手指效果
  ECarHongbao.ShowFingerAnimation=function(){    
    window.onload=function() {
      $(".car-card-bg img").addClass("on");
    };
  };
  //擦话费 n=0,1,05,5
  ECarHongbao.CreateBill=function(n){
    var imgNumber=0;
    var flagSuccess=false;
    switch(n){
      case 0:
        imgNumber = "0";  
        break;
      case 1:
        imgNumber = "05";
        flagSuccess=true;
        break;
      case 2:
        imgNumber = "1";
        flagSuccess=true; 
        break;
      case 3:
        imgNumber = "5";
        flagSuccess=true;
        break;
    }
    if(flagSuccess){
      $(".mask-bill .red-button").hide();      
      $(".mask-bill .accept").show();
      $(".bill-msg .line2").html("成功擦出话费");  
    }else{
      $(".mask-bill .red-button").hide();      
      $(".mask-bill .confirm").show();
      $(".bill-msg .line2").html("你的手机更亮了"); 
    }
    $(".number").html("<img src=\"images/bill_"+imgNumber+".png\" />");
  };
  //弹出分享层
  ECarHongbao.ShowShare=function(){
    $(".mask").show();
    $(".mask").click(function(){
      $(".mask").hide();
      $(".mask").unbind("click");
    });
  };
  //弹出中奖结果弹出层
  ECarHongbao.ShowBillMask=function(){
    $(".mask-bill").show();
    $(".mask-bill").click(function(){
      $(".mask-bill").hide();
      $(".mask-bill").unbind("click");
    });
  };
  //弹出错误
  ECarHongbao.ShowErrorMask=function(){
    $(".mask-error").show();
    $(".mask-error").click(function(){
      $(".mask-error").hide();
      $(".mask-error").unbind("click");
    });
  };
  //加载更多
  ECarHongbao.LoadMoreBill=function(){
    var k = true;
    var w = $(window);
    var curp = 2;
    $("body").scrollTop(1);
    if(totalpage<=1){
      $('#drag').hide();
        k = false;
    }
    //滚动到页面底部时，自动加载更多
    window.addEventListener("scroll",function scrollHandler(){
      var scrollh = $(document).height();
      var bua = navigator.userAgent.toLowerCase();
      if(bua.indexOf('iphone') != -1 || bua.indexOf('ios') != -1){
        scrollh = scrollh-140;
      }else{
        scrollh = scrollh-80;
      }
      var c=document.documentElement.clientHeight || document.body.clientHeight, t=$(document).scrollTop();
      if(k != false && ($(document).scrollTop() + w.height()) >= scrollh){
        load();
      }
    },100);
    function load(){
      var draginner=$('.draginner')[0];
      //k = false;
      $('.draginner').css('padding-left','10px');
      draginner.style.background="url(images/load.gif) 0 50% no-repeat";
      // draginner.innerHTML="正在加载请稍候";
      //1.$.ajax带json数据的异步请求  
      $.ajax({
         type: "GET",
         url: "result.html",
         data: {pageNo:1},
         dataType: "html",
         success: function(data){
            $(".bill-friend-list ul").append("<li><img src=\"images/aaa.png\" /><span><em>钢铁侠</em> 用激光帮你打开了一个幸运号码， 你获得了3！</span></li>");
            k = true;
            draginner.style.background="";
            // draginner.innerHTML="上拉自动加载更多";
            curp=curp+1;
            k = true;
            if(curp>parseInt(totalpage)){
              $('#drag').hide();
              k = false;
            }
         },
         error: function(){
            console.log("读取数据失败");
            k = true;
        }
      });
    }  
  }
})(jQuery,typeof ECarHongbao == "undefined" ? ECarHongbao={} : ECarHongbao,typeof totalpage == "undefined"? totalpage=0:totalpage);
//help页面
function homePageInit(){
  ECarHongbao.ShowFingerAnimation();
}
//结果页面
function resultPageInit(){
  ECarHongbao.CreateBill(randNum);  
  $(".share").click(function(){
    ECarHongbao.ShowShare();
  });
  ECarHongbao.LoadMoreBill();
}
//help页面
function helpPageInit(){
  ECarHongbao.ShowFingerAnimation();
  $(".show-bill").click(function(){
    ECarHongbao.ShowBillMask();
    $.ajax({
       type: "GET",
       url: "help.html",
       data: {pageNo:1},
       dataType: "html",
       success: function(data){        
          var randNum=parseInt(Math.random()*10000)%4;
          var randResult=1;
          //data.num 0:0 1:0.5  2:1  3:5
          //data.result 0:已擦过车牌  1:success
          data={num:randNum,result:randResult};
          if(data.result==1){
            ECarHongbao.CreateBill(data.num);
          }
       },
       error: function(){
          console.log("读取数据失败");
      }
    });
  });
}
String.prototype.padLeft = function (padChar, width) { 
  var ret = this; 
  while (ret.length < width) { 
    if (ret.length + padChar.length < width) { 
    ret = padChar + ret; 
    } 
    else { 
    ret = padChar.substring(0, width-ret.length) + ret; 
    } 
  } 
  return ret; 
};
//排名页面
function billPageInit(){
  $(".money").html(billAmount);
  $("#xiang-number").html(xiangNumber);
  rankingNumber=rankingNumber.toString().padLeft("0",6);
  $(".ranking-li .num").each(function(index){
    $(this).html(rankingNumber[index]);
  });
  ECarHongbao.LoadMoreBill();
  $(".sec-cash").click(function(){
    if(billAmount<10){
      ECarHongbao.ShowErrorMask();
    }else{
      // location.href="";
    }
  });
}