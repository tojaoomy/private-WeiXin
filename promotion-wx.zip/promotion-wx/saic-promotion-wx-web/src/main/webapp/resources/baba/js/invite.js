/*
 * Created: 2016-7-15
 * Update: 2016-7-15
 * Author: Amanda
 * Lever:    page
 * Description: 邀请好友页面相关的js操作
 */

var invitePage = (function($){
       var inviteModule ={
            init: function(){
                // 立刻兑换
                this.exchange();
            },
            popWin: function(elemId, con){
                var maskPop = $('#js-pop-mask'),
                        elemObj = $('#'+elemId);
                if(!maskPop.length){
                    $(document.body).append('<div id="js-pop-mask" class="pop-mask"></div>');
                }else{
                    maskPop.show();
                }
                $('html').addClass('pop-html');
                if(!elemObj.length){
                    $(document.body).append(con);
                }else{
                    elemObj.show();
                }
                $(window).scrollTop(0);
            },
            popClose: function(elemId, callBack){
                  var maskPop = $('#js-pop-mask'),
                        elemObj = $('#'+elemId);
                    maskPop.hide();
                    elemObj.hide();
                    $('html').removeClass('pop-html');
                    callBack && callBack();
            },
            exchange: function(){
                 var btnExchange = $('.js-btn-exchange'),
                        elemId = 'js-pop-confirm-exchange',
                        con = '<div  id='+ elemId+' class="pop-win pop-confirm-exchange">\
                                            <div class="pop-exchange-con">5000元拿到了没？<br>确认兑换就不能<br>反悔了哦~</div>\
                                            <div class="pop-exchange-btn"><button id="js-btn-cancel" class="btn-cancel">取消</button><button id="js-btn-ok" class="btn-ok">确定</button></div>\
                                    </div>',
                        _this = this;
                        btnExchange.on('tap', function(){
                            $(this).addClass('btn-exchange-disabled');
                            _this.popWin(elemId, con);
                        });

                        $(document).on('tap', '#js-btn-cancel',function(){
                            _this.popClose(elemId, function(){
                                btnExchange.removeClass('btn-exchange-disabled');
                            });
                        });
                        $(document).on('tap', '#js-btn-ok', function(){
                        	$('#js-btn-ok').attr("disabled",true);
                            var launchbz = $('#launch_bz').val();
                            var ist_bz = $('#ist_bz').val();
                            if(ist_bz=="") ist_bz = null;
                               $.ajax({
                                    url: '/spreadPraise/exchange.htm',
                                    type: 'POST',
                                    dataType: 'json',
                                    data: {launchId: launchbz,isTest:ist_bz},
                                    success: function(data) {
                                    	window.location.href=data.r_url;
                                                //objInvite.hide();
                                                //objUse.show();
                                                _this.popClose(elemId, function(){
                                                    btnExchange.removeClass('btn-exchange-disabled');
                                                });
                                    },
                                    error: function() {
                                         _this.popClose(elemId, function(){
                                            btnExchange.removeClass('btn-exchange-disabled');
                                        });
                                    }
                                });
                         });
                }
        };

    $(function(){
        inviteModule.init();
    });

})(Zepto);