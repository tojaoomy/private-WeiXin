/*
    //判断用户终端
    //使用        UserAgent.isMobile();
    //isMobile: 返回值  true， 表示是手机端, false表示非手机端
    //isWeiXin: 返回值  true， 表示是微信打开页面, false表示非微信打
*/
var UserAgent ={
    _ua: window.navigator.userAgent.toLowerCase(),
    _getUserAgent: function(){
        return (window.navigator.userAgent||window.navigator.vendor||window.opera)
    },
    isMobile: function(){
        var userAgent = this._getUserAgent();
        var isMobile = /Android|webOS|iPhone|iPod|BlackBerry|Linux|Mac|iPad/i.test(userAgent);
        return isMobile;
    },
    isWeiXin: function(){
        if(this._ua.match(/MicroMessenger/i) == 'micromessenger'){
            return true;
        }else{
            return false;
        }
    },
    isAndroid: function(){
       var userAgent = this._getUserAgent();
       var isAndroid = userAgent.indexOf('Android') > -1;
       if(isAndroid){
            return true;
        }else{
            return false;
        }
    },
    isIOS: function(){
        var userAgent = this._getUserAgent();
        var isIOS = !!userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
        if(isIOS){
            return true;
        }else{
            return false;
        }
    }
}