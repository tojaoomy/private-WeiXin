/*
 * Created: 2016-7-12
 * Update: 2016-7-12
 * Author: Amanda
 * Description: 微信分享
 */

var initWxConfig = function (shareTitle, descContent, imgUrl, callBack,lineLink) {
    var wxConfig = function (data, shareTitle, descContent, imgUrl) {
        wx.config({
            debug: false, // 调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: data.appId, // 必填，公众号的唯一标识
            timestamp: data.timestamp, // 必填，生成签名的时间戳
            nonceStr: data.nonceStr, // 必填，生成签名的随机串
            signature: data.signature, // 必填，签名
            jsApiList: ['showMenuItems','showOptionMenu','showAllNonBaseMenuItem','onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone']
        });
        wx.ready(function () {
        	if(lineLink==undefined){
        		lineLink = location.href.split('#')[0];
        	}
        	wx.showMenuItems({
        		menuList : ['menuItem:openWithSafari', 'menuItem:openWithQQBrowser','menuItem:share:appMessage', 'menuItem:share:timeline','menuItem:share:qq','menuItem:share:weiboApp','menuItem:share:QZone']
        	});
            // 分享到朋友圈
            wx.onMenuShareTimeline({
                title: shareTitle, // 分享标题
                link: lineLink, // 分享链接
                imgUrl: imgUrl, // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(1);
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(0);
                }
            });
            // 分享给朋友
            wx.onMenuShareAppMessage({
                title: shareTitle, // 分享标题
                desc: descContent, // 分享描述
                link: lineLink, // 分享链接
                imgUrl: imgUrl, // 分享图标
                type: 'link', // 分享类型,music、video或link，不填默认为link
                dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                success: function () {

                    if(launch == 3138803 ){
                        alert( shareTitle +'success');
                    }
                    // 用户确认分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(1);
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(0);
                }
            });
            // 分享到QQ
            wx.onMenuShareQQ({
                title: shareTitle, // 分享标题
                desc: descContent, // 分享描述
                link: lineLink, // 分享链接
                imgUrl: imgUrl, // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(1);
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(0);
                }
            });
            // 分享到腾讯微博
            wx.onMenuShareWeibo({
                title: shareTitle, // 分享标题
                desc: descContent, // 分享描述
                link: lineLink, // 分享链接
                imgUrl: imgUrl, // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(1);
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(0);
                }
            });
            // 分享
            wx.onMenuShareQZone({
                title: shareTitle, // 分享标题
                desc: descContent, // 分享描述
                link: lineLink, // 分享链接
                imgUrl: imgUrl, // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(1);
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                    callBack && callBack();
                    // 埋点统计
                    chexiangCa(0);
                }
            });
            wx.error(function(res){
                // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
                // alert("errorMSG:"+res);
                callBack && callBack();
                // 埋点统计
                chexiangCa(0);
            });
        });
    };


    // 判断是否微信打开
    var isFromWeixin = /MicroMessenger/i.test(navigator.userAgent.toLowerCase());
    var flag = false;
    //isFromWeixin=true;
    //if(launch == 3138803 ){
    //    alert(isFromWeixin);
    //}
    if(isFromWeixin){
        wxConfig(data, shareTitle, descContent, imgUrl);
        //if(launch == 3138803 ){
        //    alert( shareTitle +'start');
        //}
        //  $.ajax({
        //        type: "POST",
        //        url: location.protocol + "//" + location.host + "/spreadPraise/wxconfig.htm?absolute_url=" + encodeURIComponent(location.href.split('#')[0].substr((location.protocol + '//' + location.host).length+1)),
        //        dataType: "json",
        //        async: false,
        //        success: function (data) {
        //            if(launch == 3138803 ){
        //                alert( shareTitle +'result');
        //            }
        //            flag = true;
        //            flag && wxConfig(data, shareTitle, descContent, imgUrl);
        //        },
        //        error: function () {
        //        }
        //});
        //
        //if(launch == 3138803 ){
        //    alert( shareTitle +'end');
        //}
    }else{
        //if(launch == 3138803 ){
        //    alert('不是微信');
        //}
    }

    // 分享埋点统计 ca = "20160808_h5_weixin_share$status"
    function chexiangCa(status){
        var img = new Image(),
            // id = 'successNum',
            ca = '20160808_h5_weixin_share$' + status;
        img.src = ('https:' == document.location.protocol ? 'https' : 'http')
                + '://data.chexiang.com/ca.gif?'
                // + 'id=' + id
                + '&ca=' + ca
                + '&_v=' + new Date();

    }
};