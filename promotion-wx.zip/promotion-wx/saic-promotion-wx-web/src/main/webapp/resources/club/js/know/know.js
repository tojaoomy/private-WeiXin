/**
 * Copyright (C), 2016, 上海赛可电子商务有限公司
 * Author:   Amanda
 * Date:     2016-4-20
 * lever:    page
 * Description: 车知道
 */
(function($){
	var TemplateEngine = function(html, options) {
			var re = /<%([^%>]+)?%>/g, reExp = /(^( )?(if|for|else|switch|case|break|{|}))(.*)?/g, code = 'var r=[];\n', cursor = 0;
			var add = function(line, js) {
				js? (code += line.match(reExp) ? line + '\n' : 'r.push(' + line + ');\n') :
				(code += line != '' ? 'r.push("' + line.replace(/"/g, '\\"') + '");\n' : '');
				return add;
			};
			while(match = re.exec(html)) {
				add(html.slice(cursor, match.index))(match[1], true);
				cursor = match.index + match[0].length;
			}
			add(html.substr(cursor, html.length - cursor));
			code += 'return r.join("");';
			return new Function(code.replace(/[\r\t\n]/g, '')).apply(options);
		};

	var fn = {
		config:{
			likedUrl: 'demoApi/save.json',
			loadDataUrl: '',
			signUrl: 'demoApi/hadCheckIn.htm',
			checkLikeUrl: 'demoApi/hadCheckIn.htm'
		},
		init:function(){
			this.opLike();
			this.loadData();
		},
		loadData:function(){
			var answerObj = $('.answer'),
				_this = this,
				loadPageData = function(pageNum){
				// $.ajax({
				// 	url:fn.config.loadDataUrl+'?page='+pageNum,
				// 	cache: false,
				// 	success:function(data){
				// 		var str='';
				// 		if(data.status){
				// 			str ='<article class="answer-item">'
				// 				+'<p class="answer-info">'
				// 					+'<span class="name">'
				// 						+'<img src="images/default.png" class="avatar">'
				// 						+'<strong class="author">sh**3339</strong>'
				// 					+'</span>'
				// 					+'<time class="time">2015-09-26</time>'
				// 				+'</p>'
				// 				+'<div class="answer-con">挺好的</div>'
				// 				+'<p class="answer-agree">'
				// 					+'<span class="agree-op"><em>120</em><i class="icon-like"></i></span>'
				// 				+'</p>'
				// 			+'</article>';

				// 			answerObj.append(str).data('page', pageNum);
				// 		}
						
				// 	}
				// });

				var template = '<%for(var index in this.data) {%>'
							+'<article class="answer-item">'
								+'<p class="answer-info">'
									+'<span class="name">'
										+'<img src="<%this.data[index].imgUrl%>" class="avatar">'
										+'<strong class="author"><%this.data[index].author%></strong>'
									+'</span>'
									+'<time class="time"><%this.data[index].time%></time>'
								+'</p>'
								+'<div class="answer-con"><%this.data[index].con%></div>'
								+'<p class="answer-agree">'
									+'<span class="agree-op <%if(this.data[index].liked){%>agree-liked<%}%>"><em><%this.data[index].num%></em><i class="icon-like"></i></span>'
								+'</p>'
							+'</article>'
						+'<%}%>';
				var str = TemplateEngine(template, {
					data:[{
							imgUrl:'images/default.png',
							author: 'sh**3339',
							time:'2015-09-26',
							con:'<p>我的途观2.0T 自动四驱旗舰版，对于这辆车的整体驾驶感受就是易操控，且富有灵性。</p><p>在起步阶段，发动机动力输出过于柔和，加速过程显得稍有些犹豫，不够畅快，感觉过于保守，少了一点冲劲！随着转速的上升，涡轮在1500rpm便开始介入，此时动力的变化比较明显，加速来的更为顺畅、自由，深踩油门，被人踹一脚的感觉随之而来，这时会让你忘记在起步阶段带给的你那小小的不满，此时这种充裕的动力输出一直可以持续到5000rpm左右，给人一种后劲十足的深刻印象。</p>			<p>我觉得途观在驾乘的舒适性和操控性之间找到了一个很好的平衡点。它采用前麦弗逊式独立悬挂 后多连杆式独立悬挂的形式，成熟的技术令舒适性和操控性都得到了很好的兼顾。悬挂调校很好地照顾了公路行驶表现，对路面的颠簸有着很充分地过滤效果，完全没有生硬的感觉。同时，悬挂也表现出了足够的韧性，对高速过弯时车身出现的侧倾倾向起到了很有效地抑制效果，在车辆通过沟沟坎坎时，也没有多余的晃动出现，优秀的底盘功底得到了充分地展现。不过这样的悬挂调较让他失去了一些路感。</p>',
							num:'120',
							liked:true
						},{
							imgUrl:'images/default.png',
							author: 'sh**3339',
							time:'2015-09-26',
							con:'<p>我的途观2.0T 自动四驱旗舰版，对于这辆车的整体驾驶感受就是易操控，且富有灵性。</p><p>在起步阶段，发动机动力输出过于柔和，加速过程显得稍有些犹豫，不够畅快，感觉过于保守，少了一点冲劲！随着转速的上升，涡轮在1500rpm便开始介入，此时动力的变化比较明显，加速来的更为顺畅、自由，深踩油门，被人踹一脚的感觉随之而来，这时会让你忘记在起步阶段带给的你那小小的不满，此时这种充裕的动力输出一直可以持续到5000rpm左右，给人一种后劲十足的深刻印象。</p>			<p>我觉得途观在驾乘的舒适性和操控性之间找到了一个很好的平衡点。它采用前麦弗逊式独立悬挂 后多连杆式独立悬挂的形式，成熟的技术令舒适性和操控性都得到了很好的兼顾。悬挂调校很好地照顾了公路行驶表现，对路面的颠簸有着很充分地过滤效果，完全没有生硬的感觉。同时，悬挂也表现出了足够的韧性，对高速过弯时车身出现的侧倾倾向起到了很有效地抑制效果，在车辆通过沟沟坎坎时，也没有多余的晃动出现，优秀的底盘功底得到了充分地展现。不过这样的悬挂调较让他失去了一些路感。</p>',
							num:'120',
							liked:false
					}]
				});
				
				answerObj.append(str).data('page-cur', pageNum);
			};
			$(window).scroll(function(){
				var wh = $(window).height(),
					diff = $(document.body).height() - wh - 30,
					pageNum = answerObj.data('page-cur')*1 + 1,
					pageTotal = answerObj.data('page-total');

					if($(window).scrollTop()> diff && pageTotal >= pageNum){
						_this.throttle(loadPageData(pageNum), 300, 500);
					}
			});
		},
		opLike:function(){
			$('.agree-op').on('click', function(){
				var _this = $(this),
					param = {};
				if(this.checkClick || _this.hasClass('agree-liked')){
					return;
				}

				$.ajax({
					url: fn.config.likedUrl,
					method: 'POST',
					dataType:'json',
					data: param,
					cache: false,
					success:function(data){
						var objEm = _this.find('em');
						if(data.status){
							_this.addClass('agree-liked');
							objEm.html(data.num);
						}
					}
				});
			});
		},
		checkClick:function(){
			$.ajax({
				url: fn.config.checkLikeUrl,
				dataType: "json",
				cache: false,
				success: function(data) {
					if(data.hadCheckIn){
						callback && callback();
					}
				}
			});
		},
		checkSign:function(callback){
			$.ajax({
				url: fn.config.signUrl,
				dataType: "json",
				cache: false,
				success: function(data) {
					if(data.hadCheckIn){
						callback && callback();
					}
				}
			});
		},
		throttle: function(fn, delay, mustRunDelay){
			var timer = null;
			var t_start;
			return function(){
				var context = this, args = arguments, t_curr = +new Date();
				clearTimeout(timer);
				if(!t_start){
					t_start = t_curr;
				}
				if(t_curr - t_start >= mustRunDelay){
					fn.apply(context, args);
					t_start = t_curr;
				}
				else {
					timer = setTimeout(function(){
						fn.apply(context, args);
					}, delay);
				}
			};
		}
	};

	$(function(){
		fn.init();
	});

}(Zepto));